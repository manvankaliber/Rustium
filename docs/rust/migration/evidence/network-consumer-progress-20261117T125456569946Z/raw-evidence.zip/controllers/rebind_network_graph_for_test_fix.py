import hashlib,json,pathlib,sys
r=pathlib.Path('D:/Rustium');rt=r/'.rustium-runtime';info=json.loads((rt/'shared-strings-connection-latest.json').read_text());run=pathlib.Path(info['run_directory']);catalogue=pathlib.Path(json.loads((rt/'network-graph-catalogue-latest.json').read_text())['directory']);sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
old_path=pathlib.Path(info['prior_intake_directory'])/'source-manifest.json';old=json.loads(old_path.read_text());new=json.loads(pathlib.Path(info['source_manifest']).read_text());expected={'net/socket/connect_job_rust_test_support.h','net/socket/connect_job_rust_test_support.cc'}
assert old.keys()==new.keys() and {p for p in old if old[p]!=new[p]}==expected
for rel in expected:
 before=(run/('before-'+pathlib.Path(rel).name)).read_bytes();after=before
 assert hashlib.sha256(before).hexdigest()==old[rel]
 if rel.endswith('.h'):
  needle=b'#include "base/functional/callback.h"';after=after.replace(needle,needle+b'\n#include "base/memory/raw_ptr.h"\n#include "base/memory/raw_ref.h"').replace(b'Trace& trace_;',b'raw_ref<Trace> trace_;').replace(b'const HttpResponseInfo* expected_response',b'raw_ptr<const HttpResponseInfo> expected_response')
 after=after.replace(b'trace_.',b'trace_->');assert after==(r/rel).read_bytes() and hashlib.sha256(after).hexdigest()==new[rel]
captured=json.loads((catalogue/'result.json').read_text());assert captured['passed'] and captured['source_manifest_sha256']==sha(old_path);assert all(sha(c['output'])==c['output_sha256'] for c in captured['commands'])
configuration=json.loads((catalogue/'configuration-before.json').read_text());graph={p:h for p,h in configuration.items() if pathlib.Path(p).suffix=='.ninja' or pathlib.Path(p).name in ['args.gn','environment.x64']};assert graph and all(sha(p)==h for p,h in graph.items())
record={'passed':True,'old_source_manifest_sha256':sha(old_path),'current_source_manifest_sha256':info['source_manifest_sha256'],'catalogue':str(catalogue),'catalogue_result_sha256':sha(catalogue/'result.json'),'graph_files_checked':len(graph),'unchanged_graph_files':graph,'source_delta':sorted(expected),'scope':'Reuse of byte-identical evaluated GN/Ninja graph/source/output discovery only after exact two-file compiler-style transformation. Old commands were not rerun under the new source hash. No old build/native/ABI pass is promoted; all affected C++ consumers must rebuild.'}
(run/'graph-discovery-rebind.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k!='unchanged_graph_files'}))
