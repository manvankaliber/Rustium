import datetime,hashlib,importlib.util,json,pathlib,subprocess,sys
r=pathlib.Path('D:/Rustium');b=pathlib.Path('D:/RustiumBuild/src');rt=r/'.rustium-runtime';sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest();info=json.loads((rt/'shared-strings-connection-latest.json').read_text())
if len(sys.argv)==1:
 assert not (rt/'job-active.json').exists()
 obs=subprocess.check_output(['powershell','-NoProfile','-Command',"Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(ninja|clang-cl|lld-link|net_unittests|base_unittests|rustc|cargo).*' } | Select-Object ProcessId,Name,CommandLine | ConvertTo-Json"],text=True).strip();assert not obs,obs
 out=r/'.scratch/net-wave5'/('network-graph-catalogue-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
 req={'task_id':'NET-CURRENT-CONSUMER-CLOSURE','kind':'test','source_identity':info,'toolchain':{'script_sha256':sha(__file__)},'build_configuration':{'scope':'Read-only batched evaluated GN dependency/source/output catalogues and selected Ninja command/query evidence; no compiler/native execution','configured':'D:/RustiumBuild/src/out/Default'},'cwd':str(r),'process_reconciliation':{'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'compilers_native_tests':[]}}
 p=rt/'network-graph-catalogue-request.json';p.write_text(json.dumps(req,indent=2)+'\n');(rt/'network-graph-catalogue-latest.json').write_text(json.dumps({'directory':str(out)}));token=json.loads((rt/'director.json').read_text())['token'];sys.exit(subprocess.call(['python','tools/rustium_coord.py','job','--token',token,'--manifest',str(p),'--','python','-B',__file__,str(out)],cwd=r))
out=pathlib.Path(sys.argv[1]);assert not out.exists();out.mkdir();sys.path.insert(0,str(r/'docs/rust/migration/drafts/base-ordinary-delivery'));import ordinary_base_v2 as delivery
spec=importlib.util.spec_from_file_location('configured_env',r/'.scratch/net-wave5/configure_http2_family.py');envmod=importlib.util.module_from_spec(spec);spec.loader.exec_module(envmod);env=envmod.build_environment();gn=str(b/'buildtools/win/gn.exe');ninja=str(b/'third_party/ninja/ninja.exe')
old=r/'.scratch/net-wave5/parent-consumer-target-intake-20261114T001450500298Z';proposals=[old/(name+'.json') for name in ['http2','connection-jobs','dns-resolution','cookie-storage']];planpath=r/'.scratch/net-wave5/resumed-integration/native-runtime-delivery-v2/network-focus-20261117-plan.json';plan=json.loads(planpath.read_text());targets=sorted(set([t for p in proposals for t in json.loads(p.read_text())['targets']]+[c['target'] for c in plan['cases']]+['base.dll','net.dll']))
commands=[('gn-'+prop,[gn,'desc','out/Default','*',prop,'--format=json']) for prop in ['deps','sources','outputs']]
commands += [('ninja-query',[ninja,'-C','out/Default','-t','query',*targets]),('ninja-commands',[ninja,'-C','out/Default','-t','commands',*targets]),('ninja-explain',[ninja,'-C','out/Default','-n','-d','explain','-j1',*targets])]
tools={p:sha(p) for p in [gn,ninja,str(pathlib.Path(envmod.__file__))]};configuration=None;native=None;result={'passed':False,'source_manifest_sha256':info['source_manifest_sha256'],'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'targets':targets,'selected_programs':len(plan['cases']),'historical_proposals_provisional':True,'commands':[],'inputs':{str(p):sha(p) for p in [*proposals,planpath]},'scope':'Current evaluated graph/command/dependency discovery, not qualified consumer closure or actual build/runtime acceptance'}
try:
 delivery.source_check(info);native,registry,inspector=delivery.runtime_modules();configuration=delivery.configuration_identity(native);delivery.write(out/'configuration-before.json',configuration)
 for phase,cmd in commands:
  start=datetime.datetime.now(datetime.timezone.utc).isoformat();log=out/(phase+'.log');code=delivery.run_command(cmd,b,env,log,timeout=900)
  row={'phase':phase,'command':cmd,'exit_code':code,'started_utc':start,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'output':str(log),'output_sha256':sha(log),'bytes':log.stat().st_size};result['commands'].append(row);delivery.write(out/'progress.json',result)
  if code:break
  if phase.startswith('gn-'):
   value=json.loads(log.read_text());delivery.require(isinstance(value,dict) and value,'Nonempty GN JSON mapping required');row['target_records']=len(value)
 result['passed']=len(result['commands'])==len(commands) and all(c['exit_code']==0 for c in result['commands'])
except BaseException as error:
 result['exception']=type(error).__name__+': '+str(error)
 if isinstance(error,delivery.CommandFailure):result['command_failure']=error.details
finally:
 checks={}
 for name,check in [('source',lambda:delivery.source_check(info)),('configuration',lambda:delivery.require(configuration is not None and delivery.configuration_identity(native)==configuration,'Graph/config drift')),('tools',lambda:delivery.require(all(sha(p)==h for p,h in tools.items()),'Tool/helper drift'))]:
  try:check();checks[name]=True
  except BaseException as error:checks[name]=str(error)
 result['postchecks']=checks;result['passed'] &= all(x is True for x in checks.values());result['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();delivery.write(out/'result.json',result);print(json.dumps({'passed':result['passed'],'directory':str(out),'commands':len(result['commands']),'postchecks':checks}))
sys.exit(0 if result['passed'] else 1)
