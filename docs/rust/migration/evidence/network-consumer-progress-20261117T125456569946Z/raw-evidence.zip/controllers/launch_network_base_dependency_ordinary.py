import datetime,hashlib,json,pathlib,subprocess,sys
r=pathlib.Path('D:/Rustium');rt=r/'.rustium-runtime';assert not (rt/'job-active.json').exists()
observation=subprocess.check_output(['powershell','-NoProfile','-Command',"Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(ninja|clang-cl|lld-link|net_unittests|base_unittests|rustc|cargo).*' } | Select-Object ProcessId,Name,CommandLine | ConvertTo-Json"],text=True).strip();assert not observation,observation
info=json.loads((rt/'shared-strings-connection-latest.json').read_text());attest=json.loads((rt/'base-attestation-latest.json').read_text());receipt=pathlib.Path(attest['receipt']);assert json.loads(receipt.read_text())['passed']
def latest_job(predicate):
 matches=[]
 for path in (rt/'jobs').glob('*/result.json'):
  row=json.loads(path.read_text())
  if row.get('status')=='passed' and row.get('source_identity',{}).get('source_manifest_sha256')==info['source_manifest_sha256'] and predicate(row):matches.append((row['finished_utc'],path))
 assert matches,'No completed source-matched required gate'
 return max(matches)[1]
build_job=latest_job(lambda row:row.get('command')==['python','-B',str(rt/'build_shared_strings_connection.py'),'-j1'])
invocation=json.loads(receipt.read_text())['invocation']
attest_job=latest_job(lambda row:str(r/'docs/rust/migration/drafts/base-ordinary-delivery/attest_build.py') in row.get('command',[]) and invocation in row.get('command',[]))
assert all(json.loads(p.read_text())['status']=='passed' for p in [build_job,attest_job])
out=r/'.scratch/base-ordinary-delivery'/('n'+datetime.datetime.now(datetime.timezone.utc).strftime('%m%d%H%M%S'));assert not out.exists()
d=r/'docs/rust/migration/drafts/base-ordinary-delivery';script=d/'ordinary_base_v2.py';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
request={'task_id':'FOUNDATION-STRINGS-BRIDGE','kind':'test','source_identity':info,'toolchain':{'controller_sha256':sha(script),'windows_job_sha256':sha(d/'windows_job.py'),'source_review':'docs/rust/migration/evidence/base-ordinary-delivery-review4-20261117.md'},'build_configuration':{'configured':'D:/RustiumBuild/src/out/Default','scope':'Network cohort dependency: complete original StringSplit selection and all5 bridge cases, copied frozen runtime/controller; no benchmark or performance acceptance','test_jobs':1,'native_retry_limit':0,'build_gate_result':str(build_job),'attestation_gate_result':str(attest_job)},'cwd':str(r),'process_reconciliation':{'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'compilers_native_tests':[]}}
p=rt/'network-base-dependency-ordinary-request.json';p.write_text(json.dumps(request,indent=2)+'\n');(rt/'network-base-dependency-ordinary-latest.json').write_text(json.dumps({'directory':str(out),'request':str(p),'attestation':str(receipt)}));token=json.loads((rt/'director.json').read_text())['token']
command=['python','-B',str(script),'--intake',str(rt/'shared-strings-connection-latest.json'),'--expected-source-sha256',info['source_manifest_sha256'],'--build-job-result',str(build_job),'--attestation',str(receipt),'--attestation-job-result',str(attest_job),'--output',str(out)]
sys.exit(subprocess.call(['python','tools/rustium_coord.py','job','--token',token,'--manifest',str(p),'--',*command],cwd=r))
