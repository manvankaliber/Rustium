import hashlib,json,pathlib,shutil
r=pathlib.Path('D:/Rustium');e=r/'docs/rust/migration/evidence';rt=r/'.rustium-runtime';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ordinary=json.loads((rt/'network-base-dependency-ordinary-latest.json').read_text());src=pathlib.Path(ordinary['directory']);result=json.loads((src/'result.json').read_text());assert result.get('finished_utc')
dst=e/('network-base-ordinary-'+src.name);dst.mkdir(exist_ok=True)
files=[p for p in src.rglob('*') if p.is_file() and not p.is_relative_to(src/'snapshot')]
files += [src/'snapshot/input-manifest.json',src/'snapshot/controller.py',src/'snapshot/windows_job.py']
files += list((src/'snapshot/context').glob('*.py'))
files += [p for p in (src/'snapshot/provenance').rglob('*') if p.is_file()]
if (src/'snapshot/build/out/Default/debug.log').exists():files.append(src/'snapshot/build/out/Default/debug.log')
for p in files:
 target=dst/p.relative_to(src);target.parent.mkdir(parents=True,exist_ok=True)
 if target.exists():assert target.read_bytes()==p.read_bytes(),str(target)
 else:shutil.copyfile(p,target)
meta={'snapshot_retained':str(src/'snapshot'),'snapshot_manifest_sha256':sha(src/'snapshot/input-manifest.json'),'result':result,'archive_scope':'Raw result/log/XML/summary, copied controller/helpers and complete input manifest. Runtime/configuration binaries remain in retained local snapshot; no complete portable runtime claim.'}
(dst/'archive.json').write_text(json.dumps(meta,indent=2)+'\n')
attest=json.loads((rt/'base-attestation-latest.json').read_text());source=pathlib.Path(attest['directory']);target=e/('network-build-attestation-'+source.name);target.mkdir(exist_ok=True)
for p in source.iterdir():
 if p.is_file():
  dest=target/p.name
  if dest.exists():assert dest.read_bytes()==p.read_bytes()
  else:shutil.copyfile(p,dest)
attr=e/'.gitattributes';text=attr.read_text()
for line in ['network-base-ordinary-*/** -text whitespace=cr-at-eol,-blank-at-eol,-blank-at-eof\n','network-build-attestation-*/** -text whitespace=cr-at-eol,-blank-at-eol,-blank-at-eof\n']:
 if line not in text:text+=line
attr.write_text(text);print(json.dumps({'ordinary_archive':str(dst),'ordinary_passed':result['passed'],'attestation_archive':str(target)}))
