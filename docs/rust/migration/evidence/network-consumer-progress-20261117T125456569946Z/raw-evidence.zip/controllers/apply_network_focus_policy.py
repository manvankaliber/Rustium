import datetime,hashlib,importlib.util,json,pathlib,subprocess
r=pathlib.Path('D:/Rustium');rt=r/'.rustium-runtime';token=json.loads((rt/'director.json').read_text())['token'];now=datetime.datetime.now(datetime.timezone.utc).isoformat()
spec=importlib.util.spec_from_file_location('coord',r/'tools/rustium_coord.py');coord=importlib.util.module_from_spec(spec);spec.loader.exec_module(coord);c=coord.Coordinator(r)
holds=[]
for task in ['BLINK-TEXT-BOUNDARIES','FOUNDATION-VERSION-BRIDGE']:
 q=coord.read(c.state);t=next(x for x in q['tasks'] if x['id']==task);w=pathlib.Path(t['assignment']['worktree']);assert not subprocess.check_output(['git','status','--porcelain'],cwd=w)
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip();holds.append({'task_id':task,'worktree':str(w),'branch':subprocess.check_output(['git','branch','--show-current'],cwd=w,text=True).strip(),'head':head,'clean':True,'validation':'Unrun latest source checkpoint, not accepted','reason':'Explicit user Network-only focus; preserve work without further implementation'})
 c.transition(token,task,'blocked','Held by explicit user Network-only focus; clean checkpoint '+head+' retained; no further dispatch')
 c.amend(token,task,{'blockers':['Held by explicit user Network-only focus'], 'stages':{**t['stages'],'implementation':'Held clean source checkpoint '+head+'; no acceptance claimed'},'next_action':'Retain branch/worktree/evidence; resume only when user changes active subsystem focus'})
with c.transaction(token) as q:
 q['roles']['coding_worker']={'model':'gpt-6.1-terra','effort':'xhigh'}
 q['limits']['coding_workers']=q['limits'].pop('luna_workers',q['limits'].get('coding_workers',8))
 q['mode']='active; Network only by user instruction'
 q['active_focus']={'subsystem':'network-services','name':'Network','allowed_dependency_tasks':['FOUNDATION-STRINGS-BRIDGE'],
  'scope':'Finish Network connected families, production ownership and acceptance before unrelated subsystem implementation',
  'dependency_reason':'Already applied Foundation Strings bridge changes are dependencies of the current Network consumer cohort; validate/repair them as Network work, not a separate foundation expansion',
  'user_directive_utc':now,'other_work':'Preserve clean checkpoints, integrated artifacts and historical evidence; no new non-Network dispatch'}
record={'observed_utc':now,'user_directive':'Terra workers; one active subsystem, Network; independent native-build speed investigation','worker_defaults':{'model':'gpt-6.1-terra','effort':'xhigh'},'historical_assignments_unchanged':True,'held_work':holds,'active_focus':coord.read(c.state)['active_focus']}
p=r/'docs/rust/migration/evidence/network-focus-policy-20261117.json';p.write_text(json.dumps(record,indent=2)+'\n')
owner=r/'docs/rust/migration/ownership.json';data=json.loads(owner.read_text());data['active_focus']=record['active_focus'];owner.write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps({'held':holds,'policy_applied':True,'check':c.check()}))
