import datetime,hashlib,json,pathlib,shutil,subprocess,sys
r=pathlib.Path('D:/Rustium');b=pathlib.Path('D:/RustiumBuild/src');rt=r/'.rustium-runtime';sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest();info=json.loads((rt/'shared-strings-connection-latest.json').read_text())
if sys.argv[1:]!=['apply']:
 assert not (rt/'job-active.json').exists()
 obs=subprocess.check_output(['powershell','-NoProfile','-Command',"Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(ninja|clang-cl|lld-link|net_unittests|base_unittests|rustc|cargo).*' } | Select-Object ProcessId,Name,CommandLine | ConvertTo-Json"],text=True).strip();assert not obs,obs
 req={'task_id':'NET-CURRENT-CONSUMER-CLOSURE','kind':'sync','source_identity':info,'toolchain':{'script_sha256':sha(__file__)},'build_configuration':{'scope':'Preserve borrowed Trace/response semantics with required raw_ref/raw_ptr wrappers in connection verification helper; no diagnostics or assertions disabled'},'cwd':str(r),'process_reconciliation':{'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'compilers_native_tests':[]}}
 p=rt/'connect-job-test-field-sync-request.json';p.write_text(json.dumps(req,indent=2)+'\n');token=json.loads((rt/'director.json').read_text())['token'];sys.exit(subprocess.call(['python','tools/rustium_coord.py','job','--token',token,'--manifest',str(p),'--','python','-B',__file__,'apply'],cwd=r))
prior=pathlib.Path(info['run_directory']);state=r/'.scratch/net-wave2/parent/last-synced.json';raw=state.read_bytes();assert hashlib.sha256(raw).hexdigest()==info['source_manifest_sha256'];pins=json.loads(raw)
for rel,h in pins.items():assert sha(r/rel)==h==sha(b/rel),rel
out=r/'.scratch/shared-strings-connection'/datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ');out.mkdir();(out/'prior-source-manifest.json').write_bytes(raw);app=json.loads((prior/'application.json').read_text());changes=[]
for rel in ['net/socket/connect_job_rust_test_support.h','net/socket/connect_job_rust_test_support.cc']:
 before=(r/rel).read_bytes();after=before
 if rel.endswith('.h'):
  needle=b'#include "base/functional/callback.h"';assert after.count(needle)==1;after=after.replace(needle,needle+b'\n#include "base/memory/raw_ptr.h"\n#include "base/memory/raw_ref.h"')
  assert after.count(b'Trace& trace_;')==4;after=after.replace(b'Trace& trace_;',b'raw_ref<Trace> trace_;');assert after.count(b'const HttpResponseInfo* expected_response')==1;after=after.replace(b'const HttpResponseInfo* expected_response',b'raw_ptr<const HttpResponseInfo> expected_response')
 assert b'trace_.' in after;after=after.replace(b'trace_.',b'trace_->');name=pathlib.Path(rel).name;before_path=out/('before-'+name);after_path=out/('after-'+name);before_path.write_bytes(before);after_path.write_bytes(after);digest=hashlib.sha256(after).hexdigest()
 row={'path':rel,'source':str(after_path),'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':digest,'kind':'Director compiler-policy repair of nonowning test helper fields'};app['bindings'].append(row);changes.append(row)
 for root in [r,b]:(root/rel).write_bytes(after)
 pins[rel]=digest
assert len(pins)==1261
for rel,h in pins.items():assert sha(r/rel)==h==sha(b/rel),rel
(out/'application.json').write_text(json.dumps(app,indent=2)+'\n');(out/'source-manifest.json').write_text(json.dumps(pins,indent=2)+'\n');shutil.copyfile(out/'source-manifest.json',state)
info.update(run_directory=str(out),source_manifest=str(out/'source-manifest.json'),source_manifest_sha256=sha(out/'source-manifest.json'),source_count=len(pins),applied_bindings=len(app['bindings']),prior_intake_directory=str(prior),status='Current conservative Network build failed5 raw_ref/raw_ptr diagnostics in connection verification helper; narrow field/access repair prepared, full rebuild/native pending')
info.setdefault('director_integration_overlays',[]).extend(changes);(out/'application-result.json').write_text(json.dumps(info,indent=2)+'\n');(rt/'shared-strings-connection-latest.json').write_text(json.dumps(info,indent=2)+'\n');print(json.dumps({'authority':info['source_manifest_sha256'],'source_count':len(pins),'bindings':len(app['bindings']),'run':str(out)}))
