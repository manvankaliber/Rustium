import hashlib, json, pathlib
r = pathlib.Path('D:/Rustium'); rt = r/'.rustium-runtime'
script = (rt/'build_network_selected_consumers.py').read_bytes()
four = b"['connect_job_rust_test_support.cc','connect_job_rust_perftest.cc','connection_auth_baseline_unittest.cc','connection_jobs_upper_rust_jobs_perftest.cc']"
two = b"['connect_job_rust_test_support.cc','connect_job_rust_perftest.cc']"
assert script.count(four) == 1
for job_id, data in [('e0672056bd1c49d283fd09e454255e32', script), ('0ca5c1aa93a2459aba572fa22c153f33', script.replace(four, two))]:
    job = json.loads((rt/'jobs'/job_id/'result.json').read_text())
    assert hashlib.sha256(data).hexdigest() == job['toolchain']['script_sha256'], job_id
    dest = pathlib.Path(job['source_identity']['run_directory'])/'network-selected-consumer-build/runner.py'
    if dest.exists(): assert dest.read_bytes() == data
    else: dest.write_bytes(data)
    print(job_id, hashlib.sha256(data).hexdigest())
