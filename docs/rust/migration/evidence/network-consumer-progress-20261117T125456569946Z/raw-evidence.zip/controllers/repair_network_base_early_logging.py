import datetime,hashlib,json,pathlib,shutil,subprocess,sys
r=pathlib.Path('D:/Rustium');b=pathlib.Path('D:/RustiumBuild/src');rt=r/'.rustium-runtime';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if sys.argv[1:]!=['apply']:
 assert not (rt/'job-active.json').exists()
 obs=subprocess.check_output(['powershell','-NoProfile','-Command',"Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(ninja|clang-cl|lld-link|net_unittests|base_unittests|rustc|cargo).*' } | Select-Object ProcessId,Name,CommandLine | ConvertTo-Json"],text=True).strip();assert not obs,obs
 info=json.loads((rt/'shared-strings-connection-latest.json').read_text());req={'task_id':'FOUNDATION-STRINGS-BRIDGE','kind':'sync','source_identity':info,'toolchain':{'script_sha256':sha(pathlib.Path(__file__))},'build_configuration':{'scope':'Network dependency harness: initialize Windows parent launcher stderr after TestSuite constructs CommandLine, before LaunchUnitTests; preserve native tests and sealed snapshots'},'cwd':str(r),'process_reconciliation':{'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'compilers_native_tests':[]}}
 p=rt/'network-base-early-logging-sync-request.json';p.write_text(json.dumps(req,indent=2)+'\n');token=json.loads((rt/'director.json').read_text())['token'];sys.exit(subprocess.call(['python','tools/rustium_coord.py','job','--token',token,'--manifest',str(p),'--','python','-B',__file__,'apply'],cwd=r))
info=json.loads((rt/'shared-strings-connection-latest.json').read_text());prior=pathlib.Path(info['run_directory']);state=r/'.scratch/net-wave2/parent/last-synced.json';raw=state.read_bytes();assert hashlib.sha256(raw).hexdigest()==info['source_manifest_sha256'];pins=json.loads(raw)
for rel,h in pins.items():assert sha(r/rel)==h==sha(b/rel),rel
rel='base/test/run_all_unittests.cc';assert rel not in pins;before=(r/rel).read_bytes();assert sha(r/rel)==sha(b/rel)=='242f989895fbc7b91228e761aa11d62c2ffea36f8da21bc2158ee15f9496e901'
out=r/'.scratch/shared-strings-connection'/datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ');out.mkdir(parents=True);(out/'prior-source-manifest.json').write_bytes(raw)
needle=b'#if BUILDFLAG(IS_WIN)\n#include "base/win/com_init_util.h"';assert before.count(needle)==1
after=before.replace(needle,b'#if BUILDFLAG(IS_WIN)\n#include "base/logging.h"\n#include "base/logging/logging_settings.h"\n#include "base/win/com_init_util.h"')
needle=b'  base::BaseUnittestSuite test_suite(argc, argv);\n';assert after.count(needle)==1
after=after.replace(needle,needle+b'#if BUILDFLAG(IS_WIN)\n  // Construction initializes CommandLine; the parent launcher logs before Run.\n  // Keep those diagnostics in captured stderr, outside sealed runtime copies.\n  if (!logging::InitLogging({.logging_dest = logging::LOG_TO_STDERR})) {\n    return 1;\n  }\n#endif\n')
(out/'base-entrypoint-before.cc').write_bytes(before);(out/'base-entrypoint-after.cc').write_bytes(after);digest=hashlib.sha256(after).hexdigest();app=json.loads((prior/'application.json').read_text())
app['bindings'].append({'path':rel,'source':str(out/'base-entrypoint-after.cc'),'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':digest,'kind':'Director Windows test launcher logging repair; Network dependency only'})
(out/'application.json').write_text(json.dumps(app,indent=2)+'\n')
for root in [r,b]:(root/rel).write_bytes(after)
pins[rel]=digest
for p,h in pins.items():assert sha(r/p)==h==sha(b/p),p
(out/'source-manifest.json').write_text(json.dumps(pins,indent=2)+'\n');shutil.copyfile(out/'source-manifest.json',state)
overlays=info.get('director_integration_overlays',[]);overlays.append({'path':rel,'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':digest,'reason':'Native62test run completed but parent debug.log changed sealed membership; early Windows stderr initialization mirrors reviewed Net launcher repair, no expected cases or compiler checks changed'})
info.update(run_directory=str(out),source_manifest=str(out/'source-manifest.json'),source_manifest_sha256=sha(out/'source-manifest.json'),source_count=len(pins),applied_bindings=len(app['bindings']),prior_intake_directory=str(prior),director_integration_overlays=overlays,status='Native62 cases and diagnostic executed successfully but snapshot failed added debug.log; early launcher logging repaired, current build and copied rerun pending')
(out/'application-result.json').write_text(json.dumps(info,indent=2)+'\n');(rt/'shared-strings-connection-latest.json').write_text(json.dumps(info,indent=2)+'\n');print(json.dumps({'source_count':len(pins),'bindings':len(app['bindings']),'authority':info['source_manifest_sha256'],'run':str(out)}))
