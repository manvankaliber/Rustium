import datetime, hashlib, json, pathlib, shutil, subprocess, sys
r=pathlib.Path('D:/Rustium'); b=pathlib.Path('D:/RustiumBuild/src'); rt=r/'.rustium-runtime'
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
info=json.loads((rt/'shared-strings-connection-latest.json').read_text())
if sys.argv[1:]!=['apply']:
    assert not (rt/'job-active.json').exists()
    obs=subprocess.check_output(['powershell','-NoProfile','-Command',"Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(ninja|clang-cl|lld-link|net_unittests|base_unittests|rustc|cargo).*' } | Select-Object ProcessId,Name,CommandLine | ConvertTo-Json"],text=True).strip(); assert not obs,obs
    req={'task_id':'NET-CURRENT-CONSUMER-CLOSURE','kind':'sync','source_identity':info,'toolchain':{'script_sha256':sha(__file__)},'build_configuration':{'scope':'Correct exact include filename changed by prior field-access transformation; no policy, tests or diagnostics changed'},'cwd':str(r),'process_reconciliation':{'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'compilers_native_tests':[]}}
    p=rt/'network-include-typo-sync-request.json';p.write_text(json.dumps(req,indent=2)+'\n')
    token=json.loads((rt/'director.json').read_text())['token']
    sys.exit(subprocess.call(['python','tools/rustium_coord.py','job','--token',token,'--manifest',str(p),'--','python','-B',__file__,'apply'],cwd=r))
prior=pathlib.Path(info['run_directory']); state=r/'.scratch/net-wave2/parent/last-synced.json'; raw=state.read_bytes();assert hashlib.sha256(raw).hexdigest()==info['source_manifest_sha256']; pins=json.loads(raw)
for rel,h in pins.items(): assert sha(r/rel)==h==sha(b/rel),rel
rel='net/socket/connection_jobs_upper_rust_job_workloads.h'; before=(r/rel).read_bytes()
old=b'#include "base/test/task_environment->h"'; new=b'#include "base/test/task_environment.h"'
assert before.count(old)==1;after=before.replace(old,new)
out=r/'.scratch/shared-strings-connection'/datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ');out.mkdir()
(out/'prior-source-manifest.json').write_bytes(raw);shutil.copyfile(__file__,out/'transformations.py')
(out/'before-connection_jobs_upper_rust_job_workloads.h').write_bytes(before);dest=out/'after-connection_jobs_upper_rust_job_workloads.h';dest.write_bytes(after)
app=json.loads((prior/'application.json').read_text());row=next(x for x in app['bindings'] if x['path']==rel);assert row['after_sha256']==pins[rel]
digest=hashlib.sha256(after).hexdigest();row.update(source=str(dest),after_sha256=digest)
for root in [r,b]:(root/rel).write_bytes(after)
pins[rel]=digest
for path,h in pins.items():assert sha(r/path)==h==sha(b/path),path
(out/'application.json').write_text(json.dumps(app,indent=2)+'\n');(out/'source-manifest.json').write_text(json.dumps(pins,indent=2)+'\n');shutil.copyfile(out/'source-manifest.json',state)
info.update(run_directory=str(out),source_manifest=str(out/'source-manifest.json'),source_manifest_sha256=sha(out/'source-manifest.json'),prior_intake_directory=str(prior),status='Changed-object preflight found include filename typo; exact one-line correction applied; selected-consumer rebuild and full Network ordinary validation pending')
info.setdefault('director_integration_overlays',[]).append({'path':rel,'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':digest,'reason':'Exact include correction after overbroad member-access replacement; all case values/assertions unchanged'})
(out/'application-result.json').write_text(json.dumps(info,indent=2)+'\n');(rt/'shared-strings-connection-latest.json').write_text(json.dumps(info,indent=2)+'\n')
print(json.dumps({'authority':info['source_manifest_sha256'],'source_count':len(pins),'bindings':len(app['bindings']),'run':str(out)}))
