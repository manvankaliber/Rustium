// Copyright 2024 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef NET_DNS_DNS_RESOLUTION_ORIGINAL_HOST_RESOLVER_DNS_TASK_H_
#define NET_DNS_DNS_RESOLUTION_ORIGINAL_HOST_RESOLVER_DNS_TASK_H_

#include <initializer_list>
#include <memory>
#include <optional>
#include <set>
#include <variant>
#include <vector>

#include "base/containers/circular_deque.h"
#include "base/containers/unique_ptr_adapters.h"
#include "base/memory/raw_ptr.h"
#include "base/memory/safe_ref.h"
#include "base/memory/weak_ptr.h"
#include "base/numerics/safe_conversions.h"
#include "base/time/time.h"
#include "base/timer/timer.h"
#include "base/values.h"
#include "net/base/ech_mode.h"
#include "net/base/ip_endpoint.h"
#include "net/base/net_export.h"
#include "net/base/network_handle.h"
#include "net/base/request_priority.h"
#include "net/dns/dns_resolution_original_dns_transaction.h"
#include "net/dns/host_resolver.h"
#include "net/dns/httpssvc_metrics.h"
#include "net/dns/public/secure_dns_mode.h"
#include "net/dns/dns_resolution_original_resolve_context.h"
#include "net/log/net_log_with_source.h"

#include "base/component_export.h"
#include "net/dns/dns_resolution_native_provider_aliases.h"
#include "net/dns/dns_resolution_manager_native_providers.h"
#include "net/dns/dns_resolution_result_types_rust_original.h"
#include "net/dns/dns_resolution_host_value_rust_original.h"
#include "net/dns/host_resolver_cache_rust_reference.h"
#include "net/dns/dns_resolution_request_interfaces_rust_original.h"
#include "net/base/host_port_rust_reference.h"

namespace net::dns_resolution_original {

using HostPortPair = ::net::HostPortRustReference;
using HostResolverCache = ::net::host_resolver_cache_reference::HostResolverCache;
using HostResolverInternalResult = ::net::host_resolver_cache_reference::HostResolverInternalResult;
using HostResolverInternalDataResult = ::net::host_resolver_cache_reference::HostResolverInternalDataResult;
using HostResolverInternalMetadataResult = ::net::host_resolver_cache_reference::HostResolverInternalMetadataResult;
using HostResolverInternalErrorResult = ::net::host_resolver_cache_reference::HostResolverInternalErrorResult;
using HostResolverInternalAliasResult = ::net::host_resolver_cache_reference::HostResolverInternalAliasResult;


class DnsClient;

// Resolves the hostname using DnsTransaction, which is a full implementation of
// a DNS stub resolver. One DnsTransaction is created for each resolution
// needed, which for AF_UNSPEC resolutions includes both A and AAAA. The
// transactions are scheduled separately and started separately.
class COMPONENT_EXPORT(DNS_RESOLUTION_ORIGINAL) HostResolverDnsTask final {
 public:
  using Results = std::set<std::unique_ptr<HostResolverInternalResult>>;
  using ResultRefs =
      std::set<raw_ptr<const HostResolverInternalResult, DanglingUntriaged>>;

  // Represents a single transaction results.
  struct COMPONENT_EXPORT(DNS_RESOLUTION_ORIGINAL) SingleTransactionResults {
    SingleTransactionResults(DnsQueryType query_type, ResultRefs results);
    ~SingleTransactionResults();

    SingleTransactionResults(SingleTransactionResults&&);
    SingleTransactionResults& operator=(SingleTransactionResults&&);

    SingleTransactionResults(const SingleTransactionResults&) = delete;
    SingleTransactionResults& operator=(const SingleTransactionResults&) =
        delete;

    DnsQueryType query_type;
    ResultRefs results;
  };

  class Delegate {
   public:
    virtual void OnDnsTaskComplete(
        base::TimeTicks start_time,
        bool allow_fallback,
        Results results,
        DnsTransactionFactory::AttemptMode attempt_mode) = 0;

    // Called when a transaction completes (successfully or with a non-fatal
    // address failure), or when one or more transactions get cancelled, but
    // only if more transactions are needed. If no more transactions are
    // needed, expect `OnDnsTaskComplete()` to be called instead.
    // `single_transaction_results` is passed when a transaction completes
    // (with empty `results` on non-fatal address failure), and is
    // `std::nullopt` when transactions are cancelled.
    virtual void OnIntermediateTransactionsComplete(
        std::optional<SingleTransactionResults> single_transaction_results) = 0;

    virtual RequestPriority priority() const = 0;

    virtual bool ShouldSortTransactionsIndividually() const = 0;

    virtual void AddTransactionTimeQueued(base::TimeDelta time_queued) = 0;

   protected:
    Delegate() = default;
    virtual ~Delegate() = default;
  };

  HostResolverDnsTask(DnsClient* client,
                      DnsResolverHostOriginal host,
                      NetworkAnonymizationKey anonymization_key,
                      DnsQueryTypeSet query_types,
                      ResolveContext* resolve_context,
                      DnsTransactionFactory::AttemptMode attempt_mode,
                      SecureDnsMode secure_dns_mode,
                      handles::NetworkHandle target_network,
                      Delegate* delegate,
                      const NetLogWithSource& job_net_log,
                      const base::TickClock* tick_clock,
                      bool fallback_available,
                      const HostResolver::HttpsSvcbOptions& https_svcb_options);
  ~HostResolverDnsTask();

  HostResolverDnsTask(const HostResolverDnsTask&) = delete;
  HostResolverDnsTask& operator=(const HostResolverDnsTask&) = delete;

  int num_additional_transactions_needed() const {
    return base::checked_cast<int>(transactions_needed_.size());
  }

  int num_transactions_in_progress() const {
    return base::checked_cast<int>(transactions_in_progress_.size());
  }

  bool secure() const {
    switch (attempt_mode_) {
      case DnsTransactionFactory::AttemptMode::kHttp:
        return true;
      case DnsTransactionFactory::AttemptMode::kClassic:
      case DnsTransactionFactory::AttemptMode::kPlatform:
        return false;
    }
  }

  bool https_disabled() const { return https_disabled_; }

  void StartNextTransaction();

  // Returns the DoH resolution details (such as connection protocol and
  // session source) for this task, if DoH was used. Returns std::nullopt
  // otherwise. If multiple transactions (e.g., A, AAAA, HTTPS) are executed
  // concurrently, this retains the details from the first successfully
  // completed DoH transaction to prevent overwriting.
  std::optional<DohResolutionDetails> GetDohResolutionDetails() const {
    return doh_details_;
  }

  base::WeakPtr<HostResolverDnsTask> AsWeakPtr() {
    return weak_ptr_factory_.GetWeakPtr();
  }

  // Selects which non-fatal address transaction failure to retain when both
  // address transactions fail. Keeps `existing` (the first failure) unless:
  // - `existing` carries a TTL and `candidate` does not, preventing `HostCache`
  //   from negatively caching a failure (e.g. `ERR_DNS_SORT_ERROR` from
  //   `OnTransactionSorted()`) when the sibling transaction failed with an
  //   uncacheable transient error (e.g. `ERR_DNS_SERVER_FAILURE`), or
  // - both carry a TTL and `candidate` has a shorter TTL, to avoid caching the
  //   failure for longer than the authoritative server intended.
  static std::unique_ptr<HostResolverInternalErrorResult> SelectAddressFailure(
      std::unique_ptr<HostResolverInternalErrorResult> existing,
      std::unique_ptr<HostResolverInternalErrorResult> candidate);

  // There are some complex circumstances when some in-progress transactions
  // may be cancelled without cancelling the entire task. This trigger allows
  // testing that logic can correctly respond to being cancelled, regardless of
  // the reason for the cancellation.
  void CancelInProgressTransactionsForTest();

 private:
  enum class TransactionErrorBehavior {
    // Errors lead to task failure (immediately unless another pending/started
    // transaction has the `kFatalOrEmpty` behavior).
    kFailTask,

    // Transaction errors are ignored if another address transaction resolves
    // usable address results; otherwise they lead to task failure once all
    // address transactions have finished.
    kIgnoreIfOtherTransactionResolves,

    // Transaction errors are treated as if a NOERROR response were received,
    // allowing task success if other transactions complete successfully.
    kSynthesizeEmpty,

    // Transaction errors are potentially fatal (determined by
    // `OnTransactionComplete` and often its helper
    // `IsFatalTransactionFailure()`) for the entire Job and may disallow
    // fallback. Otherwise, same as `kSynthesizeEmpty`.
    // TODO(crbug.com/40203587): Implement the fatality behavior.
    kFatalOrEmpty,
  };

  struct TransactionInfo {
    explicit TransactionInfo(DnsQueryType type,
                             TransactionErrorBehavior error_behavior =
                                 TransactionErrorBehavior::kFailTask);
    ~TransactionInfo();

    DnsQueryType type;
    TransactionErrorBehavior error_behavior;
    std::unique_ptr<DnsTransaction> transaction;
    base::WeakPtrFactory<TransactionInfo> weak_ptr_factory{this};
  };

  // Holds the TTL expiration timestamps for a failure result. Both clocks are
  // tracked to match `HostResolverInternalResult` (which requires
  // `timed_expiration` whenever `expiration` is set).
  struct ExpirationTtls {
    // Monotonic-clock expiration (`base::TimeTicks`), preferred for in-memory
    // cache expiration checks as it is unaffected by system clock adjustments.
    base::TimeTicks expiration;
    // Wall-clock expiration (`base::Time`), used when serializing results (e.g.
    // to NetLog or persistent cache storage).
    base::Time timed_expiration;
  };

  base::DictValue NetLogDnsTaskCreationParams();

  base::DictValue NetLogDnsTaskTimeoutParams();

  DnsQueryTypeSet MaybeDisableAdditionalQueries(DnsQueryTypeSet types);

  void PushTransactionsNeeded(DnsQueryTypeSet query_types);

  void CreateAndStartTransaction(
      std::unique_ptr<TransactionInfo> transaction_info);

  void OnTimeout();

  // Called on completion of a `DnsTransaction`, but not necessarily completion
  // of all work for the individual transaction in this task (see
  // `OnTransactionsFinished()`).
  //
  // Takes the TransactionInfo reference as a WeakPtr only for added safety and
  // conformity with similar code. Not expected to actually be possible for this
  // callback to be called after cancellation of a transaction and deletion of
  // the TransactionInfo because the info itself owns the DnsTransaction, which
  // cancels the async call on destruction.
  void OnDnsTransactionComplete(
      base::WeakPtr<TransactionInfo> transaction_info_ptr,
      uint16_t request_port,
      int net_error,
      const DnsResponse* response);

  bool IsFatalTransactionFailure(int transaction_error,
                                 const TransactionInfo& transaction_info,
                                 const DnsResponse* response);

  void SortTransactionAndHandleResults(
      std::unique_ptr<TransactionInfo> transaction_info,
      Results transaction_results);
  void OnTransactionSorted(base::WeakPtr<TransactionInfo> transaction_info_ptr,
                           Results transaction_results,
                           bool success,
                           std::vector<IPEndPoint> sorted);
  void HandleTransactionResults(
      std::unique_ptr<TransactionInfo> transaction_info,
      Results transaction_results);

  void OnTransactionsFinished(
      std::optional<SingleTransactionResults> single_transaction_results);

  void OnSortComplete(base::TimeTicks sort_start_time,
                      Results results,
                      bool secure,
                      bool success,
                      std::vector<IPEndPoint> sorted);

  bool AnyPotentiallyFatalTransactionsRemain();

  void CancelNonFatalTransactions();

  bool HasSavedAddressResults() const;

  static std::optional<ExpirationTtls> GetMinExpirations(
      const Results& results);

  // Creates an error result for `net_error` with the given optional TTL
  // expiration timestamps.
  std::unique_ptr<HostResolverInternalErrorResult> CreateFailureResult(
      int net_error,
      std::optional<ExpirationTtls> expiration_ttls) const;

  void OnNonFatalAddressTransactionFailure(
      std::unique_ptr<TransactionInfo> transaction_info,
      int net_error,
      std::optional<ExpirationTtls> expiration_ttls);

  void OnFailure(int net_error,
                 bool allow_fallback,
                 std::optional<ExpirationTtls> expiration_ttls);
  void OnDeferredFailure(bool allow_fallback = true);

  void OnSuccess(Results results);

  // Returns whether any queued or in-progress transactions are of a transaction
  // type in `types` (returns false if no transactions remain at all). Used by
  // `OnTransactionsFinished()` to check if any address transactions remain and
  // by `MaybeStartTimeoutTimer()` to decide whether to start the timeout timer.
  bool AnyOfTypeTransactionsRemain(
      std::initializer_list<DnsQueryType> types) const;

  void MaybeStartTimeoutTimer();

  bool ShouldTriggerHttpToHttpsUpgrade(const Results& results);

  const raw_ptr<DnsClient> client_;

  DnsResolverHostOriginal host_;
  NetworkAnonymizationKey anonymization_key_;

  base::SafeRef<ResolveContext> resolve_context_;

  const DnsTransactionFactory::AttemptMode attempt_mode_;
  const SecureDnsMode secure_dns_mode_;

  const handles::NetworkHandle target_network_ = handles::kInvalidNetworkHandle;

  // The listener to the results of this DnsTask.
  const raw_ptr<Delegate> delegate_;
  const NetLogWithSource net_log_;

  bool any_transaction_started_ = false;
  base::circular_deque<std::unique_ptr<TransactionInfo>> transactions_needed_;
  // Active transactions have iterators pointing to their entry in this set, so
  // individual entries should not be modified or removed until completion or
  // cancellation of the transaction.
  std::set<std::unique_ptr<TransactionInfo>, base::UniquePtrComparator>
      transactions_in_progress_;

  // For histograms.
  base::TimeTicks a_record_end_time_;
  base::TimeTicks aaaa_record_end_time_;
  base::TimeTicks https_record_end_time_;

  Results saved_results_;
  // Set when the task is guaranteed to fail, but completion may need to wait
  // for in-progress `kFatalOrEmpty` transactions to determine whether fallback
  // should be disallowed.
  std::unique_ptr<HostResolverInternalErrorResult> deferred_failure_;
  // Holds a non-`ERR_NAME_NOT_RESOLVED` failure from an address transaction
  // while waiting to see if the sibling address transaction resolves usable
  // endpoints. Kept separate from `saved_results_` (which `HostCache::Entry`
  // requires to contain no real errors on task success) and from
  // `deferred_failure_` (which cancels remaining non-fatal transactions).
  std::unique_ptr<HostResolverInternalErrorResult> pending_address_failure_;

  const raw_ptr<const base::TickClock> tick_clock_;
  base::TimeTicks task_start_time_;

  std::optional<HttpssvcMetrics> httpssvc_metrics_;

  // Timer for task timeout. Generally started after completion of address
  // transactions to allow aborting experimental or supplemental transactions.
  base::OneShotTimer timeout_timer_;

  // If true, there are still significant fallback options available if this
  // task completes unsuccessfully. Used as a signal that underlying
  // transactions should timeout more quickly.
  bool fallback_available_;

  const HostResolver::HttpsSvcbOptions https_svcb_options_;
  const EchMode ech_mode_;

  // If true, the task will wait for the pending HTTPS query and treat
  // certain HTTPS query errors as fatal.
  const bool https_svcb_required_;

  // Set to true when HTTPS query is disabled.
  bool https_disabled_ = false;

  std::optional<DohResolutionDetails> doh_details_;

  base::WeakPtrFactory<HostResolverDnsTask> weak_ptr_factory_{this};
};

}  // namespace net::dns_resolution_original

#endif  // NET_DNS_DNS_RESOLUTION_ORIGINAL_HOST_RESOLVER_DNS_TASK_H_
