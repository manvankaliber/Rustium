// Copyright 2024 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef NET_DNS_DNS_RESOLUTION_ORIGINAL_DNS_TASK_RESULTS_MANAGER_H_
#define NET_DNS_DNS_RESOLUTION_ORIGINAL_DNS_TASK_RESULTS_MANAGER_H_

#include <map>
#include <memory>
#include <string>
#include <variant>
#include <vector>

#include "base/containers/flat_set.h"
#include "base/memory/raw_ptr.h"
#include "base/time/time.h"
#include "base/timer/timer.h"
#include "net/base/ip_endpoint.h"
#include "net/base/net_export.h"
#include "net/dns/host_resolver.h"
#include "net/dns/dns_resolution_original_host_resolver_dns_task.h"
#include "net/dns/public/dns_query_type.h"
#include "net/dns/public/host_resolver_results.h"
#include "net/log/net_log_with_source.h"
#include "url/scheme_host_port.h"

#include "base/component_export.h"
#include "net/dns/dns_resolution_native_provider_aliases.h"
#include "net/dns/dns_resolution_manager_native_providers.h"
#include "net/dns/dns_resolution_result_types_rust_original.h"
#include "net/dns/dns_resolution_host_value_rust_original.h"
#include "net/dns/host_resolver_cache_rust_reference.h"
#include "net/dns/dns_resolution_request_interfaces_rust_original.h"
#include "net/base/host_port_rust_reference.h"

namespace net::dns_resolution_original {

using HostPortPair = ::net::HostPortRustReference;
using HostResolverCache = ::net::host_resolver_cache_reference::HostResolverCache;
using HostResolverInternalResult = ::net::host_resolver_cache_reference::HostResolverInternalResult;
using HostResolverInternalDataResult = ::net::host_resolver_cache_reference::HostResolverInternalDataResult;
using HostResolverInternalMetadataResult = ::net::host_resolver_cache_reference::HostResolverInternalMetadataResult;
using HostResolverInternalErrorResult = ::net::host_resolver_cache_reference::HostResolverInternalErrorResult;
using HostResolverInternalAliasResult = ::net::host_resolver_cache_reference::HostResolverInternalAliasResult;


// Presence of address hints in HTTPS records.
//
// These values are persisted to logs. Entries should not be renumbered and
// numeric values should never be reused.
//
// LINT.IfChange(HttpsRecordAddressHintsPresence)
enum class HttpsRecordAddressHintsPresence {
  kNoHints = 0,
  kIPv4Only = 1,
  kIPv6Only = 2,
  kBoth = 3,
  kMaxValue = kBoth,
};
// LINT.ThenChange(//tools/metrics/histograms/metadata/net/enums.xml:DNS.HttpsRecordAddressHintsPresence)

// Creates and updates intermediate service endpoints while resolving a host.
// This class is designed to have a 1:1 relationship with a HostResolverDnsTask
// and expects to be notified every time a DnsTransaction is completed. When
// notified, tries to create and update service endpoints from DNS responses
// received so far.
//
// If the A response comes before the AAAA response, delays service endpoints
// creation/update until an AAAA response is received or the AAAA query is
// timed out.
//
// Address hints from HTTPS records are published as provisional endpoints only
// until the corresponding address family's response arrives.
class COMPONENT_EXPORT(DNS_RESOLUTION_ORIGINAL) DnsTaskResultsManager {
 public:
  // Time to wait for a AAAA response after receiving an A response.
  static base::TimeDelta GetResolutionDelay();

  // Interface for watching for intermediate service endpoints updates.
  class Delegate {
   public:
    virtual ~Delegate() = default;

    // Called when service endpoints are updated.
    virtual void OnServiceEndpointsUpdated() = 0;
  };

  // TODO(crbug.com/41493696): Update HostResolverManager::JobKey to use
  // DnsResolverHostOriginal so that HostResolverManager::Job can create an instance
  // of this class.
  DnsTaskResultsManager(Delegate* delegate,
                        DnsResolverHostOriginal host,
                        DnsQueryTypeSet query_types,
                        const NetLogWithSource& net_log);
  ~DnsTaskResultsManager();

  DnsTaskResultsManager(const DnsTaskResultsManager&) = delete;
  DnsTaskResultsManager& operator=(const DnsTaskResultsManager&) = delete;

  // Processes a query response represented by HostResolverInternalResults.
  // Expected be called when a DnsTransaction is completed.
  void ProcessDnsTransactionResults(DnsQueryType query_type,
                                    HostResolverDnsTask::ResultRefs results);

  // Called when the entire DnsTask completes. If HTTPS completed as the final
  // transaction, records address hints metrics. Also stops the resolution delay
  // timer if still running.
  void ProcessDnsTaskComplete(const HostResolverDnsTask::Results& results);

  // Returns the current service endpoints. The results could change over time.
  // Use the delegate's OnServiceEndpointsUpdated() to watch for updates.
  const std::vector<ServiceEndpoint>& GetCurrentEndpoints() const;

  // Returns all DNS record aliases, found as a result of A, AAAA, and HTTPS
  // queries. The results could change over time.
  const base::flat_set<std::string>& GetAliases() const;

  // True when a HTTP response is received. When true, call sites can start
  // cryptographic handshakes since Chrome doesn't support HTTPS follow-up
  // queries yet.
  bool IsMetadataReady() const;

  bool IsResolutionDelayTimerRunningForTest() {
    return resolution_delay_timer_.IsRunning();
  }

 private:
  struct PerDomainResult;

  PerDomainResult& GetOrCreatePerDomainResult(const std::string& domain_name);

  void OnAaaaResolutionTimedout();

  void UpdateEndpoints();

  // Stops the resolution delay timer if running and records the NetLog event.
  // Returns true if the timer was running.
  bool MaybeStopResolutionDelayTimer();

  // Address hints are usable only while the corresponding address family's
  // query is expected and its response has not arrived yet.
  bool Ipv4HintsUsable() const;
  bool Ipv6HintsUsable() const;

  // True when any per domain result has hint endpoints for the family,
  // regardless of usability.
  bool HasIpv4HintEndpoints() const;
  bool HasIpv6HintEndpoints() const;

  // Checks all per domain results and return true when there is at least one
  // valid address or usable IPv4 hint.
  bool HasIpv4Addresses() const;

  void RecordResolutionDelayResult(bool timedout);

  // Records address hints UMA (presence and whether address queries were
  // outstanding) for the HTTPS transaction results.
  void RecordAddressHintsMetrics(
      const HostResolverInternalMetadataResult::AddressHintsMap& address_hints,
      bool is_terminal_transaction);

  const raw_ptr<Delegate> delegate_;
  const DnsResolverHostOriginal host_;
  const DnsQueryTypeSet query_types_;
  const NetLogWithSource net_log_;

  std::vector<ServiceEndpoint> current_endpoints_;

  bool is_metadata_ready_ = false;

  // True when the A DNS transaction completes (including NODATA / empty
  // results).
  bool a_response_received_ = false;

  // True when the AAAA DNS transaction completes (including NODATA / empty
  // results).
  bool aaaa_response_received_ = false;

  base::flat_set<std::string> aliases_;

  std::map</*domain_name=*/std::string, std::unique_ptr<PerDomainResult>>
      per_domain_results_;

  base::TimeTicks resolution_delay_start_time_;
  base::OneShotTimer resolution_delay_timer_;

  // True when the AAAA resolution delay timer times out, meaning we stop
  // waiting for an AAAA response and allow intermediate endpoint updates.
  bool aaaa_resolution_delay_timed_out_ = false;
};

}  // namespace net::dns_resolution_original

#endif  // NET_DNS_DNS_RESOLUTION_ORIGINAL_DNS_TASK_RESULTS_MANAGER_H_
