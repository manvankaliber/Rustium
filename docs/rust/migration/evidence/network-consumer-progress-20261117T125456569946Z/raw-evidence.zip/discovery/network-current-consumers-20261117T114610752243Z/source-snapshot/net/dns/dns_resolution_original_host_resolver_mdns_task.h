// Copyright 2018 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef NET_DNS_DNS_RESOLUTION_ORIGINAL_HOST_RESOLVER_MDNS_TASK_H_
#define NET_DNS_DNS_RESOLUTION_ORIGINAL_HOST_RESOLVER_MDNS_TASK_H_

#include <memory>
#include <set>
#include <string>
#include <vector>

#include "base/containers/unique_ptr_adapters.h"
#include "base/functional/callback_forward.h"
#include "base/memory/raw_ptr.h"
#include "base/memory/weak_ptr.h"
#include "base/sequence_checker.h"
#include "net/base/request_priority.h"
#include "net/dns/host_resolver.h"
#include "net/dns/dns_resolution_original_mdns_client.h"
#include "net/dns/public/dns_query_type.h"

#include "base/component_export.h"
#include "net/dns/dns_resolution_native_provider_aliases.h"
#include "net/dns/dns_resolution_manager_native_providers.h"
#include "net/dns/dns_resolution_result_types_rust_original.h"
#include "net/dns/dns_resolution_host_value_rust_original.h"
#include "net/dns/host_resolver_cache_rust_reference.h"
#include "net/dns/dns_resolution_request_interfaces_rust_original.h"
#include "net/base/host_port_rust_reference.h"

namespace net::dns_resolution_original {

using HostPortPair = ::net::HostPortRustReference;
using HostResolverCache = ::net::host_resolver_cache_reference::HostResolverCache;
using HostResolverInternalResult = ::net::host_resolver_cache_reference::HostResolverInternalResult;
using HostResolverInternalDataResult = ::net::host_resolver_cache_reference::HostResolverInternalDataResult;
using HostResolverInternalMetadataResult = ::net::host_resolver_cache_reference::HostResolverInternalMetadataResult;
using HostResolverInternalErrorResult = ::net::host_resolver_cache_reference::HostResolverInternalErrorResult;
using HostResolverInternalAliasResult = ::net::host_resolver_cache_reference::HostResolverInternalAliasResult;


class RecordParsed;

// Representation of a single HostResolverImpl::Job task to resolve the hostname
// using multicast DNS transactions.  Destruction cancels the task and prevents
// any callbacks from being invoked.
class HostResolverMdnsTask {
 public:
  // |mdns_client| must outlive |this|.
  HostResolverMdnsTask(MDnsClient* mdns_client,
                       std::string hostname,
                       DnsQueryTypeSet query_types,
                       RequestPriority priority);

  HostResolverMdnsTask(const HostResolverMdnsTask&) = delete;
  HostResolverMdnsTask& operator=(const HostResolverMdnsTask&) = delete;

  ~HostResolverMdnsTask();

  // Starts the task. |completion_closure| will be called asynchronously.
  //
  // Should only be called once.
  void Start(base::OnceClosure completion_closure);

  // Results only available after invocation of the completion closure.
  std::set<std::unique_ptr<HostResolverInternalResult>> GetResults() const;

  // If `error` is `OK`, `parsed` must not be null.
  static std::unique_ptr<HostResolverInternalResult> ParseResult(
      int error,
      std::string query_hostname,
      DnsQueryType query_type,
      const RecordParsed* parsed);

 private:
  class Transaction;

  void CheckCompletion(bool post_needed);
  void Complete(bool post_needed);

  const raw_ptr<MDnsClient> mdns_client_;

  const std::string hostname_;

  const RequestPriority priority_;

  std::vector<Transaction> transactions_;

  base::OnceClosure completion_closure_;

  SEQUENCE_CHECKER(sequence_checker_);

  base::WeakPtrFactory<HostResolverMdnsTask> weak_ptr_factory_{this};
};

}  // namespace net::dns_resolution_original

#endif  // NET_DNS_DNS_RESOLUTION_ORIGINAL_HOST_RESOLVER_MDNS_TASK_H_
