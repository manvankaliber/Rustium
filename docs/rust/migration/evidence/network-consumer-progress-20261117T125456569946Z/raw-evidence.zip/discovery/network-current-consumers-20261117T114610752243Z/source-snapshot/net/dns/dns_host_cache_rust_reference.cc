// Copyright 2012 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "net/dns/dns_host_cache_rust_reference.h"

#include <algorithm>
#include <iterator>
#include <map>
#include <memory>
#include <optional>
#include <ostream>
#include <set>
#include <string>
#include <string_view>
#include <type_traits>
#include <unordered_set>
#include <utility>
#include <variant>
#include <vector>

#include "base/check_op.h"
#include "base/containers/flat_set.h"
#include "base/functional/bind.h"
#include "base/metrics/field_trial.h"
#include "base/metrics/histogram_functions.h"
#include "base/numerics/checked_math.h"
#include "base/numerics/safe_conversions.h"
#include "base/strings/strcat.h"
#include "base/strings/string_number_conversions.h"
#include "base/strings/string_util.h"
#include "base/time/default_tick_clock.h"
#include "base/time/time.h"
#include "base/trace_event/trace_event.h"
#include "base/types/optional_util.h"
#include "base/value_iterators.h"
#include "net/base/address_family.h"
#include "net/base/ip_endpoint.h"
#include "net/base/network_anonymization_key.h"
#include "net/base/network_handle.h"
#include "net/base/trace_constants.h"
#include "net/base/url_util.h"
#include "net/dns/host_resolver.h"
#include "net/dns/host_resolver_internal_result.h"
#include "net/dns/https_record_rdata.h"
#include "net/dns/public/dns_protocol.h"
#include "net/dns/public/host_resolver_source.h"
#include "net/log/net_log.h"
#include "url/scheme_host_port.h"

namespace net {

namespace {

// String constants for dictionary keys.
const char kSchemeKey[] = "scheme";
const char kHostnameKey[] = "hostname";
const char kPortKey[] = "port";
const char kDnsQueryTypeKey[] = "dns_query_type";
const char kFlagsKey[] = "flags";
const char kHostResolverSourceKey[] = "host_resolver_source";
const char kSecureKey[] = "secure";
const char kNetworkAnonymizationKey[] = "network_anonymization_key";
const char kExpirationKey[] = "expiration";
const char kTtlKey[] = "ttl";
const char kPinnedKey[] = "pinned";
const char kNetworkChangesKey[] = "network_changes";
const char kNetErrorKey[] = "net_error";
const char kIpEndpointsKey[] = "ip_endpoints";
const char kEndpointAddressKey[] = "endpoint_address";
const char kEndpointPortKey[] = "endpoint_port";
const char kInterfaceNameKey[] = "interface_name";
const char kEndpointMetadatasKey[] = "endpoint_metadatas";
const char kEndpointMetadataWeightKey[] = "endpoint_metadata_weight";
const char kEndpointMetadataValueKey[] = "endpoint_metadata_value";
const char kAliasesKey[] = "aliases";
const char kAddressesKey[] = "addresses";
const char kTextRecordsKey[] = "text_records";
const char kHostnameResultsKey[] = "hostname_results";
const char kHostPortsKey[] = "host_ports";
const char kCanonicalNamesKey[] = "canonical_names";
const char kTargetNetworkKey[] = "target_network";

base::Value IpEndpointToValue(const IPEndPoint& endpoint) {
  base::DictValue dictionary;
  dictionary.Set(kEndpointAddressKey, endpoint.ToStringWithoutPort());
  dictionary.Set(kEndpointPortKey, endpoint.port());
  if (endpoint.scope_id().has_value()) {
    base::Value interface_name =
        IPEndPoint::ScopeIdToInterfaceNameValue(endpoint.scope_id());
    if (!interface_name.is_none()) {
      dictionary.Set(kInterfaceNameKey, std::move(interface_name));
    }
  }
  return base::Value(std::move(dictionary));
}

std::optional<IPEndPoint> IpEndpointFromValue(const base::Value& value) {
  if (!value.is_dict()) {
    return std::nullopt;
  }

  const base::DictValue& dict = value.GetDict();
  const std::string* ip_str = dict.FindString(kEndpointAddressKey);
  std::optional<int> port = dict.FindInt(kEndpointPortKey);

  if (!ip_str || !port ||
      !base::IsValueInRangeForNumericType<uint16_t>(port.value())) {
    return std::nullopt;
  }

  IPAddress ip;
  if (!ip.AssignFromIPLiteral(*ip_str)) {
    return std::nullopt;
  }

  std::optional<uint32_t> scope_id =
      IPEndPoint::ScopeIdFromInterfaceName(dict.Find(kInterfaceNameKey));
  if (scope_id.has_value()) {
    if (scope_id.value() == 0 || !(ip.IsIPv6() && ip.IsLinkLocal()) ||
        !base::IsValueInRangeForNumericType<uint32_t>(scope_id.value())) {
      return std::nullopt;
    }
  }

  return IPEndPoint(ip, base::checked_cast<uint16_t>(port.value()), scope_id);
}

base::Value EndpointMetadataPairToValue(
    const std::pair<HttpsRecordPriority, ConnectionEndpointMetadata>& pair) {
  base::DictValue dictionary;
  dictionary.Set(kEndpointMetadataWeightKey, pair.first);
  dictionary.Set(kEndpointMetadataValueKey, pair.second.ToValue());
  return base::Value(std::move(dictionary));
}

std::optional<std::pair<HttpsRecordPriority, ConnectionEndpointMetadata>>
EndpointMetadataPairFromValue(const base::Value& value) {
  if (!value.is_dict()) {
    return std::nullopt;
  }

  const base::DictValue& dict = value.GetDict();
  std::optional<int> priority = dict.FindInt(kEndpointMetadataWeightKey);
  const base::Value* metadata_value = dict.Find(kEndpointMetadataValueKey);

  if (!priority || !base::IsValueInRangeForNumericType<HttpsRecordPriority>(
                       priority.value())) {
    return std::nullopt;
  }

  if (!metadata_value) {
    return std::nullopt;
  }
  std::optional<ConnectionEndpointMetadata> metadata =
      ConnectionEndpointMetadata::FromValue(*metadata_value);
  if (!metadata) {
    return std::nullopt;
  }

  return std::pair(base::checked_cast<HttpsRecordPriority>(priority.value()),
                   std::move(metadata).value());
}

bool IPEndPointsFromLegacyAddressListValue(
    const base::ListValue& value,
    std::vector<IPEndPoint>& ip_endpoints) {
  DCHECK(ip_endpoints.empty());
  for (const auto& it : value) {
    IPAddress address;
    const std::string* addr_string = it.GetIfString();
    if (!addr_string || !address.AssignFromIPLiteral(*addr_string)) {
      return false;
    }
    ip_endpoints.emplace_back(address, 0);
  }
  return true;
}

template <typename T>
void MergeLists(T& target, const T& source) {
  target.insert(target.end(), source.begin(), source.end());
}

template <typename T>
void MergeContainers(T& target, const T& source) {
  target.insert(source.begin(), source.end());
}

// Used to reject empty and IP literal (whether or not surrounded by brackets)
// hostnames.
bool IsValidHostname(std::string_view hostname) {
  if (hostname.empty()) {
    return false;
  }

  IPAddress ip_address;
  if (ip_address.AssignFromIPLiteral(hostname) ||
      ParseURLHostnameToAddress(hostname, &ip_address)) {
    return false;
  }

  return true;
}

const std::string& GetHostname(
    const std::variant<url::SchemeHostPort, std::string>& host) {
  const std::string* hostname;
  if (std::holds_alternative<url::SchemeHostPort>(host)) {
    hostname = &std::get<url::SchemeHostPort>(host).host();
  } else {
    DCHECK(std::holds_alternative<std::string>(host));
    hostname = &std::get<std::string>(host);
  }

  DCHECK(IsValidHostname(*hostname));
  return *hostname;
}

std::optional<DnsQueryType> GetDnsQueryType(int dns_query_type) {
  for (const auto& type : kDnsQueryTypes) {
    if (base::strict_cast<int>(type.first) == dns_query_type) {
      return type.first;
    }
  }
  return std::nullopt;
}

const std::string GetHistogramName(std::string_view histogram_name,
                                   const DnsHostCacheRustReference::Key& key) {
  constexpr std::string_view kHistogramPrefix =
      "Net.DNS.DnsHostCacheRustReference.";

  return base::StrCat(
      {kHistogramPrefix, histogram_name,
       (base::EqualsCaseInsensitiveASCII(GetHostname(key.host), "google.com") ||
        base::EqualsCaseInsensitiveASCII(GetHostname(key.host),
                                         "www.google.com"))
           ? ".GoogleHost"
           : ""});
}

}  // namespace

// Used in histograms; do not modify existing values.
enum DnsHostCacheRustReference::SetOutcome : int {
  SET_INSERT = 0,
  SET_UPDATE_VALID = 1,
  SET_UPDATE_STALE = 2,
  MAX_SET_OUTCOME
};

DnsHostCacheRustReference::Key::Key(
    std::variant<url::SchemeHostPort, std::string> host,
    DnsQueryType dns_query_type,
    HostResolverFlags host_resolver_flags,
    HostResolverSource host_resolver_source,
    const NetworkAnonymizationKey& network_anonymization_key,
    handles::NetworkHandle target_network)
    : host(std::move(host)),
      dns_query_type(dns_query_type),
      host_resolver_flags(host_resolver_flags),
      host_resolver_source(host_resolver_source),
      network_anonymization_key(network_anonymization_key),
      target_network(target_network) {
  DCHECK(IsValidHostname(GetHostname(this->host)));
  if (std::holds_alternative<url::SchemeHostPort>(this->host)) {
    DCHECK(std::get<url::SchemeHostPort>(this->host).IsValid());
  }
}

DnsHostCacheRustReference::Key::Key() = default;
DnsHostCacheRustReference::Key::Key(const Key& key) = default;
DnsHostCacheRustReference::Key::Key(Key&& key) = default;

DnsHostCacheRustReference::Key::~Key() = default;

DnsHostCacheRustReference::Entry::Entry(int error,
                                        Source source,
                                        std::optional<base::TimeDelta> ttl)
    : error_(error), source_(source), ttl_(ttl.value_or(kUnknownTtl)) {
  // If |ttl| has a value, must not be negative.
  DCHECK_GE(ttl.value_or(base::TimeDelta()), base::TimeDelta());
  DCHECK_NE(OK, error_);

  // host_cache.h defines its own `HttpsRecordPriority` due to
  // https_record_rdata.h not being allowed in the same places, but the types
  // should still be the same thing.
  static_assert(
      std::is_same<
          net::HttpsRecordPriority,
          DnsHostCacheRustReference::Entry::HttpsRecordPriority>::value,
      "`net::HttpsRecordPriority` and "
      "`DnsHostCacheRustReference::Entry::HttpsRecordPriority` must be same "
      "type");
}

DnsHostCacheRustReference::Entry::Entry(
    const std::set<std::unique_ptr<HostResolverInternalResult>>& results,
    base::Time now,
    base::TimeTicks now_ticks,
    Source empty_source) {
  std::vector<const HostResolverInternalResult*> data_results;
  const HostResolverInternalResult* metadata_result = nullptr;
  std::vector<const HostResolverInternalResult*> error_results;
  std::vector<const HostResolverInternalResult*> alias_results;

  std::optional<base::TimeDelta> smallest_ttl =
      TtlFromInternalResults(results, now, now_ticks);
  std::optional<Source> source;
  for (const std::unique_ptr<HostResolverInternalResult>& result : results) {
    Source result_source;
    switch (result->source()) {
      case HostResolverInternalResult::Source::kDns:
        result_source = SOURCE_DNS;
        break;
      case HostResolverInternalResult::Source::kHosts:
        result_source = SOURCE_HOSTS;
        break;
      case HostResolverInternalResult::Source::kUnknown:
        result_source = SOURCE_UNKNOWN;
        break;
    }

    switch (result->type()) {
      case HostResolverInternalResult::Type::kData:
        if (!result->AsData().endpoints().empty() &&
            result->AsData().endpoints().front().GetFamily() ==
                ADDRESS_FAMILY_IPV6) {
          // If a data result contains IPv6 addresses, put it at the front to
          // ensure we generally keep IPv6 addresses sorted before IPv4
          // addresses.
          data_results.insert(data_results.begin(), result.get());
        } else {
          data_results.push_back(result.get());
        }
        break;
      case HostResolverInternalResult::Type::kMetadata:
        DCHECK(!metadata_result);  // Expect at most one metadata result.
        metadata_result = result.get();
        break;
      case HostResolverInternalResult::Type::kError:
        error_results.push_back(result.get());
        break;
      case HostResolverInternalResult::Type::kAlias:
        alias_results.push_back(result.get());
        break;
    }

    // Expect all results to have the same source.
    DCHECK(!source.has_value() || source.value() == result_source);
    source = result_source;
  }

  ttl_ = smallest_ttl.value_or(kUnknownTtl);
  source_ = source.value_or(empty_source);

  if (!data_results.empty() || metadata_result) {
    error_ = OK;

    // Any errors should be an ignorable ERR_NAME_NOT_RESOLVED from a single
    // transaction.
    CHECK(std::ranges::all_of(
        error_results, [](const HostResolverInternalResult* error_result) {
          return error_result->query_type() != DnsQueryType::UNSPECIFIED &&
                 error_result->AsError().error() == ERR_NAME_NOT_RESOLVED;
        }));
  } else if (!error_results.empty()) {
    error_ = ERR_NAME_NOT_RESOLVED;
    bool any_error_cacheable = false;
    for (const HostResolverInternalResult* error_result : error_results) {
      if (error_result->expiration().has_value() ||
          error_result->timed_expiration().has_value()) {
        any_error_cacheable = true;
      }

      if (error_result->AsError().error() != ERR_NAME_NOT_RESOLVED ||
          error_result->query_type() == DnsQueryType::UNSPECIFIED) {
        // If not just a single-transaction ERR_NAME_NOT_RESOLVED, the error is
        // an actual failure. Expected to then be the only error result.
        CHECK_EQ(error_results.size(), 1u);

        error_ = error_result->AsError().error();
      }
    }

    // Must get at least one TTL from an error result, not e.g. alias results,
    // for an error to overall be cacheable.
    if (!any_error_cacheable) {
      ttl_ = kUnknownTtl;
    }
  } else {
    // Only alias results (or completely empty results). Never cacheable due to
    // being equivalent to an error result without TTL.
    error_ = ERR_NAME_NOT_RESOLVED;
    ttl_ = kUnknownTtl;
  }

  if (!data_results.empty()) {
    std::vector<std::string> aliases;
    aliases.reserve(base::CheckAdd(data_results.size(),
                                   base::CheckMul(alias_results.size(), 2u))
                        .ValueOrDie());
    for (const HostResolverInternalResult* data_result : data_results) {
      DCHECK(!data_result->AsData().endpoints().empty() ||
             !data_result->AsData().strings().empty() ||
             !data_result->AsData().hosts().empty());
      // Data results should always be cacheable.
      DCHECK(data_result->expiration().has_value() ||
             data_result->timed_expiration().has_value());

      MergeLists(ip_endpoints_, data_result->AsData().endpoints());
      MergeLists(text_records_, data_result->AsData().strings());
      MergeLists(hostnames_, data_result->AsData().hosts());
      canonical_names_.insert(data_result->domain_name());
      aliases.push_back(data_result->domain_name());
    }

    for (const auto* alias_result : alias_results) {
      aliases.push_back(alias_result->domain_name());
      aliases.push_back(alias_result->AsAlias().alias_target());
    }
    aliases_ = base::flat_set<std::string>(std::move(aliases));
  }

  if (metadata_result) {
    // Metadata results should always be cacheable.
    DCHECK(metadata_result->expiration().has_value() ||
           metadata_result->timed_expiration().has_value());

    endpoint_metadatas_ = metadata_result->AsMetadata().metadatas();

    // Even if otherwise empty, having the metadata result object signifies
    // receiving a compatible HTTPS record.
    if (data_results.empty() && endpoint_metadatas_.empty()) {
      error_ = ERR_NAME_NOT_RESOLVED;
    }
  }
}

DnsHostCacheRustReference::Entry::Entry(const Entry& entry) = default;

DnsHostCacheRustReference::Entry::Entry(Entry&& entry) = default;

DnsHostCacheRustReference::Entry::~Entry() = default;

std::vector<HostResolverEndpointResult>
DnsHostCacheRustReference::Entry::GetEndpoints() const {
  std::vector<HostResolverEndpointResult> endpoints;

  if (ip_endpoints_.empty()) {
    return endpoints;
  }

  std::vector<ConnectionEndpointMetadata> metadatas = GetMetadatas();

  if (!metadatas.empty() && canonical_names_.size() == 1) {
    // Currently Chrome uses HTTPS records only when A and AAAA records are at
    // the same canonical name and that matches the HTTPS target name.
    for (ConnectionEndpointMetadata& metadata : metadatas) {
      if (!canonical_names_.contains(metadata.target_name)) {
        continue;
      }
      endpoints.emplace_back();
      endpoints.back().ip_endpoints = ip_endpoints_;
      endpoints.back().metadata = std::move(metadata);
    }
  }

  // Add a final non-alternative endpoint at the end.
  endpoints.emplace_back();
  endpoints.back().ip_endpoints = ip_endpoints_;

  return endpoints;
}

std::vector<ConnectionEndpointMetadata>
DnsHostCacheRustReference::Entry::GetMetadatas() const {
  std::vector<ConnectionEndpointMetadata> metadatas;
  HttpsRecordPriority last_priority = 0;
  for (const auto& metadata : endpoint_metadatas_) {
    // Ensure metadatas are iterated in priority order.
    DCHECK_GE(metadata.first, last_priority);
    last_priority = metadata.first;

    metadatas.push_back(metadata.second);
  }

  return metadatas;
}

std::optional<base::TimeDelta>
DnsHostCacheRustReference::Entry::GetOptionalTtl() const {
  if (has_ttl()) {
    return ttl();
  } else {
    return std::nullopt;
  }
}

// static
DnsHostCacheRustReference::Entry DnsHostCacheRustReference::Entry::MergeEntries(
    Entry front,
    Entry back) {
  // Only expected to merge OK or ERR_NAME_NOT_RESOLVED results.
  DCHECK(front.error() == OK || front.error() == ERR_NAME_NOT_RESOLVED);
  DCHECK(back.error() == OK || back.error() == ERR_NAME_NOT_RESOLVED);

  // Build results in |front| to preserve unmerged fields.

  front.error_ =
      front.error() == OK || back.error() == OK ? OK : ERR_NAME_NOT_RESOLVED;

  MergeLists(front.ip_endpoints_, back.ip_endpoints_);
  MergeContainers(front.endpoint_metadatas_, back.endpoint_metadatas_);
  MergeContainers(front.aliases_, back.aliases_);
  MergeLists(front.text_records_, back.text_records());
  MergeLists(front.hostnames_, back.hostnames());
  MergeContainers(front.canonical_names_, back.canonical_names_);

  // Only expected to merge entries from same source.
  DCHECK_EQ(front.source(), back.source());

  if (front.has_ttl() && back.has_ttl()) {
    front.ttl_ = std::min(front.ttl(), back.ttl());
  } else if (back.has_ttl()) {
    front.ttl_ = back.ttl();
  }

  front.expires_ = std::min(front.expires(), back.expires());
  front.network_changes_ =
      std::max(front.network_changes(), back.network_changes());

  front.total_hits_ = front.total_hits_ + back.total_hits_;
  front.stale_hits_ = front.stale_hits_ + back.stale_hits_;

  return front;
}

DnsHostCacheRustReference::Entry
DnsHostCacheRustReference::Entry::CopyWithDefaultPort(uint16_t port) const {
  Entry copy(*this);

  for (IPEndPoint& endpoint : copy.ip_endpoints_) {
    if (endpoint.port() == 0) {
      endpoint = endpoint.CopyWithPort(port);
    }
  }

  for (HostPortPair& hostname : copy.hostnames_) {
    // Hostnames are mutable, unlike IPEndPoints, so can overwrite only the
    // ports.
    if (hostname.port() == 0) {
      hostname.set_port(port);
    }
  }

  return copy;
}

std::vector<ServiceEndpoint>
DnsHostCacheRustReference::Entry::ConvertToServiceEndpoints(
    uint16_t port) const {
  std::vector<ServiceEndpoint> endpoints;

  std::vector<IPEndPoint> ipv4_endpoints;
  std::vector<IPEndPoint> ipv6_endpoints;
  for (const auto& ip_endpoint : ip_endpoints()) {
    std::vector<IPEndPoint>& ip_endpoints =
        ip_endpoint.address().IsIPv6() ? ipv6_endpoints : ipv4_endpoints;
    if (ip_endpoint.port() == 0) {
      ip_endpoints.push_back(ip_endpoint.CopyWithPort(port));
    } else {
      ip_endpoints.push_back(ip_endpoint);
    }
  }

  // See DnsHostCacheRustReference::Entry::GetEndpoints.
  if (!ipv4_endpoints.empty() || !ipv6_endpoints.empty()) {
    for (const auto& metadata : GetMetadatas()) {
      if (!canonical_names().contains(metadata.target_name)) {
        continue;
      }

      ServiceEndpoint endpoint;
      endpoint.ipv4_endpoints = ipv4_endpoints;
      endpoint.ipv6_endpoints = ipv6_endpoints;
      endpoint.metadata = metadata;
      endpoints.emplace_back(std::move(endpoint));
    }

    // Append Non-SVCB endpoints at the end for fallback.
    // TODO(crbug.com/41493696): Revisit how to handle non-SVCB endpoints if
    // Chrome supports HTTPS follow-up queries and aliases.
    ServiceEndpoint non_alternative_endpoint;
    non_alternative_endpoint.ipv4_endpoints = ipv4_endpoints;
    non_alternative_endpoint.ipv6_endpoints = ipv6_endpoints;
    endpoints.emplace_back(std::move(non_alternative_endpoint));
  }

  return endpoints;
}

DnsHostCacheRustReference::Entry& DnsHostCacheRustReference::Entry::operator=(
    const Entry& entry) = default;

DnsHostCacheRustReference::Entry& DnsHostCacheRustReference::Entry::operator=(
    Entry&& entry) = default;

DnsHostCacheRustReference::Entry::Entry(int error,
                                        std::vector<IPEndPoint> ip_endpoints,
                                        base::flat_set<std::string> aliases,
                                        Source source,
                                        std::optional<base::TimeDelta> ttl)
    : error_(error),
      ip_endpoints_(std::move(ip_endpoints)),
      aliases_(std::move(aliases)),
      source_(source),
      ttl_(ttl ? ttl.value() : kUnknownTtl) {
  DCHECK(!ttl || ttl.value() >= base::TimeDelta());
}

DnsHostCacheRustReference::Entry::Entry(
    const DnsHostCacheRustReference::Entry& entry,
    base::TimeTicks now,
    base::TimeDelta ttl,
    int network_changes)
    : error_(entry.error()),
      ip_endpoints_(entry.ip_endpoints_),
      endpoint_metadatas_(entry.endpoint_metadatas_),
      aliases_(entry.aliases()),
      text_records_(entry.text_records()),
      hostnames_(entry.hostnames()),
      source_(entry.source()),
      pinning_(entry.pinning()),
      canonical_names_(entry.canonical_names()),
      ttl_(entry.ttl()),
      expires_(now + ttl),
      network_changes_(network_changes) {}

DnsHostCacheRustReference::Entry::Entry(
    int error,
    std::vector<IPEndPoint> ip_endpoints,
    std::multimap<HttpsRecordPriority, ConnectionEndpointMetadata>
        endpoint_metadatas,
    base::flat_set<std::string> aliases,
    std::vector<std::string>&& text_records,
    std::vector<HostPortPair>&& hostnames,
    Source source,
    base::TimeTicks expires,
    int network_changes)
    : error_(error),
      ip_endpoints_(std::move(ip_endpoints)),
      endpoint_metadatas_(std::move(endpoint_metadatas)),
      aliases_(std::move(aliases)),
      text_records_(std::move(text_records)),
      hostnames_(std::move(hostnames)),
      source_(source),
      expires_(expires),
      network_changes_(network_changes) {}

bool DnsHostCacheRustReference::Entry::IsStale(base::TimeTicks now,
                                               int network_changes) const {
  EntryStaleness stale;
  stale.expired_by = now - expires_;
  stale.network_changes = network_changes - network_changes_;
  stale.stale_hits = stale_hits_;
  return stale.is_stale();
}

void DnsHostCacheRustReference::Entry::CountHit(bool hit_is_stale) {
  ++total_hits_;
  if (hit_is_stale) {
    ++stale_hits_;
  }
}

void DnsHostCacheRustReference::Entry::GetStaleness(base::TimeTicks now,
                                                    int network_changes,
                                                    EntryStaleness* out) const {
  DCHECK(out);
  out->expired_by = now - expires_;
  out->network_changes = network_changes - network_changes_;
  out->stale_hits = stale_hits_;
}

base::Value DnsHostCacheRustReference::Entry::NetLogParams() const {
  return base::Value(GetAsValue(false /* include_staleness */));
}

base::DictValue DnsHostCacheRustReference::Entry::GetAsValue(
    bool include_staleness) const {
  base::DictValue entry_dict;

  if (include_staleness) {
    // The kExpirationKey value is using TimeTicks instead of Time used if
    // |include_staleness| is false, so it cannot be used to deserialize.
    // This is ok as it is used only for netlog.
    entry_dict.Set(kExpirationKey, NetLog::TickCountToString(expires()));
    entry_dict.Set(kTtlKey, base::saturated_cast<int>(ttl().InMilliseconds()));
    entry_dict.Set(kNetworkChangesKey, network_changes());
    // The "pinned" status is meaningful only if "network_changes" is also
    // preserved.
    if (pinning()) {
      entry_dict.Set(kPinnedKey, *pinning());
    }
  } else {
    // Convert expiration time in TimeTicks to Time for serialization, using a
    // string because base::Value doesn't handle 64-bit integers.
    base::Time expiration_time =
        base::Time::Now() - (base::TimeTicks::Now() - expires());
    entry_dict.Set(kExpirationKey,
                   base::NumberToString(expiration_time.ToInternalValue()));
  }

  if (error() != OK) {
    entry_dict.Set(kNetErrorKey, error());
  } else {
    base::ListValue ip_endpoints_list;
    for (const IPEndPoint& ip_endpoint : ip_endpoints_) {
      ip_endpoints_list.Append(IpEndpointToValue(ip_endpoint));
    }
    entry_dict.Set(kIpEndpointsKey, std::move(ip_endpoints_list));

    base::ListValue endpoint_metadatas_list;
    for (const auto& endpoint_metadata_pair : endpoint_metadatas_) {
      endpoint_metadatas_list.Append(
          EndpointMetadataPairToValue(endpoint_metadata_pair));
    }
    entry_dict.Set(kEndpointMetadatasKey, std::move(endpoint_metadatas_list));

    base::ListValue alias_list;
    for (const std::string& alias : aliases()) {
      alias_list.Append(alias);
    }
    entry_dict.Set(kAliasesKey, std::move(alias_list));

    // Append all resolved text records.
    base::ListValue text_list_value;
    for (const std::string& text_record : text_records()) {
      text_list_value.Append(text_record);
    }
    entry_dict.Set(kTextRecordsKey, std::move(text_list_value));

    // Append all the resolved hostnames.
    base::ListValue hostnames_value;
    base::ListValue host_ports_value;
    for (const HostPortPair& hostname : hostnames()) {
      hostnames_value.Append(hostname.host());
      host_ports_value.Append(hostname.port());
    }
    entry_dict.Set(kHostnameResultsKey, std::move(hostnames_value));
    entry_dict.Set(kHostPortsKey, std::move(host_ports_value));

    base::ListValue canonical_names_list;
    for (const std::string& canonical_name : canonical_names()) {
      canonical_names_list.Append(canonical_name);
    }
    entry_dict.Set(kCanonicalNamesKey, std::move(canonical_names_list));
  }

  return entry_dict;
}

// static
std::optional<base::TimeDelta>
DnsHostCacheRustReference::Entry::TtlFromInternalResults(
    const std::set<std::unique_ptr<HostResolverInternalResult>>& results,
    base::Time now,
    base::TimeTicks now_ticks) {
  std::optional<base::TimeDelta> smallest_ttl;
  for (const std::unique_ptr<HostResolverInternalResult>& result : results) {
    if (result->expiration().has_value()) {
      smallest_ttl = std::min(smallest_ttl.value_or(base::TimeDelta::Max()),
                              result->expiration().value() - now_ticks);
    }
    if (result->timed_expiration().has_value()) {
      smallest_ttl = std::min(smallest_ttl.value_or(base::TimeDelta::Max()),
                              result->timed_expiration().value() - now);
    }
  }
  return smallest_ttl;
}

// static
const DnsHostCacheRustReference::EntryStaleness
    DnsHostCacheRustReference::kNotStale = {base::Seconds(-1), 0, 0};

DnsHostCacheRustReference::DnsHostCacheRustReference(size_t max_entries)
    : max_entries_(max_entries),
      tick_clock_(base::DefaultTickClock::GetInstance()) {}

DnsHostCacheRustReference::~DnsHostCacheRustReference() {
  DCHECK_CALLED_ON_VALID_THREAD(thread_checker_);
  RecordEraseAll(EraseReason::kEraseDestruct, tick_clock_->NowTicks());
}

const std::pair<const DnsHostCacheRustReference::Key,
                DnsHostCacheRustReference::Entry>*
DnsHostCacheRustReference::Lookup(const Key& key,
                                  base::TimeTicks now,
                                  bool ignore_secure,
                                  bool record_metrics) {
  DCHECK_CALLED_ON_VALID_THREAD(thread_checker_);
  if (caching_is_disabled()) {
    return nullptr;
  }

  auto* result = LookupInternalIgnoringFields(key, now, ignore_secure);
  if (!result) {
    if (record_metrics) {
      RecordLookup(LookupOutcome::kLookupMissAbsent, now, key, nullptr);
    }
    return nullptr;
  }

  auto* entry = &result->second;
  if (entry->IsStale(now, network_changes_)) {
    if (record_metrics) {
      RecordLookup(LookupOutcome::kLookupMissStale, now, result->first, entry);
    }
    return nullptr;
  }

  entry->CountHit(/* hit_is_stale= */ false);
  if (record_metrics) {
    RecordLookup(LookupOutcome::kLookupHitValid, now, result->first, entry);
  }
  return result;
}

const std::pair<const DnsHostCacheRustReference::Key,
                DnsHostCacheRustReference::Entry>*
DnsHostCacheRustReference::LookupStale(
    const Key& key,
    base::TimeTicks now,
    DnsHostCacheRustReference::EntryStaleness* stale_out,
    bool ignore_secure,
    bool record_metrics) {
  DCHECK_CALLED_ON_VALID_THREAD(thread_checker_);
  if (caching_is_disabled()) {
    return nullptr;
  }

  auto* result = LookupInternalIgnoringFields(key, now, ignore_secure);
  if (!result) {
    if (record_metrics) {
      RecordLookup(LookupOutcome::kLookupMissAbsent, now, key, nullptr);
    }
    return nullptr;
  }

  auto* entry = &result->second;
  bool is_stale = entry->IsStale(now, network_changes_);
  entry->CountHit(/* hit_is_stale= */ is_stale);
  if (record_metrics) {
    RecordLookup(is_stale ? LookupOutcome::kLookupHitStale
                          : LookupOutcome::kLookupHitValid,
                 now, result->first, entry);
  }

  if (stale_out) {
    entry->GetStaleness(now, network_changes_, stale_out);
  }
  return result;
}

// static
std::pair<const DnsHostCacheRustReference::Key,
          DnsHostCacheRustReference::Entry>*
DnsHostCacheRustReference::GetLessStaleMoreSecureResult(
    base::TimeTicks now,
    std::pair<const DnsHostCacheRustReference::Key,
              DnsHostCacheRustReference::Entry>* result1,
    std::pair<const DnsHostCacheRustReference::Key,
              DnsHostCacheRustReference::Entry>* result2) {
  // Prefer a non-null result if possible.
  if (!result1 && !result2) {
    return nullptr;
  }
  if (result1 && !result2) {
    return result1;
  }
  if (!result1 && result2) {
    return result2;
  }

  // Both result1 are result2 are non-null.
  EntryStaleness staleness1, staleness2;
  result1->second.GetStaleness(now, 0, &staleness1);
  result2->second.GetStaleness(now, 0, &staleness2);
  if (staleness1.network_changes == staleness2.network_changes) {
    // Exactly one of the results should be secure.
    DCHECK(result1->first.secure != result2->first.secure);
    // If the results have the same number of network changes, prefer a
    // non-expired result.
    if (staleness1.expired_by.is_negative() &&
        staleness2.expired_by >= base::TimeDelta()) {
      return result1;
    }
    if (staleness1.expired_by >= base::TimeDelta() &&
        staleness2.expired_by.is_negative()) {
      return result2;
    }
    // Both results are equally stale, so prefer a secure result.
    return (result1->first.secure) ? result1 : result2;
  }
  // Prefer the result with the fewest network changes.
  return (staleness1.network_changes < staleness2.network_changes) ? result1
                                                                   : result2;
}

std::pair<const DnsHostCacheRustReference::Key,
          DnsHostCacheRustReference::Entry>*
DnsHostCacheRustReference::LookupInternalIgnoringFields(const Key& initial_key,
                                                        base::TimeTicks now,
                                                        bool ignore_secure) {
  std::pair<const DnsHostCacheRustReference::Key,
            DnsHostCacheRustReference::Entry>* preferred_result =
      LookupInternal(initial_key);

  if (ignore_secure) {
    Key effective_key = initial_key;
    effective_key.secure = !initial_key.secure;
    preferred_result = GetLessStaleMoreSecureResult(
        now, preferred_result, LookupInternal(effective_key));
  }

  return preferred_result;
}

std::pair<const DnsHostCacheRustReference::Key,
          DnsHostCacheRustReference::Entry>*
DnsHostCacheRustReference::LookupInternal(const Key& key) {
  auto it = entries_.find(key);
  return (it != entries_.end()) ? &*it : nullptr;
}

void DnsHostCacheRustReference::Set(const Key& key,
                                    const Entry& entry,
                                    base::TimeTicks now,
                                    base::TimeDelta ttl) {
  TRACE_EVENT0(NetTracingCategory(), "DnsHostCacheRustReference::Set");
  DCHECK_CALLED_ON_VALID_THREAD(thread_checker_);
  if (caching_is_disabled()) {
    return;
  }

  bool has_active_pin = false;
  bool result_changed = false;
  auto it = entries_.find(key);
  if (it != entries_.end()) {
    has_active_pin = HasActivePin(it->second);

    // TODO(juliatuttle): Remember some old metadata (hit count or frequency or
    // something like that) if it's useful for better eviction algorithms?
    result_changed = entry.error() == OK && !it->second.ContentsEqual(entry);
    entries_.erase(it);
  } else {
    result_changed = true;
    // This loop almost always runs at most once, for total runtime
    // O(max_entries_).  It only runs more than once if the cache was over-full
    // due to pinned entries, and this is the first call to Set() after
    // Invalidate().  The amortized cost remains O(size()) per call to Set().
    while (size() >= max_entries_ && EvictOneEntry(now)) {
    }
  }

  Entry entry_for_cache(entry, now, ttl, network_changes_);
  entry_for_cache.set_pinning(entry.pinning().value_or(has_active_pin));
  AddEntry(key, std::move(entry_for_cache));

  if (delegate_ && result_changed) {
    delegate_->ScheduleWrite();
  }
}

const DnsHostCacheRustReference::Key*
DnsHostCacheRustReference::GetMatchingKeyForTesting(
    std::string_view hostname,
    DnsHostCacheRustReference::Entry::Source* source_out,
    DnsHostCacheRustReference::EntryStaleness* stale_out) const {
  for (const EntryMap::value_type& entry : entries_) {
    if (GetHostname(entry.first.host) == hostname) {
      if (source_out != nullptr) {
        *source_out = entry.second.source();
      }
      if (stale_out != nullptr) {
        entry.second.GetStaleness(tick_clock_->NowTicks(), network_changes_,
                                  stale_out);
      }
      return &entry.first;
    }
  }

  return nullptr;
}

void DnsHostCacheRustReference::AddEntry(const Key& key, Entry&& entry) {
  DCHECK_EQ(0u, entries_.count(key));
  DCHECK(entry.pinning().has_value());
  entries_.emplace(key, std::move(entry));
}

void DnsHostCacheRustReference::Invalidate() {
  ++network_changes_;
}

void DnsHostCacheRustReference::set_persistence_delegate(
    PersistenceDelegate* delegate) {
  // A PersistenceDelegate shouldn't be added if there already was one, and
  // shouldn't be removed (by setting to nullptr) if it wasn't previously there.
  DCHECK_NE(delegate == nullptr, delegate_ == nullptr);
  delegate_ = delegate;
}

void DnsHostCacheRustReference::clear() {
  DCHECK_CALLED_ON_VALID_THREAD(thread_checker_);
  RecordEraseAll(EraseReason::kEraseClear, tick_clock_->NowTicks());

  // Don't bother scheduling a write if there's nothing to clear.
  if (size() == 0) {
    return;
  }

  entries_.clear();
  if (delegate_) {
    delegate_->ScheduleWrite();
  }
}

void DnsHostCacheRustReference::ClearForHosts(
    const base::RepeatingCallback<bool(const std::string&)>& host_filter) {
  DCHECK_CALLED_ON_VALID_THREAD(thread_checker_);

  if (host_filter.is_null()) {
    clear();
    return;
  }

  bool changed = false;
  base::TimeTicks now = tick_clock_->NowTicks();
  for (auto it = entries_.begin(); it != entries_.end();) {
    auto next_it = std::next(it);

    if (host_filter.Run(GetHostname(it->first.host))) {
      RecordErase(EraseReason::kEraseClear, now, it->first, it->second);
      entries_.erase(it);
      changed = true;
    }

    it = next_it;
  }

  if (delegate_ && changed) {
    delegate_->ScheduleWrite();
  }
}

void DnsHostCacheRustReference::GetList(
    base::ListValue& entry_list,
    bool include_staleness,
    SerializationType serialization_type) const {
  entry_list.clear();

  for (const auto& pair : entries_) {
    const Key& key = pair.first;
    const Entry& entry = pair.second;

    base::Value network_anonymization_key_value;
    if (serialization_type == SerializationType::kRestorable) {
      // Don't save entries associated with ephemeral NetworkAnonymizationKeys.
      if (!key.network_anonymization_key.ToValue(
              &network_anonymization_key_value)) {
        continue;
      }
      // Don't save entries associated with a specific network.
      if (key.target_network != handles::kInvalidNetworkHandle) {
        continue;
      }
    } else {
      // ToValue() fails for transient NAKs, since they should never be
      // serialized to disk in a restorable format, so use ToDebugString() when
      // serializing for debugging instead of for restoring from disk.
      network_anonymization_key_value =
          base::Value(key.network_anonymization_key.ToDebugString());
    }

    base::DictValue entry_dict = entry.GetAsValue(include_staleness);

    const auto* host = std::get_if<url::SchemeHostPort>(&key.host);
    if (host) {
      entry_dict.Set(kSchemeKey, host->scheme());
      entry_dict.Set(kHostnameKey, host->host());
      entry_dict.Set(kPortKey, host->port());
    } else {
      entry_dict.Set(kHostnameKey, std::get<std::string>(key.host));
    }

    entry_dict.Set(kDnsQueryTypeKey,
                   base::strict_cast<int>(key.dns_query_type));
    entry_dict.Set(kFlagsKey, key.host_resolver_flags);
    entry_dict.Set(kHostResolverSourceKey,
                   base::strict_cast<int>(key.host_resolver_source));
    entry_dict.Set(kNetworkAnonymizationKey,
                   std::move(network_anonymization_key_value));
    entry_dict.Set(kSecureKey, key.secure);

    if (serialization_type == SerializationType::kDebug) {
      entry_dict.Set(kTargetNetworkKey,
                     base::NumberToString(key.target_network));
    }

    entry_list.Append(std::move(entry_dict));
  }
}

bool DnsHostCacheRustReference::RestoreFromListValue(
    const base::ListValue& old_cache) {
  // Reset the restore size to 0.
  restore_size_ = 0;

  for (const auto& entry : old_cache) {
    // If the cache is already full, don't bother prioritizing what to evict,
    // just stop restoring.
    if (size() == max_entries_) {
      break;
    }

    if (!entry.is_dict()) {
      return false;
    }

    const base::DictValue& entry_dict = entry.GetDict();
    const std::string* hostname_ptr = entry_dict.FindString(kHostnameKey);
    if (!hostname_ptr || !IsValidHostname(*hostname_ptr)) {
      return false;
    }

    // Use presence of scheme to determine host type.
    const std::string* scheme_ptr = entry_dict.FindString(kSchemeKey);
    std::variant<url::SchemeHostPort, std::string> host;
    if (scheme_ptr) {
      std::optional<int> port = entry_dict.FindInt(kPortKey);
      if (!port ||
          !base::IsValueInRangeForNumericType<uint16_t>(port.value())) {
        return false;
      }

      url::SchemeHostPort scheme_host_port(*scheme_ptr, *hostname_ptr,
                                           port.value());
      if (!scheme_host_port.IsValid()) {
        return false;
      }
      host = std::move(scheme_host_port);
    } else {
      host = *hostname_ptr;
    }

    const std::string* expiration_ptr = entry_dict.FindString(kExpirationKey);
    std::optional<int> maybe_flags = entry_dict.FindInt(kFlagsKey);
    if (expiration_ptr == nullptr || !maybe_flags.has_value()) {
      return false;
    }
    std::string expiration(*expiration_ptr);
    HostResolverFlags flags = maybe_flags.value();

    std::optional<int> maybe_dns_query_type =
        entry_dict.FindInt(kDnsQueryTypeKey);
    if (!maybe_dns_query_type.has_value()) {
      return false;
    }
    std::optional<DnsQueryType> dns_query_type =
        GetDnsQueryType(maybe_dns_query_type.value());
    if (!dns_query_type.has_value()) {
      return false;
    }
    // HostResolverSource is optional.
    int host_resolver_source =
        entry_dict.FindInt(kHostResolverSourceKey)
            .value_or(base::strict_cast<int>(HostResolverSource::ANY));

    const base::Value* network_anonymization_key_value =
        entry_dict.Find(kNetworkAnonymizationKey);
    if (!network_anonymization_key_value ||
        network_anonymization_key_value->type() == base::Value::Type::STRING) {
      return false;
    }
    NetworkAnonymizationKey network_anonymization_key;
    if (!NetworkAnonymizationKey::FromValue(*network_anonymization_key_value,
                                            &network_anonymization_key)) {
      // The key may be from an older version of Chrome, and use a format or
      // values that are no longer supported (e.g., a NetworkIsolationPartition
      // that has since been removed). Skip just this entry, rather than
      // failing to restore the whole cache.
      continue;
    }

    bool secure = entry_dict.FindBool(kSecureKey).value_or(false);

    int error = OK;
    const base::ListValue* ip_endpoints_list = nullptr;
    const base::ListValue* endpoint_metadatas_list = nullptr;
    const base::ListValue* aliases_list = nullptr;
    const base::ListValue* legacy_addresses_list = nullptr;
    const base::ListValue* text_records_list = nullptr;
    const base::ListValue* hostname_records_list = nullptr;
    const base::ListValue* host_ports_list = nullptr;
    const base::ListValue* canonical_names_list = nullptr;
    std::optional<int> maybe_error = entry_dict.FindInt(kNetErrorKey);
    std::optional<bool> maybe_pinned = entry_dict.FindBool(kPinnedKey);
    if (maybe_error.has_value()) {
      error = maybe_error.value();
    } else {
      ip_endpoints_list = entry_dict.FindList(kIpEndpointsKey);
      endpoint_metadatas_list = entry_dict.FindList(kEndpointMetadatasKey);
      aliases_list = entry_dict.FindList(kAliasesKey);
      legacy_addresses_list = entry_dict.FindList(kAddressesKey);
      text_records_list = entry_dict.FindList(kTextRecordsKey);
      hostname_records_list = entry_dict.FindList(kHostnameResultsKey);
      host_ports_list = entry_dict.FindList(kHostPortsKey);
      canonical_names_list = entry_dict.FindList(kCanonicalNamesKey);

      if ((hostname_records_list == nullptr && host_ports_list != nullptr) ||
          (hostname_records_list != nullptr && host_ports_list == nullptr)) {
        return false;
      }
    }

    int64_t time_internal;
    if (!base::StringToInt64(expiration, &time_internal)) {
      return false;
    }

    base::TimeTicks expiration_time =
        tick_clock_->NowTicks() -
        (base::Time::Now() - base::Time::FromInternalValue(time_internal));

    std::vector<IPEndPoint> ip_endpoints;
    if (ip_endpoints_list) {
      bool interface_unavailable = false;
      for (const base::Value& ip_endpoint_value : *ip_endpoints_list) {
        std::optional<IPEndPoint> ip_endpoint =
            IpEndpointFromValue(ip_endpoint_value);
        if (!ip_endpoint) {
          const base::DictValue* ep_dict = ip_endpoint_value.GetIfDict();
          if (ep_dict && ep_dict->FindString(kInterfaceNameKey)) {
            interface_unavailable = true;
            break;
          }
          return false;
        }
        ip_endpoints.push_back(std::move(ip_endpoint).value());
      }
      if (interface_unavailable) {
        continue;
      }
    }

    std::multimap<HttpsRecordPriority, ConnectionEndpointMetadata>
        endpoint_metadatas;
    if (endpoint_metadatas_list) {
      for (const base::Value& endpoint_metadata_value :
           *endpoint_metadatas_list) {
        std::optional<
            std::pair<HttpsRecordPriority, ConnectionEndpointMetadata>>
            pair = EndpointMetadataPairFromValue(endpoint_metadata_value);
        if (!pair) {
          return false;
        }
        endpoint_metadatas.insert(std::move(pair).value());
      }
    }

    std::vector<std::string> aliases;
    if (aliases_list) {
      aliases.reserve(aliases_list->size());
      for (const base::Value& alias_value : *aliases_list) {
        if (!alias_value.is_string()) {
          return false;
        }
        aliases.push_back(alias_value.GetString());
      }
    }

    // `addresses` field was supported until M105. We keep reading this field
    // for backward compatibility for several milestones.
    if (legacy_addresses_list) {
      if (!ip_endpoints.empty()) {
        return false;
      }
      if (!IPEndPointsFromLegacyAddressListValue(*legacy_addresses_list,
                                                 ip_endpoints)) {
        return false;
      }
    }

    std::vector<std::string> text_records;
    if (text_records_list) {
      for (const base::Value& value : *text_records_list) {
        if (!value.is_string()) {
          return false;
        }
        text_records.push_back(value.GetString());
      }
    }

    std::vector<HostPortPair> hostname_records;
    if (hostname_records_list) {
      DCHECK(host_ports_list);
      if (hostname_records_list->size() != host_ports_list->size()) {
        return false;
      }

      for (size_t i = 0; i < hostname_records_list->size(); ++i) {
        if (!(*hostname_records_list)[i].is_string() ||
            !(*host_ports_list)[i].is_int() ||
            !base::IsValueInRangeForNumericType<uint16_t>(
                (*host_ports_list)[i].GetInt())) {
          return false;
        }
        hostname_records.emplace_back(
            (*hostname_records_list)[i].GetString(),
            base::checked_cast<uint16_t>((*host_ports_list)[i].GetInt()));
      }
    }

    std::set<std::string> canonical_names;
    if (canonical_names_list) {
      for (const auto& item : *canonical_names_list) {
        const std::string* name = item.GetIfString();
        if (!name) {
          return false;
        }
        canonical_names.insert(*name);
      }
    }

    Key key(std::move(host), dns_query_type.value(), flags,
            static_cast<HostResolverSource>(host_resolver_source),
            network_anonymization_key, handles::kInvalidNetworkHandle);
    key.secure = secure;

    // If the key is already in the cache, assume it's more recent and don't
    // replace the entry.
    auto found = entries_.find(key);
    if (found == entries_.end()) {
      Entry new_entry(
          error, std::move(ip_endpoints), std::move(endpoint_metadatas),
          base::flat_set<std::string>(std::move(aliases)),
          std::move(text_records), std::move(hostname_records),
          Entry::SOURCE_UNKNOWN, expiration_time, network_changes_ - 1);
      new_entry.set_pinning(maybe_pinned.value_or(false));
      new_entry.set_canonical_names(std::move(canonical_names));
      AddEntry(key, std::move(new_entry));
      restore_size_++;
    }
  }
  return true;
}

size_t DnsHostCacheRustReference::size() const {
  DCHECK_CALLED_ON_VALID_THREAD(thread_checker_);
  return entries_.size();
}

size_t DnsHostCacheRustReference::max_entries() const {
  DCHECK_CALLED_ON_VALID_THREAD(thread_checker_);
  return max_entries_;
}

bool DnsHostCacheRustReference::EvictOneEntry(base::TimeTicks now) {
  DCHECK_LT(0u, entries_.size());

  std::optional<net::DnsHostCacheRustReference::EntryMap::iterator> oldest_it;
  for (auto it = entries_.begin(); it != entries_.end(); ++it) {
    const Entry& entry = it->second;
    if (HasActivePin(entry)) {
      continue;
    }

    if (!oldest_it) {
      oldest_it = it;
      continue;
    }

    const Entry& oldest = (*oldest_it)->second;
    if ((entry.expires() < oldest.expires()) &&
        (entry.IsStale(now, network_changes_) ||
         !oldest.IsStale(now, network_changes_))) {
      oldest_it = it;
    }
  }

  if (oldest_it) {
    RecordErase(EraseReason::kEraseEvict, now, (*oldest_it)->first,
                (*oldest_it)->second);
    entries_.erase(*oldest_it);
    return true;
  }
  return false;
}

bool DnsHostCacheRustReference::HasActivePin(const Entry& entry) {
  return entry.pinning().value_or(false) &&
         entry.network_changes() == network_changes();
}

void DnsHostCacheRustReference::RecordLookup(LookupOutcome outcome,
                                             base::TimeTicks now,
                                             const Key& key,
                                             const Entry* entry) {
  base::UmaHistogramEnumeration(GetHistogramName("Lookup", key), outcome);
  if (outcome == LookupOutcome::kLookupHitStale) {
    CHECK_NE(entry, nullptr);
    base::UmaHistogramLongTimes(GetHistogramName("LookupStale.ExpiredBy", key),
                                now - entry->expires());
    base::UmaHistogramCounts1000(
        GetHistogramName("LookupStale.NetworkChanges", key),
        network_changes_ - entry->network_changes());
  }
}

void DnsHostCacheRustReference::RecordErase(EraseReason reason,
                                            base::TimeTicks now,
                                            const Key& key,
                                            const Entry& entry) {
  DnsHostCacheRustReference::EntryStaleness stale;
  entry.GetStaleness(now, network_changes_, &stale);
  base::UmaHistogramEnumeration(GetHistogramName("Erase", key), reason);
  if (stale.is_stale()) {
    base::UmaHistogramLongTimes(GetHistogramName("EraseStale.ExpiredBy", key),
                                stale.expired_by);
    base::UmaHistogramCounts1000(
        GetHistogramName("EraseStale.NetworkChanges", key),
        stale.network_changes);
    base::UmaHistogramCounts1000(GetHistogramName("EraseStale.StaleHits", key),
                                 entry.stale_hits());
  } else {
    base::UmaHistogramLongTimes(GetHistogramName("EraseValid.ValidFor", key),
                                -stale.expired_by);
  }
}

void DnsHostCacheRustReference::RecordEraseAll(EraseReason reason,
                                               base::TimeTicks now) {
  for (const auto& it : entries_) {
    RecordErase(reason, now, it.first, it.second);
  }
}

}  // namespace net

// Debug logging support
std::ostream& operator<<(
    std::ostream& out,
    const net::DnsHostCacheRustReference::EntryStaleness& s) {
  return out << "EntryStaleness{" << s.expired_by << ", " << s.network_changes
             << ", " << s.stale_hits << "}";
}
