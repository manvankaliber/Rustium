// Copyright 2020 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "net/cookies/cookie_access_result.h"
#include "net/cookies/cookie_family_native.h"

#include "net/cookies/cookie_constants.h"

namespace net {

CookieAccessResult::CookieAccessResult() = default;

CookieAccessResult::CookieAccessResult(
    CookieEffectiveSameSite effective_same_site,
    CookieInclusionStatus status,
    CookieAccessSemantics access_semantics,
    CookieScopeSemantics scope_semantics,
    bool is_allowed_to_access_secure_cookies)
    : status(status),
      effective_same_site(effective_same_site),
      access_semantics(access_semantics),
      scope_semantics(scope_semantics),
      is_allowed_to_access_secure_cookies(is_allowed_to_access_secure_cookies) {
}

CookieAccessResult::CookieAccessResult(CookieInclusionStatus status)
    : status(status) {}

CookieAccessResult::CookieAccessResult(const CookieAccessResult&) = default;

CookieAccessResult& CookieAccessResult::operator=(
    const CookieAccessResult& cookie_access_result) = default;

CookieAccessResult::CookieAccessResult(CookieAccessResult&&) = default;

CookieAccessResult::~CookieAccessResult() = default;

bool operator==(const CookieAccessResult& left,const CookieAccessResult& right) {
  CookieFamilyRequest request{};request.access=cookie_family::Snapshot(left);request.other_access=cookie_family::Snapshot(right);
  return cookie_family::Run(44,request).scalar;
}

}  // namespace net
