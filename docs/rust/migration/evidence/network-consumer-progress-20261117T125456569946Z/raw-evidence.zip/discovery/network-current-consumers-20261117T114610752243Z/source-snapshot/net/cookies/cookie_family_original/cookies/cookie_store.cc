// Copyright 2012 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "net/cookies/cookie_family_original/cookies/cookie_store.h"

#include <utility>

#include "base/feature_list.h"
#include "base/functional/bind.h"
#include "base/functional/callback.h"
#include "net/base/features.h"

namespace net::cookie_family_original {

CookieStore::CookieStore() {
  // Initialize the feature at startup so that clients are assigned to
  // experiment groups before seeing specific cookies.
  base::FeatureList::IsEnabled(
      features::kCookieProcessBoundEncryptOnlyImportant);
}

CookieStore::~CookieStore() = default;

// Default implementation which returns a default vector of UNKNOWN
// CookieAccessSemantics.
void CookieStore::GetAllCookiesWithAccessSemanticsAsync(
    GetAllCookiesWithAccessSemanticsCallback callback) {
  GetAllCookiesCallback adapted_callback = base::BindOnce(
      [](CookieStore::GetAllCookiesWithAccessSemanticsCallback
             original_callback,
         const CookieList& cookies) {
        std::vector<CookieAccessSemantics> default_access_semantics_list;
        default_access_semantics_list.assign(cookies.size(),
                                             CookieAccessSemantics::UNKNOWN);
        std::move(original_callback)
            .Run(cookies, default_access_semantics_list);
      },
      std::move(callback));
  GetAllCookiesAsync(std::move(adapted_callback));
}

void CookieStore::DeleteAllAsync(DeleteCallback callback) {
  DeleteAllCreatedInTimeRangeAsync(CookieDeletionInfo::TimeRange(),
                                   std::move(callback));
}

void CookieStore::SetCookieAccessDelegate(
    std::unique_ptr<CookieAccessDelegate> delegate) {
  cookie_access_delegate_ = std::move(delegate);
}

std::optional<bool> CookieStore::SiteHasCookieInOtherPartition(
    const net::cookie_family_original::SchemefulSite& site,
    const CookiePartitionKey& partition_key) const {
  return std::nullopt;
}

void CookieStore::OnPreconnect(const GURL& url) {}

}  // namespace net
