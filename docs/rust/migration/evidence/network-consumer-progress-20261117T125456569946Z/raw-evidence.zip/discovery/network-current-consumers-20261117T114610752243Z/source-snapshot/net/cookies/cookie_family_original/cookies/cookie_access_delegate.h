// Copyright 2019 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef NET_COOKIE_FAMILY_ORIGINAL_COOKIES_COOKIE_ACCESS_DELEGATE_H_
#define NET_COOKIE_FAMILY_ORIGINAL_COOKIES_COOKIE_ACCESS_DELEGATE_H_

#include <optional>

#include "net/base/net_export.h"
#include "net/cookies/cookie_family_original/cookies/canonical_cookie.h"
#include "net/cookies/cookie_family_original/cookies/cookie_constants.h"
#include "net/cookies/cookie_family_original/cookies/cookie_partition_key.h"
#include "url/origin.h"

class GURL;

namespace net::cookie_family_original {

class SiteForCookies;

class CookieAccessDelegate {
 public:
  CookieAccessDelegate();

  CookieAccessDelegate(const CookieAccessDelegate&) = delete;
  CookieAccessDelegate& operator=(const CookieAccessDelegate&) = delete;

  virtual ~CookieAccessDelegate();

  // Returns true if the passed in |url| should be permitted to access secure
  // cookies in addition to URLs that normally do so. Returning false from this
  // method on a URL that would already be treated as secure by default, e.g. an
  // https:// one has no effect.
  virtual bool ShouldTreatUrlAsTrustworthy(const GURL& url) const;

  // Gets the access semantics to apply to |cookie|, based on its domain (i.e.,
  // whether a policy specifies that legacy access semantics should apply).
  virtual CookieAccessSemantics GetAccessSemantics(
      const CanonicalCookie& cookie) const = 0;

  // Gets the scope semantics to apply to based on the given domain (i.e.,
  // whether a policy specifies this legacy cookie scope should apply).
  virtual CookieScopeSemantics GetScopeSemantics(
      const std::string_view domain) const = 0;

  // Returns whether a cookie should be attached regardless of its SameSite
  // value vs the request context.
  virtual bool ShouldIgnoreSameSiteRestrictions(
      const GURL& url,
      const SiteForCookies& site_for_cookies,
      const url::Origin& top_level_origin) const = 0;
};

}  // namespace net

#endif  // NET_COOKIE_FAMILY_ORIGINAL_COOKIES_COOKIE_ACCESS_DELEGATE_H_
