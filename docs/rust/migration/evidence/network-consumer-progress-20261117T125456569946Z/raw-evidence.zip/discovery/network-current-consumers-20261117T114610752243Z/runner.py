import datetime,hashlib,importlib.util,json,pathlib,shutil,subprocess,sys
r=pathlib.Path('D:/Rustium');b=pathlib.Path('D:/RustiumBuild/src');rt=r/'.rustium-runtime';sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest();info=json.loads((rt/'shared-strings-connection-latest.json').read_text())
if len(sys.argv)==1:
 assert not (rt/'job-active.json').exists()
 obs=subprocess.check_output(['powershell','-NoProfile','-Command',"Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(ninja|clang-cl|lld-link|net_unittests|base_unittests|rustc|cargo).*' } | Select-Object ProcessId,Name,CommandLine | ConvertTo-Json"],text=True).strip();assert not obs,obs
 out=r/'.scratch/net-wave5'/('network-current-consumers-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
 request={'task_id':'NET-CURRENT-CONSUMER-CLOSURE','kind':'test','source_identity':info,'toolchain':{'script_sha256':sha(__file__),'gn_sha256':sha(b/'buildtools/win/gn.exe')},'build_configuration':{'scope':'Read-only fresh GN reverse-dependency capture plus current copied source/configuration identity; no compilation/native tests','configured':'D:/RustiumBuild/src/out/Default'},'cwd':str(r),'process_reconciliation':{'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'compilers_native_tests':[]}}
 p=rt/'network-current-refs-request.json';p.write_text(json.dumps(request,indent=2)+'\n');(rt/'network-current-refs-latest.json').write_text(json.dumps({'directory':str(out)}));token=json.loads((rt/'director.json').read_text())['token'];sys.exit(subprocess.call(['python','tools/rustium_coord.py','job','--token',token,'--manifest',str(p),'--','python','-B',__file__,str(out)],cwd=r))
out=pathlib.Path(sys.argv[1]);assert not out.exists();out.mkdir();sys.path.insert(0,str(r/'docs/rust/migration/drafts/base-ordinary-delivery'));import ordinary_base_v2 as delivery
result={'passed':False,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_manifest_sha256':info['source_manifest_sha256'],'source_count':info['source_count'],'scope':'Fresh current GN consumers and graph/source bindings only; not a complete ABI review, successful rebuild or native pass'};configuration=None;native=None;tool=sha(b/'buildtools/win/gn.exe')
try:
 pins=delivery.source_check(info);manifest=out/'source-sha256.json';shutil.copyfile(info['source_manifest'],manifest);assert sha(manifest)==info['source_manifest_sha256']
 for rel,h in pins.items():
  dest=out/'source-snapshot'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/rel,dest);assert sha(dest)==h and dest.stat().st_nlink==1
 native,registry,inspector=delivery.runtime_modules();configuration=delivery.configuration_identity(native);delivery.write(out/'configuration-before.json',configuration)
 command=[str(b/'buildtools/win/gn.exe'),'refs','out/Default','//net:net','//net/dns:dns_client','--all'];result['command']=command
 code=delivery.run_command(command,b,__import__('os').environ.copy(),out/'refs-net-dns.log',timeout=600);result['exit_code']=code
 delivery.source_check(info);assert sha(b/'buildtools/win/gn.exe')==tool
 result['passed']=code==0
except BaseException as error:
 result['exception']=type(error).__name__+': '+str(error)
 if isinstance(error,delivery.CommandFailure):result['command_failure']=error.details
finally:
 checks={}
 for name,check in [('source',lambda:delivery.source_check(info)),('configuration',lambda:delivery.require(configuration is not None and delivery.configuration_identity(native)==configuration,'Graph/configuration drift')),('gn',lambda:delivery.require(sha(b/'buildtools/win/gn.exe')==tool,'GN drift'))]:
  try:check();checks[name]=True
  except BaseException as error:checks[name]=str(error)
 result['postchecks']=checks;result['passed'] &= all(x is True for x in checks.values());result['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();delivery.write(out/'result.json',result);print(json.dumps(result))
sys.exit(0 if result['passed'] else 1)
