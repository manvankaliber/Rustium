// Copyright 2020 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef NET_DNS_DNS_RESOLUTION_ORIGINAL_DNS_SERVER_ITERATOR_H_
#define NET_DNS_DNS_RESOLUTION_ORIGINAL_DNS_SERVER_ITERATOR_H_

#include <stddef.h>
#include <vector>

#include "base/memory/weak_ptr.h"
#include "net/base/net_export.h"
#include "net/dns/public/secure_dns_mode.h"

#include "base/component_export.h"
#include "net/dns/dns_resolution_native_provider_aliases.h"
#include "net/dns/dns_resolution_manager_native_providers.h"
#include "net/dns/dns_resolution_result_types_rust_original.h"
#include "net/dns/dns_resolution_host_value_rust_original.h"
#include "net/dns/host_resolver_cache_rust_reference.h"
#include "net/dns/dns_resolution_request_interfaces_rust_original.h"
#include "net/base/host_port_rust_reference.h"

namespace net::dns_resolution_original {

using HostPortPair = ::net::HostPortRustReference;
using HostResolverCache = ::net::host_resolver_cache_reference::HostResolverCache;
using HostResolverInternalResult = ::net::host_resolver_cache_reference::HostResolverInternalResult;
using HostResolverInternalDataResult = ::net::host_resolver_cache_reference::HostResolverInternalDataResult;
using HostResolverInternalMetadataResult = ::net::host_resolver_cache_reference::HostResolverInternalMetadataResult;
using HostResolverInternalErrorResult = ::net::host_resolver_cache_reference::HostResolverInternalErrorResult;
using HostResolverInternalAliasResult = ::net::host_resolver_cache_reference::HostResolverInternalAliasResult;


class ResolveContext;

// Iterator used to get the next server to try for a DNS transaction.
// Each iterator should be scoped to a single query. A new query, therefore,
// requires a new iterator.
//
// Finds the first eligible server below the global failure limits
// (|max_failures|), or if no eligible servers are below failure limits, the
// eligible one with the oldest last failure. Global failures are tracked by
// ResolveContext.
//
// If |session| goes out of date, this iterator will report that no attempts are
// available and thus cease to return anything.
class COMPONENT_EXPORT(DNS_RESOLUTION_ORIGINAL) DnsServerIterator {
 public:
  DnsServerIterator(size_t nameservers_size,
                    size_t starting_index,
                    int max_times_returned,
                    int max_failures,
                    const ResolveContext* resolve_context,
                    const DnsSession* session);

  virtual ~DnsServerIterator();

  // Not copy or moveable.
  DnsServerIterator(const DnsServerIterator&) = delete;
  DnsServerIterator& operator=(const DnsServerIterator&) = delete;
  DnsServerIterator(DnsServerIterator&&) = delete;

  // Return the index of the next server to be attempted.
  // Should only be called if AttemptAvailable() is true.
  virtual size_t GetNextAttemptIndex() = 0;

  virtual bool AttemptAvailable() = 0;

 protected:
  // The number of times each server index was returned.
  std::vector<int> times_returned_;
  // The number of attempts that will be made per server.
  int max_times_returned_;
  // The failure limit before a server is skipped in the attempt ordering.
  // Servers past their failure limit will only be used once all remaining
  // servers are also past their failure limit.
  int max_failures_;
  base::WeakPtr<const ResolveContext> resolve_context_;
  // The first server index to try when GetNextAttemptIndex() is called.
  size_t next_index_;

  base::WeakPtr<const DnsSession> session_;
};

// Iterator used to get the next server to try for a DoH transaction.
// Each iterator should be scoped to a single query. A new query, therefore,
// requires a new iterator.
//
// Finds the first eligible server below the global failure limits
// (|max_failures|), or if no eligible servers are below failure limits, the
// eligible one with the oldest last failure. Global failures are tracked by
// ResolveContext.
//
// Once a server is returned |max_times_returned| times, it is ignored.
//
// If in AUTOMATIC mode, DoH servers are only eligible if "available".  See
// GetDohServerAvailability() for details.
class COMPONENT_EXPORT(DNS_RESOLUTION_ORIGINAL) DohDnsServerIterator : public DnsServerIterator {
 public:
  DohDnsServerIterator(size_t nameservers_size,
                       size_t starting_index,
                       int max_times_returned,
                       int max_failures,
                       const SecureDnsMode& secure_dns_mode,
                       const ResolveContext* resolve_context,
                       const DnsSession* session)
      : DnsServerIterator(nameservers_size,
                          starting_index,
                          max_times_returned,
                          max_failures,
                          resolve_context,
                          session),
        secure_dns_mode_(secure_dns_mode) {}

  ~DohDnsServerIterator() override = default;

  // Not copy or moveable.
  DohDnsServerIterator(const DohDnsServerIterator&) = delete;
  DohDnsServerIterator& operator=(const DohDnsServerIterator&) = delete;
  DohDnsServerIterator(DohDnsServerIterator&&) = delete;

  size_t GetNextAttemptIndex() override;

  // Return true if any servers in the list still has attempts available.
  // False otherwise. An attempt is possible if any server, that is available,
  // is under max_times_returned_ tries.
  bool AttemptAvailable() override;

 private:
  SecureDnsMode secure_dns_mode_;
};

// Iterator used to get the next server to try for a classic DNS transaction.
// Each iterator should be scoped to a single query. A new query, therefore,
// requires a new iterator.
//
// Finds the first eligible server below the global failure limits
// (|max_failures|), or if no eligible servers are below failure limits, the
// eligible one with the oldest last failure. Global failures are tracked by
// ResolveContext.

// Once a server is returned |max_times_returned| times, it is ignored.
class COMPONENT_EXPORT(DNS_RESOLUTION_ORIGINAL) ClassicDnsServerIterator : public DnsServerIterator {
 public:
  ClassicDnsServerIterator(size_t nameservers_size,
                           size_t starting_index,
                           int max_times_returned,
                           int max_failures,
                           const ResolveContext* resolve_context,
                           const DnsSession* session)
      : DnsServerIterator(nameservers_size,
                          starting_index,
                          max_times_returned,
                          max_failures,
                          resolve_context,
                          session) {}

  ~ClassicDnsServerIterator() override = default;

  // Not copy or moveable.
  ClassicDnsServerIterator(const ClassicDnsServerIterator&) = delete;
  ClassicDnsServerIterator& operator=(const ClassicDnsServerIterator&) = delete;
  ClassicDnsServerIterator(ClassicDnsServerIterator&&) = delete;

  size_t GetNextAttemptIndex() override;

  // Return true if any servers in the list still has attempts available.
  // False otherwise. An attempt is possible if any server is under
  // max_times_returned_ tries.
  bool AttemptAvailable() override;
};

// Iterator that can be used when the query is sent via APIs that do not allow
// controlling the underlying DNS server used. For example, this is the case for
// DnsTransactionFactory::AttemptMode::kPlatform on Android.
// In this scenario, we want to limit the number of attempts for each query to
// `max_attempts`: calling GetNextAttemptIndex increments the attempt count,
// and AttemptAvailable will return false once `max_attempts` is reached.
class COMPONENT_EXPORT(DNS_RESOLUTION_ORIGINAL) PlatformDnsServerIterator : public DnsServerIterator {
 public:
  explicit PlatformDnsServerIterator(int max_attempts)
      : DnsServerIterator(/*nameservers_size=*/1,
                          /*starting_index=*/0,
                          /*max_times_returned=*/max_attempts,
                          /*max_failures=*/0,
                          /*resolve_context=*/nullptr,
                          /*session=*/nullptr) {}

  ~PlatformDnsServerIterator() override = default;

  // Not copy or moveable.
  PlatformDnsServerIterator(const PlatformDnsServerIterator&) = delete;
  PlatformDnsServerIterator& operator=(const PlatformDnsServerIterator&) =
      delete;
  PlatformDnsServerIterator(PlatformDnsServerIterator&&) = delete;

  // DnsServerIterator methods:
  size_t GetNextAttemptIndex() override;
  bool AttemptAvailable() override;
};

}  // namespace net::dns_resolution_original
#endif  // NET_DNS_DNS_RESOLUTION_ORIGINAL_DNS_SERVER_ITERATOR_H_
