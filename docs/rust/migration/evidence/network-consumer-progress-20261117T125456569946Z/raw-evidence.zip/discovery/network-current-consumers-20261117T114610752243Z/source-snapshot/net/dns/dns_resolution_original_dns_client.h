// Copyright 2012 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef NET_DNS_DNS_RESOLUTION_ORIGINAL_DNS_CLIENT_H_
#define NET_DNS_DNS_RESOLUTION_ORIGINAL_DNS_CLIENT_H_

#include <memory>
#include <optional>

#include "base/values.h"
#include "net/base/ech_mode.h"
#include "net/base/features.h"
#include "net/base/ip_endpoint.h"
#include "net/base/net_export.h"
#include "net/base/rand_callback.h"
#include "net/dns/dns_config.h"
#include "net/dns/dns_hosts.h"
#include "net/dns/public/dns_config_overrides.h"
#include "net/dns/public/insecure_dns_mode.h"

namespace url {

class SchemeHostPort;

}  // namespace url

#include "base/component_export.h"
#include "net/dns/dns_resolution_rust_original_types.h"
#include "net/dns/dns_resolution_result_types_rust_original.h"
#include "net/base/host_port_rust_reference.h"

#include "net/dns/dns_resolution_native_provider_aliases.h"

namespace net::dns_resolution_original {
using HostPortPair = ::net::HostPortRustReference;


class DnsTransactionFactory;
class ResolveContext;

// These values are persisted to logs. Entries should not be renumbered and
// numeric values should never be reused.
enum class DnsConfigLocalNameserverState {
  kNoLocal = 0,
  kOnlyLoopback = 1,
  kOnlyNonLoopbackLocal = 2,
  kLoopbackAndNonLoopback = 3,
  kMaxValue = kLoopbackAndNonLoopback,
};

// These values are persisted to logs. Entries should not be renumbered and
// numeric values should never be reused.
// LINT.IfChange(FallbackFromSecureTransactionPreferredReason)
enum class FallbackFromSecureTransactionPreferredReason {
  kFallbackNotPreferred = 0,
  kFallbackPreferredCannotUseSecureDns = 1,
  kFallbackPreferredCanaryDomainCheckPending = 2,
  kFallbackPreferredCanaryDomainCheckNegative = 3,
  kFallbackPreferredNoAvailableDohServers = 4,
  // kFallbackPreferredDohFallbackUpgradeNotAllowed = 5,
  // kFallbackPreferredDohFallbackExperimentDisabled = 6,
  kMaxValue = kFallbackPreferredNoAvailableDohServers,
};
// LINT.ThenChange(//tools/metrics/histograms/metadata/net/enums.xml:FallbackFromSecureTransactionPreferredReason)

// Entry point for HostResolverManager to interact with the built-in async
// resolver, as implemented by DnsTransactionFactory. Manages configuration and
// status of the resolver.
class COMPONENT_EXPORT(DNS_RESOLUTION_ORIGINAL) DnsClient {
 public:
  static const int kMaxInsecureFallbackFailures = 16;

  // Whether TaskType::DNS_PLATFORM should be used instead of whichever TaskType
  // would normally be selected.
  static bool UseDnsPlatformDueToEchMode(std::optional<EchMode> ech_mode) {
    return ech_mode.has_value() && *ech_mode == EchMode::kStrict &&
           features::IsDnsPlatformSupported();
  }

  virtual ~DnsClient() = default;

  // Returns true if the DnsClient is able and allowed to make secure DNS
  // transactions and DoH probe runners. If false, secure transactions and DoH
  // probe runners should not be created.
  virtual bool CanUseSecureDnsTransactions() const = 0;

  // Returns true if the DnsClient is able and allowed to make insecure DNS
  // transactions. If false, insecure transactions should not be created.
  // TODO(crbug.com/448975408): Remove `ech_mode` (here and in other places)
  // once the performance regression introduced by `TaskType::DNS_PLATFORM` has
  // been addressed. For the time being, it is necessary to enable support
  // `EchMode::kStrict` without causing a performance regression for non-kStrict
  // requests.
  virtual bool CanUseInsecureDnsTransactions(
      std::optional<EchMode> ech_mode) const = 0;
  virtual bool CanQueryAdditionalTypesViaInsecureDns(
      std::optional<EchMode> ech_mode) const = 0;
  virtual void SetInsecureEnabled(InsecureDnsMode mode,
                                  bool additional_types_enabled) = 0;
  virtual InsecureDnsMode GetInsecureDnsMode(
      std::optional<EchMode> ech_mode) const = 0;

  // When true, DoH should not be used in AUTOMATIC mode since no DoH servers
  // have a successful probe state.
  virtual bool FallbackFromSecureTransactionPreferred(
      ResolveContext* context) const = 0;

  // When true, insecure DNS transactions should not be used when reasonable
  // fallback alternatives, e.g. system resolution can be used instead.
  virtual bool FallbackFromInsecureTransactionPreferred(
      std::optional<EchMode> ech_mode) const = 0;

  // Updates DNS config.  If effective config has changed, destroys the current
  // DnsTransactionFactory and creates a new one according to the effective
  // config, unless it is invalid or has |unhandled_options|.
  //
  // Returns whether or not the effective config changed.
  virtual bool SetSystemConfig(std::optional<DnsConfig> system_config) = 0;
  virtual bool SetConfigOverrides(DnsConfigOverrides config_overrides) = 0;

  // If there is a current session, forces replacement with a new current
  // session with the same effective config, and creates a new
  // DnsTransactionFactory for the new session.
  virtual void ReplaceCurrentSession() = 0;

  // Used for tracking per-context-per-session data.
  // TODO(crbug.com/40106440): Once more per-context-per-session data has been
  // moved to ResolveContext and it doesn't need to call back into DnsSession,
  // convert this to a more limited session handle to prevent overuse of
  // DnsSession outside the DnsClient code.
  virtual DnsSession* GetCurrentSession() = 0;

  // Retrieve the current DNS configuration that would be used if transactions
  // were otherwise currently allowed.
  virtual const DnsConfig& GetEffectiveConfig() const = 0;
  virtual const DnsHosts* GetHosts() const = 0;

  // Returns all preset addresses for the specified endpoint, if any are
  // present in the current effective DnsConfig.
  virtual std::optional<std::vector<IPEndPoint>> GetPresetAddrs(
      const url::SchemeHostPort& endpoint) const = 0;

  // Returns null if the current config is not valid.
  virtual DnsTransactionFactory* GetTransactionFactory() = 0;

  virtual AddressSorter* GetAddressSorter() = 0;

  virtual void IncrementInsecureFallbackFailures() = 0;
  virtual void ClearInsecureFallbackFailures() = 0;

  // Return the effective DNS configuration as a value that can be recorded in
  // the NetLog. This also synthesizes interpretative data to the Value, e.g.
  // whether secure and insecure transactions are enabled.
  virtual base::DictValue GetDnsConfigAsValueForNetLog() const = 0;

  virtual std::optional<DnsConfig> GetSystemConfigForTesting() const = 0;
  virtual DnsConfigOverrides GetConfigOverridesForTesting() const = 0;

  virtual void SetTransactionFactoryForTesting(
      std::unique_ptr<DnsTransactionFactory> factory) = 0;
  virtual void SetAddressSorterForTesting(
      std::unique_ptr<AddressSorter> address_sorter) = 0;

  // Creates default client.
  static std::unique_ptr<DnsClient> CreateClient(NetLog* net_log);

  // Creates a client for testing.  Allows using a mock ClientSocketFactory and
  // a deterministic random number generator. |socket_factory| must outlive
  // the returned DnsClient.
  static std::unique_ptr<DnsClient> CreateClientForTesting(
      NetLog* net_log,
      const RandIntCallback& rand_int_callback);
};

}  // namespace net

#endif  // NET_DNS_DNS_CLIENT_H_
