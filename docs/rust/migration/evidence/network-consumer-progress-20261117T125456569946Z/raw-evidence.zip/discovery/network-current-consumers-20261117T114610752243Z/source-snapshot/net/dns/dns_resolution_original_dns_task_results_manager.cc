// Copyright 2024 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "net/dns/dns_resolution_original_dns_task_results_manager.h"

#include <algorithm>
#include <iterator>
#include <map>
#include <memory>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

#include "base/containers/flat_set.h"
#include "base/containers/map_util.h"
#include "base/memory/raw_ptr.h"
#include "base/metrics/field_trial_params.h"
#include "base/metrics/histogram_functions.h"
#include "base/strings/string_number_conversions.h"
#include "base/time/time.h"
#include "base/timer/timer.h"
#include "net/base/connection_endpoint_metadata.h"
#include "net/base/features.h"
#include "net/base/ip_address.h"
#include "net/base/ip_endpoint.h"
#include "net/base/net_errors.h"
#include "net/dns/dns_resolution_original_dns_alias_utility.h"
#include "net/dns/host_resolver.h"
#include "net/dns/dns_resolution_original_host_resolver_dns_task.h"
#include "net/dns/dns_resolution_result_types_rust_original.h"
#include "net/dns/dns_resolution_original_https_record_rdata.h"
#include "net/dns/public/dns_query_type.h"
#include "net/dns/public/host_resolver_results.h"
#include "net/log/net_log_event_type.h"
#include "net/log/net_log_with_source.h"
#include "url/scheme_host_port.h"

#include "base/component_export.h"
#include "net/dns/dns_resolution_native_provider_aliases.h"
#include "net/dns/dns_resolution_manager_native_providers.h"
#include "net/dns/dns_resolution_result_types_rust_original.h"
#include "net/dns/dns_resolution_host_value_rust_original.h"
#include "net/dns/host_resolver_cache_rust_reference.h"
#include "net/dns/dns_resolution_request_interfaces_rust_original.h"
#include "net/base/host_port_rust_reference.h"

namespace net::dns_resolution_original {

using HostPortPair = ::net::HostPortRustReference;
using HostResolverCache = ::net::host_resolver_cache_reference::HostResolverCache;
using HostResolverInternalResult = ::net::host_resolver_cache_reference::HostResolverInternalResult;
using HostResolverInternalDataResult = ::net::host_resolver_cache_reference::HostResolverInternalDataResult;
using HostResolverInternalMetadataResult = ::net::host_resolver_cache_reference::HostResolverInternalMetadataResult;
using HostResolverInternalErrorResult = ::net::host_resolver_cache_reference::HostResolverInternalErrorResult;
using HostResolverInternalAliasResult = ::net::host_resolver_cache_reference::HostResolverInternalAliasResult;


namespace {

// Prioritize with-ipv6 over ipv4-only.
bool CompareServiceEndpointAddresses(const ServiceEndpoint& a,
                                     const ServiceEndpoint& b) {
  const bool a_has_ipv6 = !a.ipv6_endpoints.empty();
  const bool b_has_ipv6 = !b.ipv6_endpoints.empty();
  if ((a_has_ipv6 && b_has_ipv6) || (!a_has_ipv6 && !b_has_ipv6)) {
    return false;
  }

  if (b_has_ipv6) {
    return false;
  }

  return true;
}

// Prioritize with-metadata, with-ipv6 over ipv4-only.
// TODO(crbug.com/41493696): Consider which fields should be prioritized. We
// may want to have different sorting algorithms and choose one via config.
bool CompareServiceEndpoint(const ServiceEndpoint& a,
                            const ServiceEndpoint& b) {
  const bool a_has_metadata = a.metadata != ConnectionEndpointMetadata();
  const bool b_has_metadata = b.metadata != ConnectionEndpointMetadata();
  if (a_has_metadata && b_has_metadata) {
    return CompareServiceEndpointAddresses(a, b);
  }

  if (a_has_metadata) {
    return true;
  }

  if (b_has_metadata) {
    return false;
  }

  return CompareServiceEndpointAddresses(a, b);
}

// https://datatracker.ietf.org/doc/html/draft-pauly-v6ops-happy-eyeballs-v3-02#name-summary-of-configurable-val
const base::FeatureParam<base::TimeDelta> kResolutionDelay{
    &features::kHappyEyeballsV3,
    "resolution_delay",
    base::Milliseconds(50),
};

}  // namespace

// Holds service endpoint results per domain name.
struct DnsTaskResultsManager::PerDomainResult {
  PerDomainResult() = default;
  ~PerDomainResult() = default;

  PerDomainResult(PerDomainResult&&) = default;
  PerDomainResult& operator=(PerDomainResult&&) = default;
  PerDomainResult(const PerDomainResult&) = delete;
  PerDomainResult& operator=(const PerDomainResult&) = delete;

  std::vector<IPEndPoint> ipv4_endpoints;
  std::vector<IPEndPoint> ipv6_endpoints;

  // Endpoints from HTTPS record ipv4hint/ipv6hint. Used only until the
  // corresponding address family's response arrives.
  std::vector<IPEndPoint> ipv4_hint_endpoints;
  std::vector<IPEndPoint> ipv6_hint_endpoints;

  std::multimap<HttpsRecordPriority, ConnectionEndpointMetadata> metadatas;
};

// static
base::TimeDelta DnsTaskResultsManager::GetResolutionDelay() {
  return kResolutionDelay.Get();
}

DnsTaskResultsManager::DnsTaskResultsManager(Delegate* delegate,
                                             DnsResolverHostOriginal host,
                                             DnsQueryTypeSet query_types,
                                             const NetLogWithSource& net_log)
    : delegate_(delegate),
      host_(std::move(host)),
      query_types_(query_types),
      net_log_(net_log) {
  CHECK(delegate_);
}

DnsTaskResultsManager::~DnsTaskResultsManager() = default;

void DnsTaskResultsManager::ProcessDnsTransactionResults(
    DnsQueryType query_type,
    HostResolverDnsTask::ResultRefs results) {
  CHECK(query_types_.Has(query_type));

  bool should_update_endpoints = false;
  bool should_notify = false;
  bool has_new_ipv4_hints = false;
  bool has_new_ipv6_hints = false;

  if (query_type == DnsQueryType::HTTPS) {
    // Chrome does not yet support HTTPS follow-up queries so metadata is
    // considered ready when the HTTPS response is received.
    CHECK(!is_metadata_ready_);
    is_metadata_ready_ = true;
    should_notify = true;
  }

  if (query_type == DnsQueryType::A) {
    a_response_received_ = true;
    if (HasIpv4HintEndpoints()) {
      for (auto& [domain_name, per_domain_result] : per_domain_results_) {
        per_domain_result->ipv4_hint_endpoints.clear();
      }
      should_update_endpoints = true;
    }
  }

  if (query_type == DnsQueryType::AAAA) {
    aaaa_response_received_ = true;
    if (HasIpv6HintEndpoints()) {
      for (auto& [domain_name, per_domain_result] : per_domain_results_) {
        per_domain_result->ipv6_hint_endpoints.clear();
      }
      should_update_endpoints = true;
    }
    if (MaybeStopResolutionDelayTimer()) {
      // Need to update endpoints when there are IPv4 addresses.
      if (HasIpv4Addresses()) {
        should_update_endpoints = true;
      }
    }
  }

  std::vector<std::string_view> new_aliases;

  for (const auto& result : results) {
    if (!aliases_.contains(result->domain_name())) {
      new_aliases.emplace_back(result->domain_name());
    }

    switch (result->type()) {
      case HostResolverInternalResult::Type::kData: {
        PerDomainResult& per_domain_result =
            GetOrCreatePerDomainResult(result->domain_name());
        for (const auto& ip_endpoint : result->AsData().endpoints()) {
          CHECK_EQ(ip_endpoint.port(), 0);
          if (ip_endpoint.address().IsIPv4()) {
            per_domain_result.ipv4_endpoints.emplace_back(ip_endpoint.address(),
                                                          host_.GetPort());
          } else {
            CHECK(ip_endpoint.address().IsIPv6());
            per_domain_result.ipv6_endpoints.emplace_back(ip_endpoint.address(),
                                                          host_.GetPort());
          }
        }

        should_update_endpoints |= !result->AsData().endpoints().empty();

        break;
      }
      case HostResolverInternalResult::Type::kMetadata: {
        CHECK_EQ(query_type, DnsQueryType::HTTPS);
        RecordAddressHintsMetrics(result->AsMetadata().address_hints(),
                                  /*is_terminal_transaction=*/false);
        for (auto [priority, metadata] : result->AsMetadata().metadatas()) {
          // Associate the metadata with the target name instead of the domain
          // name since the metadata is for the target name.
          PerDomainResult& per_domain_result =
              GetOrCreatePerDomainResult(metadata.target_name);
          per_domain_result.metadatas.emplace(priority, metadata);
        }

        for (const auto& [target_name, hints] :
             result->AsMetadata().address_hints()) {
          PerDomainResult& per_domain_result =
              GetOrCreatePerDomainResult(target_name);
          if (Ipv4HintsUsable()) {
            for (const IPAddress& address : hints.ipv4_hints) {
              CHECK(address.IsIPv4());
              IPEndPoint endpoint(address, host_.GetPort());
              if (!std::ranges::contains(per_domain_result.ipv4_hint_endpoints,
                                         endpoint)) {
                per_domain_result.ipv4_hint_endpoints.push_back(
                    std::move(endpoint));
                has_new_ipv4_hints = true;
              }
            }
          }
          if (Ipv6HintsUsable()) {
            for (const IPAddress& address : hints.ipv6_hints) {
              CHECK(address.IsIPv6());
              IPEndPoint endpoint(address, host_.GetPort());
              if (!std::ranges::contains(per_domain_result.ipv6_hint_endpoints,
                                         endpoint)) {
                per_domain_result.ipv6_hint_endpoints.push_back(
                    std::move(endpoint));
                has_new_ipv6_hints = true;
              }
            }
          }
        }

        should_update_endpoints |= !result->AsMetadata().metadatas().empty();

        break;
      }
      case HostResolverInternalResult::Type::kAlias: {
        if (!aliases_.contains(result->AsAlias().alias_target())) {
          new_aliases.emplace_back(result->AsAlias().alias_target());
        }

        break;
      }
      case HostResolverInternalResult::Type::kError:
        // Need to update endpoints when AAAA response is NODATA but there is
        // at least one valid IPv4 address or usable IPv4 hint.
        // TODO(crbug.com/41493696): Revisit how to handle errors other than
        // NODATA. Currently we just ignore errors here and defer
        // HostResolverManager::Job to create an error result and notify the
        // error to the corresponding requests. This means that if the
        // connection layer has already attempted a connection using an
        // intermediate endpoint, the error might not be treated as fatal. We
        // may want to have a different semantics.
        if (query_type == DnsQueryType::AAAA &&
            result->AsError().error() == ERR_NAME_NOT_RESOLVED &&
            HasIpv4Addresses()) {
          should_update_endpoints = true;
        }

        break;
    }
  }

  // Only fix up and insert aliases if new ones were added.
  if (!new_aliases.empty()) {
    base::flat_set<std::string> fixed_up_aliases =
        dns_alias_utility::FixUpDnsAliases(
            base::flat_set<std::string_view>(std::move(new_aliases)));
    if (aliases_.empty()) {
      aliases_ = std::move(fixed_up_aliases);
    } else if (!fixed_up_aliases.empty()) {
      std::vector<std::string> extracted_aliases =
          std::move(fixed_up_aliases).extract();
      aliases_.insert(std::make_move_iterator(extracted_aliases.begin()),
                      std::make_move_iterator(extracted_aliases.end()));
    }
  }

  should_update_endpoints |= (has_new_ipv4_hints && Ipv4HintsUsable()) ||
                             (has_new_ipv6_hints && Ipv6HintsUsable());

  const bool waiting_for_aaaa_response = query_types_.Has(DnsQueryType::AAAA) &&
                                         !aaaa_response_received_ &&
                                         !aaaa_resolution_delay_timed_out_;
  if (waiting_for_aaaa_response) {
    // IPv6 hint endpoints cover the IPv6 side, so publish without waiting
    // for the AAAA response.
    if (should_update_endpoints && Ipv6HintsUsable() &&
        HasIpv6HintEndpoints()) {
      MaybeStopResolutionDelayTimer();
      UpdateEndpoints();
      return;
    }

    const bool has_new_ipv4_endpoints =
        (query_type == DnsQueryType::A && should_update_endpoints &&
         HasIpv4Addresses()) ||
        (has_new_ipv4_hints && Ipv4HintsUsable());
    if (has_new_ipv4_endpoints && !resolution_delay_timer_.IsRunning()) {
      // IPv4 addresses are available but no IPv6 yet, start the resolution
      // delay timer.
      resolution_delay_start_time_ = base::TimeTicks::Now();
      net_log_.BeginEvent(
          NetLogEventType::HOST_RESOLVER_SERVICE_ENDPOINTS_RESOLUTION_DELAY);
      // Safe to unretain since `this` owns the timer.
      resolution_delay_timer_.Start(
          FROM_HERE, GetResolutionDelay(),
          base::BindOnce(&DnsTaskResultsManager::OnAaaaResolutionTimedout,
                         base::Unretained(this)));
    }

    // If A completed without IPv4 addresses, stop holding back for Happy
    // Eyeballs and immediately flush any superseded IPv4 hints.
    if (query_type == DnsQueryType::A && !HasIpv4Addresses()) {
      MaybeStopResolutionDelayTimer();
      if (should_update_endpoints) {
        UpdateEndpoints();
      }
    }

    return;
  }

  if (should_update_endpoints) {
    UpdateEndpoints();
    return;
  }

  if (should_notify && !current_endpoints_.empty()) {
    delegate_->OnServiceEndpointsUpdated();
  }
}

const std::vector<ServiceEndpoint>& DnsTaskResultsManager::GetCurrentEndpoints()
    const {
  return current_endpoints_;
}

const base::flat_set<std::string>& DnsTaskResultsManager::GetAliases() const {
  return aliases_;
}

bool DnsTaskResultsManager::IsMetadataReady() const {
  return !query_types_.Has(DnsQueryType::HTTPS) || is_metadata_ready_;
}

DnsTaskResultsManager::PerDomainResult&
DnsTaskResultsManager::GetOrCreatePerDomainResult(
    const std::string& domain_name) {
  return *base::GetOrCreate(per_domain_results_, domain_name,
                            [] { return std::make_unique<PerDomainResult>(); });
}

void DnsTaskResultsManager::OnAaaaResolutionTimedout() {
  // The resolution delay timer should only fire while we're still waiting for a
  // real AAAA response.
  CHECK(!aaaa_response_received_);
  CHECK(!aaaa_resolution_delay_timed_out_);

  // Treat the delay timer firing as "completion" only for the purpose of
  // allowing intermediate endpoint updates.
  aaaa_resolution_delay_timed_out_ = true;

  RecordResolutionDelayResult(/*timedout=*/true);
  UpdateEndpoints();
}

void DnsTaskResultsManager::UpdateEndpoints() {
  // Tracks whether each endpoint's per-family addresses came from hints.
  struct EndpointAndProvenance {
    ServiceEndpoint endpoint;
    bool ipv4_from_hints = false;
    bool ipv6_from_hints = false;
  };
  std::vector<EndpointAndProvenance> new_endpoints;

  const bool ipv4_hints_usable = Ipv4HintsUsable();
  const bool ipv6_hints_usable = Ipv6HintsUsable();

  for (const auto& [domain_name, per_domain_result] : per_domain_results_) {
    // Hint endpoints are used only until the corresponding address family's
    // response arrives.
    const bool ipv4_from_hints =
        ipv4_hints_usable && per_domain_result->ipv4_endpoints.empty() &&
        !per_domain_result->ipv4_hint_endpoints.empty();
    const std::vector<IPEndPoint>& ipv4_endpoints =
        ipv4_from_hints ? per_domain_result->ipv4_hint_endpoints
                        : per_domain_result->ipv4_endpoints;
    const bool ipv6_from_hints =
        ipv6_hints_usable && per_domain_result->ipv6_endpoints.empty() &&
        !per_domain_result->ipv6_hint_endpoints.empty();
    const std::vector<IPEndPoint>& ipv6_endpoints =
        ipv6_from_hints ? per_domain_result->ipv6_hint_endpoints
                        : per_domain_result->ipv6_endpoints;

    if (ipv4_endpoints.empty() && ipv6_endpoints.empty()) {
      continue;
    }

    for (const auto& [priority, metadata] : per_domain_result->metadatas) {
      ServiceEndpoint endpoint;
      endpoint.ipv4_endpoints = ipv4_endpoints;
      endpoint.ipv6_endpoints = ipv6_endpoints;
      // TODO(crbug.com/41493696): Just adding per-domain metadata does not
      // work properly when the target name of HTTPS is an alias, e.g:
      //   example.com.     60 IN CNAME svc.example.com.
      //   svc.example.com. 60 IN AAAA  2001:db8::1
      //   svc.example.com. 60 IN HTTPS 1 example.com alpn="h2"
      // In this case, svc.example.com should have metadata with alpn="h2" but
      // the current logic doesn't do that. To handle it correctly we need to
      // go though an alias tree for the domain name.
      endpoint.metadata = metadata;
      new_endpoints.push_back(
          {std::move(endpoint), ipv4_from_hints, ipv6_from_hints});
    }

    // Append non-SVCB endpoints for fallback. Ignore hint endpoints since they
    // are part of SVCB/HTTPS records.
    // See https://datatracker.ietf.org/doc/html/rfc9460#section-3-8 and
    // HostCache::Entry::ConvertToServiceEndpoints().
    if (!per_domain_result->ipv4_endpoints.empty() ||
        !per_domain_result->ipv6_endpoints.empty()) {
      ServiceEndpoint non_alternative_endpoint;
      non_alternative_endpoint.ipv4_endpoints =
          per_domain_result->ipv4_endpoints;
      non_alternative_endpoint.ipv6_endpoints =
          per_domain_result->ipv6_endpoints;
      new_endpoints.push_back({std::move(non_alternative_endpoint),
                               /*ipv4_from_hints=*/false,
                               /*ipv6_from_hints=*/false});
    }
  }

  // Stable sort preserves metadata priorities and places endpoints with
  // metadata before non-SVCB fallback endpoints.
  std::ranges::stable_sort(new_endpoints, CompareServiceEndpoint,
                           &EndpointAndProvenance::endpoint);
  const bool had_endpoints = !current_endpoints_.empty();
  current_endpoints_.clear();
  current_endpoints_.reserve(new_endpoints.size());
  for (EndpointAndProvenance& entry : new_endpoints) {
    current_endpoints_.push_back(std::move(entry.endpoint));
  }

  if (current_endpoints_.empty() && !had_endpoints) {
    return;
  }

  net_log_.AddEvent(NetLogEventType::HOST_RESOLVER_SERVICE_ENDPOINTS_UPDATED,
                    [&] {
                      base::DictValue dict;
                      base::ListValue endpoints;
                      for (size_t i = 0; i < current_endpoints_.size(); ++i) {
                        base::DictValue value = current_endpoints_[i].ToValue();
                        if (new_endpoints[i].ipv4_from_hints) {
                          value.Set("ipv4_endpoints_from_hints", true);
                        }
                        if (new_endpoints[i].ipv6_from_hints) {
                          value.Set("ipv6_endpoints_from_hints", true);
                        }
                        endpoints.Append(std::move(value));
                      }
                      dict.Set("endpoints", std::move(endpoints));
                      return dict;
                    });

  delegate_->OnServiceEndpointsUpdated();
}

bool DnsTaskResultsManager::MaybeStopResolutionDelayTimer() {
  if (resolution_delay_timer_.IsRunning()) {
    resolution_delay_timer_.Stop();
    RecordResolutionDelayResult(/*timedout=*/false);
    return true;
  }
  return false;
}

bool DnsTaskResultsManager::Ipv4HintsUsable() const {
  return query_types_.Has(DnsQueryType::A) && !a_response_received_;
}

bool DnsTaskResultsManager::Ipv6HintsUsable() const {
  return query_types_.Has(DnsQueryType::AAAA) && !aaaa_response_received_;
}

bool DnsTaskResultsManager::HasIpv4HintEndpoints() const {
  return std::ranges::any_of(per_domain_results_, [](const auto& pair) {
    return !pair.second->ipv4_hint_endpoints.empty();
  });
}

bool DnsTaskResultsManager::HasIpv6HintEndpoints() const {
  return std::ranges::any_of(per_domain_results_, [](const auto& pair) {
    return !pair.second->ipv6_hint_endpoints.empty();
  });
}

bool DnsTaskResultsManager::HasIpv4Addresses() const {
  const bool ipv4_hints_usable = Ipv4HintsUsable();
  return std::ranges::any_of(
      per_domain_results_, [ipv4_hints_usable](const auto& pair) {
        return !pair.second->ipv4_endpoints.empty() ||
               (ipv4_hints_usable && !pair.second->ipv4_hint_endpoints.empty());
      });
}

void DnsTaskResultsManager::RecordAddressHintsMetrics(
    const HostResolverInternalMetadataResult::AddressHintsMap& address_hints,
    bool is_terminal_transaction) {
  bool has_ipv4_hints = false;
  bool has_ipv6_hints = false;
  for (const auto& [target_name, hints] : address_hints) {
    has_ipv4_hints |= !hints.ipv4_hints.empty();
    has_ipv6_hints |= !hints.ipv6_hints.empty();
  }

  HttpsRecordAddressHintsPresence presence;
  if (has_ipv4_hints && has_ipv6_hints) {
    presence = HttpsRecordAddressHintsPresence::kBoth;
  } else if (has_ipv4_hints) {
    presence = HttpsRecordAddressHintsPresence::kIPv4Only;
  } else if (has_ipv6_hints) {
    presence = HttpsRecordAddressHintsPresence::kIPv6Only;
  } else {
    presence = HttpsRecordAddressHintsPresence::kNoHints;
  }
  base::UmaHistogramEnumeration("Net.DNS.HttpsRecordAddressHints.Presence",
                                presence);

  if (has_ipv4_hints || has_ipv6_hints) {
    const bool query_outstanding =
        !is_terminal_transaction && ((has_ipv4_hints && Ipv4HintsUsable()) ||
                                     (has_ipv6_hints && Ipv6HintsUsable()));
    base::UmaHistogramBoolean(
        "Net.DNS.HttpsRecordAddressHints.AddressQueryOutstanding",
        query_outstanding);
  }
}

void DnsTaskResultsManager::ProcessDnsTaskComplete(
    const HostResolverDnsTask::Results& results) {
  MaybeStopResolutionDelayTimer();

  if (!is_metadata_ready_) {
    for (const auto& result : results) {
      if (result->type() == HostResolverInternalResult::Type::kMetadata) {
        RecordAddressHintsMetrics(result->AsMetadata().address_hints(),
                                  /*is_terminal_transaction=*/true);
        break;
      }
    }
  }
}

void DnsTaskResultsManager::RecordResolutionDelayResult(bool timedout) {
  net_log_.EndEvent(
      NetLogEventType::HOST_RESOLVER_SERVICE_ENDPOINTS_RESOLUTION_DELAY, [&]() {
        base::TimeDelta elapsed =
            base::TimeTicks::Now() - resolution_delay_start_time_;
        base::DictValue dict;
        dict.Set("timedout", timedout);
        dict.Set("elapsed", base::NumberToString(elapsed.InMilliseconds()));
        return dict;
      });
}

}  // namespace net::dns_resolution_original
