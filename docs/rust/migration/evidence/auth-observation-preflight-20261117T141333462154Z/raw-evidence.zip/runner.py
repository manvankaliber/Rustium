import ctypes,datetime,hashlib,importlib.util,io,json,pathlib,re,subprocess,sys,tarfile
r=pathlib.Path('D:/Rustium');b=pathlib.Path('D:/RustiumBuild/src');rt=r/'.rustium-runtime';w=pathlib.Path('D:/RustiumReview');candidate='89021f54f4b5ac762513fb8114901e6dd6a4754c';prefix='docs/rust/migration/drafts/net-connection-reference-independence';sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest();info=json.loads((rt/'shared-strings-connection-latest.json').read_text())
if sys.argv[1:]!=['run','-j1']:
    assert not (rt/'job-active.json').exists()
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()==candidate and not subprocess.check_output(['git','status','--porcelain'],cwd=w).strip()
    obs=subprocess.check_output(['powershell','-NoProfile','-Command',"Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(ninja|clang-cl|lld-link|rustc|cargo|net_unittests|base_unittests).*' } | Select-Object ProcessId,Name,CommandLine | ConvertTo-Json"],text=True).strip();assert not obs,obs
    out=r/'.scratch/net-wave5'/('auth-observation-preflight-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'));out.mkdir();(out/'runner.py').write_bytes(pathlib.Path(__file__).read_bytes())
    archive=subprocess.check_output(['git','archive','--format=tar',candidate,prefix],cwd=w)
    with tarfile.open(fileobj=io.BytesIO(archive)) as tar:
        for member in tar.getmembers():
            if not member.isfile():continue
            assert not member.issym() and not member.islnk() and member.name.startswith(prefix+'/')
            target=out/'candidate'/pathlib.Path(member.name).relative_to(prefix);assert target.resolve().is_relative_to((out/'candidate').resolve());target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(tar.extractfile(member).read())
    (rt/'auth-observation-preflight-latest.json').write_text(json.dumps({'directory':str(out),'candidate_commit':candidate},indent=2)+'\n')
    req={'task_id':'NET-CONNECTION-REFERENCE-INDEPENDENCE','kind':'build','source_identity':{'candidate_commit':candidate,'current_configured_source':info,'candidate_snapshot':str(out/'candidate')},'toolchain':{'script_sha256':sha(out/'runner.py')},'build_configuration':{'compiler_jobs':1,'scope':'Standalone qualification test source compile using retained configured clang flags; actual Windows Kerberos and synthetic no-Kerberos header variant only. No GN target, linking, runtime or platform acceptance'},'cwd':str(r),'process_reconciliation':{'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'compilers_native_tests':[]}}
    p=out/'request.json';p.write_text(json.dumps(req,indent=2)+'\n');token=json.loads((rt/'director.json').read_text())['token'];sys.exit(subprocess.call(['python','tools/rustium_coord.py','job','--token',token,'--manifest',str(p),'--','python','-B',str(out/'runner.py'),'run','-j1'],cwd=r))
out=pathlib.Path(__file__).parent;d=out/'candidate';sys.path.insert(0,str(r/'docs/rust/migration/drafts/base-ordinary-delivery'));import ordinary_base_v2 as delivery
catalogue=pathlib.Path(json.loads((rt/'network-graph-catalogue-latest.json').read_text())['directory']);commands=(catalogue/'ninja-commands.log').read_text().splitlines();lines=[line for line in commands if '/c ../../net/http/connection_auth_baseline_unittest.cc ' in line];assert len(lines)==1
shell32=ctypes.WinDLL('shell32',use_last_error=True);shell32.CommandLineToArgvW.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_int)];shell32.CommandLineToArgvW.restype=ctypes.POINTER(ctypes.c_wchar_p);kernel32=ctypes.WinDLL('kernel32');kernel32.LocalFree.argtypes=[ctypes.c_void_p];count=ctypes.c_int();ptr=shell32.CommandLineToArgvW(lines[0],ctypes.byref(count));assert ptr
args=[ptr[i] for i in range(count.value)];kernel32.LocalFree(ptr)
source=d/'proposal/net/http/connection_auth_reference_qualification_unittest.cc';names=re.findall(r'TEST_F\(AuthReferenceQualificationTest,\s*(\w+)\)',source.read_text());assert len(names)==13
common=names[:6];flags=b/'out/Default/gen/net/net_buildflags.h';raw_flags=flags.read_bytes();false_flags=re.sub(rb'(#define BUILDFLAG_INTERNAL_USE_KERBEROS\(\)\s*)\(1\)',rb'\g<1>(0)',raw_flags);assert false_flags!=raw_flags
overlay=out/'non-kerberos/net/net_buildflags.h';overlay.parent.mkdir(parents=True);overlay.write_bytes(false_flags);(out/'original-net-buildflags.h').write_bytes(raw_flags)
spec=importlib.util.spec_from_file_location('envmod',r/'.scratch/net-wave5/configure_http2_family.py');envmod=importlib.util.module_from_spec(spec);spec.loader.exec_module(envmod);env=envmod.build_environment();dumpbin=pathlib.Path('C:/Program Files (x86)/Microsoft Visual Studio/2022/BuildTools/VC/Tools/MSVC/14.44.35207/bin/Hostx64/x64/dumpbin.exe');assert dumpbin.is_file()
pins={str(p):sha(p) for p in [source,flags,b/'third_party/llvm-build/Release+Asserts/bin/clang-cl.exe',dumpbin,pathlib.Path(envmod.__file__)]};rows=[];result={'passed':False,'candidate_commit':candidate,'configured_source_manifest_sha256':info['source_manifest_sha256'],'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Test-source standalone compilation/object test registration only. Synthetic no-Kerberos is not an evaluated GN configuration; no linked/native/provider/ABI acceptance','runs':rows}
try:
    delivery.source_check(info)
    for variant in ['windows-kerberos','synthetic-no-kerberos']:
        command=[];object_path=out/(variant+'.obj')
        for arg in args:
            if arg=='../../net/http/connection_auth_baseline_unittest.cc':command.append(str(source))
            elif arg.startswith('/Fo'):command.append('/Fo'+str(object_path))
            elif arg.startswith('/Fd'):command.append('/Fd'+str(out/(variant+'.pdb')))
            else:command.append(arg)
        extra=['-DRUSTIUM_REFERENCE_PROBE=1','-I'+str(d/'proposal/instrumentation'),'-I'+str(d/'proposal')]
        if variant=='synthetic-no-kerberos':extra.insert(0,'-I'+str(out/'non-kerberos'))
        command[1:1]=extra
        log=out/(variant+'.log');code=delivery.run_command(command,b/'out/Default',env,log,timeout=300);row={'variant':variant,'command':command,'cwd':str(b/'out/Default'),'exit_code':code,'output_log':str(log)};rows.append(row);delivery.write(out/'result.json',result)
        if code:continue
        symbols=out/(variant+'-symbols.log');dumpcode=delivery.run_command([str(dumpbin),'/nologo','/symbols',str(object_path)],b/'out/Default',env,symbols,timeout=60);text=symbols.read_text(errors='replace');observed=[name for name in names if 'AuthReferenceQualificationTest_'+name+'_Test' in text];expected=names if variant=='windows-kerberos' else common
        row.update(object_sha256=sha(object_path),symbols_sha256=sha(symbols),dump_exit_code=dumpcode,observed_tests=observed,expected_tests=expected,test_registration_matches=dumpcode==0 and observed==expected)
    delivery.source_check(info);assert all(sha(p)==h for p,h in pins.items());result['passed']=all(x['exit_code']==0 and x.get('test_registration_matches') for x in rows) and len(rows)==2;result['source_and_tool_pins_stable']=True;result['pins']=pins
except BaseException as error:result['exception']=type(error).__name__+': '+str(error)
finally:
    result['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();delivery.write(out/'result.json',result);print(json.dumps({'passed':result['passed'],'directory':str(out),'variants':[{k:x.get(k) for k in ['variant','exit_code','test_registration_matches']} for x in rows]}))
sys.exit(0 if result['passed'] else 1)
