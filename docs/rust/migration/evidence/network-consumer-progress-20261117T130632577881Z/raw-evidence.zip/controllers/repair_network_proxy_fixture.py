import datetime, hashlib, json, pathlib, shutil, subprocess, sys
import network_compile_test_repairs as repairs
r=pathlib.Path('D:/Rustium');b=pathlib.Path('D:/RustiumBuild/src');rt=r/'.rustium-runtime'
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
info=json.loads((rt/'shared-strings-connection-latest.json').read_text())
if sys.argv[1:]!=['apply']:
    assert not (rt/'job-active.json').exists()
    obs=subprocess.check_output(['powershell','-NoProfile','-Command',"Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(ninja|clang-cl|lld-link|net_unittests|base_unittests|rustc|cargo).*' } | Select-Object ProcessId,Name,CommandLine | ConvertTo-Json"],text=True).strip();assert not obs,obs
    # Preserve the exact driver which produced the failed native compiler run.
    job=json.loads((rt/'jobs/64acae260e6d45e9a855963be19031e6/result.json').read_text());script=rt/'build_network_selected_consumers.py'
    script_bytes=script.read_bytes()
    five=b"['connect_job_rust_test_support.cc','connect_job_rust_perftest.cc','connection_auth_baseline_unittest.cc','connection_jobs_upper_rust_jobs_perftest.cc','http_proxy_connect_job_rust_original_unittest.cc']"
    four=b"['connect_job_rust_test_support.cc','connect_job_rust_perftest.cc','connection_auth_baseline_unittest.cc','connection_jobs_upper_rust_jobs_perftest.cc']"
    assert script_bytes.count(five)==1; prior_driver=script_bytes.replace(five,four)
    assert hashlib.sha256(prior_driver).hexdigest()==job['toolchain']['script_sha256']
    dest=pathlib.Path(info['run_directory'])/'network-selected-consumer-build-v2/runner.py'
    if dest.exists():assert dest.read_bytes()==prior_driver
    else:dest.write_bytes(prior_driver)
    req={'task_id':'NET-CURRENT-CONSUMER-CLOSURE','kind':'sync','source_identity':info,'toolchain':{'script_sha256':sha(__file__),'transforms_sha256':sha(repairs.__file__)},'build_configuration':{'scope':'Native original-test compiler adaptations: fixture-owned immutable proxy constants and explicit borrowed controller.get(); original cases, wire bytes and checks preserved'},'cwd':str(r),'process_reconciliation':{'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'compilers_native_tests':[]}}
    p=rt/'network-proxy-fixture-sync-request.json';p.write_text(json.dumps(req,indent=2)+'\n');token=json.loads((rt/'director.json').read_text())['token']
    sys.exit(subprocess.call(['python','tools/rustium_coord.py','job','--token',token,'--manifest',str(p),'--','python','-B',__file__,'apply'],cwd=r))
prior=pathlib.Path(info['run_directory']);state=r/'.scratch/net-wave2/parent/last-synced.json';raw=state.read_bytes();assert hashlib.sha256(raw).hexdigest()==info['source_manifest_sha256'];pins=json.loads(raw)
for rel,h in pins.items():assert sha(r/rel)==h==sha(b/rel),rel
rel='net/http/http_proxy_connect_job_rust_original_unittest.cc';before=(r/rel).read_bytes();after=repairs.proxy_fixture(before)
out=r/'.scratch/shared-strings-connection'/datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ');out.mkdir();(out/'prior-source-manifest.json').write_bytes(raw);shutil.copyfile(repairs.__file__,out/'transformations.py');shutil.copyfile(__file__,out/'sync-controller.py')
(out/('before-'+pathlib.Path(rel).name)).write_bytes(before);dest=out/('after-'+pathlib.Path(rel).name);dest.write_bytes(after)
app=json.loads((prior/'application.json').read_text());row=next(x for x in app['bindings'] if x['path']==rel);assert row['after_sha256']==pins[rel];digest=hashlib.sha256(after).hexdigest();row.update(source=str(dest),after_sha256=digest)
for root in [r,b]:(root/rel).write_bytes(after)
pins[rel]=digest
for path,h in pins.items():assert sha(r/path)==h==sha(b/path),path
(out/'application.json').write_text(json.dumps(app,indent=2)+'\n');(out/'source-manifest.json').write_text(json.dumps(pins,indent=2)+'\n');shutil.copyfile(out/'source-manifest.json',state)
info.update(run_directory=str(out),source_manifest=str(out/'source-manifest.json'),source_manifest_sha256=sha(out/'source-manifest.json'),prior_intake_directory=str(prior),status='Selected build failed9 original proxy-test compiler diagnostics; immutable constants moved to fixture and borrowed controllers made explicit; rebuild and native validation pending')
info.setdefault('director_integration_overlays',[]).append({'path':rel,'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':digest,'reason':'Immutable fixture-owned constants and five explicit borrowed controller.get() calls; original assertions unchanged'})
(out/'application-result.json').write_text(json.dumps(info,indent=2)+'\n');(rt/'shared-strings-connection-latest.json').write_text(json.dumps(info,indent=2)+'\n');print(json.dumps({'authority':info['source_manifest_sha256'],'run':str(out)}))
