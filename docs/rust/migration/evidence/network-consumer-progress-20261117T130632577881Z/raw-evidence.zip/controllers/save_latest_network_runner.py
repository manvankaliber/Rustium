import hashlib,json,pathlib
r=pathlib.Path('D:/Rustium');rt=r/'.rustium-runtime';info=json.loads((rt/'shared-strings-connection-latest.json').read_text());out=pathlib.Path(json.loads((rt/'network-selected-consumer-build-latest.json').read_text())['directory'])
jobs=[]
for p in (rt/'jobs').glob('*/result.json'):
    j=json.loads(p.read_text())
    if j.get('source_identity',{}).get('source_manifest_sha256')==info['source_manifest_sha256'] and j.get('kind')=='build' and 'build_network_selected_consumers.py' in ' '.join(j.get('command',[])) and j.get('finished_utc'):jobs.append(j)
assert jobs;j=max(jobs,key=lambda j:j['finished_utc']);raw=(rt/'build_network_selected_consumers.py').read_bytes();assert hashlib.sha256(raw).hexdigest()==j['toolchain']['script_sha256'];dest=out/'runner.py'
if dest.exists():assert dest.read_bytes()==raw
else:dest.write_bytes(raw)
print(j['finished_utc'],j['status'])
