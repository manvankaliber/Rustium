"""Apply named exact fixture transformations with full two-checkout guards."""
import datetime, hashlib, json, pathlib, shutil, subprocess, sys
import network_compile_test_repairs as repairs
r=pathlib.Path('D:/Rustium');b=pathlib.Path('D:/RustiumBuild/src');rt=r/'.rustium-runtime'
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
choices={'proxy-constants':('net/http/http_proxy_connect_job_unittest.cc',repairs.proxy_constants,'Fixture-owned immutable proxy constants; original production-test assertions and wire values preserved')}
choices['deleting-delegate']=('net/socket/connection_jobs_http2_baseline_unittest.cc',repairs.deleting_delegate,'Preserve callback reentrant deletion using explicit nonowning raw_ref wrappers; same original expectations')
choices['ssl-original']=('net/socket/ssl_connect_job_rust_original_unittest.cc',repairs.ssl_original_fixture,'Fixture-owned immutable SSL test constants and three explicit borrowed controller.get() calls; original assertions preserved')
choices['ssl-native']=('net/socket/ssl_connect_job_unittest.cc',repairs.ssl_constants,'Fixture-owned immutable native SSL test constants; original assertions preserved')
key=sys.argv[1];rel,transform,reason=choices[key];info=json.loads((rt/'shared-strings-connection-latest.json').read_text())
if sys.argv[2:]!=['apply']:
    assert not (rt/'job-active.json').exists()
    obs=subprocess.check_output(['powershell','-NoProfile','-Command',"Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(ninja|clang-cl|lld-link|net_unittests|base_unittests|rustc|cargo).*' } | Select-Object ProcessId,Name,CommandLine | ConvertTo-Json"],text=True).strip();assert not obs,obs
    req={'task_id':'NET-CURRENT-CONSUMER-CLOSURE','kind':'sync','source_identity':info,'toolchain':{'script_sha256':sha(__file__),'transforms_sha256':sha(repairs.__file__)},'build_configuration':{'scope':reason},'cwd':str(r),'process_reconciliation':{'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'compilers_native_tests':[]}}
    p=rt/(key+'-sync-request.json');p.write_text(json.dumps(req,indent=2)+'\n');token=json.loads((rt/'director.json').read_text())['token']
    sys.exit(subprocess.call(['python','tools/rustium_coord.py','job','--token',token,'--manifest',str(p),'--','python','-B',__file__,key,'apply'],cwd=r))
prior=pathlib.Path(info['run_directory']);state=r/'.scratch/net-wave2/parent/last-synced.json';raw=state.read_bytes();assert hashlib.sha256(raw).hexdigest()==info['source_manifest_sha256'];pins=json.loads(raw)
for path,h in pins.items():assert sha(r/path)==h==sha(b/path),path
before=(r/rel).read_bytes();after=transform(before);assert before!=after
out=r/'.scratch/shared-strings-connection'/datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ');out.mkdir();(out/'prior-source-manifest.json').write_bytes(raw);shutil.copyfile(repairs.__file__,out/'transformations.py');shutil.copyfile(__file__,out/'sync-controller.py')
(out/('before-'+pathlib.Path(rel).name)).write_bytes(before);dest=out/('after-'+pathlib.Path(rel).name);dest.write_bytes(after)
app=json.loads((prior/'application.json').read_text());rows=[x for x in app['bindings'] if x['path']==rel];assert len(rows)<=1
if rows:row=rows[0];assert row['after_sha256']==pins[rel]
else:row={'path':rel,'before_sha256':pins[rel],'kind':'Director test fixture compiler adaptation'};app['bindings'].append(row)
digest=hashlib.sha256(after).hexdigest();row.update(source=str(dest),after_sha256=digest)
for root in [r,b]:(root/rel).write_bytes(after)
pins[rel]=digest
for path,h in pins.items():assert sha(r/path)==h==sha(b/path),path
(out/'application.json').write_text(json.dumps(app,indent=2)+'\n');(out/'source-manifest.json').write_text(json.dumps(pins,indent=2)+'\n');shutil.copyfile(out/'source-manifest.json',state)
info.update(run_directory=str(out),source_manifest=str(out/'source-manifest.json'),source_manifest_sha256=sha(out/'source-manifest.json'),prior_intake_directory=str(prior),applied_bindings=len(app['bindings']),status=reason+'; configured rebuild/native pending')
info.setdefault('director_integration_overlays',[]).append({'path':rel,'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':digest,'reason':reason})
(out/'application-result.json').write_text(json.dumps(info,indent=2)+'\n');(rt/'shared-strings-connection-latest.json').write_text(json.dumps(info,indent=2)+'\n');print(json.dumps({'authority':info['source_manifest_sha256'],'run':str(out),'bindings':len(app['bindings'])}))
