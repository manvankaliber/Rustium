"""Exact, narrow compiler adaptations; expected cases and values stay intact."""
def trace_fields(data, header):
    if header:
        needle=b'#include "base/functional/callback.h"'
        data=data.replace(needle,needle+b'\n#include "base/memory/raw_ptr.h"\n#include "base/memory/raw_ref.h"')
        data=data.replace(b'Trace& trace_;',b'raw_ref<Trace> trace_;')
        data=data.replace(b'const HttpResponseInfo* expected_response',b'raw_ptr<const HttpResponseInfo> expected_response')
    return data.replace(b'trace_.',b'trace_->')

def auth_fixture(data):
    assert data.count(b'const NetworkAnonymizationKey kNak;')==1
    data=data.replace(b'const NetworkAnonymizationKey kNak;\n',b'')
    data=data.replace(b'  HttpAuthCache cache{true};',b'  const NetworkAnonymizationKey kNak;\n  HttpAuthCache cache{true};')
    data=data.replace(b'#include <type_traits>',b'#include <string_view>\n#include <type_traits>')
    data=data.replace(b'for (const std::string value :',b'for (const std::string& value :')
    data=data.replace(b'const char* first=',b'constexpr std::string_view first=').replace(b'const char* second=',b'constexpr std::string_view second=')
    old=b'''base::BindOnce([&](int rv) {
        EXPECT_EQ(OK,rv);++callbacks;
        HttpRequestHeaders token;Headers::AddAuthorizationHeader(*auth,&token);
        EXPECT_EQ(Headers::GetHeader(token,"proxy-authorization"),"auth_token");
        auth.reset(); // no post-callback access to controller or handler
      })'''
    new=b'''base::BindOnce([](unsigned* callback_count,
                        scoped_refptr<HttpAuthController>* controller, int rv) {
        EXPECT_EQ(OK,rv);++*callback_count;
        HttpRequestHeaders token;Headers::AddAuthorizationHeader(**controller,&token);
        EXPECT_EQ(Headers::GetHeader(token,"proxy-authorization"),"auth_token");
        controller->reset(); // no post-callback access to controller or handler
      }, base::Unretained(&callbacks), base::Unretained(&auth))'''
    assert data.count(old)==1
    return data.replace(old,new)

def upper_fixture(data):
    data=data.replace(b'#include <string>\n',b'#include <string>\n#include <string_view>\n')
    data=data.replace(b'#include "base/functional/callback_helpers.h"',b'#include "base/functional/callback_helpers.h"\n#include "base/memory/raw_ref.h"')
    assert data.count(b'base::test::TaskEnvironment&environment;')==1
    data=data.replace(b'base::test::TaskEnvironment&environment;',b'raw_ref<base::test::TaskEnvironment> environment;')
    data=data.replace(b'environment.RunUntilIdle(',b'environment->RunUntilIdle(').replace(b'environment.FastForwardBy(',b'environment->FastForwardBy(')
    start=data.index(b'        script->reads.emplace_back(SYNCHRONOUS,1,kind==Case::kHttpAuth?')
    end=data.index(b');',start)+2;old=data[start:end]
    new=old.replace(b',1,kind==',b',1,std::string_view(kind==',1)
    new=new[:-2]+b'));'
    return data[:start]+new+data[end:]

def proxy_constants(data):
    start=data.index(b'const ProxyServer kHttpProxyServer{')
    end=data.index(b'constexpr char kTestHeaderName[]',start)
    constants=data[start:end]
    old=b'const ProxyChain kHttpsNestedProxyChain({kHttpsProxyServer,\n                                         kHttpsNestedProxyServer});'
    assert constants.count(old)==1
    constants=constants.replace(old,b'const ProxyChain kHttpsNestedProxyChain = ProxyChain({kHttpsProxyServer,\n                                         kHttpsNestedProxyServer});')
    data=data[:start]+data[end:]
    anchor=b' protected:\n  std::unique_ptr<TestProxyDelegate> proxy_delegate_;'
    assert data.count(anchor)==1
    data=data.replace(anchor,b' protected:\n'+constants+b'  std::unique_ptr<TestProxyDelegate> proxy_delegate_;')
    return data

def proxy_fixture(data):
    data=proxy_constants(data)
    old=b'ConnectionAuthOriginalPolicy::ResetAuth(test_delegate.auth_controller(),'
    assert data.count(old)==5
    return data.replace(old,b'ConnectionAuthOriginalPolicy::ResetAuth(test_delegate.auth_controller().get(),')
