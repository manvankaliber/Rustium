"""Prepare independent images during a build; apply only after the gate is free."""
import datetime,hashlib,json,pathlib,shutil,subprocess,sys
import network_compile_test_repairs as repairs
r=pathlib.Path('D:/Rustium');b=pathlib.Path('D:/RustiumBuild/src');rt=r/'.rustium-runtime';sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
operations=[
 ('net/socket/connection_jobs_family_flow_fixture.h',repairs.flow_pool_fields,'Nonowning flow provider trace/handle wrappers; preserve exchange-before-publication ordering'),
 ('net/socket/connection_jobs_family_flow_unittest.cc',repairs.flow_test_lookup,'Resolve free fixture Run template explicitly instead of inherited private testing::Test::Run; same8expected comparisons'),
 ('net/socket/connection_jobs_family_rust_unittest.cc',repairs.family_test_lookup,'Resolve free family Run explicitly instead of inherited private testing::Test::Run; same2expected comparisons'),
 ('net/socket/connection_jobs_provider_wiring_unittest.cc',repairs.provider_witness_fields,'Observed native provider borrowed pointers use raw_ptr; same identities/ownership assertions'),
 ('net/socket/socket_pool_additional_capacity_rust_original_unittest.cc',repairs.capacity_validation_enums,'Adapt independent original enum callbacks to native statistical test helper with explicit conversion and compile-time equality of both enumerators; all100iterations and expected bounds unchanged')]
info=json.loads((rt/'shared-strings-connection-latest.json').read_text())
if sys.argv[1:] == ['prepare']:
    pins=json.loads(pathlib.Path(info['source_manifest']).read_text());out=r/'.scratch/net-wave5'/('prepared-network-compiler-fixtures-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'));out.mkdir();rows=[]
    for rel,fn,reason in operations:
        assert rel in pins and sha(r/rel)==pins[rel]==sha(b/rel),rel
        raw=(r/rel).read_bytes();after=fn(raw);assert after!=raw
        before=out/'before'/rel;dest=out/'after'/rel;before.parent.mkdir(parents=True,exist_ok=True);dest.parent.mkdir(parents=True,exist_ok=True);before.write_bytes(raw);dest.write_bytes(after)
        rows.append({'path':rel,'before':str(before),'before_sha256':sha(before),'source':str(dest),'after_sha256':sha(dest),'reason':reason})
    shutil.copyfile(repairs.__file__,out/'transformations.py');plan={'source_identity':info,'source_manifest_sha256':sha(info['source_manifest']),'transformations_sha256':sha(out/'transformations.py'),'rows':rows};(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');(rt/'network-batch-repair-latest.json').write_text(json.dumps({'directory':str(out)},indent=2)+'\n');print(json.dumps({'prepared':str(out),'files':len(rows),'applied':False}));sys.exit(0)
prepared=pathlib.Path(json.loads((rt/'network-batch-repair-latest.json').read_text())['directory']);plan=json.loads((prepared/'plan.json').read_text());assert plan['source_manifest_sha256']==info['source_manifest_sha256']
if sys.argv[1:]!=['apply']:
    assert not (rt/'job-active.json').exists()
    obs=subprocess.check_output(['powershell','-NoProfile','-Command',"Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(ninja|clang-cl|lld-link|net_unittests|base_unittests|rustc|cargo).*' } | Select-Object ProcessId,Name,CommandLine | ConvertTo-Json"],text=True).strip();assert not obs,obs
    req={'task_id':'NET-CURRENT-CONSUMER-CLOSURE','kind':'sync','source_identity':info,'toolchain':{'script_sha256':sha(__file__),'prepared_plan_sha256':sha(prepared/'plan.json')},'build_configuration':{'scope':'Batched strict fixture compiler repairs; all expected assertions and workload membership preserved'},'cwd':str(r),'process_reconciliation':{'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'compilers_native_tests':[]}}
    p=rt/'network-batch-fixture-sync-request.json';p.write_text(json.dumps(req,indent=2)+'\n');token=json.loads((rt/'director.json').read_text())['token'];sys.exit(subprocess.call(['python','tools/rustium_coord.py','job','--token',token,'--manifest',str(p),'--','python','-B',__file__,'apply'],cwd=r))
prior=pathlib.Path(info['run_directory']);state=r/'.scratch/net-wave2/parent/last-synced.json';raw=state.read_bytes();assert hashlib.sha256(raw).hexdigest()==plan['source_manifest_sha256'];pins=json.loads(raw)
for rel,h in pins.items():assert sha(r/rel)==h==sha(b/rel),rel
for row in plan['rows']:assert sha(row['before'])==row['before_sha256']==pins[row['path']] and sha(row['source'])==row['after_sha256']
out=r/'.scratch/shared-strings-connection'/datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ');out.mkdir();(out/'prior-source-manifest.json').write_bytes(raw);shutil.copyfile(prepared/'plan.json',out/'prepared-plan.json');shutil.copyfile(prepared/'transformations.py',out/'transformations.py');shutil.copyfile(__file__,out/'sync-controller.py');app=json.loads((prior/'application.json').read_text())
for row in plan['rows']:
    rel=row['path'];matches=[x for x in app['bindings'] if x['path']==rel];assert len(matches)<=1
    if matches:entry=matches[0];assert entry['after_sha256']==row['before_sha256']
    else:entry={'path':rel,'before_sha256':row['before_sha256'],'kind':'Director strict fixture compiler adaptation'};app['bindings'].append(entry)
    before=out/('before-'+pathlib.Path(rel).name);after=out/('after-'+pathlib.Path(rel).name);shutil.copyfile(row['before'],before);shutil.copyfile(row['source'],after);entry.update(source=str(after),after_sha256=row['after_sha256'])
    for root in [r,b]:(root/rel).write_bytes(after.read_bytes())
    pins[rel]=row['after_sha256']
for rel,h in pins.items():assert sha(r/rel)==h==sha(b/rel),rel
(out/'application.json').write_text(json.dumps(app,indent=2)+'\n');(out/'source-manifest.json').write_text(json.dumps(pins,indent=2)+'\n');shutil.copyfile(out/'source-manifest.json',state)
info.update(run_directory=str(out),source_manifest=str(out/'source-manifest.json'),source_manifest_sha256=sha(out/'source-manifest.json'),prior_intake_directory=str(prior),applied_bindings=len(app['bindings']),status='Batched flow/provider helper compiler repairs applied; original expected cases retained; current consumer rebuild/native pending');info.setdefault('director_integration_overlays',[]).extend(plan['rows'])
(out/'application-result.json').write_text(json.dumps(info,indent=2)+'\n');(rt/'shared-strings-connection-latest.json').write_text(json.dumps(info,indent=2)+'\n');print(json.dumps({'authority':info['source_manifest_sha256'],'run':str(out),'files':len(plan['rows'])}))
