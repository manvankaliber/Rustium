$ErrorActionPreference = 'Stop'
$taskRoot = 'D:\Rustium'
$taskLatest = Get-Content -LiteralPath "$taskRoot\.rustium-runtime\network-selected-consumer-build-latest.json" -Raw | ConvertFrom-Json
$taskOutput = Join-Path $taskLatest.directory 'memory-samples.jsonl'
if (Test-Path -LiteralPath $taskOutput) { throw 'Choose a new evidence file; memory samples already exist' }
$taskUntil = [DateTime]::UtcNow.AddSeconds(55)
do {
  $taskMemory = Get-CimInstance Win32_OperatingSystem
  $taskProcesses = @(Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(ninja|clang-cl|lld-link|rustc)\.exe$' } | ForEach-Object {
    [ordered]@{ name=$_.Name; working_set_bytes=[uint64]$_.WorkingSetSize; private_page_bytes=[uint64]$_.PrivatePageCount }
  })
  $taskSample = [ordered]@{ observed_utc=[DateTime]::UtcNow.ToString('o'); free_physical_kib=[uint64]$taskMemory.FreePhysicalMemory; free_virtual_kib=[uint64]$taskMemory.FreeVirtualMemory; processes=$taskProcesses; scope='Partial read-only samples during necessary serial build; not lifetime peak or throughput acceptance' }
  ($taskSample | ConvertTo-Json -Compress -Depth 4) | Add-Content -LiteralPath $taskOutput -Encoding utf8
  if (-not (Test-Path -LiteralPath "$taskRoot\.rustium-runtime\job-active.json")) { break }
  Start-Sleep -Seconds 2
} while ([DateTime]::UtcNow -lt $taskUntil)
Write-Output $taskOutput
