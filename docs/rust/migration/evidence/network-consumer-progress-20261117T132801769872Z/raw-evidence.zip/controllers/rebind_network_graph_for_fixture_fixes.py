import hashlib,json,pathlib
import network_compile_test_repairs as repairs
r=pathlib.Path('D:/Rustium');rt=r/'.rustium-runtime';info=json.loads((rt/'shared-strings-connection-latest.json').read_text());run=pathlib.Path(info['run_directory']);catalogue=pathlib.Path(json.loads((rt/'network-graph-catalogue-latest.json').read_text())['directory']);sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest();captured=json.loads((catalogue/'result.json').read_text())
matches=[p for p in (r/'.scratch/shared-strings-connection').glob('*/source-manifest.json') if sha(p)==captured['source_manifest_sha256']];assert len(matches)==1;old_path=matches[0];old=json.loads(old_path.read_text());new=json.loads(pathlib.Path(info['source_manifest']).read_text());expected={'net/socket/connect_job_rust_test_support.h','net/socket/connect_job_rust_test_support.cc','net/http/connection_auth_baseline_unittest.cc','net/socket/connection_jobs_upper_rust_job_workloads.h','net/http/http_proxy_connect_job_rust_original_unittest.cc'}
expected.add('net/http/http_proxy_connect_job_unittest.cc')
expected.add('net/socket/connection_jobs_http2_baseline_unittest.cc')
expected.update(['net/socket/ssl_connect_job_rust_original_unittest.cc','net/socket/ssl_connect_job_unittest.cc'])
expected.update(['net/socket/connection_jobs_upper_rust_test_support.h','net/socket/connection_jobs_upper_rust_test_support.cc'])
assert old.keys()==new.keys() and {p for p in old if old[p]!=new[p]}==expected
frozen=r/'.scratch/net-wave5/network-current-consumers-20261117T114935331577Z/source-snapshot'
for rel in expected:
 before=(frozen/rel).read_bytes();assert hashlib.sha256(before).hexdigest()==old[rel]
 if 'connect_job_rust_test_support' in rel:after=repairs.trace_fields(before,rel.endswith('.h'))
 elif rel.endswith('connection_auth_baseline_unittest.cc'):after=repairs.auth_fixture(before)
 elif rel.endswith('http_proxy_connect_job_rust_original_unittest.cc'):after=repairs.proxy_fixture(before)
 elif rel.endswith('http_proxy_connect_job_unittest.cc'):after=repairs.proxy_constants(before)
 elif rel.endswith('connection_jobs_http2_baseline_unittest.cc'):after=repairs.deleting_delegate(before)
 elif rel.endswith('ssl_connect_job_rust_original_unittest.cc'):after=repairs.ssl_original_fixture(before)
 elif rel.endswith('ssl_connect_job_unittest.cc'):after=repairs.ssl_constants(before)
 elif rel.endswith('connection_jobs_upper_rust_test_support.h'):after=repairs.upper_test_header(before)
 elif rel.endswith('connection_jobs_upper_rust_test_support.cc'):after=repairs.upper_test_impl(before)
 else:after=repairs.upper_fixture(before)
 assert after==(r/rel).read_bytes() and hashlib.sha256(after).hexdigest()==new[rel]
assert captured['passed'] and all(sha(c['output'])==c['output_sha256'] for c in captured['commands'])
configuration=json.loads((catalogue/'configuration-before.json').read_text());graph={p:h for p,h in configuration.items() if pathlib.Path(p).suffix=='.ninja' or pathlib.Path(p).name in ['args.gn','environment.x64']};assert graph and all(sha(p)==h for p,h in graph.items())
record={'passed':True,'old_source_manifest_sha256':sha(old_path),'current_source_manifest_sha256':info['source_manifest_sha256'],'catalogue':str(catalogue),'catalogue_result_sha256':sha(catalogue/'result.json'),'graph_files_checked':len(graph),'unchanged_graph_files':graph,'source_delta':sorted(expected),'exact_transformations_sha256':sha(repairs.__file__),'scope':'Reuse of byte-identical evaluated GN/Ninja discovery after exact four-file compiler-fixture transformations. Old commands were not rerun under the new source hash. No old build/native/ABI pass is promoted; all affected C++ consumers must rebuild.'}
record['scope']=f'Reuse of byte-identical evaluated GN/Ninja discovery after exact {len(expected)}-file compiler-fixture transformations. Old commands were not rerun under the new source hash. No old build/native/ABI pass is promoted; all affected C++ consumers must rebuild.'
(run/'graph-discovery-rebind.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:v for k,v in record.items() if k!='unchanged_graph_files'}))
