import pathlib,subprocess
r=pathlib.Path('D:/Rustium');rt=r/'.rustium-runtime'
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=r).strip(),'Preserve preexisting staged changes; inspect separately'
exact={'docs/rust/migration/HANDOFF.md','docs/rust/migration/OPERATING.md','docs/rust/migration/DECISIONS.md','docs/rust/migration/queue.json','docs/rust/net-migration-execution.json'}
raw=subprocess.check_output(['git','status','--porcelain=v1','-z','--untracked-files=all','--','docs/rust/migration','docs/rust/net-migration-execution.json'],cwd=r)
paths=[]
for row in raw.split(b'\0'):
    if not row:continue
    assert row[:2] not in [b'R ',b' C',b'UU']
    path=row[3:].decode('utf-8')
    if path in exact or path.startswith('docs/rust/migration/evidence/'):paths.append(path)
assert paths
p=rt/'network-checkpoint-paths.nul';p.write_bytes(b'\0'.join(x.encode() for x in paths)+b'\0')
subprocess.run(['git','add','--pathspec-from-file='+str(p),'--pathspec-file-nul'],cwd=r,check=True)
subprocess.run(['git','diff','--cached','--check'],cwd=r,check=True)
subprocess.run(['git','commit','-m','Checkpoint Network dependency native pass and current consumer repairs'],cwd=r,check=True,stdout=subprocess.DEVNULL)
print(subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),len(paths),'scoped evidence/doc paths')
