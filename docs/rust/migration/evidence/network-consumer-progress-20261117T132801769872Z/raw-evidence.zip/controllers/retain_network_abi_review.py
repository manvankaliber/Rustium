import datetime,hashlib,json,pathlib,subprocess,sys
r=pathlib.Path('D:/Rustium');rt=r/'.rustium-runtime';w=pathlib.Path('D:/RustiumReview');prefix='docs/rust/migration/drafts/net-current-abi-qualification';commit='7009cb3c3c211d9b459d06ca2b5e233e1f6d82c5';base='f149b6a1935b268dc4aa9cf99f0c953659e96138';sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()==commit
assert not subprocess.check_output(['git','status','--porcelain'],cwd=w).strip()
paths=subprocess.check_output(['git','diff','--name-only',base,commit],cwd=w,text=True).splitlines();assert paths and all(p.startswith(prefix+'/') for p in paths)
inputs=json.loads((w/prefix/'input-bindings.json').read_text());aliases=[]
for path,h in inputs['inputs'].items():
    if sha(path)==h:continue
    assert pathlib.Path(path)==rt/'shared-strings-connection-latest.json',path
    matches=[p for p in (r/'.scratch/shared-strings-connection').glob('*/application-result.json') if sha(p)==h];assert len(matches)==1
    aliases.append({'mutable_alias':path,'reviewed_sha256':h,'immutable_resolution':str(matches[0]),'current_alias_differs':True})
for row in inputs['exact_before_after']:
    assert sha(row['before_path'])==row['before_sha256'] and sha(row['after_path'])==row['after_sha256'],row['path']
for path in paths:
    raw=subprocess.check_output(['git','show',commit+':'+path],cwd=w);dest=r/path;assert not dest.exists();dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
subprocess.run(['git','add','--',*paths],cwd=r,check=True)
subprocess.run(['git','diff','--cached','--check'],cwd=r,check=True)
subprocess.run(['git','commit','-m','Retain independent current Network header and bridge ABI review'],cwd=r,check=True,stdout=subprocess.DEVNULL)
intake=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();info=json.loads((rt/'shared-strings-connection-latest.json').read_text())
e={'task_id':'NET-CURRENT-ABI-QUALIFICATION','candidate_commit':commit,'source_identity':{'reviewed_global_manifest_sha256':inputs['qualified_source_manifest_sha256'],'current_global_manifest_sha256':info['source_manifest_sha256'],'reviewed_shared_inputs_still_match':True,'exact_before_after_verified':len(inputs['exact_before_after']),'resolved_mutable_aliases':aliases,'graph_result_sha256':'7a879787ca8a71117e56356d3dad8d218dc2bccd9c90db5ea7b0c7b769123b3c','artifact_intake_commit':intake},'tests':{'status':'pending','checks':'Clean exact task commit, scoped diff/check, all immutable input pins and all9before/after header/bridge bindings verified; mutable pointer resolved to matching immutable intake result','not_run':'No compiler, native, binary ABI, runtime or performance validation by this review'},'review':{'status':'conditional','model':'gpt-6.1-terra','effort':'xhigh','report':prefix+'/REVIEW.md','disposition':'No production-header ABI/layout/existing-inline expansion beyond conservative155 boundary; reference changed-type cohort owner+5executables within boundary. Current161 explicit aliases/artifacts equivalent; successful build, generated/link artifacts/export availability and bounded compilerdeps capture still required'},'platform_limits':['Windows source/graph inspection only','No production/runtime/cutover acceptance','Native/provider/reference independence, optimizedQUIC and performance remain open'],'remaining_cpp_bridge_ownership':'C++ public containers, resource/platform lifetimes and remaining policy/bridge ownership explicit','next_action':'Finish current build, capture exact generated/link artifacts and compilerdeps for reference owner+5executables, then full36-program232-workload ordinary snapshot. Preserve unavailable prechange binary export comparison as unavailable.'}
p=r/'docs/rust/migration/evidence/net-current-abi-qualification-delivery-20261117.json';p.write_text(json.dumps(e,indent=2)+'\n');pin=subprocess.check_output(['python','.rustium-runtime/pin_evidence.py',str(p)],cwd=r,text=True).strip();token=json.loads((rt/'director.json').read_text())['token']
for state in ['submitted','validating']:
    cmd=['python','tools/rustium_coord.py','transition',e['task_id'],state,'--token',token,'--note',e['next_action']]
    if state=='submitted':cmd+=['--commit',commit,'--evidence',pin]
    subprocess.run(cmd,cwd=r,check=True,stdout=subprocess.DEVNULL)
print(json.dumps({'candidate':commit,'artifact_intake':intake,'verified_before_after':len(inputs['exact_before_after']),'mutable_aliases_resolved':len(aliases),'review_scope':'source/graph conditional; current consumer capture still pending'}))
