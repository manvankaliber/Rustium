import datetime,hashlib,io,json,pathlib,stat,subprocess,tarfile
r=pathlib.Path('D:/Rustium');rt=r/'.rustium-runtime';w=pathlib.Path('C:/Users/jackv/.t3/worktrees/Rustium/t3-b9522825-1c2d775265c524e6');prefix='docs/rust/migration/drafts/net-connection-reference-independence';candidate='adcbf06ce7926b5f85273d6aa7cd7b7211fb6818';base='f149b6a1935b268dc4aa9cf99f0c953659e96138';sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()==candidate
assert not subprocess.check_output(['git','status','--porcelain'],cwd=w).strip()
paths=subprocess.check_output(['git','diff','--name-only',base,candidate],cwd=w,text=True).splitlines();assert paths and all(p.startswith(prefix+'/') for p in paths)
assert not (r/prefix).exists()
raw=subprocess.check_output(['git','archive','--format=tar',candidate,prefix],cwd=w)
with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
    for member in archive.getmembers():
        assert not member.issym() and not member.islnk()
        dest=(r/member.name).resolve()
        if member.isdir() and (r/prefix).resolve().is_relative_to(dest):continue
        assert dest.is_relative_to((r/prefix).resolve())
        if member.isdir():dest.mkdir(parents=True,exist_ok=True)
        elif member.isfile():dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(archive.extractfile(member).read())
d=r/prefix;frozen={};drift=[]
for name in ['input-bindings.json','provider-input-bindings.json','observation-input-bindings.json']:
    for row in json.loads((d/name).read_text())['inputs']:
        assert sha(d/row['copy'])==row['sha256'],row['copy'];frozen[row['copy']]=row['sha256']
        current=sha(r/row['path'])
        if current!=row['sha256']:drift.append({'path':row['path'],'frozen_sha256':row['sha256'],'current_sha256':current})
assert {row['path'] for row in drift}=={'net/socket/connection_jobs_upper_rust_job_workloads.h'}
proposal=json.loads((d/'proposal-manifest.json').read_text())
for row in proposal['proposal_files']:assert sha(d/row['path'])==row['sha256'],row['path']
for rel in frozen:(d/rel).chmod(stat.S_IREAD)
subprocess.run(['git','add','--',prefix],cwd=r,check=True);subprocess.run(['git','diff','--cached','--check'],cwd=r,check=True)
subprocess.run(['git','commit','-m','Retain Network auth reference provider qualification candidate'],cwd=r,check=True,stdout=subprocess.DEVNULL)
intake=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();info=json.loads((rt/'shared-strings-connection-latest.json').read_text())
e={'task_id':'NET-CONNECTION-REFERENCE-INDEPENDENCE','candidate_commit':candidate,'source_identity':{'artifact_intake_commit':intake,'source_manifest_sha256':info['source_manifest_sha256'],'frozen_inputs_verified':len(frozen),'proposal_files_verified':len(proposal['proposal_files']),'known_frozen_lifecycle_header_drift':drift,'v4_46binding_application_sha256':'5405cc7c5994ff26aa0b2cc9ade42acfb128277faea2c17544fe74e87e3f32fc'},'tests':{'status':'pending','checks':'Clean exact worker branch, all scoped changes, frozen copied bytes and indexed proposal hashes verified; worker format/patch checks only','not_run':'Compiler, native, Rust probe controls, Windows SSPI, POSIX GSSAPI and lifecycle runtime tests'},'review':{'status':'pending','required_model':'gpt-6.1-terra','required_effort':'xhigh','scope':'Independent provider/helper, lifetime/callback, injection, seven-entry-probe coverage and GN/component ABI review before any configured application'},'platform_limits':['Windows and POSIX proposal branches uncompiled','Arbitrary injected mechanisms remain external and require individual reference contracts','Non-auth helper closure remains open;7probes are bounded observations only'],'remaining_cpp_bridge_ownership':'Director owns proposed shared friends/decoder encoder exports, generated CXX/accessors/GN and isolated probe build; native crypto/OS/URL/provider boundaries retain explicit debt','next_action':'Independent Terra review of coherent auth provider/test/probe proposal; reconcile newer lifecycle fixture header, then director-owned guarded integration and ordinary validation. Current configured build inputs unchanged.'}
p=r/'docs/rust/migration/evidence/net-connection-reference-independence-delivery-20261117.json';p.write_text(json.dumps(e,indent=2)+'\n');pin=subprocess.check_output(['python','.rustium-runtime/pin_evidence.py',str(p)],cwd=r,text=True).strip();token=json.loads((rt/'director.json').read_text())['token']
for state in ['submitted','validating']:
    cmd=['python','tools/rustium_coord.py','transition',e['task_id'],state,'--token',token,'--note',e['next_action']]
    if state=='submitted':cmd+=['--commit',candidate,'--evidence',pin]
    subprocess.run(cmd,cwd=r,check=True,stdout=subprocess.DEVNULL)
print(json.dumps({'candidate':candidate,'artifact_intake':intake,'frozen_inputs':len(frozen),'proposal_files':len(proposal['proposal_files']),'worker_slot_released':True}))
