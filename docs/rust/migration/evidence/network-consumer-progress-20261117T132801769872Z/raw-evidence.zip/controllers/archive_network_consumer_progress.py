"""Retain raw failed runs and graph discovery without publishing acceptance."""
import datetime, hashlib, json, pathlib, subprocess, zipfile
r=pathlib.Path('D:/Rustium');rt=r/'.rustium-runtime';e=r/'docs/rust/migration/evidence'
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
now=datetime.datetime.now(datetime.timezone.utc); stamp=now.strftime('%Y%m%dT%H%M%S%fZ')
dest=e/('network-consumer-progress-'+stamp);dest.mkdir()
files={}
previous=None; previous_index={}
pointer=rt/'network-consumer-progress-latest.json'
if pointer.exists():
    previous=json.loads(pointer.read_text()); old_record=json.loads(pathlib.Path(previous['record']).read_text())
    old_archive=r/old_record['archive'];assert sha(old_archive)==old_record['archive_sha256']
    chain=[]; cursor=old_record
    while cursor:
        chain.append(cursor)
        prior=cursor.get('prior_progress_archive')
        if prior:
            assert sha(prior['record'])==prior['record_sha256']
            cursor=json.loads(pathlib.Path(prior['record']).read_text())
        else:cursor=None
    for entry in reversed(chain):
        path=r/entry['archive'];assert sha(path)==entry['archive_sha256']
        with zipfile.ZipFile(path) as z:previous_index.update(json.loads(z.read('raw-index.json')))
def add_tree(path, prefix):
    for p in path.rglob('*'):
        if p.is_file():files[prefix+'/'+p.relative_to(path).as_posix()]=p
for name in ['network-current-consumers-20261117T114610752243Z','network-current-consumers-20261117T114935331577Z','network-graph-catalogue-20261117T115905192295Z']:
    add_tree(r/'.scratch/net-wave5'/name,'discovery/'+name)
intakes=[]
for intake in sorted((r/'.scratch/shared-strings-connection').iterdir()):
    if intake.name < '20261117T112907106914Z':continue
    if not intake.is_dir():continue
    intakes.append(str(intake))
    for p in intake.iterdir():
        if p.is_file():files['intakes/'+intake.name+'/'+p.name]=p
        elif p.is_dir() and p.name.startswith('network-selected-consumer-build'):
            # Do not snapshot a still-running log/result as terminal evidence.
            result=p/'result.json';outcome=p/'outcome.json'
            if (result.exists() and json.loads(result.read_text()).get('finished_utc')) or outcome.exists():
                add_tree(p,'intakes/'+intake.name+'/'+p.name)
for p in rt.glob('*.py'):
    if any(word in p.name for word in ['network','connection_fixture','connect_job_test']):files['controllers/'+p.name]=p
for p in rt.glob('sample_network*.ps1'):files['controllers/'+p.name]=p
jobs=[]
for p in (rt/'jobs').glob('*/result.json'):
    j=json.loads(p.read_text())
    if j.get('task_id')!='NET-CURRENT-CONSUMER-CLOSURE' or not j.get('finished_utc'):continue
    clean={k:v for k,v in j.items() if k not in ['launcher_pid','child_pid']}
    q=dest/('job-'+p.parent.name+'.json');q.write_text(json.dumps(clean,indent=2)+'\n')
    jobs.append({'job_id':p.parent.name,'status':j['status'],'kind':j['kind'],'source_manifest_sha256':j.get('source_identity',{}).get('source_manifest_sha256'),'record':q.name})
    log=p.parent/'output.log'
    if log.exists():files['jobs/'+p.parent.name+'/output.log']=log
index={}
archive=dest/'raw-evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for name,p in sorted(files.items()):
        raw=p.read_bytes();digest=hashlib.sha256(raw).hexdigest()
        old=previous_index.get(name)
        if old and old['sha256']==digest:continue
        index[name]={'origin':str(p),'sha256':digest,'bytes':len(raw)};z.writestr(name,raw)
    z.writestr('raw-index.json',json.dumps(index,indent=2)+'\n')
info=json.loads((rt/'shared-strings-connection-latest.json').read_text())
latest=json.loads((rt/'network-selected-consumer-build-latest.json').read_text())
record={'observed_utc':now.isoformat(),'archive':str(archive.relative_to(r)).replace('\\','/'),'archive_sha256':sha(archive),'raw_files':len(index),'raw_bytes':sum(x['bytes'] for x in index.values()),'archive_bytes':archive.stat().st_size,'source_identity':info,'terminal_jobs':jobs,'current_build_directory':latest['directory'],'scope':'Raw discovery, failed compiler/preflight runs, exact source repairs and controller provenance. No complete consumer/ABI, native four-family, performance, platform or cutover acceptance.'}
if previous:record['prior_progress_archive']={'record':previous['record'],'record_sha256':sha(previous['record']),'archive':old_record['archive'],'archive_sha256':old_record['archive_sha256']}
(dest/'record.json').write_text(json.dumps(record,indent=2)+'\n')
(rt/'network-consumer-progress-latest.json').write_text(json.dumps({'directory':str(dest),'record':str(dest/'record.json')},indent=2)+'\n')
token=json.loads((rt/'director.json').read_text())['token'];q=json.loads((r/'docs/rust/migration/queue.json').read_text())
updates={
 'NET-CURRENT-CONSUMER-CLOSURE':{'configured_validation':'1261-input current conservative155-target rebuild in progress; prior failed source-bound compiler/preflight runs retained. Complete header/inline/ABI closure still pending','next':'Finish current rebuild, qualify actual header/ABI consumers, then full36-program/232-workload ordinary batch'},
 'NET-NATIVE-BUILD-THROUGHPUT':{'implementation':'Independent Sol/high report delivered and locally retained; changed-object preflight and dirty-edge capture implemented','configured_validation':'Preflight caught compiler errors before broad rebuild; no measured throughput gain; -j1 retained pending memory qualification','next':'Use preflight on necessary builds; any -j2 trial needs memory telemetry and existing max2/link-pool constraints'},
 'NET-CONNECTION-REFERENCE-INDEPENDENCE':{'implementation':'Terra checkpoints6862a026/e591719d preserved; named reference provider candidates and frozen source proposals prepared; missing verification being completed','next':'Complete actual-registry auth verification and per-family observations; injected mechanism requires separately reviewed reference implementation; remaining non-auth closure still open'}
}
for task_id,update in updates.items():
    t=next(t for t in q['tasks'] if t['id']==task_id);st=dict(t['stages'])
    for key in ['implementation','configured_validation']:
        if key in update:st[key]=update[key]
    patch={'stages':st,'next_action':update['next'],'evidence':t['evidence']+[{'path':str((dest/'record.json').relative_to(r)).replace('\\','/'),'sha256':sha(dest/'record.json')}]}
    f=rt/(task_id.lower()+'-progress-patch.json');f.write_text(json.dumps(patch,indent=2)+'\n')
    subprocess.run(['python','tools/rustium_coord.py','amend',task_id,'--token',token,'--patch',str(f)],cwd=r,check=True,stdout=subprocess.DEVNULL)
ledger=r/'docs/rust/net-migration-execution.json';v=json.loads(ledger.read_text());v['resumed_delivery_intake'].update(network_current_consumer_progress_20261117=record,source_manifest_sha256=info['source_manifest_sha256'],source_identity_count=info['source_count']);ledger.write_text(json.dumps(v,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ['archive','archive_sha256','raw_files','raw_bytes','archive_bytes','current_build_directory']}))
