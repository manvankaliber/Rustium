import hashlib,json,pathlib
r=pathlib.Path('D:/Rustium');rt=r/'.rustium-runtime';job=json.loads((rt/'job-active.json').read_text());out=pathlib.Path(json.loads((rt/'network-selected-consumer-build-latest.json').read_text())['directory'])
assert job['task_id']=='NET-CURRENT-CONSUMER-CLOSURE' and job['kind']=='build'
raw=(rt/'build_network_selected_consumers.py').read_bytes();assert hashlib.sha256(raw).hexdigest()==job['toolchain']['script_sha256']
p=out/'runner.py'
if p.exists():assert p.read_bytes()==raw
else:p.write_bytes(raw)
print('Active exact driver retained without changing build inputs')
