import datetime,hashlib,importlib.util,json,pathlib,re,subprocess,sys
r=pathlib.Path('D:/Rustium');b=pathlib.Path('D:/RustiumBuild/src');rt=r/'.rustium-runtime';sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest();info=json.loads((rt/'shared-strings-connection-latest.json').read_text());catalogue=pathlib.Path(json.loads((rt/'network-graph-catalogue-latest.json').read_text())['directory'])
if len(sys.argv)==1:
 assert not (rt/'job-active.json').exists();assert json.loads((catalogue/'result.json').read_text())['passed']
 obs=subprocess.check_output(['powershell','-NoProfile','-Command',"Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(ninja|clang-cl|lld-link|net_unittests|base_unittests|rustc|cargo).*' } | Select-Object ProcessId,Name,CommandLine | ConvertTo-Json"],text=True).strip();assert not obs,obs
 memory=json.loads(subprocess.check_output(['powershell','-NoProfile','-Command','Get-CimInstance Win32_OperatingSystem | Select-Object TotalVisibleMemorySize,FreePhysicalMemory,TotalVirtualMemorySize,FreeVirtualMemory | ConvertTo-Json'],text=True))
 out=pathlib.Path(info['run_directory'])/'network-selected-consumer-build-v2';req={'task_id':'NET-CURRENT-CONSUMER-CLOSURE','kind':'build','source_identity':info,'toolchain':{'script_sha256':sha(__file__)},'build_configuration':{'scope':'Necessary selected36-program roots,82 historical conservative targets and actual current applied-source GN owners; not final complete changed-header consumer or ABI acceptance','compiler_jobs':1,'memory_before_kib':memory,'parallelism_reason':'Retain-j1 while global compiler/linker peaks are unqualified; maximum2 remains available for an evidence-supported future trial'},'cwd':str(r),'process_reconciliation':{'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'compilers_native_tests':[]}}
 p=rt/'network-selected-consumer-build-request.json';p.write_text(json.dumps(req,indent=2)+'\n');(rt/'network-selected-consumer-build-latest.json').write_text(json.dumps({'directory':str(out),'catalogue':str(catalogue)}));token=json.loads((rt/'director.json').read_text())['token'];sys.exit(subprocess.call(['python','tools/rustium_coord.py','job','--token',token,'--manifest',str(p),'--','python','-B',__file__,'-j1','run'],cwd=r))
out=pathlib.Path(info['run_directory'])/'network-selected-consumer-build-v2';assert not out.exists();out.mkdir();sys.path.insert(0,str(r/'docs/rust/migration/drafts/base-ordinary-delivery'));import ordinary_base_v2 as delivery
captured=json.loads((catalogue/'result.json').read_text());assert captured['passed'];assert all(sha(c['output'])==c['output_sha256'] for c in captured['commands'])
if captured['source_manifest_sha256']!=info['source_manifest_sha256']:
 rebind_path=pathlib.Path(info['run_directory'])/'graph-discovery-rebind.json';rebind=json.loads(rebind_path.read_text())
 assert rebind['passed'] and rebind['old_source_manifest_sha256']==captured['source_manifest_sha256'] and rebind['current_source_manifest_sha256']==info['source_manifest_sha256'] and rebind['catalogue_result_sha256']==sha(catalogue/'result.json')
 assert all(sha(p)==h for p,h in rebind['unchanged_graph_files'].items())
sources=json.loads((catalogue/'gn-sources.log').read_text());outputs=json.loads((catalogue/'gn-outputs.log').read_text());app=json.loads((pathlib.Path(info['run_directory'])/'application.json').read_text());changed={'//'+row['path'] for row in app['bindings']};owners={label:sorted(set(row.get('sources',[]))&changed) for label,row in sources.items() if set(row.get('sources',[]))&changed}
targets=set(captured['targets']);owner_outputs={};unresolved=[]
for label,witness in owners.items():
 values=outputs.get(label,{}).get('outputs',[]);mapped=[]
 for value in values:
  prefix='//out/Default/'
  delivery.require(value.startswith(prefix),'Unexpected evaluated GN output path: '+value);rel=value[len(prefix):];delivery.require((b/'out/Default'/rel).resolve().is_relative_to((b/'out/Default').resolve()),'GN output escapes configured directory');mapped.append(rel);targets.add(rel)
 if not mapped:
  if '(' not in label:targets.add(label.removeprefix('//'))
  else:unresolved.append(label)
 owner_outputs[label]={'applied_sources':witness,'outputs':mapped}
delivery.require(not unresolved,'Nondefault source-owner aliases require explicit resolution: '+repr(unresolved));targets=sorted(targets);delivery.write(out/'manifest.json',{'source_manifest_sha256':info['source_manifest_sha256'],'targets':targets,'current_direct_source_owners':owner_outputs,'selected_programs':36,'historical_proposals_provisional':True,'scope':'Conservative necessary-build manifest; complete header/inline/ABI and outside-scope consumer acceptance remains pending'})
spec=importlib.util.spec_from_file_location('configured_env',r/'.scratch/net-wave5/configure_http2_family.py');envmod=importlib.util.module_from_spec(spec);spec.loader.exec_module(envmod);env=envmod.build_environment();ninja=str(b/'third_party/ninja/ninja.exe');command=[ninja,'-C',str(b/'out/Default'),'-j1',*targets];tools={p:sha(p) for p in [ninja,str(b/'third_party/llvm-build/Release+Asserts/bin/clang-cl.exe'),str(b/'third_party/llvm-build/Release+Asserts/bin/lld-link.exe'),str(b/'third_party/rust-toolchain/bin/rustc.exe'),envmod.__file__]}
result={'passed':False,'command':command,'cwd':str(b),'source_manifest_sha256':info['source_manifest_sha256'],'configured_args_sha256':sha(b/'out/Default/args.gn'),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'compiler_jobs':1,'output_log':str(out/'build.log'),'scope':'Actual conservative selected-program/direct-source-owner rebuild only; no native, complete ABI/consumer, baseline-independence, performance or cutover acceptance'}
try:
 delivery.source_check(info);delivery.write(out/'result.json',result)
 objects=set()
 names={pathlib.PurePosixPath(row['path']).name for row in app['bindings'] if row['path'].endswith('.cc')}
 for line in (catalogue/'ninja-commands.log').read_text().splitlines():
  if any(name in line for name in names):
   match=re.search(r'/Fo([^\s"]+)',line)
   if match:objects.add(match.group(1))
 delivery.require(len(objects)>=2,'Changed connection verification object owners missing')
 preflight=[ninja,'-C',str(b/'out/Default'),'-j1',*sorted(objects)]
 code=delivery.run_command(preflight,b,env,out/'changed-objects.log',timeout=1800);result['changed_object_preflight']={'command':preflight,'exit_code':code};delivery.write(out/'result.json',result)
 if code==0:
  result['full_command_executed']=True;delivery.write(out/'result.json',result);code=delivery.run_command(command,b,env,out/'build.log',timeout=10800)
 result['exit_code']=code
 delivery.source_check(info);delivery.require(all(sha(p)==h for p,h in tools.items()),'Compiler/linker/helper drift');result.update(passed=code==0,source_inputs_stable=True,source_drift=[],tools=tools)
except BaseException as error:
 result['exception']=type(error).__name__+': '+str(error)
 if isinstance(error,delivery.CommandFailure):result['command_failure']=error.details
finally:
 result['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();delivery.write(out/'result.json',result);print(json.dumps({'passed':result['passed'],'exit_code':result.get('exit_code'),'directory':str(out),'targets':len(targets)}))
sys.exit(0 if result['passed'] else 1)
