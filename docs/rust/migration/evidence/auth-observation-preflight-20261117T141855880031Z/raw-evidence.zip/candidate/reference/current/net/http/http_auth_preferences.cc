// Copyright 2015 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "net/http/http_auth_preferences.h"

#include <utility>
#include <vector>

#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#include "build/build_config.h"
#include "net/http/http_auth_filter.h"
#include "net/http/url_security_manager.h"

namespace net {

HttpAuthPreferences::HttpAuthPreferences()
    : security_manager_(URLSecurityManager::Create()) {}

HttpAuthPreferences::~HttpAuthPreferences() = default;

bool HttpAuthPreferences::NegotiateDisableCnameLookup() const {
  return negotiate_disable_cname_lookup_;
}

bool HttpAuthPreferences::NegotiateEnablePort() const {
  return negotiate_enable_port_;
}

#if BUILDFLAG(IS_POSIX)
bool HttpAuthPreferences::NtlmV2Enabled() const {
  return ntlm_v2_enabled_;
}
#endif


#if BUILDFLAG(IS_LINUX)
bool HttpAuthPreferences::AllowGssapiLibraryLoad() const {
  return allow_gssapi_library_load_;
}
#endif

bool HttpAuthPreferences::CanUseDefaultCredentials(
    const url::SchemeHostPort& auth_scheme_host_port) const {
  return allow_default_credentials_ == ALLOW_DEFAULT_CREDENTIALS &&
         security_manager_->CanUseDefaultCredentials(auth_scheme_host_port);
}

using DelegationType = HttpAuth::DelegationType;

DelegationType HttpAuthPreferences::GetDelegationType(
    const url::SchemeHostPort& auth_scheme_host_port) const {
  if (!security_manager_->CanDelegate(auth_scheme_host_port)) {
    return DelegationType::kNone;
  }

  if (delegate_by_kdc_policy()) {
    return DelegationType::kByKdcPolicy;
  }

  return DelegationType::kUnconstrained;
}

void HttpAuthPreferences::SetAllowDefaultCredentials(DefaultCredentials creds) {
  allow_default_credentials_ = creds;
}

void HttpAuthPreferences::SetAllowedSchemes(
    const std::optional<base::flat_set<std::string>>& allowed_schemes) {
  if (allowed_schemes) {
    allowed_schemes_ = base::MakeFlatSet<std::string>(
        *allowed_schemes,
        /*comp=*/{},
        [](const auto& scheme) { return base::ToLowerASCII(scheme); });
  } else {
    allowed_schemes_ = std::nullopt;
  }
}

bool HttpAuthPreferences::IsAllowedToUseAllHttpAuthSchemes(
    const url::SchemeHostPort& scheme_host_port,
    HttpAuth::Target target) const {
  return !http_auth_scheme_filter_ ||
         http_auth_scheme_filter_.Run(scheme_host_port, target);
}

void HttpAuthPreferences::SetServerAllowlist(
    const std::string& server_allowlist) {
  std::unique_ptr<HttpAuthFilter> allowlist;
  if (!server_allowlist.empty()) {
    allowlist = std::make_unique<HttpAuthFilterAllowlist>(server_allowlist);
  }
  security_manager_->SetDefaultAllowlist(std::move(allowlist));
}

void HttpAuthPreferences::SetDelegateAllowlist(
    const std::string& delegate_allowlist) {
  std::unique_ptr<HttpAuthFilter> allowlist;
  if (!delegate_allowlist.empty()) {
    allowlist = std::make_unique<HttpAuthFilterAllowlist>(delegate_allowlist);
  }
  security_manager_->SetDelegateAllowlist(std::move(allowlist));
}

}  // namespace net
