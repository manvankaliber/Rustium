import datetime, hashlib, json, pathlib, shutil, subprocess, sys
r = pathlib.Path('D:/Rustium'); b = pathlib.Path('D:/RustiumBuild/src'); rt = r / '.rustium-runtime'
d = r / 'docs/rust/migration/drafts/net-compile-parent-fixes'
sha = lambda p: hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
info = json.loads((rt / 'shared-strings-connection-latest.json').read_text())
manifest = json.loads((d / 'manifest.json').read_text())
assert manifest['source_identity'] == info['source_manifest_sha256']
if sys.argv[1:] != ['apply']:
    assert not (rt / 'job-active.json').exists()
    observed = subprocess.check_output(['powershell', '-NoProfile', '-Command', "Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(ninja|clang-cl|lld-link|net_unittests|base_unittests|rustc|cargo).*' } | Select-Object ProcessId,Name,CommandLine | ConvertTo-Json"], text=True).strip()
    assert not observed, observed
    request = {'task_id': 'NET-CURRENT-CONSUMER-CLOSURE', 'kind': 'sync', 'source_identity': info, 'toolchain': {'script_sha256': sha(__file__), 'proposal_manifest_sha256': sha(d / 'manifest.json')}, 'build_configuration': {'scope': '29 guarded compiler/export and parent review repairs; all existing cases retained; new component crossing test additive'}, 'cwd': str(r), 'process_reconciliation': {'observed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'compilers_native_tests': []}}
    p = rt / 'network-reviewed-compiler-sync-request.json'; p.write_text(json.dumps(request, indent=2) + '\n')
    token = json.loads((rt / 'director.json').read_text())['token']
    sys.exit(subprocess.call(['python', 'tools/rustium_coord.py', 'job', '--token', token, '--manifest', str(p), '--', 'python', '-B', __file__, 'apply'], cwd=r))
state = r / '.scratch/net-wave2/parent/last-synced.json'
assert sha(state) == info['source_manifest_sha256']
prior = pathlib.Path(info['run_directory'])
raw = state.read_bytes(); pins = json.loads(raw)
for rel, h in pins.items():
    assert sha(r / rel) == h == sha(b / rel), rel
for row in manifest['changes']:
    rel = row['path']
    for root in [r, b]:
        actual = sha(root / rel) if (root / rel).exists() else None
        assert actual == row['before_sha256'], rel
    assert sha(d / 'proposal' / rel) == row['after_sha256']
    if row['before_sha256'] is not None:
        assert sha(d / 'before' / rel) == row['before_sha256']
for row in manifest['frozen_unchanged_proxy_definitions']:
    assert sha(r / row['path']) == row['sha256'] == sha(b / row['path'])
out = r / '.scratch/shared-strings-connection' / datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
out.mkdir()
(out / 'prior-source-manifest.json').write_bytes(raw)
shutil.copyfile(__file__, out / 'sync-controller.py')
shutil.copyfile(d / 'manifest.json', out / 'prepared-plan.json')
app = json.loads((prior / 'application.json').read_text())
for row in manifest['changes']:
    rel = row['path']
    for side in ['before', 'proposal']:
        p = d / side / rel
        if p.exists():
            destination = out / side / rel
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(p, destination)
    matches = [x for x in app['bindings'] if x['path'] == rel]
    assert len(matches) <= 1
    if matches:
        entry = matches[0]
        assert entry['after_sha256'] == row['before_sha256']
    else:
        entry = {'path': rel, 'before_sha256': row['before_sha256'], 'kind': 'Reviewed Network compiler repair with explicit parent findings disposition'}
        app['bindings'].append(entry)
    entry.update(source=str(out / 'proposal' / rel), after_sha256=row['after_sha256'])
    for root in [r, b]:
        p = root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes((out / 'proposal' / rel).read_bytes())
    pins[rel] = row['after_sha256']
for rel, h in pins.items():
    assert sha(r / rel) == h == sha(b / rel), rel
(out / 'application.json').write_text(json.dumps(app, indent=2) + '\n')
(out / 'source-manifest.json').write_text(json.dumps(pins, indent=2) + '\n')
shutil.copyfile(out / 'source-manifest.json', state)
info.update(run_directory=str(out), source_manifest=str(out / 'source-manifest.json'), source_manifest_sha256=sha(state), source_count=len(pins), applied_bindings=len(app['bindings']), prior_intake_directory=str(prior), parent_proposal_commit='09db0827216ecdebc00974fd0b480cf773177cd8', status='Guarded29-file reviewed compiler/export and ownership/schema repairs applied; fresh GN, consumer compilation/link and runtime qualification pending')
info.setdefault('director_integration_overlays', []).extend(manifest['changes'])
(out / 'application-result.json').write_text(json.dumps(info, indent=2) + '\n')
(rt / 'shared-strings-connection-latest.json').write_text(json.dumps(info, indent=2) + '\n')
print(json.dumps({'source_manifest_sha256': info['source_manifest_sha256'], 'files': len(manifest['changes']), 'run_directory': str(out), 'source_count': len(pins)}))
