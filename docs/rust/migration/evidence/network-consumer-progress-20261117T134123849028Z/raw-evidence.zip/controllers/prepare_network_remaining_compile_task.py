import copy,datetime,hashlib,json,pathlib,shutil,subprocess,sys
r=pathlib.Path('D:/Rustium');rt=r/'.rustium-runtime';w=pathlib.Path('C:/Users/jackv/.t3/worktrees/Rustium/t3-b9522825-1c2d775265c524e6');candidate='adcbf06ce7926b5f85273d6aa7cd7b7211fb6818';prefix='docs/rust/migration/drafts/net-connection-reference-independence';sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
assert not (rt/'job-active.json').exists();assert w.resolve().is_relative_to(pathlib.Path('C:/Users/jackv/.t3/worktrees/Rustium').resolve());assert w.resolve()==pathlib.Path('C:/Users/jackv/.t3/worktrees/Rustium/t3-b9522825-1c2d775265c524e6').resolve()
branch='rust/net-connection-reference-independence-20261117'
if (w/'.git').exists():
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()==candidate
    assert not subprocess.check_output(['git','status','--porcelain','--ignored','--untracked-files=all'],cwd=w).strip()
    assert subprocess.check_output(['git','branch','--show-current'],cwd=w,text=True).strip()==branch
else:
    # Previous Git removal unregistered/deleted checkout contents but Windows
    # retained an empty directory. Never retry a recursive/forced deletion.
    assert w.is_dir() and not list(w.iterdir())
    assert str(w).replace('\\','/') not in subprocess.check_output(['git','worktree','list','--porcelain'],cwd=r,text=True)
assert subprocess.check_output(['git','rev-parse',branch],cwd=r,text=True).strip()==candidate
tree=subprocess.check_output(['git','rev-parse',candidate+':'+prefix],cwd=r,text=True).strip();assert tree==subprocess.check_output(['git','rev-parse','HEAD:'+prefix],cwd=r,text=True).strip()
q=json.loads((r/'docs/rust/migration/queue.json').read_text());old=next(t for t in q['tasks'] if t['id']=='NET-CONNECTION-REFERENCE-INDEPENDENCE');assert not old['assignment']['active'] and old['delivery_commit']==candidate
if (w/'.git').exists():
    removal=subprocess.run(['git','worktree','remove',str(w)],cwd=r)
    if removal.returncode:
        assert w.is_dir() and not list(w.iterdir())
        assert str(w).replace('\\','/') not in subprocess.check_output(['git','worktree','list','--porcelain'],cwd=r,text=True)
retired={'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'removed_clean_worktree':str(w),'retained_branch':branch,'retained_candidate_commit':candidate,'artifact_subtree':prefix,'candidate_and_root_tree':tree,'checks':['Latest worker task completed; assignment inactive','Exact candidate HEAD; clean including ignored/untracked files','Resolved absolute target within named T3 worker root','Exact candidate subtree already committed in Root; branch retained'],'scope':'Retire clean delivered sparse workspace to reuse bounded8worker pool; no configured cache, frozen run, source candidate or branch deleted'}
retired.update(empty_directory_retained=w.exists(),windows_cleanup_limitation='Git unregistered and removed all checkout content; exit255reported permission denied removing final empty directory. Empty directory retained; no forced deletion or branch/source loss.')
(r/'docs/rust/migration/evidence/network-reference-workspace-retirement-20261117.json').write_text(json.dumps(retired,indent=2)+'\n')
info=json.loads((rt/'shared-strings-connection-latest.json').read_text());latest=json.loads((rt/'network-selected-consumer-build-latest.json').read_text());build=pathlib.Path(latest['directory']);result=json.loads((build/'result.json').read_text());assert result['finished_utc'] and result['exit_code']==1 and result['source_inputs_stable']
bundle=r/'.scratch/net-wave5'/('remaining-network-compile-inputs-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'));bundle.mkdir();raw=pathlib.Path(info['source_manifest']).read_bytes();assert hashlib.sha256(raw).hexdigest()==info['source_manifest_sha256'];pins=json.loads(raw)
for rel,h in pins.items():
    assert sha(r/rel)==h==sha(pathlib.Path('D:/RustiumBuild/src')/rel),rel
    dest=bundle/'source-snapshot'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/rel,dest);assert sha(dest)==h
(bundle/'source-manifest.json').write_bytes(raw)
for name in ['result.json','build.log','changed-objects.log','manifest.json','runner.py']:shutil.copyfile(build/name,bundle/name)
owned_by_director=['net/socket/connection_jobs_family_flow_fixture.h','net/socket/connection_jobs_family_flow_unittest.cc','net/socket/connection_jobs_family_rust_unittest.cc','net/socket/connection_jobs_provider_wiring_unittest.cc','net/socket/socket_pool_additional_capacity_rust_original_unittest.cc']
binding={'source_manifest_sha256':info['source_manifest_sha256'],'source_count':len(pins),'directory':str(bundle),'build_result_sha256':sha(bundle/'result.json'),'full_log_sha256':sha(bundle/'build.log'),'director_excluded_files':owned_by_director,'scope':'Frozen terminal-k0 compiler diagnostics and source inputs; no runtime/ABI pass'};(bundle/'intake.json').write_text(json.dumps(binding,indent=2)+'\n');(rt/'remaining-network-compile-inputs-latest.json').write_text(json.dumps(binding,indent=2)+'\n')
sys.path.insert(0,str(r/'tools'));from rustium_coord import Coordinator
c=Coordinator(r);token=json.loads((rt/'director.json').read_text())['token'];t=copy.deepcopy(old);base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip();t.update(id='NET-ORDINARY-COMPILE-REPAIR',priority=0,state='ready',objective='Repair remaining current Network ordinary compiler failures in cookie/DNS/HTTP2 reference adapters and test fixtures without weakening algorithms or assertions',owned_files=['docs/rust/migration/drafts/net-ordinary-compile-repairs'],assignment={'active':False},base_revision=base,delivery_commit=None,integration_commit=None,evidence=[],history=[],blockers=[],dependencies=[],next_action='Prepare Terra isolated bounded checkout, bind before source-only proposal implementation')
t['original_cpp_reference']={'paths':[str(bundle/'source-snapshot')],'revision':base,'source_manifest_sha256':info['source_manifest_sha256'],'freeze_status':'Independent copied exact1261current inputs plus complete terminal compiler diagnostics; freeze any supplemental helpers before adaptation'};t['acceptance_tests']=['All remaining diagnostics outside5director-owned connection fixtures mapped to exact unchanged source/assertions','Minimal reference-safe namespace/type/callback/borrow adapter proposals with supplemental helper closure and before/after hashes','No warning suppression, test removal, fallback to migrated policy or configured writes; director owns shared URL/GN/bridge application'];t['stages']={'implementation':'not started','configured_validation':'Compiler failures captured; no runtime validation','production_integration':'not applied','rust_ownership':'Existing Rust policy retained; independent original adapter compile debt under repair','subsystem_cutover':'incomplete'}
p=rt/'remaining-network-compile-task.json';p.write_text(json.dumps(t,indent=2)+'\n');c.enqueue(token,t);c.claim(token,t['id'],'terra-network-ordinary-compile-repair-20261117');print(json.dumps({'task':t['id'],'base':base,'input_bundle':str(bundle),'retired_clean_candidate':candidate,'worker_pool_slot_reserved':True}))
