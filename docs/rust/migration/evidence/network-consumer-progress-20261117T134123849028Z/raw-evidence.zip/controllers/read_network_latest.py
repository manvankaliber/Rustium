import json,pathlib,re
r=pathlib.Path('D:/Rustium');rt=r/'.rustium-runtime';d=pathlib.Path(json.loads((rt/'network-selected-consumer-build-latest.json').read_text())['directory'])
print(d)
p=d/'result.json'
if p.exists():
    v=json.loads(p.read_text());print(json.dumps({k:v.get(k) for k in ['passed','source_manifest_sha256','started_utc','finished_utc','exception','exit_code','full_command_executed']},indent=2))
for name in ['changed-objects.log','build.log']:
    p=d/name
    if not p.exists():continue
    lines=p.read_text(errors='replace').splitlines();print(name)
    errors=list(dict.fromkeys(line for line in lines if 'error:' in line))
    print('\n'.join(errors[:30]))
    if len(errors)>30:print(str(len(errors))+' unique error lines; inspect raw log for remainder')
    print('\n'.join(lines[-5:]))
