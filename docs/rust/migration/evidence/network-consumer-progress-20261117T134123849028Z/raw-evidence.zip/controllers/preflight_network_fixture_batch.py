import datetime,hashlib,importlib.util,json,pathlib,re,subprocess,sys
r=pathlib.Path('D:/Rustium');b=pathlib.Path('D:/RustiumBuild/src');rt=r/'.rustium-runtime';sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest();info=json.loads((rt/'shared-strings-connection-latest.json').read_text());out=pathlib.Path(info['run_directory'])/'connection-fixture-preflight';catalogue=pathlib.Path(json.loads((rt/'network-graph-catalogue-latest.json').read_text())['directory'])
if sys.argv[1:]!=['run','-j1']:
    assert not (rt/'job-active.json').exists()
    obs=subprocess.check_output(['powershell','-NoProfile','-Command',"Get-CimInstance Win32_Process | Where-Object { $_.Name -match '^(ninja|clang-cl|lld-link|net_unittests|base_unittests|rustc|cargo).*' } | Select-Object ProcessId,Name,CommandLine | ConvertTo-Json"],text=True).strip();assert not obs,obs
    req={'task_id':'NET-CURRENT-CONSUMER-CLOSURE','kind':'build','source_identity':info,'toolchain':{'script_sha256':sha(__file__)},'build_configuration':{'compiler_jobs':1,'scope':'Five connection fixture compiler repairs and affected flow object preflight ONLY; not all consumer targets or runtime acceptance'},'cwd':str(r),'process_reconciliation':{'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'compilers_native_tests':[]}}
    p=rt/'network-fixture-batch-preflight-request.json';p.write_text(json.dumps(req,indent=2)+'\n');(rt/'network-fixture-batch-preflight-latest.json').write_text(json.dumps({'directory':str(out)},indent=2)+'\n');token=json.loads((rt/'director.json').read_text())['token'];sys.exit(subprocess.call(['python','tools/rustium_coord.py','job','--token',token,'--manifest',str(p),'--','python','-B',__file__,'run','-j1'],cwd=r))
assert not out.exists();out.mkdir();(out/'runner.py').write_bytes(pathlib.Path(__file__).read_bytes());sys.path.insert(0,str(r/'docs/rust/migration/drafts/base-ordinary-delivery'));import ordinary_base_v2 as delivery
names=['connection_jobs_family_flow_unittest.cc','connection_jobs_family_flow_fixture.cc','connection_jobs_family_rust_unittest.cc','connection_jobs_provider_wiring_unittest.cc','socket_pool_additional_capacity_rust_original_unittest.cc'];objects=set();witness={name:[] for name in names}
for line in (catalogue/'ninja-commands.log').read_text().splitlines():
    for name in names:
        if name not in line:continue
        match=re.search(r'/Fo([^\s"]+)',line)
        if match:objects.add(match.group(1));witness[name].append(match.group(1))
assert all(witness.values()),witness
spec=importlib.util.spec_from_file_location('configured_env',r/'.scratch/net-wave5/configure_http2_family.py');envmod=importlib.util.module_from_spec(spec);spec.loader.exec_module(envmod)
ninja=str(b/'third_party/ninja/ninja.exe');command=[ninja,'-C',str(b/'out/Default'),'-v','-k0','-j1',*sorted(objects)];tools={str(p):sha(p) for p in [pathlib.Path(ninja),b/'third_party/llvm-build/Release+Asserts/bin/clang-cl.exe',pathlib.Path(envmod.__file__)]};args_sha=sha(b/'out/Default/args.gn')
result={'passed':False,'source_manifest_sha256':info['source_manifest_sha256'],'configured_args_sha256':args_sha,'command':command,'cwd':str(b),'object_sources':witness,'output_log':str(out/'build.log'),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Exact current connection fixture object compilation only; no full affected-consumer, native, binary ABI, performance or cutover acceptance'}
try:
    delivery.source_check(info);code=delivery.run_command(command,b,envmod.build_environment(),out/'build.log',timeout=1800);result['exit_code']=code;delivery.source_check(info)
    assert sha(b/'out/Default/args.gn')==args_sha and all(sha(p)==h for p,h in tools.items())
    result.update(passed=code==0,source_inputs_stable=True,source_drift=[],tools=tools)
except BaseException as error:result['exception']=type(error).__name__+': '+str(error)
finally:
    result['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();delivery.write(out/'result.json',result);print(json.dumps({'passed':result['passed'],'objects':len(objects),'directory':str(out)}))
sys.exit(0 if result['passed'] else 1)
