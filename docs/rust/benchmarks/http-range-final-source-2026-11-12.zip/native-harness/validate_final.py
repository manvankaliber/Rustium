import json,hashlib,subprocess,os,ctypes,time,sys,shutil
from pathlib import Path
root=Path('D:/Rustium');work=root/'.scratch/http-range';full=Path('D:/RustiumBuild/src');mode=sys.argv[1]
env=os.environ.copy()
for item in (full/'out/Default/environment.x64').read_bytes().decode().split('\0'):
 k,sep,v=item.partition('=')
 if sep:env[k]=v
env['PATH']=str(full/'out/Default')+os.pathsep+env.get('PATH','')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
paths=[root/'net/http/http_util.cc',*sorted((root/'net/http').glob('http_range*.rs')),*sorted((root/'net/http').glob('http_range*.h')),root/'net/http/http_range_benchmark_adapter.cc',root/'net/http/http_range_fuzzer.cc',root/'net/base/parse_number_parser.rs']
hashes={p.relative_to(root).as_posix():sha(p) for p in paths}
if mode=='fuzz':
 binary=work/'fuzz.exe';build=json.loads((work/'fuzz-build.json').read_text())
 assert sha(binary)==build['binary_sha256'] and all(sha(root/p)==h for p,h in build['source_sha256'].items())
 corpus=work/'inline-corpus';corpus.mkdir(exist_ok=True)
 for p in (root/'net/http/http_range_fuzzer_corpus').iterdir():shutil.copy2(p,corpus/p.name)
 command=[str(binary),'-runs=1000000','-max_len=512','-seed=20261112','-print_final_stats=1',str(corpus)]
 extra={'binary_sha256':sha(binary),'build':build,'instrumentation':'C++ libFuzzer inline counters and trace-cmp; Rust not sanitizer-instrumented','seed_corpus':{p.name:sha(p) for p in (root/'net/http/http_range_fuzzer_corpus').iterdir()}}
else:
 env['CARGO_TARGET_DIR']=str(work/'clippy-target');command=['C:/Users/jackv/.cargo/bin/cargo.exe','clippy','--release','--offline','--','-D','warnings'];extra={'toolchain':subprocess.check_output(['C:/Users/jackv/.cargo/bin/rustc.exe','--version'],text=True).strip(),'clippy':subprocess.check_output(['C:/Users/jackv/.cargo/bin/cargo.exe','clippy','--version'],text=True).strip()}
record={'command':command,'source_sha256':hashes,'cpu':8,**extra};(work/('final-'+mode+'-started.json')).write_text(json.dumps(record,indent=2)+'\n')
start=time.monotonic()
with (work/('final-'+mode+'.log')).open('wb') as stream:
 p=subprocess.Popen(command,cwd=work,env=env,stdout=stream,stderr=subprocess.STDOUT)
 if not ctypes.windll.kernel32.SetProcessAffinityMask(ctypes.c_void_p(int(p._handle)),ctypes.c_size_t(1<<8)):p.kill();raise RuntimeError('affinity failed')
 code=p.wait()
record.update(exit_code=code,elapsed_seconds=time.monotonic()-start,source_unchanged=all(sha(root/p)==h for p,h in hashes.items()))
(work/('final-'+mode+'-execution.json')).write_text(json.dumps(record,indent=2)+'\n');print(mode,'exit',code,'seconds',record['elapsed_seconds'],'unchanged',record['source_unchanged']);sys.exit(code)
