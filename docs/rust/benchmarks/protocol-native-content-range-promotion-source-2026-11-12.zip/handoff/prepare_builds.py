from pathlib import Path
r=Path('D:/Rustium');w=r/'.scratch/net-wave1/promote'
for module,old in [('numbers','protocol-numbers'),('range','http-range')]:
 p=w/module/'Cargo.toml';p.write_text(p.read_text().replace('../../../../../net','../../../../net'))
 p=w/module/'core/Cargo.toml';p.write_text(p.read_text().replace('../../../../../../net','../../../../../net'))
 text=(r/'.scratch'/old/('build_fast.py' if module=='numbers' else 'build_native.py')).read_text()
 text=text.replace("work=root/'.scratch/"+old+"'", "work=root/'.scratch/net-wave1/promote/"+module+"'")
 if module=='numbers':
  a=text.index("    subprocess.run(['C:/Users/jackv/.cargo/bin/cargo.exe'");b=text.index('\nvariables=dict',a)
  text=text[:a]+"    subprocess.run(['C:/Users/jackv/.cargo/bin/cargo.exe','build','--release','--offline'],cwd=work,env=env,check=True)\n    sys.exit()\n"+text[b:]
  text=text.replace('fast-coverage-target','coverage-target').replace('fast-target','chromium-target').replace("compile(work/'fast.cc','reader')","compile(root/'net/base/parse_number.cc','reader')").replace('protocol_number_validation.lib','protocol_number_native_validation.lib')
  for a,b in [('parse_number_test_support.cc','parse_number_native_reference.cc'),('parse_number_perftest.cc','parse_number_native_perftest.cc'),('parse_number_parser_unittest.cc','parse_number_native_unittest.cc'),('parse_number_fuzzer.cc','parse_number_native_fuzzer.cc')]:text=text.replace(a,b)
 else:
  # No historical output paths are reused, and baseline uses our independent frozen numbers.
  for a,b in [('http_range_test_support.cc','http_range_promote_reference.cc'),('parse_number_test_support.cc','parse_number_native_reference.cc'),('parse_number_test_support.h','parse_number_native_reference.h'),('http_range_perftest.cc','http_range_promote_perftest.cc'),('http_range_unittest.cc','http_range_promote_unittest.cc'),('http_range_fuzzer.cc','http_range_promote_fuzzer.cc'),('http_range_validation.lib','http_range_promote_validation.lib')]:text=text.replace(a,b)
  # Build metadata below is regenerated in shared validation driver instead.
  text=text[:text.index("\nif mode in ('bench', 'fuzz'):")]
 # Capture exact executed link command and compiler response files for every mode.
 text=text.replace("result=subprocess.run(command,cwd=out,env=env,capture_output=True,text=True)","import json\n(work/(mode+'-link-command.json')).write_text(json.dumps(command,indent=2)+'\\n')\nresult=subprocess.run(command,cwd=out,env=env,capture_output=True,text=True)")
 (w/module/'build_native.py').write_text(text)
# Explicit public API cases for null-empty input and uninitialized integer output.
p=r/'net/base/parse_number_native_unittest.cc';text=p.read_text();point=text.rindex('}  // namespace\n')
text=text[:point]+'''TEST(ParseNumberNativeTest, NullEmptyAndUninitializedSuccessOutputs) {
  const std::string_view empty;
  ParseIntError error = ParseIntError::FAILED_UNDERFLOW;
  EXPECT_FALSE(ParseInt64(empty, ParseIntFormat::NON_NEGATIVE, nullptr, &error));
  EXPECT_EQ(error, ParseIntError::FAILED_PARSE);
  int32_t a;
  int64_t b;
  uint32_t c;
  uint64_t d;
  error = ParseIntError::FAILED_OVERFLOW;
  EXPECT_TRUE(ParseInt32("123", ParseIntFormat::NON_NEGATIVE, &a, &error));
  EXPECT_TRUE(ParseInt64("123", ParseIntFormat::NON_NEGATIVE, &b, &error));
  EXPECT_TRUE(ParseUint32("123", ParseIntFormat::NON_NEGATIVE, &c, &error));
  EXPECT_TRUE(ParseUint64("123", ParseIntFormat::NON_NEGATIVE, &d, &error));
  EXPECT_EQ(a, 123);
  EXPECT_EQ(b, 123);
  EXPECT_EQ(c, 123u);
  EXPECT_EQ(d, 123u);
  EXPECT_EQ(error, ParseIntError::FAILED_OVERFLOW);
}

'''+text[point:];p.write_text(text)
print('Prepared isolated native builds.')
