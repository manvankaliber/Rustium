from pathlib import Path
import subprocess,json
w=Path('D:/Rustium/.scratch/net-wave1/promote');tools=Path('D:/Rustium/.scratch/gzip-header/llvm-tools/bin')
for module in ('numbers','range'):
 work=w/module;commands=[]
 cmd=[str(tools/'llvm-profdata.exe'),'merge','-sparse',*map(str,work.glob('unit-*.profraw')),'-o',str(work/'coverage.profdata')];commands.append(cmd);subprocess.run(cmd,check=True)
 for kind,args in [('coverage',['export']),('coverage-summary',['export','-summary-only'])]:
  cmd=[str(tools/'llvm-cov.exe'),*args,str(work/'unit.exe'),'-instr-profile='+str(work/'coverage.profdata')];commands.append(cmd)
  p=subprocess.run(cmd,capture_output=True,text=True);(work/(kind+'.json')).write_text(p.stdout);(work/(kind+'-stderr.log')).write_text(p.stderr);p.check_returncode()
 (work/'coverage-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 data=json.loads((work/'coverage-summary.json').read_text())
 print(module,[(Path(f['filename']).name,f['summary']['lines'],f['summary']['regions']) for f in data['data'][0]['files'] if 'net\\base\\parse_number' in f['filename'] or 'net\\http\\http_range' in f['filename']])

