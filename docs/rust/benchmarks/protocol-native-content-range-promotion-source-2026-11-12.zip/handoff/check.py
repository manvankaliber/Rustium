from pathlib import Path
import subprocess,json,hashlib,re,sys
r=Path('D:/Rustium');w=r/'.scratch/net-wave1/promote';full=Path('D:/RustiumBuild/src')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
from importlib.util import spec_from_file_location,module_from_spec
spec=spec_from_file_location('runner',r/'tools/run_rust_rewrite_benchmarks.py');runner=module_from_spec(spec);spec.loader.exec_module(runner)
wrap=(w/'content-range-wrapper.cc.txt').read_text();adapter=(r/'net/http/http_range_benchmark_adapter.cc').read_text();sig='bool HttpUtil::ParseContentRangeHeaderFor206('
assert runner.method_tokens(wrap,sig)==runner.method_tokens(adapter,sig)
initial=json.loads((w/'initial-source-manifest.json').read_text())
frozen=['net/base/parse_number_parser.rs','net/base/parse_number_ffi.rs','net/base/parse_number_candidate.cc','net/http/http_range_ffi.rs','net/http/http_range_parser.rs','net/http/http_range_benchmark_adapter.cc']
assert all(sha(r/p)==initial[p] for p in frozen)
for module,source in [('numbers','net/base/parse_number_native_perftest.cc'),('range','net/http/http_range_promote_perftest.cc')]:
 d=json.loads((w/(module+'-benchmark-descriptor.json')).read_text());keys=[c[0] for g in d['groups'] for c in g['cases']];assert len(keys)==len(set(keys))==35 and all(len(g['cases'])<=5 for g in d['groups'])
 source_text=(r/source).read_text();assert all(('"'+k+'"') in source_text for k in keys)
for module in ('numbers','range'):
 for mode in ('unit','fuzz','clippy'):
  ex=json.loads((w/module/(mode+'-execution.json')).read_text());assert ex['exit_code']==0 and ex['source_unchanged'];assert all(sha(r/p)==h for p,h in ex['source_sha256'].items())
commands=[]
cpp=[str(r/'net/base/parse_number.cc'),*map(str,(r/'net/base').glob('parse_number_native_*.cc')),*map(str,(r/'net/base').glob('parse_number_native_*.h')),*map(str,(r/'net/http').glob('http_range_promote_*.cc')),*map(str,(r/'net/http').glob('http_range_promote_*.h'))]
for cmd in [[str(r/'.scratch/clang-format/clang_format/data/bin/clang-format.exe'),'--dry-run','--Werror',*cpp],[str(full/'third_party/rust-toolchain/bin/rustfmt.exe'),'--edition','2024','--check',str(r/'net/base/parse_number_native_ffi.rs')]]:
 p=subprocess.run(cmd,capture_output=True,text=True);commands.append({'command':cmd,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr});p.check_returncode()
(w/'identity-format-checks.json').write_text(json.dumps({'wrapper_exact_tokens_match_adapter':True,'unchanged_frozen_files':frozen,'descriptors_each_have_35_unique_cases':True,'all_validation_source_manifests_still_match':True,'formatting':commands},indent=2)+'\n')
# Freeze additional original helper dependencies, which are unchanged in this task.
for p in ['base/strings/string_number_conversions.h','base/strings/string_util.cc','base/strings/string_util_internal.h','base/strings/string_util_constants.cc','base/strings/string_util_win.cc','base/strings/string_util_win.h','base/strings/string_tokenizer.cc']:
 source=r/p
 if source.exists():
  dest=w/'baseline'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(source.read_bytes())
print('Token identity, frozen dependencies, all 70 descriptor cases and formatting verified.')
