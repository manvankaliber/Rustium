from pathlib import Path
import json,hashlib,shutil
r=Path('D:/Rustium'); w=r/'.scratch/net-wave1/promote'; b=w/'baseline';b.mkdir(exist_ok=True)
paths=['net/base/parse_number.cc','net/base/parse_number.h','net/base/parse_number_parser.rs','net/base/parse_number_ffi.rs','net/base/parse_number_candidate.cc','net/http/http_util.cc','net/http/http_range_benchmark_adapter.cc','net/http/http_range_ffi.rs','net/http/http_range_parser.rs','net/http/http_range_test_support.cc','net/http/http_byte_range.cc','base/strings/string_number_conversions.cc','base/strings/string_number_conversions_internal.h','base/strings/string_util.h','base/strings/string_tokenizer.h']
for p in paths:
 dest=b/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r/p,dest)
(w/'initial-source-manifest.json').write_text(json.dumps({p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in paths},indent=2)+'\n')
# Independent references/test namespaces keep historical artifacts reproducible.
for old,new in [('parse_number_test_support.h','parse_number_native_reference.h'),('parse_number_test_support.cc','parse_number_native_reference.cc'),('parse_number_parser_unittest.cc','parse_number_native_unittest.cc'),('parse_number_fuzzer.cc','parse_number_native_fuzzer.cc'),('parse_number_perftest.cc','parse_number_native_perftest.cc')]:
 text=(r/'net/base'/old).read_text().replace('parse_number_test_support.h','parse_number_native_reference.h').replace('parse_number_internal::test','parse_number_native_internal::test').replace('PARSE_NUMBER_TEST_SUPPORT','PARSE_NUMBER_NATIVE_REFERENCE').replace('ParseNumberRustTest','ParseNumberNativeTest')
 (r/'net/base'/new).write_text(text)
# Own Range copies; original reference already routes numeric parsing to frozen C++.
for old,new in [('http_range_test_support.h','http_range_promote_reference.h'),('http_range_test_support.cc','http_range_promote_reference.cc'),('http_range_unittest.cc','http_range_promote_unittest.cc'),('http_range_fuzzer.cc','http_range_promote_fuzzer.cc'),('http_range_perftest.cc','http_range_promote_perftest.cc')]:
 text=(r/'net/http'/old).read_text().replace('http_range_test_support.h','http_range_promote_reference.h').replace('http_range_internal::test','http_range_promote_internal::test').replace('HTTP_RANGE_TEST_SUPPORT','HTTP_RANGE_PROMOTE_REFERENCE').replace('HttpRangeRustTest','HttpRangePromoteTest').replace('parse_number_test_support.h','parse_number_native_reference.h').replace('parse_number_internal::test','parse_number_native_internal::test')
 (r/'net/http'/new).write_text(text)
text=(r/'.scratch/protocol-numbers/fast_ffi.rs').read_text().replace('rustium_parse_number_','rustium_parse_number_native_')
(r/'net/base/parse_number_native_ffi.rs').write_text('// Copyright 2026 The Chromium Authors\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.\n\n//! Narrow production C ABI. Grammar and numeric policy live in the unchanged\n//! safe parse_number_core crate. No CXX representations cross this boundary.\n\n'+text)
text=(r/'.scratch/protocol-numbers/fast.cc').read_text().replace('#include "base/check.h"','#include "base/check.h"\n#include "net/base/parse_number_native_ffi.h"').replace('#include <type_traits>','').replace('rustium_parse_number_','parse_number_native_internal::rustium_parse_number_native_')
text='\n'.join(line for line in text.splitlines() if not line.startswith('extern "C"'))+'\n'
text=text.replace('static_assert(sizeof(ParseIntError) == 4);','static_assert(sizeof(ParseIntFormat) == sizeof(int32_t));\nstatic_assert(static_cast<int32_t>(ParseIntFormat::NON_NEGATIVE) == 0);\nstatic_assert(static_cast<int32_t>(ParseIntFormat::OPTIONALLY_NEGATIVE) == 1);\nstatic_assert(static_cast<int32_t>(ParseIntFormat::STRICT_NON_NEGATIVE) == 2);\nstatic_assert(static_cast<int32_t>(ParseIntFormat::STRICT_OPTIONALLY_NEGATIVE) == 3);\nstatic_assert(sizeof(ParseIntError) == 4);')
(r/'net/base/parse_number.cc').write_text('// Copyright 2016 The Chromium Authors\n// Use of this source code is governed by a BSD-style license that can be\n// found in the LICENSE file.\n\n'+text)
header='''// Copyright 2026 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef NET_BASE_PARSE_NUMBER_NATIVE_FFI_H_
#define NET_BASE_PARSE_NUMBER_NATIVE_FFI_H_

#include <cstddef>
#include <cstdint>

#include "net/base/parse_number.h"

namespace net::parse_number_native_internal {
// Synchronous C ABI for the public numeric adapters. A nonempty input identifies
// len initialized live bytes (len <= PTRDIFF_MAX); null input is allowed for zero
// length. Only success writes output; its aligned storage may be uninitialized.
// Only failure writes a non-null error. No previous output/error value is read.
// Input may overlap either output: the input borrow ends before scalar writes.
// Formats preserve the public enum values and legacy unknown signed formats;
// unsigned format validation remains a CHECK in the public C++ wrapper.
extern "C" {
'''
for name,ty in [('i32','int32_t'),('i64','int64_t'),('u32','uint32_t'),('u64','uint64_t')]:header+=f'bool rustium_parse_number_native_{name}(const uint8_t* input, size_t len, int32_t format, {ty}* output, ParseIntError* error);\n'
header+='''}
}  // namespace net::parse_number_native_internal

#endif  // NET_BASE_PARSE_NUMBER_NATIVE_FFI_H_
'''
(r/'net/base/parse_number_native_ffi.h').write_text(header)
a=(r/'net/http/http_range_benchmark_adapter.cc').read_text();start=a.index('bool HttpUtil::ParseContentRangeHeaderFor206(');body=a[start:a.rindex('}  // namespace net')].strip()+'\n'
(w/'content-range-wrapper.cc.txt').write_text(body)
for module,old in [('numbers','protocol-numbers'),('range','http-range')]:
 target=w/module; (target/'core').mkdir(parents=True,exist_ok=True);(target/'.cargo').mkdir(exist_ok=True)
 (target/'core/Cargo.toml').write_text('[package]\nname="parse_number_core"\nversion="0.1.0"\nedition="2024"\n[lib]\npath="../../../../../../net/base/parse_number_parser.rs"\n')
 crate='protocol_number_native_validation' if module=='numbers' else 'http_range_promote_validation';source='net/base/parse_number_native_ffi.rs' if module=='numbers' else 'net/http/http_range_ffi.rs'
 (target/'Cargo.toml').write_text(f'[package]\nname="{crate}"\nversion="0.1.0"\nedition="2024"\n[lib]\npath="../../../../../{source}"\ncrate-type=["staticlib"]\n[dependencies]\nparse_number_core={{path="core"}}\n'+('memchr="=2.8.3"\n' if module=='range' else '')+'[profile.release]\nopt-level=3\ncodegen-units=1\n')
 shutil.copy2(r/'.scratch/http-range/.cargo/config.toml',target/'.cargo/config.toml')
 desc=json.loads((r/'.scratch'/old/'benchmark-descriptor.json').read_text());desc['production_status']='integrated';desc['include_in_average']=True;desc['acceptance_note']='Use only after parent canonical integration and validation; native screening does not establish configured final provenance.'
 for g in desc['groups']:g['production_status']='integrated';g['include_in_average']=True
 (w/(module+'-benchmark-descriptor.json')).write_text(json.dumps(desc,indent=2)+'\n')
print('Prepared production adapter, independent references, wrappers and 70-case descriptors.')
