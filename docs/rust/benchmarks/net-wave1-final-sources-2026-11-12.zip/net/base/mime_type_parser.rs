// Copyright 2026 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

//! Byte-preserving legacy MIME grammar and Content-Type state transitions.
#![forbid(unsafe_code)]

#[derive(Debug, Default, PartialEq, Eq)]
pub struct Parameter {
    pub name: Vec<u8>,
    pub value: Vec<u8>,
}

#[derive(Debug, Default, PartialEq, Eq)]
pub struct Parsed {
    pub mime: Vec<u8>,
    pub parameters: Vec<Parameter>,
}

fn lws(b: u8) -> bool {
    matches!(b, b' ' | b'\t')
}

fn trim_lws(bytes: &[u8]) -> &[u8] {
    bytes.trim_ascii_start_with(lws).trim_ascii_end_with(lws)
}

// Explicit predicates avoid Unicode normalization and preserve arbitrary bytes.
trait TrimBytes {
    fn trim_ascii_start_with(&self, predicate: fn(u8) -> bool) -> &Self;
    fn trim_ascii_end_with(&self, predicate: fn(u8) -> bool) -> &Self;
}

impl TrimBytes for [u8] {
    fn trim_ascii_start_with(&self, predicate: fn(u8) -> bool) -> &Self {
        &self[self.iter().position(|&b| !predicate(b)).unwrap_or(self.len())..]
    }

    fn trim_ascii_end_with(&self, predicate: fn(u8) -> bool) -> &Self {
        &self[..self.iter().rposition(|&b| !predicate(b)).map_or(0, |i| i + 1)]
    }
}

/// The permissive parser is intentionally distinct from the HTTP-token parser.
/// A slash anywhere before the first type delimiter suffices, even for `/`.
pub fn parse(input: &[u8], want_parameters: bool) -> Option<Parsed> {
    let start = input.iter().position(|&b| !lws(b)).unwrap_or(input.len());
    let end = input[start..]
        .iter()
        .position(|&b| lws(b) || matches!(b, b';' | b'('))
        .map_or(input.len(), |i| start + i);
    if input.iter().position(|&b| b == b'/')? > end {
        return None;
    }
    let mut result = Parsed { mime: input[start..end].to_vec(), parameters: Vec::new() };
    if !want_parameters {
        return Some(result);
    }
    let mut offset = end;
    while let Some(semicolon) = input[offset..].iter().position(|&b| b == b';') {
        offset += semicolon + 1;
        while offset < input.len() && lws(input[offset]) {
            offset += 1;
        }
        let name_start = offset;
        while offset < input.len() && !matches!(input[offset], b';' | b'=') {
            offset += 1;
        }
        if offset == input.len() || input[offset] == b';' {
            continue;
        }
        let name = &input[name_start..offset];
        offset += 1;
        while offset < input.len() && lws(input[offset]) {
            offset += 1;
        }
        if offset == input.len() || input[offset] == b';' {
            continue;
        }
        let value = if input[offset] == b'"' {
            offset += 1;
            let mut unescaped = Vec::new();
            while offset < input.len() && input[offset] != b'"' {
                if input[offset] == b'\\' && offset + 1 < input.len() {
                    offset += 1;
                }
                unescaped.push(input[offset]);
                offset += 1;
            }
            // Post-quote junk is discarded up to the next semicolon. The
            // closing quote itself is consumed by the next delimiter search.
            unescaped
        } else {
            let value_start = offset;
            while offset < input.len() && input[offset] != b';' {
                offset += 1;
            }
            input[value_start..offset].trim_ascii_end_with(lws).to_vec()
        };
        result.parameters.push(Parameter { name: name.to_vec(), value });
    }
    Some(result)
}

fn ascii_whitespace(b: u8) -> bool {
    // base::kWhitespaceASCII includes vertical tab, unlike is_ascii_whitespace.
    matches!(b, b' ' | b'\t' | b'\n' | b'\x0b' | b'\x0c' | b'\r')
}

fn token(input: &[u8]) -> bool {
    !input.is_empty()
        && input.iter().all(|&b| b > 0x20 && b < 0x7f && !b"()<>@,;:\\\"/[]?={}".contains(&b))
}

pub fn without_parameters(input: &[u8]) -> Option<(&[u8], &[u8])> {
    let slash = input.iter().position(|&b| b == b'/')?;
    let top = input[..slash].trim_ascii_start_with(ascii_whitespace);
    let sub = input[slash + 1..].trim_ascii_end_with(ascii_whitespace);
    (token(top) && token(sub)).then_some((top, sub))
}

#[derive(Debug, Default, PartialEq, Eq)]
pub struct ContentTypeUpdate {
    pub needs_had_charset: bool,
    pub write_mime: bool,
    pub mime: Vec<u8>,
    pub write_charset: bool,
    pub charset: Vec<u8>,
    pub write_boundary: bool,
    pub boundary: Vec<u8>,
}

/// Parse and select first parameters before inspecting any caller outputs.
pub fn select_content_type(input: &[u8], want_boundary: bool) -> Option<ContentTypeSelection> {
    let parsed = parse(input, true)?;
    if input == b"*/*" {
        return None;
    }
    let mut selection =
        ContentTypeSelection { mime: parsed.mime, ..ContentTypeSelection::default() };
    let mut charset = None;
    for parameter in parsed.parameters {
        if charset.is_none() && parameter.name.eq_ignore_ascii_case(b"charset") {
            charset = Some(trim_lws(&parameter.value).to_ascii_lowercase());
        } else if want_boundary
            && !selection.has_boundary
            && parameter.name.eq_ignore_ascii_case(b"boundary")
        {
            selection.has_boundary = true;
            selection.boundary = trim_lws(&parameter.value).to_vec();
        }
    }
    selection.has_charset = charset.is_some();
    selection.charset = charset.unwrap_or_default();
    Some(selection)
}

#[derive(Debug, Default, PartialEq, Eq)]
pub struct ContentTypeSelection {
    pub mime: Vec<u8>,
    pub has_charset: bool,
    pub charset: Vec<u8>,
    pub has_boundary: bool,
    pub boundary: Vec<u8>,
}

// State is inspected only after parsing succeeds. Equality is computed after
// the boundary assignment (which may alias MIME), before any charset write.
pub fn plan_content_type(
    selection: ContentTypeSelection,
    current_mime: &[u8],
    boundary_is_mime: bool,
) -> ContentTypeUpdate {
    let previous =
        if boundary_is_mime && selection.has_boundary { &selection.boundary } else { current_mime };
    let equal = selection.mime.eq_ignore_ascii_case(previous);
    ContentTypeUpdate {
        needs_had_charset: !equal,
        write_mime: !equal,
        mime: selection.mime.to_ascii_lowercase(),
        write_charset: selection.has_charset,
        charset: selection.charset,
        write_boundary: selection.has_boundary,
        boundary: selection.boundary,
    }
}

pub fn resolve_charset(has_charset: bool, had_charset: bool) -> bool {
    had_charset || has_charset
}
