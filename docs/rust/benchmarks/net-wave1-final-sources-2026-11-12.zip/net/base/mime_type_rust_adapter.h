// Copyright 2026 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef NET_BASE_MIME_TYPE_RUST_ADAPTER_H_
#define NET_BASE_MIME_TYPE_RUST_ADAPTER_H_

#include <cstdint>
#include <string>
#include <string_view>

#include "base/containers/span_rust.h"
#include "net/base/mime_type_ffi.rs.h"

namespace net::mime_type_internal {

// CXX borrows only for the call. Its result owns all bytes, including NULs and
// non-UTF8 bytes, before any possibly aliased caller output is changed.
inline rust::Slice<const uint8_t> Bytes(std::string_view input) {
  return base::SpanToRustSlice(base::as_byte_span(input));
}

inline std::string String(const rust::Vec<uint8_t>& bytes) {
  return {reinterpret_cast<const char*>(bytes.data()), bytes.size()};
}

}  // namespace net::mime_type_internal

#endif  // NET_BASE_MIME_TYPE_RUST_ADAPTER_H_
