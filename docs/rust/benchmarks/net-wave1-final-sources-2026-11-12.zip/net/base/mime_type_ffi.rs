// Copyright 2026 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

mod mime_type_parser;

#[cxx::bridge(namespace = "net::mime_type_internal")]
mod ffi {
    struct Parameter {
        name: Vec<u8>,
        value: Vec<u8>,
    }
    struct Parsed {
        valid: bool,
        mime: Vec<u8>,
        parameters: Vec<Parameter>,
    }
    struct Components {
        valid: bool,
        top: Vec<u8>,
        sub: Vec<u8>,
    }
    struct ContentTypeUpdate {
        needs_had_charset: bool,
        write_mime: bool,
        mime: Vec<u8>,
        write_charset: bool,
        charset: Vec<u8>,
        write_boundary: bool,
        boundary: Vec<u8>,
    }
    struct ContentTypeSelection {
        valid: bool,
        mime: Vec<u8>,
        has_charset: bool,
        charset: Vec<u8>,
        has_boundary: bool,
        boundary: Vec<u8>,
    }
    extern "Rust" {
        fn parse_mime(input: &[u8], want_parameters: bool) -> Parsed;
        fn parse_without_parameters(input: &[u8]) -> Components;
        fn select_content_type(input: &[u8], want_boundary: bool) -> ContentTypeSelection;
        fn plan_content_type(
            selection: ContentTypeSelection,
            current_mime: &[u8],
            boundary_is_mime: bool,
        ) -> ContentTypeUpdate;
        fn resolve_charset(update: &mut ContentTypeUpdate, had_charset: bool);
    }
}

fn parse_mime(input: &[u8], want_parameters: bool) -> ffi::Parsed {
    let parsed = mime_type_parser::parse(input, want_parameters);
    let valid = parsed.is_some();
    let parsed = parsed.unwrap_or_default();
    ffi::Parsed {
        valid,
        mime: parsed.mime,
        parameters: parsed
            .parameters
            .into_iter()
            .map(|p| ffi::Parameter { name: p.name, value: p.value })
            .collect(),
    }
}

fn parse_without_parameters(input: &[u8]) -> ffi::Components {
    let parsed = mime_type_parser::without_parameters(input);
    let valid = parsed.is_some();
    let (top, sub) = parsed.unwrap_or_default();
    ffi::Components { valid, top: top.to_vec(), sub: sub.to_vec() }
}

fn select_content_type(input: &[u8], want_boundary: bool) -> ffi::ContentTypeSelection {
    let selection = mime_type_parser::select_content_type(input, want_boundary);
    let valid = selection.is_some();
    let selection = selection.unwrap_or_default();
    ffi::ContentTypeSelection {
        valid,
        mime: selection.mime,
        has_charset: selection.has_charset,
        charset: selection.charset,
        has_boundary: selection.has_boundary,
        boundary: selection.boundary,
    }
}

fn plan_content_type(
    selection: ffi::ContentTypeSelection,
    current_mime: &[u8],
    boundary_is_mime: bool,
) -> ffi::ContentTypeUpdate {
    let selection = mime_type_parser::ContentTypeSelection {
        mime: selection.mime,
        has_charset: selection.has_charset,
        charset: selection.charset,
        has_boundary: selection.has_boundary,
        boundary: selection.boundary,
    };
    let update = mime_type_parser::plan_content_type(selection, current_mime, boundary_is_mime);
    ffi::ContentTypeUpdate {
        needs_had_charset: update.needs_had_charset,
        write_mime: update.write_mime,
        mime: update.mime,
        write_charset: update.write_charset,
        charset: update.charset,
        write_boundary: update.write_boundary,
        boundary: update.boundary,
    }
}

fn resolve_charset(update: &mut ffi::ContentTypeUpdate, had_charset: bool) {
    update.write_charset = mime_type_parser::resolve_charset(update.write_charset, had_charset);
}
