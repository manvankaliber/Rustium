// Copyright 2018 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef NET_BASE_FEATURES_H_
#define NET_BASE_FEATURES_H_

#include <stddef.h>

#include <optional>
#include <string>
#include <string_view>

#include "base/feature_list.h"
#include "base/metrics/field_trial_params.h"
#include "base/task/task_traits.h"
#include "base/time/time.h"
#include "build/build_config.h"
#include "crypto/crypto_buildflags.h"
#include "net/base/net_export.h"
#include "net/disk_cache/buildflags.h"
#include "net/net_buildflags.h"

namespace net::features {

// If enabled, HttpNetworkTransaction will use a hybrid retry strategy for
// connection errors: retrying synchronously initially, and switching to
// asynchronous (yielding to the message loop) after many attempts.
NET_EXPORT BASE_DECLARE_FEATURE(kAsyncRetryOnTooManyConnectionErrors);

// If enabled, when an HttpNetworkTransaction retries a request and the new
// attempt uses a different proxy chain, the proxy auth controller is discarded,
// as is server auth state for non-cryptographic schemes. Requests fail if this
// discards auth state too many times. Also, 407 responses are rejected when not
// talking to a proxy using GET.
NET_EXPORT BASE_DECLARE_FEATURE(kClearAuthControllersOnProxyChange);

// Derives Android connection type from NetworkCapabilities inside
// NetworkCallbacks instead of calling synchronous ConnectivityManager methods.
NET_EXPORT BASE_DECLARE_FEATURE(kDeriveConnectionTypeFromCapabilities);

// Enables the built-in DNS resolver.
NET_EXPORT BASE_DECLARE_FEATURE(kAsyncDns);

// Enables optimistic DNS for TCP.
NET_EXPORT BASE_DECLARE_FEATURE(kOptimisticDnsForTcp);
NET_EXPORT extern const base::FeatureParam<bool>
    kUseStaleConnectorsForOptimisticDns;

// Enables optimistic DNS for QUIC.
NET_EXPORT BASE_DECLARE_FEATURE(kOptimisticDnsForQuic);

// Caches UDP connect() results in AddressSorterPosix.
NET_EXPORT BASE_DECLARE_FEATURE(kAddressSorterConnectCache);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(size_t,
                                      kAddressSorterConnectCacheMaxNetworks);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(
    size_t,
    kAddressSorterConnectCacheMaxNaksPerNetwork);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(
    size_t,
    kAddressSorterConnectCacheMaxPredictionsPerPartition);

// Support for altering the parameters used for DNS transaction timeout. See
// ResolveContext::SecureTransactionTimeout().
NET_EXPORT BASE_DECLARE_FEATURE(kDnsTransactionDynamicTimeouts);
// Multiplier applied to current fallback periods in determining a transaction
// timeout.
NET_EXPORT extern const base::FeatureParam<double>
    kDnsTransactionTimeoutMultiplier;
NET_EXPORT extern const base::FeatureParam<base::TimeDelta>
    kDnsMinTransactionTimeout;

// Enables fail-fast and retry behavior for DNS_PLATFORM queries.
NET_EXPORT BASE_DECLARE_FEATURE(kDnsPlatformFailFastAndRetry);
NET_EXPORT extern const base::FeatureParam<bool>
    kDnsPlatformCancelPreviousAttemptOnRetry;

// If enabled, HostResolverDnsTask ignores errors from an address (A/AAAA) DNS
// transaction if the sibling address transaction succeeds with usable
// addresses, rather than failing the entire DnsTask and falling back to the
// system resolver.
NET_EXPORT BASE_DECLARE_FEATURE(kDnsTaskAllowPartialAddressResults);

// Enables querying HTTPS DNS records that will affect results from HostResolver
// and may be used to affect connection behavior. Whether or not those results
// are used (e.g. to connect via ECH) may be controlled by separate features.
NET_EXPORT BASE_DECLARE_FEATURE(kUseDnsHttpsSvcb);

// If enabled, HostResolver carries address hints (ipv4hint/ipv6hint) from
// HTTPS DNS records in its results for consumption by the
// ServiceEndpointRequest path.
NET_EXPORT BASE_DECLARE_FEATURE(kUseDnsHttpsSvcbAddressHints);

// Enables partial support for Structured DNS Errors
// (draft-ietf-dnsop-structured-dns-error). When enabled, the Chrome DNS
// resolver will indicate support for structured extended errors in outgoing DNS
// requests, render EDNS error codes on the error page, and populate filtering
// details when provided as a structured error
// (draft-nottingham-public-resolver-errors).
NET_EXPORT BASE_DECLARE_FEATURE(kUseStructuredDnsErrors);

// Param to control whether or not HostResolver, when using Secure DNS, will
// fail the entire connection attempt when receiving an inconclusive response to
// an HTTPS query (anything except transport error, timeout, or SERVFAIL). Used
// to prevent certain downgrade attacks against ECH behavior.
NET_EXPORT extern const base::FeatureParam<bool>
    kUseDnsHttpsSvcbEnforceSecureResponse;

// If we are still waiting for an HTTPS transaction after all the
// other transactions in an insecure DnsTask have completed, we will compute a
// timeout for the remaining transaction. The timeout will be
// `kUseDnsHttpsSvcbInsecureExtraTimePercent.Get() / 100 * t`, where `t` is the
// time delta since the first query began. And the timeout will additionally be
// clamped by:
//   (a) `kUseDnsHttpsSvcbInsecureExtraTimeMin.Get()`
//   (b) `kUseDnsHttpsSvcbInsecureExtraTimeMax.Get()`
//
// Any param is ignored if zero, and if one of min/max is non-zero with a zero
// percent param it will be used as an absolute timeout. If all are zero, there
// is no timeout specific to HTTPS transactions, only the regular DNS query
// timeout and server fallback.
NET_EXPORT extern const base::FeatureParam<base::TimeDelta>
    kUseDnsHttpsSvcbInsecureExtraTimeMax;
NET_EXPORT extern const base::FeatureParam<int>
    kUseDnsHttpsSvcbInsecureExtraTimePercent;
NET_EXPORT extern const base::FeatureParam<base::TimeDelta>
    kUseDnsHttpsSvcbInsecureExtraTimeMin;

// Same as `kUseDnsHttpsSvcbInsecureExtraTime...` except for secure DnsTasks.
//
// If `kUseDnsHttpsSvcbEnforceSecureResponse` is enabled, the timeouts will not
// be used because there is no sense killing a transaction early if that will
// just kill the entire request.
NET_EXPORT extern const base::FeatureParam<base::TimeDelta>
    kUseDnsHttpsSvcbSecureExtraTimeMax;
NET_EXPORT extern const base::FeatureParam<int>
    kUseDnsHttpsSvcbSecureExtraTimePercent;
NET_EXPORT extern const base::FeatureParam<base::TimeDelta>
    kUseDnsHttpsSvcbSecureExtraTimeMin;

// If enabled, HostResolver will use the new HostResolverCache that separately
// caches by DNS type, unlike the old HostCache that always cached by merged
// request results. May enable related behavior such as separately sorting DNS
// results after each transaction rather than sorting collectively after all
// transactions complete.
NET_EXPORT BASE_DECLARE_FEATURE(kUseHostResolverCache);

// Enables Happy Eyeballs V2 by using TcpConnectJobs in place of
// TransportConnectJobs. TcpConnectJobs start establishing TCP connections even
// while only partial DNS results are available.
//
// `kHappyEyeballsV3` takes precedence over this, though this will still affect
// proxy connections if both are enabled.
NET_EXPORT BASE_DECLARE_FEATURE(kHappyEyeballsV2);

// Enables the Happy Eyeballs v3, where we use intermediate DNS resolution
// results to make connection attempts as soon as possible.
NET_EXPORT BASE_DECLARE_FEATURE(kHappyEyeballsV3);

// Enables HostResolverManager::Job to report intermediate DNS resolution
// results to ServiceEndpointRequest delegates.
// Note: If kHappyEyeballsV3 is enabled, this behavior is automatically active
// regardless of this flag's state.
NET_EXPORT BASE_DECLARE_FEATURE(kEnableIntermediateDnsResults);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(
    bool,
    kEnableIntermediateDnsResultsSortTransactionsIndividually);

// Feature to control the Happy Eyeballs slow timer (IPv6 fallback time).
NET_EXPORT BASE_DECLARE_FEATURE(kAdjustIPv6FallbackTime);

// The duration to use for the slow timer if the feature is enabled.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(base::TimeDelta, kIPv6FallbackTime);

// Feature to base the Happy Eyeballs slow timer on the network RTT.
NET_EXPORT BASE_DECLARE_FEATURE(kIPv6FallbackBasedOnRTT);

// The multiplier for the RTT if the RTT based fallback feature is enabled.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(double, kIPv6FallbackRTTMultiplier);

// The minimum value to use for the fallback time if the RTT based fallback
// feature is enabled.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(base::TimeDelta, kIPv6FallbackMin);

// The maximum value to use for the fallback time if the RTT based fallback
// feature is enabled.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(base::TimeDelta, kIPv6FallbackMax);

// Allows Cache-Control: immutable to override Pragma: no-cache.
NET_EXPORT BASE_DECLARE_FEATURE(kCacheControlImmutable);

// Enables transparent zstd decompression of cached HTTP response bodies
// written by the CDT (Compression Dictionary Transport) cache compression
// feature. When disabled, compressed cache entries are doomed and the
// request falls back to the network.
NET_EXPORT BASE_DECLARE_FEATURE(kHttpCacheZstdDecompression);

// Enables transparent zstd compression of cacheable HTTP response bodies
// at cache-write time by the CDT (Compression Dictionary Transport) cache
// compression feature. When disabled, bodies are stored uncompressed as
// before. Requires kHttpCacheZstdDecompression to be enabled for the
// resulting cache entries to be served on subsequent reads.
NET_EXPORT BASE_DECLARE_FEATURE(kHttpCacheZstdCompression);

// Enables the Renderer-Accessible HTTP Cache (crbug.com/473666511), an
// experimental feature allowing renderers direct access to the HTTP cache.
NET_EXPORT BASE_DECLARE_FEATURE(kRendererAccessibleHttpCache);
// Enables Write-Ahead Logging (WAL) mode for the Renderer-Accessible HTTP
// Cache.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(bool,
                                      kRendererAccessibleHttpCacheWalMode);

// If the `kUseAlternativePortForGloballyReachableCheck` flag is enabled, the
// globally reachable check will use the port number specified by
// `kAlternativePortForGloballyReachableCheck` flag. Otherwise, the globally
// reachable check will use 443 port.
NET_EXPORT extern const base::FeatureParam<int>
    kAlternativePortForGloballyReachableCheck;
NET_EXPORT BASE_DECLARE_FEATURE(kUseAlternativePortForGloballyReachableCheck);

// If enabled, overrides IPv6 reachability probe results based on the system's
// IP addresses.
NET_EXPORT BASE_DECLARE_FEATURE(kEnableIPv6ReachabilityOverride);

// If enabled, avoids aborting connections in response to adding or removing an
// IPv6 temporary address.
NET_EXPORT BASE_DECLARE_FEATURE(kMaintainConnectionsOnIpv6TempAddrChange);

// Enables TLS 1.3 early data.
NET_EXPORT BASE_DECLARE_FEATURE(kEnableTLS13EarlyData);

// Enables optimizing the network quality estimation algorithms in network
// quality estimator (NQE).
NET_EXPORT BASE_DECLARE_FEATURE(kNetworkQualityEstimator);

// Enables caching of IsPrivateHost() results in NetworkQualityEstimator.
NET_EXPORT BASE_DECLARE_FEATURE(kNetworkQualityEstimatorIsPrivateHostCache);

// The maximum age in seconds of observations to be used for calculating the
// HTTP RTT from the historical data.
// Negative value means infinite. i.e. all data are used.
NET_EXPORT extern const base::FeatureParam<int> kRecentHTTPThresholdInSeconds;

// The maximum age in seconds of observations to be used for calculating the
// transport RTT from the historical data.
// Negative value means infinite. i.e. all data are used.
NET_EXPORT extern const base::FeatureParam<int>
    kRecentTransportThresholdInSeconds;

// The maximum age in seconds of observations to be used for calculating the
// end to end RTT from the historical data.
// Negative value means infinite. i.e. all data are used.
NET_EXPORT extern const base::FeatureParam<int>
    kRecentEndToEndThresholdInSeconds;

// Number of observations received after which the effective connection type
// should be recomputed.
NET_EXPORT extern const base::FeatureParam<int>
    kCountNewObservationsReceivedComputeEct;

// Maximum number of observations that can be held in a single
// ObservationBuffer.
NET_EXPORT extern const base::FeatureParam<int> kObservationBufferSize;

// Minimum duration between two consecutive computations of effective
// connection type. Set to non-zero value as a performance optimization.
NET_EXPORT extern const base::FeatureParam<base::TimeDelta>
    kEffectiveConnectionTypeRecomputationInterval;

// Splits cache entries by the request's includeCredentials.
NET_EXPORT BASE_DECLARE_FEATURE(kSplitCacheByIncludeCredentials);

// Splits cache entries by the request's NetworkIsolationKey if one is
// available.
NET_EXPORT BASE_DECLARE_FEATURE(kSplitCacheByNetworkIsolationKey);

// Splits the generated code cache by the request's NetworkIsolationKey if one
// is available. Note that this feature is also gated behind
// `net::HttpCache::IsSplitCacheEnabled()`.
NET_EXPORT BASE_DECLARE_FEATURE(kSplitCodeCacheByNetworkIsolationKey);

// Partitions connections and other network states based on the
// NetworkAnonymizationKey associated with a request.
// See https://github.com/MattMenke2/Explainer---Partition-Network-State.
NET_EXPORT BASE_DECLARE_FEATURE(kPartitionConnectionsByNetworkIsolationKey);

// Splits HostCache and DNS resolution requests by the request's
// NetworkAnonymizationKey if one is available.
NET_EXPORT BASE_DECLARE_FEATURE(kSplitHostCacheByNetworkAnonymizationKey);

// Changes the interval between two search engine preconnect attempts.
NET_EXPORT BASE_DECLARE_FEATURE(kSearchEnginePreconnectInterval);

// Enables a more efficient SearchEnginePreconnector
NET_EXPORT BASE_DECLARE_FEATURE(kSearchEnginePreconnect2);

// The idle timeout for the SearchEnginePreconnector2 feature.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(int, kIdleTimeoutInSeconds);

// The maximum time for the SearchEnginePreconnector2 to be considered as short.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(base::TimeDelta, kShortSessionThreshold);

// The maximum time to backoff when attempting preconnect retry for
// SearchEnginePreconnector2.
NET_EXPORT extern const base::FeatureParam<int> kMaxPreconnectRetryInterval;

// The interval between two QUIC ping requests for the periodic PING for
// SearchEnginePreconnector2.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(int, kPingIntervalInSeconds);

// The QUIC connection options which will be sent to the server in order to
// enable certain QUIC features. This should be set using `QuicTag`s (32-bit
// value represented in ASCII equivalent e.g. EXMP). If we want to set
// multiple features, then the values should be separated with a comma
// (e.g. "ABCD,EFGH").
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(std::string, kQuicConnectionOptions);

// Whether to fallback to the old preconnect interval when the device is in low
// power mode.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(bool, kFallbackInLowPowerMode);

// Enables Connection Keep-Alive feature for Http2
NET_EXPORT BASE_DECLARE_FEATURE(kConnectionKeepAliveForHttp2);

// Configures the client-side initial RTT for QUIC preconnect sessions when no
// cached or 2G/3G RTT estimate is available, reducing the initial handshake
// Probe Timeout (PTO) delay (`3 * initial_rtt`).
NET_EXPORT BASE_DECLARE_FEATURE(kQuicPreconnectInitialRtt);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(base::TimeDelta,
                                      kQuicPreconnectInitialRttParam);
// Returns `kQuicPreconnectInitialRttParam` when `kQuicPreconnectInitialRtt` is
// enabled and the configured duration is positive and finite; otherwise returns
// `std::nullopt`.
NET_EXPORT std::optional<base::TimeDelta> GetQuicPreconnectInitialRtt();

// When enabled, the time threshold for Lax-allow-unsafe cookies will be lowered
// from 2 minutes to 10 seconds. This time threshold refers to the age cutoff
// for which cookies that default into SameSite=Lax, which are newer than the
// threshold, will be sent with any top-level cross-site navigation regardless
// of HTTP method (i.e. allowing unsafe methods). This is a convenience for
// integration tests which may want to test behavior of cookies older than the
// threshold, but which would not be practical to run for 2 minutes.
NET_EXPORT BASE_DECLARE_FEATURE(kShortLaxAllowUnsafeThreshold);

// When enabled, the SameSite by default feature does not add the
// "Lax-allow-unsafe" behavior. Any cookies that do not specify a SameSite
// attribute will be treated as Lax only, i.e. POST and other unsafe HTTP
// methods will not be allowed at all for top-level cross-site navigations.
// This only has an effect if the cookie defaults to SameSite=Lax.
NET_EXPORT BASE_DECLARE_FEATURE(kSameSiteDefaultChecksMethodRigorously);

// Enables a timeout on individual TCP connect attempts, based on
// the parameter values.
NET_EXPORT BASE_DECLARE_FEATURE(kTimeoutTcpConnectAttempt);

// FeatureParams associated with kTimeoutTcpConnectAttempt.

// When there is an estimated RTT available, the experimental TCP connect
// attempt timeout is calculated as:
//
//  clamp(kTimeoutTcpConnectAttemptMin,
//        kTimeoutTcpConnectAttemptMax,
//        <Estimated RTT> * kTimeoutTcpConnectAttemptRTTMultiplier);
//
// Otherwise the TCP connect attempt timeout is set to
// kTimeoutTcpConnectAttemptMax.
NET_EXPORT extern const base::FeatureParam<double>
    kTimeoutTcpConnectAttemptRTTMultiplier;
NET_EXPORT extern const base::FeatureParam<base::TimeDelta>
    kTimeoutTcpConnectAttemptMin;
NET_EXPORT extern const base::FeatureParam<base::TimeDelta>
    kTimeoutTcpConnectAttemptMax;

// When this feature is enabled, redirected requests will be considered
// cross-site for the purpose of SameSite cookies if any redirect hop was
// cross-site to the target URL, even if the original initiator of the
// redirected request was same-site with the target URL (and the
// site-for-cookies).
// See spec changes in https://github.com/httpwg/http-extensions/pull/1348
NET_EXPORT BASE_DECLARE_FEATURE(kCookieSameSiteConsidersRedirectChain);

// Controls whether static key pinning is enforced.
NET_EXPORT BASE_DECLARE_FEATURE(kStaticKeyPinningEnforcement);

// When enabled, cookies with a non-ASCII domain attribute will be rejected.
NET_EXPORT BASE_DECLARE_FEATURE(kCookieDomainRejectNonASCII);

// When enabled, HTTP/HTTPS/WS/WSS URLs with non-IP hosts must have a
// DNS-compliant canonicalized host (via net::IsCanonicalizedHostCompliant())
// to set or retrieve cookies.
NET_EXPORT BASE_DECLARE_FEATURE(kCookieRequireCompliantHost);

NET_EXPORT BASE_DECLARE_FEATURE(kThirdPartyStoragePartitioning);

// Whether ALPS parsing is on for any type of frame.
NET_EXPORT BASE_DECLARE_FEATURE(kAlpsParsing);

NET_EXPORT BASE_DECLARE_FEATURE(kEnableWebsocketsOverHttp3);

#if BUILDFLAG(IS_WIN)
// Whether or not to use the GetNetworkConnectivityHint API on modern Windows
// versions for the Network Change Notifier.
NET_EXPORT BASE_DECLARE_FEATURE(kEnableGetNetworkConnectivityHintAPI);

// Whether or not to enable TCP port randomization via SO_RANDOMIZE_PORT on
// Windows for versions >= kTcpPortRandomizationWinVersionMinimum.
// See crbug.com/40744069 for more details.
// This was launched in M141, but the finch flag was kept around in case it
// ever causes issues (as some may take time to detect due to rarity).
NET_EXPORT BASE_DECLARE_FEATURE(kTcpPortRandomizationWin);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(int,
                                      kTcpPortRandomizationWinVersionMinimum);

// Whether or not TCP port reuse timing metrics are recorded.
// See crbug.com/40744069 for more details.
NET_EXPORT BASE_DECLARE_FEATURE(kTcpPortReuseMetricsWin);

// Whether to use a TCP socket implementation which uses an IO completion
// handler to be notified of completed reads and writes, instead of an event.
NET_EXPORT BASE_DECLARE_FEATURE(kTcpSocketIoCompletionPortWin);

// Whether to defer the initial connection type computation from the
// NetworkChangeNotifierWin constructor to an async call in
// WatchForAddressChange(), avoiding a synchronous cross-process call that can
// block the UI thread for ~50ms during startup.
NET_EXPORT BASE_DECLARE_FEATURE(kDeferConnectionTypeAtStartup);
#endif

#if BUILDFLAG(IS_MAC)
// Whether or not to enable TCP port randomization on macOS by choosing a
// randomized ephemeral source port.
NET_EXPORT BASE_DECLARE_FEATURE(kTcpPortRandomizationMac);
// How long (in seconds) to avoid reusing a recently-used ephemeral port for
// the same peer. Defaults to 120 to match common NAT timeout values.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(int, kTcpPortRandomizationReuseDelaySec);
// If enabled, port randomization applies even where the remote address is
// a private route. See https://crbug.com/575343797 for context.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(bool,
                                      kTcpPortRandomizationMacForPrivateRoutes);
#endif

// Avoid creating cache entries for transactions that are most likely no-store.
NET_EXPORT BASE_DECLARE_FEATURE(kAvoidEntryCreationForNoStore);
NET_EXPORT extern const base::FeatureParam<int>
    kAvoidEntryCreationForNoStoreCacheSize;

// A flag to use asynchronous session creation for new QUIC sessions.
NET_EXPORT BASE_DECLARE_FEATURE(kAsyncQuicSession);

// A flag to use QuicSessionPool::AsyncDnsJob, which resolves hostnames with
// HostResolver::ServiceEndpointRequest, for direct QUIC sessions.
NET_EXPORT BASE_DECLARE_FEATURE(kAsyncDnsQuicJob);

// Whether HttpStreamFactory::JobController resumes the main job without delay
// when a QUIC job reports a connection initialization failure.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(bool, kAsyncDnsQuicJobFastFail);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(
    bool,
    kAsyncDnsQuicJobSortTransactionsIndividually);

// Makes the QUIC slow timer delay configurable.
// How long to wait before starting a second connection attempt
// if one is already in flight.
NET_EXPORT BASE_DECLARE_FEATURE(kAdjustQuicSlowTimerDelay);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(base::TimeDelta, kQuicSlowTimerDelay);

// Feature to base the QUIC slow timer on the network RTT.
NET_EXPORT BASE_DECLARE_FEATURE(kQuicSlowTimerBasedOnRTT);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(double, kQuicSlowTimerRTTMultiplier);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(base::TimeDelta, kQuicSlowTimerMin);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(base::TimeDelta, kQuicSlowTimerMax);

// A flag to make multiport context creation asynchronous.
NET_EXPORT BASE_DECLARE_FEATURE(kAsyncMultiPortPath);

// Maximum report body size (KB) to include in serialized reports. Bodies
// exceeding this are omitted when kExcludeLargeBodyReports is enabled.  Use
// Reporting.ReportBodySize UMA histogram to monitor report body sizes and
// inform this value.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(size_t, kMaxReportBodySizeKB);

// Whether QuicParams::migrate_sessions_on_network_change_v2 defaults to true or
// false. This is needed as a workaround to set this value to true on Android
// but not on WebView (until crbug.com/1430082 has been fixed).
NET_EXPORT BASE_DECLARE_FEATURE(kMigrateSessionsOnNetworkChangeV2);

// Enables binding of cookies to the port that originally set them by default.
NET_EXPORT BASE_DECLARE_FEATURE(kEnablePortBoundCookies);

// Enables binding of cookies to the scheme that originally set them. Also
// enables domain cookie shadowing protection.
NET_EXPORT BASE_DECLARE_FEATURE(kEnableSchemeBoundCookies);

// Disallows cookies to have non ascii values in their name or value.
NET_EXPORT BASE_DECLARE_FEATURE(kDisallowNonAsciiCookies);

// Enables expiration duration limit (3 hours) for cookies on insecure websites.
// This feature is a no-op unless kEnableSchemeBoundCookies is enabled.
NET_EXPORT BASE_DECLARE_FEATURE(kTimeLimitedInsecureCookies);

// Enables enabling third-party cookie blocking from the command line.
NET_EXPORT BASE_DECLARE_FEATURE(kForceThirdPartyCookieBlocking);

// Enables Early Hints on HTTP/1.1.
NET_EXPORT BASE_DECLARE_FEATURE(kEnableEarlyHintsOnHttp11);

// Enables draft-07 version of WebTransport over HTTP/3.
NET_EXPORT BASE_DECLARE_FEATURE(kEnableWebTransportDraft07);

// Enables a smarter throttling strategy based in the server's IP.
NET_EXPORT BASE_DECLARE_FEATURE(kWebTransportFineGrainedThrottling);

// Enables a more efficient implementation of SpdyHeadersToHttpResponse().
NET_EXPORT BASE_DECLARE_FEATURE(kSpdyHeadersToHttpResponseUseBuilder);

// Enables using the new ALPS codepoint to negotiate application settings for
// HTTP2.
NET_EXPORT BASE_DECLARE_FEATURE(kUseNewAlpsCodepointHttp2);

// Enables using the new ALPS codepoint to negotiate application settings for
// QUIC.
NET_EXPORT BASE_DECLARE_FEATURE(kUseNewAlpsCodepointQUIC);

// Enables truncating the response body to the content length.
NET_EXPORT BASE_DECLARE_FEATURE(kTruncateBodyToContentLength);

#if BUILDFLAG(IS_APPLE)
// Uses the Network framework path monitor instead of SCNetworkReachability for
// connection type change detection on macOS & iOS.
NET_EXPORT BASE_DECLARE_FEATURE(kUseNetworkPathMonitorForNetworkChangeNotifier);
#endif  // BUILDFLAG(IS_APPLE)

// This feature will enable the Device Bound Session Credentials protocol to let
// the server assert sessions (and cookies) are bound to a specific device.
NET_EXPORT BASE_DECLARE_FEATURE(kDeviceBoundSessions);
// This feature prevents deadlocks from recursive DBSC token refresh requests
// by setting `device_bound_session_mode` to `kBypassDeferral` on DBSC refresh
// requests.
NET_EXPORT BASE_DECLARE_FEATURE(
    kDeviceBoundSessionsBypassDeferralsForRefreshRequests);
// This feature controls whether DBSC retry mechanism is enabled for transient
// refresh errors (network and proxy errors).
NET_EXPORT BASE_DECLARE_FEATURE(
    kDeviceBoundSessionsRetryTransientRefreshErrors);
// This feature enables the Device Bound Session Credentials signing quota.
// This behavior is expected by default; disabling it should only be for
// testing purposes.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(bool, kDeviceBoundSessionsSigningQuota);
// This feature controls whether DBSC checks the .well-known for subdomain
// registration.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(
    bool,
    kDeviceBoundSessionsCheckSubdomainRegistration);
// This feature controls the database schema version for stored sessions.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(int, kDeviceBoundSessionsSchemaVersion);

// This feature controls whether DBSC allows federated sessions.
NET_EXPORT BASE_DECLARE_FEATURE(kDeviceBoundSessionsFederatedRegistration);
// This param controls whether DBSC checks the .well-known for federated
// sessions.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(
    bool,
    kDeviceBoundSessionsFederatedRegistrationCheckWellKnown);

// Kill switch for blocking all redirects on federated registration requests
// before they are followed. When disabled, federated registration requests
// follow redirects like other registration requests.
// TODO(crbug.com/518806368): Remove once this has shipped to stable.
NET_EXPORT BASE_DECLARE_FEATURE(
    kDeviceBoundSessionsFederatedRegistrationBlockRedirects);

// This feature controls whether DBSC is allowed to register sessions on
// a certain list of sites, as specified in
// `device_bound_sessions_restricted_sites` in the
// `NetworkContextParams`.
NET_EXPORT BASE_DECLARE_FEATURE(kDeviceBoundSessionsForRestrictedSites);

// This feature controls whether DBSC allows mTLS / client certificate
// selection for background registration and refresh requests.
NET_EXPORT BASE_DECLARE_FEATURE(kDeviceBoundSessionsClientCertSelection);

// This feature will enable the browser to use Device Bound Session Credentials
// for Single Sign On. This feature is only valid if `kDeviceBoundSessions` is
// enabled.
NET_EXPORT BASE_DECLARE_FEATURE(kDeviceBoundSessionsForSingleSignOn);

// Controls whether a session's expiry timestamp is updated in memory and
// persisted to disk when a network refresh finishes with NoSessionConfigChange.
NET_EXPORT BASE_DECLARE_FEATURE(kDeviceBoundSessionsPersistExpiryOnRefresh);

// Controls whether DBSC includes the 'aud' (audience) claim in registration
// and refresh JWT payloads.
NET_EXPORT BASE_DECLARE_FEATURE(kDeviceBoundSessionsIncludeAudienceClaim);

// Kill switch for draining a session's deferred requests queue when every
// request in it is destroyed while the session's binding key is being restored.
// Without this, the abandoned queue entry looks like an in-flight refresh, so
// later requests and pre-warms for the session wait on it until the session is
// deleted, and proactive refreshes do not start.
// TODO(crbug.com/509885112): Remove once this has shipped to stable.
NET_EXPORT BASE_DECLARE_FEATURE(kDeviceBoundSessionsDrainDeferredOnAllCanceled);

// Enables more checks when creating a SpdySession for proxy. These checks are
// already applied to non-proxy SpdySession creations.
// TODO(crbug.com/343519247): Remove this once we are sure that these checks are
// not causing any problems.
NET_EXPORT BASE_DECLARE_FEATURE(kSpdySessionForProxyAdditionalChecks);

// When this feature is enabled, Chromium will use stored shared dictionaries
// only if the request URL is a localhost URL or the transport layer is using a
// certificate rooted at a standard CA root.
NET_EXPORT BASE_DECLARE_FEATURE(
    kCompressionDictionaryTransportRequireKnownRootCert);

// Enables enterprises to use the Reporting API to collect 3PCD-related
// issues from sites used in their organization.
NET_EXPORT BASE_DECLARE_FEATURE(kReportingApiEnableEnterpriseCookieIssues);

// Use the simdutf library to base64 decode data: URLs.
NET_EXPORT BASE_DECLARE_FEATURE(kSimdutfBase64Support);

// Further optimize parsing data: URLs.
NET_EXPORT BASE_DECLARE_FEATURE(kFurtherOptimizeParsingDataUrls);

// Preserve MIME type parameters in data: URLs for WPT compliance.
// When enabled, non-charset parameters (e.g., "boundary=xxx") are preserved
// in the Content-Type header, and quoted parameter values are properly
// normalized. See https://fetch.spec.whatwg.org/#data-url-processor
NET_EXPORT BASE_DECLARE_FEATURE(kDataUrlMimeTypeParameterPreservation);

// If enabled, unrecognized keys in a No-Vary-Search header will be ignored.
// Otherwise, unrecognized keys are treated as if the header was invalid.
NET_EXPORT BASE_DECLARE_FEATURE(kNoVarySearchIgnoreUnrecognizedKeys);

// Enables enforcement of One-RFC6962 policy for Certificate Transparency. When
// disabled, Chrome does not distinguish between SCTs based on log type.
NET_EXPORT BASE_DECLARE_FEATURE(kEnforceOneRfc6962CtPolicy);

// Finch experiment to select a disk cache backend.
enum class DiskCacheBackend {
  kDefault,
  kSimple,
  kBlockfile,
#if BUILDFLAG(ENABLE_DISK_CACHE_SQL_BACKEND)
  kSql,
#endif  // ENABLE_DISK_CACHE_SQL_BACKEND
};
NET_EXPORT BASE_DECLARE_FEATURE(kDiskCacheBackendExperiment);
NET_EXPORT extern const base::FeatureParam<DiskCacheBackend>
    kDiskCacheBackendParam;

// When true, the disk cache backend experiment group name is included in cache
// reset logic (GetHttpCacheBackendResetParam() and
// CheckFakeIndexFileInternal()) so that changing experiment groups resets the
// HTTP cache for clean A/B comparison. When false (default), cache resets on
// group changes are bypassed to prevent widespread cache clearing during
// gradual feature rollouts.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(bool,
                                      kDiskCacheBackendResetCacheOnGroupChange);

#if BUILDFLAG(ENABLE_DISK_CACHE_SQL_BACKEND)
// If the number of pages recorded in the WAL file of the SQL disk cache's DB
// exceeds this value, a checkpoint is executed on committing data.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(int,
                                      kSqlDiskCacheForceCheckpointThreshold);
// If the number of pages recorded in the WAL file of the SQL disk cache's DB
// exceeds this value and the browser is idle, a checkpoint is executed.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(int,
                                      kSqlDiskCacheIdleCheckpointThreshold);
// While the memory usage for the buffer doesn't exceed the number of bytes
// specified by this param, the SQL backend executes optimistic writes.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(int,
                                      kSqlDiskCacheOptimisticWriteBufferSize);
// Whether to enable WAL mode for the SQL disk cache backend.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(bool, kSqlDiskCacheWalMode);
// Disables synchronous writes in the SQL disk cache's DB.
// This is faster but less safe.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(bool, kSqlDiskCacheSynchronousOff);
// The number of shards for the SQL disk cache.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(int, kSqlDiskCacheShardCount);
// Loads the in-memory index on initialization.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(bool, kSqlDiskCacheLoadIndexOnInit);
// Reduces UMA metrics recorded by the SQL disk cache.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(bool, kSqlDiskCacheReduceUma);
// The maximum size of the write buffer for all entries.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(int,
                                      kSqlDiskCacheMaxWriteBufferTotalSize);
// The maximum size of the write buffer for a single entry.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(int,
                                      kSqlDiskCacheMaxWriteBufferSizePerEntry);
// The maximum size of the read buffer for all entries.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(int, kSqlDiskCacheMaxReadBufferTotalSize);
// The maximum body size (in bytes) for an entry to be copied to shared cache.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(int,
                                      kSqlDiskCacheMaxSharedCacheCopyEntrySize);
// The read buffer size (in bytes) when copying entries to shared cache.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(int,
                                      kSqlDiskCacheSharedCacheReadBufferSize);
// Execute the checkpoint serially.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(bool, kSqlDiskCacheSerialCheckpoint);
// Execute the initialization serially.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(bool, kSqlDiskCacheSerialInitialize);
// Whether to use size and priority aware eviction for the SQL disk cache.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(
    bool,
    kSqlDiskCacheSizeAndPriorityAwareEviction);
// Whether to aggressively release SQLite's cached memory after writes.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(bool,
                                      kSqlDiskCacheReleaseMemoryAfterWrites);
// The size of in-memory cache of SQLite database. 0 invokes SQLite's default.
// See https://sqlite.org/pragma.html#pragma_cache_size for more details.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(int, kSqlDiskCacheCacheSize);
// Whether to use consolidated in memory index.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(bool,
                                      kSqlDiskCacheConsolidatedInMemoryIndex);
// Whether to enable incremental vacuum for the SQL disk cache backend.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(bool, kSqlDiskCacheIncrementalVacuum);
// The number of pages to vacuum per step during incremental vacuum.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(int,
                                      kSqlDiskCacheIncrementalVacuumPageCount);
#endif  // ENABLE_DISK_CACHE_SQL_BACKEND

// If enabled, ignore Strict-Transport-Security for [*.]localhost hosts.
NET_EXPORT BASE_DECLARE_FEATURE(kIgnoreHSTSForLocalhost);

// If enabled, URLRequests for http, https, ws, and wss URLs whose hostnames are
// not valid DNS names (per IsCanonicalizedHostCompliant()) fail with
// ERR_INVALID_URL. Without this, such requests may still be sent through a
// proxy, bypassing HSTS, which can't be applied to such hosts.
NET_EXPORT BASE_DECLARE_FEATURE(kRejectNonCompliantHttpHosts);

// If enabled, main frame navigation resources will be prioritized in Simple
// Cache and SQL Cache. So they will be less likely to be evicted.
NET_EXPORT BASE_DECLARE_FEATURE(kSimpleCachePrioritizedCaching);
// This is a factor by which we divide the size of an entry that has the
// HINT_HIGH_PRIORITY flag set to prioritize it for eviction to be less likely
// evicted.
NET_EXPORT extern const base::FeatureParam<int>
    kSimpleCachePrioritizedCachingPrioritizationFactor;
// The period of time that the entry with HINT_HIGH_PRIORITY flag is considered
// prioritized.
NET_EXPORT extern const base::FeatureParam<base::TimeDelta>
    kSimpleCachePrioritizedCachingPrioritizationPeriod;

// When enabled HSTS upgrades will only apply to top-level navigations.
NET_EXPORT BASE_DECLARE_FEATURE(kHstsTopLevelNavigationsOnly);

#if BUILDFLAG(IS_WIN)
// Whether or not to flush on MappedFile::Flush().
NET_EXPORT BASE_DECLARE_FEATURE(kHttpCacheMappedFileFlushWin);
#endif

// Whether or not to apply No-Vary-Search processing in the HTTP disk cache.
NET_EXPORT BASE_DECLARE_FEATURE(kHttpCacheNoVarySearch);

NET_EXPORT BASE_DECLARE_FEATURE_PARAM(size_t,
                                      kHttpCacheNoVarySearchCacheMaxEntries);

NET_EXPORT BASE_DECLARE_FEATURE_PARAM(
    size_t,
    kHttpCacheNoVarySearchCacheMaxPartitionEntries);

NET_EXPORT BASE_DECLARE_FEATURE_PARAM(size_t,
                                      kHttpCacheNoVarySearchCacheMaxPartitions);

// Whether persistence is enabled in on-the-record profiles. True by default.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(bool,
                                      kHttpCacheNoVarySearchPersistenceEnabled);

// Whether to skip opening the http cache entry which was marked as "unusable"
// from the "Cache-Control" header point of view.
NET_EXPORT BASE_DECLARE_FEATURE(kHttpCacheSkipUnusableEntry);

// Enables sending the CORS Origin header on the POST request for Reporting API
// report uploads.
NET_EXPORT BASE_DECLARE_FEATURE(kReportingApiCorsOriginHeader);

// Enables exclusion of reports having large body during serialized reports.
// When enabled, report bodies exceeding kMaxReportBodySizeKB are omitted. This
// helps prevent excessively large reports json stringification.
NET_EXPORT BASE_DECLARE_FEATURE(kExcludeLargeBodyReports);

// Enables the Related Website Partition API, allowing members of a Related
// Website Set to access partitioned non-cookie storage. See
// https://github.com/explainers-by-googlers/related-website-partition-api.
NET_EXPORT BASE_DECLARE_FEATURE(kRelatedWebsitePartitionAPI);


// Enables a special interstitial for self signed cert errors in local network
// URLs.
NET_EXPORT BASE_DECLARE_FEATURE(kSelfSignedLocalNetworkInterstitial);

#if BUILDFLAG(CHROME_ROOT_STORE_SUPPORTED)
// If enabled, server certificates that successfully verify and that identify
// as QWACs will be verified against the 1-QWAC specification as well.
NET_EXPORT BASE_DECLARE_FEATURE(kVerifyQWACs);
#endif

// Finch-controlled list of ports that should be blocked due to ongoing abuse.
NET_EXPORT BASE_DECLARE_FEATURE(kRestrictAbusePorts);
NET_EXPORT extern const base::FeatureParam<std::string>
    kPortsToRestrictForAbuse;
NET_EXPORT extern const base::FeatureParam<std::string>
    kPortsToRestrictForAbuseMonitorOnly;

// Finch-controlled list of ports that should be blocked on localhost.
NET_EXPORT BASE_DECLARE_FEATURE(kRestrictAbusePortsOnLocalhost);

// Enables TLS Trust Anchor IDs
// (https://tlswg.org/tls-trust-anchor-ids/draft-ietf-tls-trust-anchor-ids.html),
// a TLS extension to help the server serve a certificate that the client will
// trust.
NET_EXPORT BASE_DECLARE_FEATURE(kTLSTrustAnchorIDs);

// Controls whether TLS Trust Anchor IDs that are not for MTCs are sent.
NET_EXPORT BASE_DECLARE_FEATURE(kNonMtcTrustAnchorIDs);

#if BUILDFLAG(CHROME_ROOT_STORE_SUPPORTED)
// Enables support for Merkle Tree Certificates. `kTLSTrustAnchorIDs` must also
// be enabled for this to be useful.
NET_EXPORT BASE_DECLARE_FEATURE(kVerifyMTCs);
#endif

// Indicates if the client is participating in TCP socket pool limit
// randomization. The params below define the bounds for the probability.
// function we use when calculating the chance the state should flip between
// capped and uncapped. See crbug.com/415691664 for more details.
NET_EXPORT BASE_DECLARE_FEATURE(kTcpSocketPoolLimitRandomization);
// The base of an exponent when calculating the probability.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(double,
                                      kTcpSocketPoolLimitRandomizationBase);
// The minimum probability allowed to be returned.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(double,
                                      kTcpSocketPoolLimitRandomizationMinimum);
// The percentage of noise to add/subtract from the probability.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(double,
                                      kTcpSocketPoolLimitRandomizationNoise);

// When enabled, Net Task Scheduler is enabled on the network thread.
NET_EXPORT BASE_DECLARE_FEATURE(kNetTaskScheduler);

// When enabled, HostResolver and its subtasks use the Net Task Scheduler.
NET_EXPORT BASE_DECLARE_FEATURE(kNetTaskSchedulerHostResolver);

// When enabled, Net Task Scheduler supports per-net::RequestPriority task
// queues for each RequestPriority variant.
//
// TODO(crbug.com/450428442): Rename this to kNetPerPriorityTaskQueues once the
// active Finch study referencing "NetworkServicePerPriorityTaskQueues"
// finishes.
NET_EXPORT BASE_DECLARE_FEATURE(kNetworkServicePerPriorityTaskQueues);

// These parameters control whether the Net Task Scheduler is used
// for specific classes.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(bool,
                                      kNetTaskSchedulerHttpProxyConnectJob);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(bool,
                                      kNetTaskSchedulerHttpStreamFactoryJob);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(
    bool,
    kNetTaskSchedulerHttpStreamFactoryJobController);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(bool,
                                      kNetTaskSchedulerURLRequestErrorJob);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(bool, kNetTaskSchedulerURLRequestHttpJob);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(bool, kNetTaskSchedulerURLRequestJob);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(bool,
                                      kNetTaskSchedulerURLRequestRedirectJob);

NET_EXPORT BASE_DECLARE_FEATURE(kNetTaskScheduler2);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(bool, kNetTaskSchedulerHttpCache);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(bool,
                                      kNetTaskSchedulerHttpCacheTransaction);



// If enabled, we will add an additional delay to the main job in
// HttpStreamFactoryJobController.
NET_EXPORT BASE_DECLARE_FEATURE(kAdditionalDelayMainJob);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(base::TimeDelta, kAdditionalDelay);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(bool,
                                      kDelayMainJobWithAvailableSpdySession);

// If enabled, we will extend the quic handshake timeout.
NET_EXPORT BASE_DECLARE_FEATURE(kExtendQuicHandshakeTimeout);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(base::TimeDelta, kQuicHandshakeTimeout);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(base::TimeDelta,
                                      kMaxIdleTimeBeforeCryptoHandshake);

// If enabled, we will ignore redundant OnNetworkMadeDefault notifications.
NET_EXPORT BASE_DECLARE_FEATURE(kQuicIgnoreRedundantOnNetworkMadeDefault);

// If enabled, we will use a longer idle timeout.
NET_EXPORT BASE_DECLARE_FEATURE(kQuicLongerIdleConnectionTimeout);

// If enabled, always cancel pre-existing probing when migrating immediately or
// committing a migration.
NET_EXPORT BASE_DECLARE_FEATURE(
    kQuicAlwaysCancelPreExistingProbingOnMigration);

// If enabled, allows QUIC sessions to migrate to a different port when the
// current path is degrading.
NET_EXPORT BASE_DECLARE_FEATURE(kQuicEnablePortMigration);

// Controls the timeout for waiting for a new network to connect before giving
// up on connection migration.
NET_EXPORT BASE_DECLARE_FEATURE(kQuicWaitForNewNetworkTimeout);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(base::TimeDelta,
                                      kQuicWaitForNewNetworkTimeoutParam);

// If enabled, we will use QUIC with a smaller MTU.
NET_EXPORT BASE_DECLARE_FEATURE(kLowerQuicMaxPacketSize);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(size_t, kQuicMaxPacketSize);

// If enabled, QuicChromiumPacketReader will use ReadMultiple API.
NET_EXPORT BASE_DECLARE_FEATURE(kQuicUseReadMultiple);

// If enabled, UDPSocketPosix will enable UDP Generic Receive Offload (UDP_GRO).
NET_EXPORT BASE_DECLARE_FEATURE(kEnableUdpGro);

// When enabled, races QUIC connection attempts for the specified hostnames
// even when there is no available ALPN information.
NET_EXPORT BASE_DECLARE_FEATURE(kConfigureQuicHints);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(std::string, kQuicHintHostPortPairs);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(std::string,
                                      kWildcardQuicHintHostPortPairs);

// When enabled, the browser checks if a navigation URL is in any navigation
// entry. If so, it sets the
// `IS_MAIN_FRAME_ORIGIN_RECENTLY_ACCESSED` load flag.
// Note that this flag is only set for metric collection.
NET_EXPORT BASE_DECLARE_FEATURE(kUpdateIsMainFrameOriginRecentlyAccessed);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(size_t, kRecentlyAccessedOriginCacheSize);

// When enabled, the browser tries QUIC by default.
NET_EXPORT BASE_DECLARE_FEATURE(kTryQuicByDefault);

// If enabled, close all QUIC sessions when the app is about to be frozen
// (Android only).
NET_EXPORT BASE_DECLARE_FEATURE(kCloseQuicSessionsOnPreFreeze);

// The QUIC connection options which will be sent to the server in order to
// enable certain QUIC features. This should be set using `QuicTag`s (32-bit
// value represented in ASCII equivalent e.g. EXMP). To set multiple features,
// separate the values with a comma (e.g. "ABCD,EFGH").
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(std::string, kQuicOptions);

// When enabled, allows the browser to ignore IP matching and rely on
// the hostname being present in the existing session's certificate when
// connection coalescing.
NET_EXPORT BASE_DECLARE_FEATURE(kIgnoreIpMatching);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(std::string, kNoIPQuicOption);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(
    bool,
    kIgnoreIpMatchingWhenFindingExistingSessions);

// When enabled, allows DoH upgrade even if there are local nameservers.
NET_EXPORT BASE_DECLARE_FEATURE(kDohFallbackAllowedWithLocalNameservers);

// When enabled, users can make Secure DNS in AUTOMATIC mode fallback to a
// well-known DoH provider before using insecure DNS.
NET_EXPORT BASE_DECLARE_FEATURE(kAddAutomaticWithDohFallbackMode);

// If true, a CONNECT-UDP response is not needed to start sending datagrams.
NET_EXPORT BASE_DECLARE_FEATURE(
    kUseQuicProxiesWithoutWaitingForConnectResponse);

// If enabled, the configured bootstrap IP addresses of DoH providers will
// be randomized for better load balancing of the initial DoH URL lookups.
NET_EXPORT BASE_DECLARE_FEATURE(kEnableBootstrapIPRandomizationForDoh);

#if BUILDFLAG(IS_APPLE)
// If enabled, the GURL conversion for NSURLs will use the data representation
// of the URL if it differs from the absolute string.
NET_EXPORT BASE_DECLARE_FEATURE(kUseNSURLDataForGURLConversion);

// Enables asynchronous PAC resolution and request cancellation in
// ProxyResolverApple on a shared CFRunLoop thread instead of per-resolver
// worker threads.
NET_EXPORT BASE_DECLARE_FEATURE(kAsyncProxyResolverApple);
#endif  // BUILDFLAG(IS_APPLE)

// Enables logical HTTP cache clearing, which adds a filter to the cache
// to immediately treat entries as invalid, while they are physically deleted
// in the background.
NET_EXPORT BASE_DECLARE_FEATURE(kLogicalClearHttpCache);
NET_EXPORT extern const base::FeatureParam<bool>
    kLogicalClearHttpCacheUserVisiblePriority;
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(int, kLogicalClearHttpCacheMaxFilters);

// If enabled, SPDY sessions will be synchronously drained when the underlying
// transport socket is detected to be disconnected in GetRemoteEndpoint().
NET_EXPORT BASE_DECLARE_FEATURE(
    kDrainSpdySessionSynchronouslyOnRemoteEndpointDisconnect);

// When enabled, SQLitePersistentCookieStore is initialized upon creation,
// rather than waiting for the first load request.
NET_EXPORT BASE_DECLARE_FEATURE(kSQLitePersistentCookieStoreEarlyInit);
NET_EXPORT extern const base::FeatureParam<bool>
    kSQLitePersistentCookieStoreEarlyInitCheckDisk;

// If enabled, cookies are loaded early on preconnect requests.
NET_EXPORT BASE_DECLARE_FEATURE(kEarlyCookieLoadOnPreconnect);

// If enabled, the error code will be propagated for preconnect attempts.
NET_EXPORT BASE_DECLARE_FEATURE(kEnableErrorCodePropagationForPreconnect);

// If enabled, TransportClientSocketPool can retry stalled connections.
// See crbug.com/481934003 to track efforts to disable this by default.
NET_EXPORT BASE_DECLARE_FEATURE(kPermitTcpSocketPoolConnectBackupJobs);

// If enabled, examine why a network operation was blocked due to local network
// permission.
NET_EXPORT BASE_DECLARE_FEATURE(kLocalNetworkPermissionCheck);

// If enabled, QuicCryptoClientConfigOwner will ignore memory pressure events
// for all network isolation partitions.
NET_EXPORT BASE_DECLARE_FEATURE(kIgnoreQuicCryptoConfigMemoryPressure);

// If enabled, QuicCryptoClientConfigOwner will ignore memory pressure events
// for the kDnsOverHttps partition.
NET_EXPORT BASE_DECLARE_FEATURE(kIgnoreQuicCryptoConfigMemoryPressureForDoh);

// If enabled, SSLClientSessionCache will ignore memory pressure events.
NET_EXPORT BASE_DECLARE_FEATURE(kIgnoreMemoryPressureForSslClientSessionCache);

// If enabled, cookie parsing will reject a cookie line whose first
// semicolon-separated substring looks like "=Foo=Bar", i.e. starts with an
// equals sign and has another equals sign. Such cookies have an ambiguous
// serialization.
NET_EXPORT BASE_DECLARE_FEATURE(kCookieParseRejectEmptyNameAmbiguous);

NET_EXPORT BASE_DECLARE_FEATURE(kEnablePrivateVerificationTokens);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(std::string,
                                      kPrivateVerificationTokensCustomIssuer);

// If enabled, request servers to add additional padding to TLS handshakes. The
// amount requested is configurable by the parameter
// kAddTLSServerHandshakePaddingBytes, with a maximum of 16k bytes.
NET_EXPORT BASE_DECLARE_FEATURE(kAddTLSServerHandshakePadding);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(int, kAddTLSServerHandshakePaddingBytes);

NET_EXPORT bool IsDnsPlatformSupported();

// If enabled, load the NoVarySearchCache persisted data on a different
// threadpool sequence than used for journalling.
NET_EXPORT BASE_DECLARE_FEATURE(kNoVarySearchCacheLoadOnSeparateTaskRunner);

// The priority to load the persisted data with. 0 => BEST_EFFORT,
// 1 => USER_VISIBLE, 2 => USER_BLOCKING.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(base::TaskPriority,
                                      kNoVarySearchCacheLoadTaskRunnerPriority);

// Enable MTC certificate verification based on test-only roots. This is unsafe
// and may permit an attacker to intercept or modify your HTTPS connections. Do
// not use this flag on an instance containing personal data. Recommended for
// developer use only in isolated testing environments.
NET_EXPORT BASE_DECLARE_FEATURE(kTestRootStore);

// If enabled, cache certificate verification results will be put into the
// certificate verification cache. All other cache interactions (creation,
// clear, get) are performed regardless of this feature.
NET_EXPORT BASE_DECLARE_FEATURE(kCacheCertVerification);

// The TTL in seconds for entries put into the certificate verification cache.
// If set to 0, entries will still technically be put into the cache, but will
// already be expired.
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(int, kCacheCertVerificationTtlSecs);

// Enables the BackendCleanupTracker for HTTP cache backends (net::DISK_CACHE)
// to prevent conflicts when multiple backends are created for the same path.
NET_EXPORT BASE_DECLARE_FEATURE(kEnableBackendCleanupTrackerOnHttpCache);

// If enabled, WebSocketEndpointLockManager partitions locks by
// NetworkAnonymizationKey.
// TODO(crbug.com/533028862): Remove the base::Feature after August 2026
// once it has been verified safe.
NET_EXPORT BASE_DECLARE_FEATURE(
    kPartitionWebSocketEndpointLocksByNetworkAnonymizationKey);

// Controls initial delay for broken alternative services.
NET_EXPORT BASE_DECLARE_FEATURE(kInitialDelayForBrokenAlternativeService);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(
    base::TimeDelta,
    kInitialDelayForBrokenAlternativeServiceParam);

// Controls whether broken alternative services should be persisted to disk
// cache.
NET_EXPORT BASE_DECLARE_FEATURE(kPersistBrokenAlternativeServices);

// Controls maximum delay for broken alternative services.
NET_EXPORT BASE_DECLARE_FEATURE(kMaxDelayForBrokenAlternativeService);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(
    base::TimeDelta,
    kMaxDelayForBrokenAlternativeServiceParam);

#if BUILDFLAG(IS_WIN)
// Disables SYN retransmissions for TCP loopback connections on Windows.
NET_EXPORT BASE_DECLARE_FEATURE(kEnableWindowsTcpLoopbackFastFail);
#endif

// Controls the socket send buffer size for QUIC client sockets.
// If the feature is enabled:
// - If the parameter is -1, SetSendBufferSize() is not called at all.
// - If the parameter is > 0, SetSendBufferSize() is called with this value.
// If the feature is disabled, the default behavior (20 packets) is used.
NET_EXPORT BASE_DECLARE_FEATURE(kQuicSocketSendBufferSize);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(int, kQuicSocketSendBufferSizeParam);

// Controls the disk cache backend experiment for the GPU shader cache
// (`net::SHADER_CACHE`). When enabled, each shader cache directory is wiped
// once on first open (tracked in the cache index header) and recreated using
// the backend specified by `kShaderDiskCacheBackendType`.
NET_EXPORT BASE_DECLARE_FEATURE(kShaderDiskCacheBackendExperiment);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(DiskCacheBackend,
                                      kShaderDiskCacheBackendType);

// Enables per-key (eTLD+1) task queueing for single-domain cookie deletions
// (`DeleteCanonicalCookieAsync` and single-domain `DeleteAllMatchingInfoAsync`)
// so they do not set `seen_global_task_` and block concurrent navigations on
// the full SQLite cookie store load.
NET_EXPORT BASE_DECLARE_FEATURE(kCookieMonsterPerKeyDelete);

// When enabled, CanonicalCookie only encrypts cookie values in memory (via
// crypto::ProcessBoundString) for important cookies. Cookies marked Secure are
// always important. Cookies marked HttpOnly are considered important if the
// kCookieProcessBoundEncryptHttpOnly param is true.
NET_EXPORT BASE_DECLARE_FEATURE(kCookieProcessBoundEncryptOnlyImportant);
NET_EXPORT BASE_DECLARE_FEATURE_PARAM(bool, kCookieProcessBoundEncryptHttpOnly);

// Enables the Rust implementation of the HTTP chunked decoder, called via FFI.
NET_EXPORT BASE_DECLARE_FEATURE(kHttpChunkedDecoderInRust);

// Enables checking all resolved IP endpoints (and preserving DNS aliases) for
// post-handshake cross-origin IP pooling in QUIC and HTTP/2 when concurrent
// connection attempts complete.
NET_EXPORT BASE_DECLARE_FEATURE(kPostHandshakeIpPoolingAllEndpoints);

}  // namespace net::features

#endif  // NET_BASE_FEATURES_H_

