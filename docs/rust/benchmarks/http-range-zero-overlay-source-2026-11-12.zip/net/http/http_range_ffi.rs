// Copyright 2026 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

mod http_range_parser;

#[cxx::bridge(namespace = "net::http_range_internal")]
mod ffi {
    struct Range {
        first: i64,
        last: i64,
        suffix: i64,
    }
    struct RangesResult {
        success: bool,
        ranges: Vec<Range>,
    }
    struct FetchResult {
        success: bool,
        range: Range,
    }
    struct ContentAliases {
        first_offset: i64,
        last_offset: i64,
        length_offset: i64,
        mask: u8,
    }
    struct ContentResult {
        success: bool,
        first: i64,
        last: i64,
        length: i64,
    }
    extern "Rust" {
        fn parse_ranges(input: &[u8]) -> RangesResult;
        fn parse_fetch(input: &[u8], allow_whitespace: bool) -> FetchResult;
        fn parse_content(input: &[u8], aliases: &ContentAliases) -> ContentResult;
    }
}

fn wire(range: http_range_parser::Range) -> ffi::Range {
    ffi::Range { first: range.first, last: range.last, suffix: range.suffix }
}

fn parse_ranges(input: &[u8]) -> ffi::RangesResult {
    let mut ranges = Vec::new();
    let success = http_range_parser::parse_ranges(input, true, |range| ranges.push(wire(range)));
    ffi::RangesResult { success, ranges }
}

fn parse_fetch(input: &[u8], allow_whitespace: bool) -> ffi::FetchResult {
    let range = http_range_parser::parse_fetch(input, allow_whitespace);
    ffi::FetchResult { success: range.is_some(), range: wire(range.unwrap_or_default()) }
}

fn parse_content(input: &[u8], aliases: &ffi::ContentAliases) -> ffi::ContentResult {
    let values = http_range_parser::parse_content(
        input,
        http_range_parser::ContentAliases {
            offsets: [aliases.first_offset, aliases.last_offset, aliases.length_offset],
            mask: aliases.mask,
        },
    );
    let [first, last, length] = values.unwrap_or([-1; 3]);
    ffi::ContentResult { success: values.is_some(), first, last, length }
}

// These fixed C ABI records avoid CXX slice construction/forwarding for the
// two allocation-free APIs. Variable-length list results retain CXX ownership.
#[derive(Clone, Copy)]
#[repr(C)]
pub struct BorrowedBytes {
    pub data: *const u8,
    pub len: usize,
}

#[repr(C)]
pub struct ParsedRange {
    pub first: i64,
    pub last: i64,
    pub suffix: i64,
}

const _: () = {
    assert!(std::mem::size_of::<BorrowedBytes>() == 2 * std::mem::size_of::<usize>());
    assert!(std::mem::offset_of!(BorrowedBytes, len) == std::mem::size_of::<usize>());
    assert!(std::mem::size_of::<ParsedRange>() == 24);
    assert!(std::mem::align_of::<ParsedRange>() == std::mem::align_of::<i64>());
    assert!(std::mem::offset_of!(ParsedRange, last) == 8);
    assert!(std::mem::offset_of!(ParsedRange, suffix) == 16);
};

/// Borrow the live bytes supplied by the C++ adapter.
///
/// # Safety
/// Nonzero len requires that data identify len initialized live bytes, with
/// len <= isize::MAX, immutable for the resulting borrow. Zero length may use
/// a null data pointer. The caller limits the returned reference's lifetime.
unsafe fn bytes<'a>(view: BorrowedBytes) -> &'a [u8] {
    if view.len == 0 {
        &[]
    } else {
        // SAFETY: This is the documented, synchronous std::string_view range.
        unsafe { std::slice::from_raw_parts(view.data, view.len) }
    }
}

/// Parse Fetch's single-range grammar into uninitialized or initialized output.
///
/// # Safety
/// The byte range obeys bytes()'s contract. On success, output must be writable
/// aligned storage for ParsedRange. Input may alias output: the input borrow
/// ends before the only output write. On failure output is never accessed.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn rustium_http_range_fetch(
    view: BorrowedBytes,
    whitespace: bool,
    output: *mut ParsedRange,
) -> bool {
    let result = {
        // SAFETY: Forward the foreign-call range contract. Retain no borrow.
        let input = unsafe { bytes(view) };
        http_range_parser::parse_fetch(input, whitespace)
    };
    if let Some(range) = result {
        // SAFETY: The initialized parsed value is written without reading old
        // caller storage, after the shared input borrow has ended.
        unsafe {
            output.write(ParsedRange { first: range.first, last: range.last, suffix: range.suffix })
        };
        true
    } else {
        false
    }
}

/// Parse Content-Range preserving initialization, scalar aliases and byte
/// overlap.
///
/// # Safety
/// All three pointers identify writable aligned i64 storage; their old contents
/// may be uninitialized and the pointers may be equal. The byte range obeys
/// bytes()'s contract after initial output writes. It may overlap outputs: no
/// shared input reference exists during any real foreign-memory write.
#[unsafe(no_mangle)]
pub unsafe extern "C" fn rustium_http_range_content(
    view: BorrowedBytes,
    first: *mut i64,
    last: *mut i64,
    length: *mut i64,
) -> bool {
    // SAFETY: Preserve the original C++ initialization order before borrowing
    // any input. Raw writes support uninitialized and aliased output storage.
    unsafe {
        first.write(-1);
        last.write(-1);
        length.write(-1);
    }
    let offset = |output: *mut i64| {
        let begin = view.data as usize;
        let address = output as usize;
        if address >= begin {
            let distance = address - begin;
            if distance < view.len {
                return distance as i64;
            }
        } else if begin - address < 8 {
            return -((begin - address) as i64);
        }
        http_range_parser::NO_OVERLAP
    };
    let aliases = http_range_parser::ContentAliases {
        offsets: [offset(first), offset(last), offset(length)],
        mask: u8::from(first == last)
            | (u8::from(first == length) << 1)
            | (u8::from(last == length) << 2),
    };
    let result = {
        // SAFETY: Initial writes are complete; all subsequent writes are
        // simulated by safe Rust until this shared borrow ends.
        let input = unsafe { bytes(view) };
        http_range_parser::parse_content(input, aliases)
    };
    if let Some([a, b, c]) = result {
        // SAFETY: The input is no longer borrowed. These writes preserve the
        // public API's final assignment order, including equal output pointers.
        unsafe {
            first.write(a);
            last.write(b);
            length.write(c);
        }
        true
    } else {
        false
    }
}
