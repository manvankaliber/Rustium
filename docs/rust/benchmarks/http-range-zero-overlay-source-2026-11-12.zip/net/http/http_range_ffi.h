// Copyright 2026 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef NET_HTTP_HTTP_RANGE_FFI_H_
#define NET_HTTP_HTTP_RANGE_FFI_H_

#include <stddef.h>
#include <stdint.h>

#include <type_traits>

namespace net::http_range_internal {

// Explicit C ABI records. No std::string_view, Rust Vec, or CXX private layout
// is shared by these two fixed-result entrypoints.
struct BorrowedBytes {
  const uint8_t* data;
  size_t len;
};
struct ParsedRange {
  int64_t first;
  int64_t last;
  int64_t suffix;
};
static_assert(std::is_trivially_copyable_v<BorrowedBytes>);
static_assert(sizeof(BorrowedBytes) == 2 * sizeof(void*));
static_assert(offsetof(BorrowedBytes, len) == sizeof(void*));
static_assert(sizeof(ParsedRange) == 3 * sizeof(int64_t));
static_assert(alignof(ParsedRange) == alignof(int64_t));
static_assert(offsetof(ParsedRange, last) == sizeof(int64_t));
static_assert(offsetof(ParsedRange, suffix) == 2 * sizeof(int64_t));

// The byte range is live for the synchronous call; null data is allowed only
// for zero length. Fetch writes its output only on success. Content initializes
// every output to-1 before borrowing input, supports equal/overlapping output
// storage, and commits the parsed result after the input borrow has ended.
extern "C" bool rustium_http_range_fetch(BorrowedBytes,
                                         bool allow_whitespace,
                                         ParsedRange*) noexcept;
extern "C" bool rustium_http_range_content(BorrowedBytes,
                                           int64_t* first,
                                           int64_t* last,
                                           int64_t* length) noexcept;

}  // namespace net::http_range_internal
#endif  // NET_HTTP_HTTP_RANGE_FFI_H_
