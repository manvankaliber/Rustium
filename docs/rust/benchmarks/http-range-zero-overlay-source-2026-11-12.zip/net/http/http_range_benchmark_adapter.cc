// Copyright 2026 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Exact production function bodies, verified by the benchmark runner.
#include "base/strings/string_view_rust.h"
#include "net/http/http_range_ffi.h"
#include "net/http/http_range_ffi.rs.h"
#include "net/http/http_util.h"
namespace net {
bool HttpUtil::ParseRangeHeader(std::string_view ranges_specifier,
                                std::vector<HttpByteRange>* ranges) {
  auto result = http_range_internal::parse_ranges(
      base::StringViewToRustSlice(ranges_specifier));
  // Preserve successfully parsed prefixes even if a later range is invalid.
  for (const auto& parsed : result.ranges) {
    HttpByteRange range;
    range.set_first_byte_position(parsed.first);
    range.set_last_byte_position(parsed.last);
    range.set_suffix_length(parsed.suffix);
    ranges->push_back(range);
  }
  // Only inspect caller storage after syntactic validation. Invalid headers
  // historically permit a null output when no valid prefix was appended.
  return result.success && !ranges->empty();
}
std::optional<HttpByteRange> HttpUtil::ParseFetchSingleRange(
    std::string_view range_header_value,
    bool allow_whitespace) {
  const http_range_internal::BorrowedBytes input{
      reinterpret_cast<const uint8_t*>(range_header_value.data()),
      range_header_value.size()};
  http_range_internal::ParsedRange parsed;
  if (!http_range_internal::rustium_http_range_fetch(input, allow_whitespace,
                                                     &parsed)) {
    return std::nullopt;
  }
  HttpByteRange range;
  range.set_first_byte_position(parsed.first);
  range.set_last_byte_position(parsed.last);
  range.set_suffix_length(parsed.suffix);
  return range;
}
bool HttpUtil::ParseContentRangeHeaderFor206(
    std::string_view content_range_spec,
    int64_t* first_byte_position,
    int64_t* last_byte_position,
    int64_t* instance_length) {
  const http_range_internal::BorrowedBytes input{
      reinterpret_cast<const uint8_t*>(content_range_spec.data()),
      content_range_spec.size()};
  // The adapter initializes outputs before borrowing input and commits only
  // after the last input borrow, including scalar and byte-overlap aliases.
  return http_range_internal::rustium_http_range_content(
      input, first_byte_position, last_byte_position, instance_length);
}
}  // namespace net
