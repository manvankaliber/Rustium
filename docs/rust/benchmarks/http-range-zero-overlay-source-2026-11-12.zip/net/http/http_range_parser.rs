// Copyright 2026 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

//! The three legacy HTTP range-header grammars, without foreign ownership.

#![forbid(unsafe_code)]

use parse_number_core::{parse_i64, parse_i64_iter};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Range {
    pub first: i64,
    pub last: i64,
    pub suffix: i64,
}

impl Default for Range {
    fn default() -> Self {
        Self { first: -1, last: -1, suffix: -1 }
    }
}

impl Range {
    fn valid(&self) -> bool {
        self.suffix > 0 || (self.first >= 0 && (self.last == -1 || self.last >= self.first))
    }
}

fn lws(byte: u8) -> bool {
    byte == b' ' || byte == b'\t'
}

fn trim(mut input: &[u8]) -> &[u8] {
    while input.first().is_some_and(|&byte| lws(byte)) {
        input = &input[1..];
    }
    while input.last().is_some_and(|&byte| lws(byte)) {
        input = &input[..input.len() - 1];
    }
    input
}

// base::StringToInt64 allows one leading '+', but rejects leading whitespace.
// It also reports failure on overflow; its partial output is not used here.
fn legacy_i64(input: &[u8]) -> Option<i64> {
    if let Some(rest) = input.strip_prefix(b"+") {
        if !rest.first().is_some_and(u8::is_ascii_digit) {
            return None;
        }
        parse_i64(rest, 0, false).ok()
    } else {
        parse_i64(input, 1, false).ok()
    }
}

pub fn parse_ranges(input: &[u8], had_ranges: bool, mut emit: impl FnMut(Range)) -> bool {
    let Some(equal) = input.iter().position(|&byte| byte == b'=') else {
        return false;
    };
    if !trim(&input[..equal]).eq_ignore_ascii_case(b"bytes") {
        return false;
    }
    let mut pos = equal + 1;
    let mut emitted = false;
    while pos < input.len() {
        let start = pos;
        let mut quote = false;
        let mut escaped = false;
        while pos < input.len() {
            let byte = input[pos];
            if quote {
                if escaped {
                    escaped = false;
                } else if byte == b'\\' {
                    escaped = true;
                } else if byte == b'"' {
                    quote = false;
                }
            } else if byte == b',' {
                break;
            } else if byte == b'"' {
                quote = true;
            }
            pos += 1;
        }
        let token = trim(&input[start..pos]);
        if pos < input.len() {
            pos += 1;
        }
        if token.is_empty() {
            continue;
        }
        let Some(minus) = token.iter().position(|&byte| byte == b'-') else {
            return false;
        };
        let mut range = Range::default();
        let first = trim(&token[..minus]);
        if !first.is_empty() {
            let Some(value) = legacy_i64(first) else { return false };
            range.first = value;
        }
        let last = trim(&token[minus + 1..]);
        if !last.is_empty() {
            let Some(value) = legacy_i64(last) else { return false };
            if range.first != -1 {
                range.last = value;
            } else {
                range.suffix = value;
            }
        } else if range.first == -1 {
            return false;
        }
        if !range.valid() {
            return false;
        }
        emit(range);
        emitted = true;
    }
    had_ranges || emitted
}

fn delimiter(input: &[u8], pos: &mut usize, expected: u8, whitespace: bool) -> bool {
    if whitespace {
        while input.get(*pos).is_some_and(|&byte| lws(byte)) {
            *pos += 1;
        }
    }
    if input.get(*pos) != Some(&expected) {
        return false;
    }
    *pos += 1;
    if whitespace {
        while input.get(*pos).is_some_and(|&byte| lws(byte)) {
            *pos += 1;
        }
    }
    true
}

fn fetch_decimal(input: &[u8], pos: &mut usize) -> Option<i64> {
    let start = *pos;
    while input.get(*pos).is_some_and(u8::is_ascii_digit) {
        *pos += 1;
    }
    if *pos == start {
        None
    } else {
        // This slice contains only digits, so overflow is its only parse error.
        Some(parse_i64(&input[start..*pos], 0, false).unwrap_or(i64::MAX))
    }
}

pub fn parse_fetch(input: &[u8], whitespace: bool) -> Option<Range> {
    if !input.starts_with(b"bytes") {
        return None;
    }
    let mut pos = 5;
    if !delimiter(input, &mut pos, b'=', whitespace) {
        return None;
    }
    let first = fetch_decimal(input, &mut pos);
    if !delimiter(input, &mut pos, b'-', whitespace) {
        return None;
    }
    let last = fetch_decimal(input, &mut pos);
    if pos != input.len() {
        return None;
    }
    // Fetch deliberately returns syntactically valid but semantically invalid
    // ranges such as bytes=-0 or bytes=10-5. Do not call Range::valid here.
    match (first, last) {
        (None, Some(suffix)) => Some(Range { suffix, ..Range::default() }),
        (Some(first), None) => Some(Range { first, ..Range::default() }),
        (Some(first), Some(last)) => Some(Range { first, last, ..Range::default() }),
        (None, None) => None,
    }
}

pub const NO_OVERLAP: i64 = i64::MIN;

#[derive(Clone, Copy, Debug)]
pub struct ContentAliases {
    pub offsets: [i64; 3],
    pub mask: u8,
}

struct ContentInput<'a, const OVERLAP: bool> {
    input: &'a [u8],
    aliases: ContentAliases,
    values: [i64; 3],
    written: [bool; 3],
}

impl<const OVERLAP: bool> ContentInput<'_, OVERLAP> {
    #[inline]
    fn byte(&self, index: usize) -> u8 {
        if OVERLAP {
            for slot in 0..3 {
                let offset = self.aliases.offsets[slot];
                if self.written[slot] && offset != NO_OVERLAP {
                    let relative = if offset >= 0 {
                        index.checked_sub(offset as usize)
                    } else {
                        index.checked_add(offset.unsigned_abs() as usize)
                    };
                    if let Some(byte) = relative.filter(|&byte| byte < 8) {
                        return self.values[slot].to_ne_bytes()[byte];
                    }
                }
            }
        }
        self.input[index]
    }

    fn set(&mut self, slot: usize, value: i64) {
        self.values[slot] = value;
        self.written[slot] = true;
        if self.aliases.mask == 0 {
            return;
        }
        for other in 0..3 {
            let bit = match (slot.min(other), slot.max(other)) {
                (0, 1) => 1,
                (0, 2) => 2,
                (1, 2) => 4,
                _ => 0,
            };
            if self.aliases.mask & bit != 0 {
                self.values[other] = value;
                self.written[other] = true;
            }
        }
    }

    fn field(&self, mut begin: usize, mut end: usize) -> Option<i64> {
        // Even overlapping inputs usually have fields untouched by earlier
        // scalar writes. Borrow those fields directly; replay only writes
        // whose eight-byte cells intersect the field being parsed.
        let changed = OVERLAP
            && (0..3).any(|slot| {
                let offset = self.aliases.offsets[slot];
                self.written[slot]
                    && offset != NO_OVERLAP
                    && i128::from(offset) < end as i128
                    && i128::from(offset) + 8 > begin as i128
            });
        if !changed {
            return legacy_i64(trim(&self.input[begin..end]));
        }
        while begin < end && lws(self.byte(begin)) {
            begin += 1;
        }
        while begin < end && lws(self.byte(end - 1)) {
            end -= 1;
        }
        let mut bytes = (begin..end).map(|index| self.byte(index));
        let first = bytes.next()?;
        if first == b'+' {
            let digit = bytes.next()?;
            if !digit.is_ascii_digit() {
                return None;
            }
            parse_i64_iter(std::iter::once(digit).chain(bytes), 0, false).ok()
        } else {
            parse_i64_iter(std::iter::once(first).chain(bytes), 1, false).ok()
        }
    }
}

fn content<const OVERLAP: bool>(input: &[u8], aliases: ContentAliases) -> Option<[i64; 3]> {
    let begin = input.iter().position(|&byte| !lws(byte)).unwrap_or(input.len());
    let end = input.iter().rposition(|&byte| !lws(byte)).map_or(begin, |index| index + 1);
    let space = begin + input[begin..end].iter().position(|&byte| byte == b' ')?;
    if !trim(&input[begin..space]).eq_ignore_ascii_case(b"bytes") {
        return None;
    }
    let minus = space + 1 + input[space + 1..end].iter().position(|&byte| byte == b'-')?;
    let slash = minus + 1 + input[minus + 1..end].iter().position(|&byte| byte == b'/')?;
    let mut source =
        ContentInput::<OVERLAP> { input, aliases, values: [-1; 3], written: [false; 3] };
    source.set(0, source.field(space + 1, minus)?);
    // This field ends at the first '-', so a successfully parsed first
    // position cannot be negative. Later aliasing writes may change it.
    source.set(1, source.field(minus + 1, slash)?);
    if source.values[1] < source.values[0] {
        return None;
    }
    source.set(2, source.field(slash + 1, end)?);
    if source.values[2] <= source.values[1] {
        return None;
    }
    Some(source.values)
}

pub fn parse_content(input: &[u8], aliases: ContentAliases) -> Option<[i64; 3]> {
    if aliases.offsets.iter().any(|&offset| offset != NO_OVERLAP) {
        content::<true>(input, aliases)
    } else {
        content::<false>(input, aliases)
    }
}
