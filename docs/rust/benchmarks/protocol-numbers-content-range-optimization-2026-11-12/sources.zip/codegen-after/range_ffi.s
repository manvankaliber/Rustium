	.def	@feat.00;
	.scl	3;
	.type	0;
	.endef
	.globl	@feat.00
@feat.00 = 2048
	.att_syntax
	.file	"range_ffi.c63e0d924bc54e24-cgu.0"
	.def	_RINvCs4A2AHSyUD2M_17parse_number_core11parse_sliceKy7fffffffffffffff_Ky8000000000000000_ECsh1eR4S1pMdQ_9range_ffi;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RINvCs4A2AHSyUD2M_17parse_number_core11parse_sliceKy7fffffffffffffff_Ky8000000000000000_ECsh1eR4S1pMdQ_9range_ffi,unique,0
	.p2align	4
_RINvCs4A2AHSyUD2M_17parse_number_core11parse_sliceKy7fffffffffffffff_Ky8000000000000000_ECsh1eR4S1pMdQ_9range_ffi:
.seh_proc _RINvCs4A2AHSyUD2M_17parse_number_core11parse_sliceKy7fffffffffffffff_Ky8000000000000000_ECsh1eR4S1pMdQ_9range_ffi
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rbx
	.seh_pushreg %rbx
	.seh_endprologue
	testq	%r8, %r8
	je	.LBB0_9
	movzbl	(%rdx), %r10d
	cmpl	$45, %r10d
	je	.LBB0_3
	cmpl	$48, %r10d
	jne	.LBB0_8
.LBB0_3:
	leaq	(%rdx,%r8), %rax
	leal	-48(%r10), %r11d
	cmpb	$10, %r11b
	jae	.LBB0_5
	incq	%rdx
	jmp	.LBB0_24
.LBB0_5:
	cmpb	$45, %r10b
	sete	%r11b
	testl	%r9d, %r9d
	setne	%r9b
	testb	%r11b, %r9b
	je	.LBB0_22
	cmpq	$1, %r8
	je	.LBB0_22
	movzbl	1(%rdx), %r8d
	addq	$2, %rdx
	jmp	.LBB0_23
.LBB0_8:
	leal	-48(%r10), %eax
	cmpb	$9, %al
	jbe	.LBB0_13
.LBB0_9:
	movb	$3, %r11b
.LBB0_10:
	movb	%r11b, (%rcx)
	movb	$2, 8(%rcx)
	.seh_startepilogue
	popq	%rbx
	popq	%rsi
	.seh_endepilogue
	retq
.LBB0_13:
	movzbl	%al, %eax
	cmpq	$1, %r8
	jne	.LBB0_16
.LBB0_14:
	movq	%rax, (%rcx)
	movb	$0, 8(%rcx)
	.seh_startepilogue
	popq	%rbx
	popq	%rsi
	.seh_endepilogue
	retq
.LBB0_16:
	movl	$1, %r9d
	movabsq	$922337203685477580, %r10
	movb	$1, %r11b
	jmp	.LBB0_18
	.p2align	4
.LBB0_17:
	leaq	(%rax,%rax,4), %rax
	leaq	(%rsi,%rax,2), %rax
	incq	%r9
	cmpq	%r9, %r8
	je	.LBB0_14
.LBB0_18:
	movzbl	(%rdx,%r9), %ebx
	addb	$-48, %bl
	cmpb	$9, %bl
	ja	.LBB0_9
	cmpq	%r10, %rax
	ja	.LBB0_10
	movzbl	%bl, %esi
	jne	.LBB0_17
	cmpb	$7, %sil
	jbe	.LBB0_17
	jmp	.LBB0_10
.LBB0_24:
	cmpq	%rax, %rdx
	je	.LBB0_26
	movzbl	(%rdx), %r8d
	incq	%rdx
.LBB0_23:
	cmpb	$48, %r8b
	je	.LBB0_24
	addb	$-48, %r8b
	cmpb	$9, %r8b
	jbe	.LBB0_28
.LBB0_22:
	movb	$3, (%rcx)
	movb	$2, 8(%rcx)
	.seh_startepilogue
	popq	%rbx
	popq	%rsi
	.seh_endepilogue
	retq
.LBB0_26:
	cmpb	$45, %r10b
	movq	$0, (%rcx)
	sete	8(%rcx)
	.seh_startepilogue
	popq	%rbx
	popq	%rsi
	.seh_endepilogue
	retq
.LBB0_28:
	movzbl	%r8b, %r8d
	cmpb	$45, %r10b
	jne	.LBB0_36
	cmpq	%rax, %rdx
	je	.LBB0_43
	movabsq	$922337203685477580, %r9
	movb	$2, %r10b
	jmp	.LBB0_32
.LBB0_31:
	leaq	(%r8,%r8,4), %r8
	leaq	(%r11,%r8,2), %r8
	cmpq	%rax, %rdx
	je	.LBB0_43
.LBB0_32:
	movzbl	(%rdx), %r11d
	addb	$-48, %r11b
	cmpb	$9, %r11b
	ja	.LBB0_45
	incq	%rdx
	cmpq	%r9, %r8
	ja	.LBB0_46
	movzbl	%r11b, %r11d
	jne	.LBB0_31
	cmpb	$9, %r11b
	jne	.LBB0_31
	jmp	.LBB0_46
.LBB0_36:
	cmpq	%rax, %rdx
	je	.LBB0_44
	movabsq	$922337203685477580, %r9
	movb	$1, %r10b
	jmp	.LBB0_39
.LBB0_38:
	leaq	(%r8,%r8,4), %r8
	leaq	(%r11,%r8,2), %r8
	cmpq	%rax, %rdx
	je	.LBB0_44
.LBB0_39:
	movzbl	(%rdx), %r11d
	addb	$-48, %r11b
	cmpb	$9, %r11b
	ja	.LBB0_45
	incq	%rdx
	cmpq	%r9, %r8
	ja	.LBB0_46
	movzbl	%r11b, %r11d
	jne	.LBB0_38
	cmpb	$7, %r11b
	jbe	.LBB0_38
	jmp	.LBB0_46
.LBB0_43:
	movq	%r8, (%rcx)
	movb	$1, 8(%rcx)
	.seh_startepilogue
	popq	%rbx
	popq	%rsi
	.seh_endepilogue
	retq
.LBB0_44:
	movq	%r8, (%rcx)
	movb	$0, 8(%rcx)
	.seh_startepilogue
	popq	%rbx
	popq	%rsi
	.seh_endepilogue
	retq
.LBB0_45:
	movb	$3, %r10b
.LBB0_46:
	movb	%r10b, (%rcx)
	movb	$2, 8(%rcx)
	.seh_startepilogue
	popq	%rbx
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc

	.def	_RNvCsh1eR4S1pMdQ_9range_ffi5bytes;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvCsh1eR4S1pMdQ_9range_ffi5bytes,unique,1
	.globl	_RNvCsh1eR4S1pMdQ_9range_ffi5bytes
	.p2align	4
_RNvCsh1eR4S1pMdQ_9range_ffi5bytes:
.seh_proc _RNvCsh1eR4S1pMdQ_9range_ffi5bytes
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%rdx, %rdx
	je	.LBB1_3
	testq	%rcx, %rcx
	setne	%al
	testq	%rdx, %rdx
	setns	%r8b
	testb	%r8b, %al
	je	.LBB1_4
	movq	%rcx, %rax
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB1_3:
	movl	$1, %ecx
	movq	%rcx, %rax
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB1_4:
	leaq	alloc_a28e8c8fd5088943a8b5d44af697ff83(%rip), %rcx
	leaq	alloc_56c01fe01d1a47ca560ad2a33d46aaec(%rip), %r9
	movl	$559, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
	.seh_endproc

	.def	_RNvMs7_NtCs8tsiLsQ9XHg_5alloc7raw_vecINtB5_6RawVecNtCsh1eR4S1pMdQ_9range_ffi11ParsedRangeE8grow_oneBO_;
	.scl	2;
	.type	32;
	.endef
	.section	.text$unlikely,"xr",one_only,_RNvMs7_NtCs8tsiLsQ9XHg_5alloc7raw_vecINtB5_6RawVecNtCsh1eR4S1pMdQ_9range_ffi11ParsedRangeE8grow_oneBO_,unique,2
	.globl	_RNvMs7_NtCs8tsiLsQ9XHg_5alloc7raw_vecINtB5_6RawVecNtCsh1eR4S1pMdQ_9range_ffi11ParsedRangeE8grow_oneBO_
	.p2align	4
_RNvMs7_NtCs8tsiLsQ9XHg_5alloc7raw_vecINtB5_6RawVecNtCsh1eR4S1pMdQ_9range_ffi11ParsedRangeE8grow_oneBO_:
.seh_proc _RNvMs7_NtCs8tsiLsQ9XHg_5alloc7raw_vecINtB5_6RawVecNtCsh1eR4S1pMdQ_9range_ffi11ParsedRangeE8grow_oneBO_
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	(%rcx), %rdx
	callq	_RNvMs8_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14grow_amortizedCsh1eR4S1pMdQ_9range_ffi
	cmpq	$-1, %rax
	jne	.LBB2_1
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB2_1:
	movq	%rax, %rcx
	callq	_RNvNtCs8tsiLsQ9XHg_5alloc7raw_vec12handle_error
	ud2
	.seh_endproc

	.def	_RNvMs8_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsh1eR4S1pMdQ_9range_ffi;
	.scl	3;
	.type	32;
	.endef
	.section	.text$unlikely,"xr",one_only,_RNvMs8_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsh1eR4S1pMdQ_9range_ffi,unique,3
	.p2align	4
_RNvMs8_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsh1eR4S1pMdQ_9range_ffi:
.seh_proc _RNvMs8_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsh1eR4S1pMdQ_9range_ffi
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$56, %rsp
	.seh_stackalloc 56
	.seh_endprologue
	movq	%rcx, %rsi
	movabsq	$384307168202282325, %rax
	cmpq	%rax, %r9
	jbe	.LBB3_1
	movq	$0, 8(%rsi)
	movl	$1, %eax
	jmp	.LBB3_21
.LBB3_1:
	testq	%rdx, %rdx
	je	.LBB3_2
	movabsq	$768614336404564651, %rcx
	cmpq	%rcx, %rdx
	jae	.LBB3_4
	incq	%rax
	cmpq	%rax, %rdx
	jae	.LBB3_6
	shlq	$3, %rdx
	leaq	(%rdx,%rdx,2), %rax
	movq	$8, 40(%rsp)
	leaq	48(%rsp), %rcx
	jmp	.LBB3_8
.LBB3_2:
	leaq	40(%rsp), %rcx
	xorl	%eax, %eax
.LBB3_8:
	shlq	$3, %r9
	leaq	(%r9,%r9,2), %rdi
	movq	%rax, (%rcx)
	movq	40(%rsp), %rax
	testq	%rax, %rax
	je	.LBB3_17
	cmpq	$8, %rax
	jne	.LBB3_10
	movq	48(%rsp), %rdx
	testq	%rdx, %rdx
	je	.LBB3_17
	cmpq	%rdx, %rdi
	jb	.LBB3_15
	movq	%r8, %rcx
	movl	$8, %r8d
	movq	%rdi, %r9
	callq	_RNvCs6d6XRwTwhVh_7___rustc14___rust_realloc
	testq	%rax, %rax
	jne	.LBB3_20
.LBB3_19:
	movq	$8, 8(%rsi)
	movq	%rdi, 16(%rsi)
	movl	$1, %eax
	jmp	.LBB3_21
.LBB3_17:
	callq	_RNvCs6d6XRwTwhVh_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$8, %edx
	movq	%rdi, %rcx
	callq	_RNvCs6d6XRwTwhVh_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB3_19
.LBB3_20:
	movq	%rax, 8(%rsi)
	movq	%rdi, 16(%rsi)
	xorl	%eax, %eax
.LBB3_21:
	movq	%rax, (%rsi)
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB3_4:
	leaq	alloc_db07ae5a9ce650d9b7cc970d048e6f0c(%rip), %rcx
	leaq	alloc_ad088eaa3dc0ae68b11fd72bfcf5e34b(%rip), %r9
	movl	$373, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
.LBB3_6:
	leaq	alloc_1be5ea12ba708d9a11b6e93a7d387a75(%rip), %rcx
	leaq	alloc_dade1aed0d0fe800cb3ecdb07302e098(%rip), %r9
	movl	$563, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
.LBB3_10:
	leaq	alloc_64e308ef4babfeb8b6220184de794a17(%rip), %rcx
	leaq	alloc_5a885d3db7500f26d581e948d37c49fe(%rip), %r9
	movl	$443, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
.LBB3_15:
	leaq	alloc_64e308ef4babfeb8b6220184de794a17(%rip), %rcx
	leaq	alloc_1b98de0e82d923a9daff35d520cf360d(%rip), %r9
	movl	$443, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
	.seh_endproc

	.def	_RNvMs8_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14grow_amortizedCsh1eR4S1pMdQ_9range_ffi;
	.scl	3;
	.type	32;
	.endef
	.section	.text$unlikely,"xr",one_only,_RNvMs8_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14grow_amortizedCsh1eR4S1pMdQ_9range_ffi,unique,4
	.p2align	4
_RNvMs8_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14grow_amortizedCsh1eR4S1pMdQ_9range_ffi:
.seh_proc _RNvMs8_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14grow_amortizedCsh1eR4S1pMdQ_9range_ffi
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$56, %rsp
	.seh_stackalloc 56
	.seh_endprologue
	movq	%rcx, %rsi
	incq	%rdx
	movq	(%rcx), %rax
	leaq	(%rax,%rax), %rcx
	cmpq	%rdx, %rcx
	cmovaq	%rcx, %rdx
	cmpq	$5, %rdx
	movl	$4, %edi
	cmovaeq	%rdx, %rdi
	movq	8(%rsi), %r8
	leaq	32(%rsp), %rcx
	movq	%rax, %rdx
	movq	%rdi, %r9
	callq	_RNvMs8_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsh1eR4S1pMdQ_9range_ffi
	cmpb	$0, 32(%rsp)
	je	.LBB4_2
	movq	40(%rsp), %rax
	movq	48(%rsp), %rdx
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB4_2:
	movq	40(%rsp), %rax
	movq	%rax, 8(%rsi)
	movq	%rdi, (%rsi)
	movq	$-1, %rax
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc

	.def	_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser10legacy_i64;
	.scl	3;
	.type	32;
	.endef
	.globl	__xmm@30303030303030303030303030303030
	.section	.rdata,"dr",discard,__xmm@30303030303030303030303030303030
	.p2align	4, 0x0
__xmm@30303030303030303030303030303030:
	.zero	16,48
	.section	.text,"xr",one_only,_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser10legacy_i64,unique,5
	.p2align	4
_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser10legacy_i64:
.seh_proc _RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser10legacy_i64
	subq	$56, %rsp
	.seh_stackalloc 56
	.seh_endprologue
	movq	%rdx, %rax
	movq	%rcx, %rdx
	testq	%rax, %rax
	je	.LBB5_1
	cmpb	$43, (%rdx)
	jne	.LBB5_5
	movq	%rax, %r8
	decq	%r8
	je	.LBB5_4
	incq	%rdx
	movzbl	(%rdx), %ecx
	addb	$-48, %cl
	cmpb	$9, %cl
	ja	.LBB5_4
	cmpq	$18, %rax
	jb	.LBB5_15
	movdqa	__xmm@30303030303030303030303030303030(%rip), %xmm0
	.p2align	4
.LBB5_13:
	movdqu	(%rdx), %xmm1
	pcmpeqb	%xmm0, %xmm1
	pmovmskb	%xmm1, %eax
	cmpl	$65535, %eax
	jne	.LBB5_15
	addq	$-16, %r8
	addq	$16, %rdx
	cmpq	$16, %r8
	ja	.LBB5_13
.LBB5_15:
	leaq	40(%rsp), %rcx
	xorl	%r9d, %r9d
	callq	_RINvCs4A2AHSyUD2M_17parse_number_core11parse_sliceKy7fffffffffffffff_Ky8000000000000000_ECsh1eR4S1pMdQ_9range_ffi
	movzbl	48(%rsp), %eax
	cmpb	$2, %al
	je	.LBB5_4
.LBB5_17:
	movq	40(%rsp), %rcx
	movq	%rcx, %rdx
	negq	%rdx
	testb	$1, %al
	cmoveq	%rcx, %rdx
	movl	$1, %eax
	.seh_startepilogue
	addq	$56, %rsp
	.seh_endepilogue
	retq
.LBB5_1:
	xorl	%eax, %eax
	jmp	.LBB5_9
.LBB5_5:
	cmpq	$17, %rax
	jb	.LBB5_9
	movdqa	__xmm@30303030303030303030303030303030(%rip), %xmm0
	.p2align	4
.LBB5_7:
	movdqu	(%rdx), %xmm1
	pcmpeqb	%xmm0, %xmm1
	pmovmskb	%xmm1, %ecx
	cmpl	$65535, %ecx
	jne	.LBB5_9
	addq	$-16, %rax
	addq	$16, %rdx
	cmpq	$16, %rax
	ja	.LBB5_7
.LBB5_9:
	leaq	40(%rsp), %rcx
	movq	%rax, %r8
	movl	$1, %r9d
	callq	_RINvCs4A2AHSyUD2M_17parse_number_core11parse_sliceKy7fffffffffffffff_Ky8000000000000000_ECsh1eR4S1pMdQ_9range_ffi
	movzbl	48(%rsp), %eax
	cmpb	$2, %al
	jne	.LBB5_17
.LBB5_4:
	xorl	%eax, %eax
	.seh_startepilogue
	addq	$56, %rsp
	.seh_endepilogue
	retq
	.seh_endproc

	.def	_RNvNvNtCs9l4wcBNbII5_4core4hint21unreachable_unchecked18precondition_check;
	.scl	3;
	.type	32;
	.endef
	.section	.text$unlikely,"xr",one_only,_RNvNvNtCs9l4wcBNbII5_4core4hint21unreachable_unchecked18precondition_check,unique,6
	.p2align	4
_RNvNvNtCs9l4wcBNbII5_4core4hint21unreachable_unchecked18precondition_check:
.seh_proc _RNvNvNtCs9l4wcBNbII5_4core4hint21unreachable_unchecked18precondition_check
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	%rcx, %r9
	leaq	alloc_75fb06c2453febd814e73f5f2e72ae38(%rip), %rcx
	movl	$399, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
	.seh_endproc

	.def	rustium_http_range_content;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,rustium_http_range_content,unique,7
	.globl	rustium_http_range_content
	.p2align	4
rustium_http_range_content:
.seh_proc rustium_http_range_content
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$104, %rsp
	.seh_stackalloc 104
	.seh_endprologue
	movq	%rdx, %rdi
	movq	208(%rsp), %rax
	movq	$-1, (%rax)
	movq	$-1, (%r9)
	movq	$-1, (%r8)
	testq	%rdx, %rdx
	je	.LBB7_1
	testq	%rcx, %rcx
	setne	%al
	testq	%rdi, %rdi
	setns	%dl
	testb	%dl, %al
	je	.LBB7_3
	xorl	%esi, %esi
	jmp	.LBB7_6
	.p2align	4
.LBB7_8:
	incq	%rsi
	cmpq	%rsi, %rdi
	je	.LBB7_9
.LBB7_6:
	movzbl	(%rcx,%rsi), %eax
	cmpl	$32, %eax
	je	.LBB7_8
	cmpl	$9, %eax
	je	.LBB7_8
	cmpq	%rdi, %rsi
	jb	.LBB7_10
	jmp	.LBB7_16
.LBB7_9:
	movq	%rdi, %rsi
.LBB7_10:
	movq	%rdi, %rbx
	jmp	.LBB7_11
	.p2align	4
.LBB7_13:
	decq	%rbx
	je	.LBB7_14
.LBB7_11:
	movzbl	-1(%rcx,%rbx), %eax
	cmpl	$32, %eax
	je	.LBB7_13
	cmpl	$9, %eax
	je	.LBB7_13
	leaq	-1(%rbx), %rax
	movq	%rcx, %r13
	cmpq	%rdi, %rax
	jb	.LBB7_18
	jmp	.LBB7_16
.LBB7_14:
	movq	%rcx, %r13
	movq	%rsi, %rbx
	jmp	.LBB7_18
.LBB7_1:
	movl	$1, %r13d
	xorl	%esi, %esi
	xorl	%ebx, %ebx
.LBB7_18:
	movq	%rbx, %rbp
	subq	%rsi, %rbp
	setae	%al
	cmpq	%rdi, %rbx
	setbe	%dl
	testb	%dl, %al
	je	.LBB7_19
	leaq	(%rsi,%r13), %r11
	leaq	(%rbx,%r13), %r10
	cmpq	$17, %rbp
	jae	.LBB7_21
	cmpq	%rsi, %rbx
	je	.LBB7_117
	xorl	%edx, %edx
	.p2align	4
.LBB7_27:
	cmpb	$32, (%r11,%rdx)
	je	.LBB7_29
	incq	%rdx
	cmpq	%rdx, %rbp
	jne	.LBB7_27
	jmp	.LBB7_117
.LBB7_21:
	movq	%r13, 56(%rsp)
	movq	%rcx, 40(%rsp)
	movq	%r9, %r15
	movq	%r8, %r14
	movq	__imp__RNvNvNtNtNtCskuZNHgLkVkS_6memchr4arch6x86_646memchr10memchr_raw2FN(%rip), %rax
	movq	(%rax), %rax
	movb	$32, %cl
	movq	%r11, %rdx
	movq	%r10, %r12
	movq	%r10, %r8
	movq	%r11, %r13
	callq	*__guard_dispatch_icall_fptr(%rip)
	cmpq	$1, %rax
	jne	.LBB7_117
	subq	%r13, %rdx
	js	.LBB7_119
	movq	%r13, %r11
	cmpq	%rbp, %rdx
	movq	%r14, %r8
	movq	%r15, %r9
	movq	40(%rsp), %rcx
	movq	56(%rsp), %r13
	movq	%r12, %r10
	jb	.LBB7_30
.LBB7_24:
	leaq	alloc_a59d8fe4279b26f926811f91f116a398(%rip), %rcx
	callq	_RNvNvNtCs9l4wcBNbII5_4core4hint21unreachable_unchecked18precondition_check
	ud2
.LBB7_29:
	cmpq	%rbp, %rdx
	jae	.LBB7_16
.LBB7_30:
	leaq	(%rdx,%rsi), %rax
	cmpq	%rdi, %rax
	ja	.LBB7_31
	testq	%rdx, %rdx
	je	.LBB7_117
	movq	%r11, %r15
	movq	%r10, %r12
	leaq	(%rsi,%r13), %r14
	addq	$4, %r14
	xorl	%r10d, %r10d
	jmp	.LBB7_34
	.p2align	4
.LBB7_40:
	incq	%r10
	cmpq	%r10, %rdx
	je	.LBB7_117
.LBB7_34:
	movzbl	-4(%r14,%r10), %r11d
	cmpl	$9, %r11d
	je	.LBB7_40
	cmpl	$32, %r11d
	je	.LBB7_40
	movq	%r13, 56(%rsp)
	addq	%rax, %r13
	decq	%r13
	xorl	%ebp, %ebp
	jmp	.LBB7_37
	.p2align	4
.LBB7_39:
	leaq	(%rdx,%rbp), %r14
	decq	%r14
	decq	%rbp
	cmpq	%r10, %r14
	je	.LBB7_117
.LBB7_37:
	movzbl	(%r13,%rbp), %r14d
	cmpl	$32, %r14d
	je	.LBB7_39
	cmpl	$9, %r14d
	je	.LBB7_39
	leaq	(%rdx,%rbp), %r14
	addq	$-5, %r14
	cmpq	%r10, %r14
	jne	.LBB7_117
	leal	-65(%r11), %ebp
	cmpb	$26, %bpl
	setb	%bpl
	shlb	$5, %bpl
	orb	%r11b, %bpl
	cmpb	$98, %bpl
	jne	.LBB7_117
	movzbl	1(%r10,%r15), %r11d
	leal	-65(%r11), %ebp
	cmpb	$26, %bpl
	setb	%bpl
	shlb	$5, %bpl
	orb	%r11b, %bpl
	cmpb	$121, %bpl
	jne	.LBB7_117
	movzbl	2(%r10,%r15), %r11d
	leal	-65(%r11), %ebp
	cmpb	$26, %bpl
	setb	%bpl
	shlb	$5, %bpl
	orb	%r11b, %bpl
	cmpb	$116, %bpl
	jne	.LBB7_117
	movzbl	3(%r10,%r15), %r11d
	leal	-65(%r11), %ebp
	cmpb	$26, %bpl
	setb	%bpl
	shlb	$5, %bpl
	orb	%r11b, %bpl
	cmpb	$101, %bpl
	jne	.LBB7_117
	movzbl	4(%r10,%r15), %r10d
	leal	-65(%r10), %r11d
	cmpb	$26, %r11b
	setb	%r11b
	shlb	$5, %r11b
	orb	%r10b, %r11b
	cmpb	$115, %r11b
	jne	.LBB7_117
	leaq	1(%rax), %r10
	cmpq	%rax, %rbx
	jbe	.LBB7_120
	movq	%rbx, %rbp
	subq	%r10, %rbp
	movq	56(%rsp), %r11
	leaq	(%r11,%r10), %r13
	cmpq	$17, %rbp
	jae	.LBB7_49
	cmpq	%r10, %rbx
	je	.LBB7_117
	movq	%rax, %r14
	movq	%rdx, 88(%rsp)
	movq	%rcx, 40(%rsp)
	xorl	%edx, %edx
.LBB7_54:
	cmpb	$45, (%r13,%rdx)
	je	.LBB7_56
	incq	%rdx
	xorl	%eax, %eax
	cmpq	%rdx, %rbp
	jne	.LBB7_54
	jmp	.LBB7_118
.LBB7_19:
	leaq	alloc_5fd5ad9d8a4f43eaaa74e75f1fc82bac(%rip), %r9
	movq	%rsi, %rcx
	movq	%rbx, %rdx
	movq	%rdi, %r8
	callq	_RNvNtNtCs9l4wcBNbII5_4core5slice5index16slice_index_fail
	ud2
.LBB7_49:
	movq	%r10, %r15
	movq	%rax, %r14
	movq	%rdx, 88(%rsp)
	movq	%rcx, 40(%rsp)
	movq	%r9, 80(%rsp)
	movq	%r8, 64(%rsp)
	movq	__imp__RNvNvNtNtNtCskuZNHgLkVkS_6memchr4arch6x86_646memchr10memchr_raw2FN(%rip), %rax
	movq	(%rax), %rax
	movb	$45, %cl
	movq	%r13, %rdx
	movq	%r12, %r8
	callq	*__guard_dispatch_icall_fptr(%rip)
	cmpq	$1, %rax
	jne	.LBB7_117
	subq	%r13, %rdx
	js	.LBB7_119
	cmpq	%rbp, %rdx
	jb	.LBB7_57
	jmp	.LBB7_24
.LBB7_31:
	leaq	alloc_16cbcd9a81ccfa6f0d62eca93b6e0394(%rip), %r9
	movq	%rsi, %rcx
	movq	%rax, %rdx
	movq	%rdi, %r8
	callq	_RNvNtNtCs9l4wcBNbII5_4core5slice5index16slice_index_fail
	ud2
.LBB7_56:
	movq	%r9, 80(%rsp)
	movq	%r8, 64(%rsp)
	cmpq	%rbp, %rdx
	movq	%r10, %r15
	jae	.LBB7_16
.LBB7_57:
	addq	%rdx, %r15
	cmpq	%r14, %r15
	jbe	.LBB7_121
	leaq	1(%r15), %rcx
	cmpq	%r15, %rbx
	jbe	.LBB7_71
	movq	%r15, 96(%rsp)
	movq	%rdx, 72(%rsp)
	movq	%rbx, %rbp
	subq	%rcx, %rbp
	addq	%rcx, 56(%rsp)
	cmpq	$17, %rbp
	movq	%rcx, 48(%rsp)
	jae	.LBB7_60
	cmpq	%rcx, %rbx
	je	.LBB7_117
	xorl	%r15d, %r15d
.LBB7_68:
	movq	56(%rsp), %rax
	cmpb	$47, (%rax,%r15)
	je	.LBB7_70
	incq	%r15
	xorl	%eax, %eax
	cmpq	%r15, %rbp
	jne	.LBB7_68
	jmp	.LBB7_118
.LBB7_60:
	movq	__imp__RNvNvNtNtNtCskuZNHgLkVkS_6memchr4arch6x86_646memchr10memchr_raw2FN(%rip), %rax
	movq	(%rax), %rax
	movb	$47, %cl
	movq	56(%rsp), %rdx
	movq	%r12, %r8
	callq	*__guard_dispatch_icall_fptr(%rip)
	cmpq	$1, %rax
	jne	.LBB7_117
	movq	%rdx, %r15
	subq	56(%rsp), %r15
	js	.LBB7_119
	cmpq	%rbp, %r15
	jb	.LBB7_63
	jmp	.LBB7_24
.LBB7_119:
	leaq	alloc_6d855724149bc5132e1bc43bfd525250(%rip), %rcx
	callq	_RNvNvNtCs9l4wcBNbII5_4core4hint21unreachable_unchecked18precondition_check
	ud2
.LBB7_70:
	cmpq	%rbp, %r15
	jae	.LBB7_16
.LBB7_63:
	cmpq	$0, 40(%rsp)
	setne	%al
	testq	%rdi, %rdi
	setns	%cl
	testb	%cl, %al
	je	.LBB7_3
	movq	40(%rsp), %rax
	leaq	(%rax,%r14), %rcx
	incq	%rcx
	cmpq	$0, 72(%rsp)
	je	.LBB7_65
	movq	96(%rsp), %rax
	addq	40(%rsp), %rax
	movq	%rax, 96(%rsp)
	xorl	%edx, %edx
	xorl	%eax, %eax
	movq	72(%rsp), %r8
	jmp	.LBB7_75
.LBB7_3:
	leaq	alloc_a28e8c8fd5088943a8b5d44af697ff83(%rip), %rcx
	leaq	alloc_56c01fe01d1a47ca560ad2a33d46aaec(%rip), %r9
	movl	$559, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
.LBB7_81:
	incq	%rax
	cmpq	%rax, %r8
	je	.LBB7_82
.LBB7_75:
	movzbl	(%rcx,%rax), %r9d
	cmpl	$9, %r9d
	je	.LBB7_81
	cmpl	$32, %r9d
	je	.LBB7_81
	leaq	(%rsi,%r8), %r9
	movq	88(%rsp), %rdx
	movq	40(%rsp), %r10
	addq	%r10, %rdx
	addq	%rdx, %r9
	addq	%rax, %rcx
	xorl	%edx, %edx
	xorl	%r10d, %r10d
	jmp	.LBB7_78
.LBB7_16:
	leaq	alloc_64e308ef4babfeb8b6220184de794a17(%rip), %rcx
	leaq	alloc_1d1b1e35bb489427b2bdc9752de92226(%rip), %r9
	movl	$443, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
.LBB7_80:
	leaq	(%r10,%r8), %r11
	decq	%r11
	decq	%r10
	cmpq	%rax, %r11
	je	.LBB7_84
.LBB7_78:
	movzbl	(%r9,%r10), %r11d
	cmpl	$32, %r11d
	je	.LBB7_80
	cmpl	$9, %r11d
	je	.LBB7_80
	movq	%r8, %rdx
	subq	%rax, %rdx
	addq	%r10, %rdx
	jmp	.LBB7_84
.LBB7_82:
	movq	96(%rsp), %rcx
	jmp	.LBB7_84
.LBB7_65:
	xorl	%edx, %edx
.LBB7_84:
	callq	_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser10legacy_i64
	cmpq	$1, %rax
	jne	.LBB7_117
	movq	48(%rsp), %rax
	leaq	(%r15,%rax), %r14
	movq	64(%rsp), %rax
	movq	%rdx, (%rax)
	cmpq	%rdi, %r14
	ja	.LBB7_97
	movq	40(%rsp), %rax
	addq	%rax, 48(%rsp)
	testq	%r15, %r15
	je	.LBB7_87
	movq	40(%rsp), %rax
	leaq	(%rax,%r14), %r8
	xorl	%edx, %edx
	xorl	%eax, %eax
	movq	48(%rsp), %rcx
	jmp	.LBB7_89
.LBB7_95:
	incq	%rax
	cmpq	%rax, %r15
	je	.LBB7_96
.LBB7_89:
	movzbl	(%rcx,%rax), %r9d
	cmpl	$9, %r9d
	je	.LBB7_95
	cmpl	$32, %r9d
	je	.LBB7_95
	movq	88(%rsp), %rdx
	movq	72(%rsp), %r8
	leaq	(%r8,%rdx), %r8
	addq	%rsi, %r8
	addq	%r15, %r8
	movq	40(%rsp), %rdx
	addq	%rdx, %r8
	incq	%r8
	addq	%rax, %rcx
	movq	%rcx, 48(%rsp)
	xorl	%edx, %edx
	xorl	%ecx, %ecx
	jmp	.LBB7_92
.LBB7_94:
	leaq	(%rcx,%r15), %r9
	decq	%r9
	decq	%rcx
	cmpq	%rax, %r9
	je	.LBB7_99
.LBB7_92:
	movzbl	(%r8,%rcx), %r9d
	cmpl	$32, %r9d
	je	.LBB7_94
	cmpl	$9, %r9d
	je	.LBB7_94
	movq	%r15, %rdx
	subq	%rax, %rdx
	addq	%rcx, %rdx
	jmp	.LBB7_99
.LBB7_96:
	movq	%r8, 48(%rsp)
	jmp	.LBB7_99
.LBB7_87:
	xorl	%edx, %edx
.LBB7_99:
	movq	48(%rsp), %rcx
	callq	_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser10legacy_i64
	cmpq	$1, %rax
	movq	64(%rsp), %rcx
	movq	80(%rsp), %r8
	jne	.LBB7_116
	movq	%rdx, (%r8)
	cmpq	(%rcx), %rdx
	jl	.LBB7_116
	movq	%r8, 80(%rsp)
	movq	%rcx, 64(%rsp)
	leaq	1(%r14), %rcx
	cmpq	%r14, %rbx
	jbe	.LBB7_112
	cmpq	%rcx, %rbx
	je	.LBB7_103
	movq	40(%rsp), %rdx
	leaq	(%rdx,%rbx), %rcx
	addq	%r15, %rsi
	addq	72(%rsp), %rsi
	movq	%rdx, %r8
	movq	88(%rsp), %r11
	leaq	(%r11,%rdx), %r10
	addq	$3, %r10
	movq	%rbx, %rax
	movq	%r11, %r9
	subq	%r11, %rax
	leaq	-3(%rax), %r11
	xorl	%edx, %edx
	jmp	.LBB7_105
.LBB7_111:
	incq	%rsi
	cmpq	%rsi, %r11
	je	.LBB7_114
.LBB7_105:
	movzbl	(%r10,%rsi), %edi
	cmpl	$9, %edi
	je	.LBB7_111
	cmpl	$32, %edi
	je	.LBB7_111
	movq	%r8, %rcx
	addq	%rbx, %r8
	decq	%r8
	addq	%rcx, %r9
	leaq	(%rsi,%r9), %rcx
	addq	$3, %rcx
	xorl	%edx, %edx
	xorl	%r9d, %r9d
	jmp	.LBB7_108
.LBB7_110:
	leaq	(%rax,%r9), %r10
	addq	$-4, %r10
	decq	%r9
	cmpq	%rsi, %r10
	je	.LBB7_114
.LBB7_108:
	movzbl	(%r8,%r9), %r10d
	cmpl	$32, %r10d
	je	.LBB7_110
	cmpl	$9, %r10d
	je	.LBB7_110
	subq	%rsi, %rax
	leaq	(%rax,%r9), %rdx
	addq	$-3, %rdx
	jmp	.LBB7_114
.LBB7_103:
	movq	40(%rsp), %rax
	addq	%rcx, %rax
	xorl	%edx, %edx
	movq	%rax, %rcx
.LBB7_114:
	callq	_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser10legacy_i64
	cmpq	$1, %rax
	movq	64(%rsp), %rcx
	movq	80(%rsp), %r8
	jne	.LBB7_116
	movq	208(%rsp), %rax
	movq	%rdx, (%rax)
	movb	$1, %al
	cmpq	(%r8), %rdx
	jg	.LBB7_118
.LBB7_116:
	movq	208(%rsp), %rax
	movq	$-1, (%rax)
	movq	$-1, (%r8)
	movq	$-1, (%rcx)
.LBB7_117:
	xorl	%eax, %eax
.LBB7_118:
	.seh_startepilogue
	addq	$104, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB7_120:
	leaq	alloc_6ca9fc8d99acf98ecf00d162e0ad6d5e(%rip), %r9
	movq	%r10, %rcx
	movq	%rbx, %rdx
	movq	%rdi, %r8
	callq	_RNvNtNtCs9l4wcBNbII5_4core5slice5index16slice_index_fail
	ud2
.LBB7_71:
	leaq	alloc_cd7dc146611f1efd96d87a1399113f8c(%rip), %r9
	movq	%rbx, %rdx
	movq	%rdi, %r8
	callq	_RNvNtNtCs9l4wcBNbII5_4core5slice5index16slice_index_fail
	ud2
.LBB7_97:
	leaq	alloc_f9be6c591f7e00dc1cf1dc33e68f267a(%rip), %r9
	movq	48(%rsp), %rcx
	movq	%r14, %rdx
	movq	%rdi, %r8
	callq	_RNvNtNtCs9l4wcBNbII5_4core5slice5index16slice_index_fail
	ud2
.LBB7_112:
	leaq	alloc_0a48ea62e5579eec5969b23ab3020878(%rip), %r9
	movq	%rbx, %rdx
	movq	%rdi, %r8
	callq	_RNvNtNtCs9l4wcBNbII5_4core5slice5index16slice_index_fail
	ud2
.LBB7_121:
	leaq	alloc_1bb48cd636a7e77d2a1a241c967005fc(%rip), %rcx
	callq	_RNvNtNtCs9l4wcBNbII5_4core9panicking11panic_const24panic_const_add_overflow
	ud2
	.seh_endproc

	.def	rustium_http_range_fetch;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,rustium_http_range_fetch,unique,8
	.globl	rustium_http_range_fetch
	.p2align	4
rustium_http_range_fetch:
.seh_proc rustium_http_range_fetch
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$72, %rsp
	.seh_stackalloc 72
	.seh_endprologue
	testq	%rdx, %rdx
	je	.LBB8_3
	testq	%rcx, %rcx
	setne	%al
	testq	%rdx, %rdx
	setns	%r10b
	testb	%r10b, %al
	je	.LBB8_51
	cmpq	$5, %rdx
	jb	.LBB8_3
	movl	$1702132066, %eax
	xorl	(%rcx), %eax
	movzbl	4(%rcx), %r10d
	xorl	$115, %r10d
	orl	%eax, %r10d
	je	.LBB8_8
.LBB8_3:
	xorl	%eax, %eax
.LBB8_4:
	.seh_startepilogue
	addq	$72, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB8_8:
	cmpq	$5, %rdx
	sete	%al
	movl	%r8d, %r11d
	xorb	$1, %r11b
	movl	$5, %r10d
	orb	%al, %r11b
	je	.LBB8_10
	jmp	.LBB8_12
	.p2align	4
.LBB8_9:
	incq	%r10
	cmpq	%r10, %rdx
	je	.LBB8_3
.LBB8_10:
	movzbl	(%rcx,%r10), %eax
	cmpl	$9, %eax
	je	.LBB8_9
	cmpl	$32, %eax
	je	.LBB8_9
.LBB8_12:
	cmpq	%rdx, %r10
	jae	.LBB8_3
	cmpb	$61, (%rcx,%r10)
	jne	.LBB8_3
	incq	%r10
	cmpq	%rdx, %r10
	setb	%al
	andb	%r8b, %al
	cmpb	$1, %al
	je	.LBB8_16
	jmp	.LBB8_18
	.p2align	4
.LBB8_15:
	incq	%r10
	xorl	%eax, %eax
	cmpq	%r10, %rdx
	je	.LBB8_4
.LBB8_16:
	movzbl	(%rcx,%r10), %eax
	cmpl	$32, %eax
	je	.LBB8_15
	cmpl	$9, %eax
	je	.LBB8_15
.LBB8_18:
	cmpq	%rdx, %r10
	jae	.LBB8_24
	movq	%r10, %rax
.LBB8_20:
	movzbl	(%rcx,%rax), %r11d
	addb	$-48, %r11b
	cmpb	$10, %r11b
	jae	.LBB8_23
	incq	%rax
	cmpq	%rax, %rdx
	jne	.LBB8_20
	movq	%rdx, %rax
.LBB8_23:
	movq	%rax, %r11
	subq	%r10, %r11
	jne	.LBB8_28
.LBB8_24:
	xorl	%edi, %edi
	jmp	.LBB8_30
.LBB8_28:
	movb	%r8b, 48(%rsp)
	setae	%r8b
	movq	%rdx, 40(%rsp)
	movq	%rax, 32(%rsp)
	cmpq	%rdx, %rax
	setbe	%al
	testb	%al, %r8b
	je	.LBB8_66
	movq	%r9, %rsi
	addq	%rcx, %r10
	leaq	56(%rsp), %rax
	movq	%rcx, %rdi
	movq	%rax, %rcx
	movq	%r10, %rdx
	movq	%r11, %r8
	xorl	%r9d, %r9d
	callq	_RINvCs4A2AHSyUD2M_17parse_number_core11parse_sliceKy7fffffffffffffff_Ky8000000000000000_ECsh1eR4S1pMdQ_9range_ffi
	movq	%rdi, %rcx
	movzbl	64(%rsp), %eax
	movq	56(%rsp), %rdx
	movq	%rdx, %r8
	negq	%r8
	testb	$1, %al
	cmoveq	%rdx, %r8
	cmpb	$2, %al
	movabsq	$9223372036854775807, %r11
	cmovneq	%r8, %r11
	movb	$1, %dil
	movq	32(%rsp), %r10
	movq	%rsi, %r9
	movq	40(%rsp), %rdx
	movzbl	48(%rsp), %r8d
.LBB8_30:
	testb	%r8b, %r8b
	je	.LBB8_35
	cmpq	%rdx, %r10
	jb	.LBB8_33
	jmp	.LBB8_35
.LBB8_32:
	incq	%r10
	xorl	%eax, %eax
	cmpq	%r10, %rdx
	je	.LBB8_4
.LBB8_33:
	movzbl	(%rcx,%r10), %eax
	cmpl	$9, %eax
	je	.LBB8_32
	cmpl	$32, %eax
	je	.LBB8_32
.LBB8_35:
	cmpq	%rdx, %r10
	jae	.LBB8_3
	cmpb	$45, (%rcx,%r10)
	jne	.LBB8_3
	incq	%r10
	testb	%r8b, %r8b
	je	.LBB8_42
	cmpq	%rdx, %r10
	jb	.LBB8_40
	jmp	.LBB8_42
.LBB8_39:
	incq	%r10
	cmpq	%r10, %rdx
	je	.LBB8_52
.LBB8_40:
	movzbl	(%rcx,%r10), %eax
	cmpl	$32, %eax
	je	.LBB8_39
	cmpl	$9, %eax
	je	.LBB8_39
.LBB8_42:
	cmpq	%rdx, %r10
	jae	.LBB8_48
	movq	%r10, %rax
.LBB8_44:
	movzbl	(%rcx,%rax), %r8d
	addb	$-48, %r8b
	cmpb	$10, %r8b
	jae	.LBB8_47
	incq	%rax
	cmpq	%rax, %rdx
	jne	.LBB8_44
	movq	%rdx, %rax
.LBB8_47:
	movq	%rax, %r8
	subq	%r10, %r8
	jne	.LBB8_54
.LBB8_48:
	xorl	%ecx, %ecx
	jmp	.LBB8_56
.LBB8_51:
	leaq	alloc_a28e8c8fd5088943a8b5d44af697ff83(%rip), %rcx
	leaq	alloc_56c01fe01d1a47ca560ad2a33d46aaec(%rip), %r9
	movl	$559, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
.LBB8_52:
	testb	%dil, %dil
	je	.LBB8_3
	jmp	.LBB8_61
.LBB8_54:
	movq	%r11, 48(%rsp)
	movq	%r9, %rsi
	setae	%r9b
	movq	%rdx, 40(%rsp)
	movq	%rax, 32(%rsp)
	cmpq	%rdx, %rax
	setbe	%al
	testb	%al, %r9b
	je	.LBB8_66
	addq	%r10, %rcx
	leaq	56(%rsp), %rax
	movq	%rcx, %rdx
	movq	%rax, %rcx
	xorl	%r9d, %r9d
	callq	_RINvCs4A2AHSyUD2M_17parse_number_core11parse_sliceKy7fffffffffffffff_Ky8000000000000000_ECsh1eR4S1pMdQ_9range_ffi
	movzbl	64(%rsp), %eax
	movq	56(%rsp), %rcx
	movq	%rcx, %rdx
	negq	%rdx
	testb	$1, %al
	cmoveq	%rcx, %rdx
	cmpb	$2, %al
	movabsq	$9223372036854775807, %rax
	cmovneq	%rdx, %rax
	movb	$1, %cl
	movq	32(%rsp), %r10
	movq	%rsi, %r9
	movq	40(%rsp), %rdx
	movq	48(%rsp), %r11
.LBB8_56:
	cmpq	%rdx, %r10
	jne	.LBB8_3
	testb	%dil, %dil
	je	.LBB8_63
	testb	%cl, %cl
	je	.LBB8_61
	movq	%rax, %rdx
	jmp	.LBB8_62
.LBB8_61:
	movq	$-1, %rdx
.LBB8_62:
	movq	$-1, %rax
	jmp	.LBB8_64
.LBB8_63:
	movq	$-1, %r11
	movq	$-1, %rdx
	testb	%cl, %cl
	je	.LBB8_3
.LBB8_64:
	movq	%r11, (%r9)
	movq	%rdx, 8(%r9)
	movq	%rax, 16(%r9)
	movb	$1, %al
	.seh_startepilogue
	addq	$72, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB8_66:
	leaq	alloc_df10a442b0b4a87147a8f65479b3c67a(%rip), %r9
	movq	%r10, %rcx
	movq	32(%rsp), %rdx
	movq	40(%rsp), %r8
	callq	_RNvNtNtCs9l4wcBNbII5_4core5slice5index16slice_index_fail
	ud2
	.seh_endproc

	.def	rustium_http_range_list;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,rustium_http_range_list,unique,9
	.globl	rustium_http_range_list
	.p2align	4
rustium_http_range_list:
.seh_proc rustium_http_range_list
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$144, %rsp
	.seh_stackalloc 144
	.seh_endprologue
	movq	$0, 64(%rsp)
	movq	$8, 72(%rsp)
	movq	$0, 80(%rsp)
	testq	%rdx, %rdx
	je	.LBB9_5
	testq	%rcx, %rcx
	setne	%al
	testq	%rdx, %rdx
	setns	%r9b
	testb	%r9b, %al
	je	.LBB9_34
	xorl	%eax, %eax
	.p2align	4
.LBB9_3:
	cmpb	$61, (%rcx,%rax)
	je	.LBB9_6
	incq	%rax
	cmpq	%rax, %rdx
	jne	.LBB9_3
	jmp	.LBB9_24
.LBB9_5:
	leaq	56(%rsp), %rax
	xorl	%esi, %esi
	xorl	%edx, %edx
	movq	%rdx, (%rax)
	movq	56(%rsp), %r8
	testq	%r8, %r8
	jne	.LBB9_31
	jmp	.LBB9_33
.LBB9_6:
	cmpq	%rdx, %rax
	jae	.LBB9_102
	testq	%rax, %rax
	je	.LBB9_24
	movq	%rcx, %r9
	movq	%rax, %r10
	jmp	.LBB9_10
	.p2align	4
.LBB9_9:
	incq	%r9
	decq	%r10
	je	.LBB9_24
.LBB9_10:
	movzbl	(%r9), %r11d
	cmpl	$9, %r11d
	je	.LBB9_9
	cmpl	$32, %r11d
	je	.LBB9_9
	movq	$-1, %rsi
	jmp	.LBB9_14
	.p2align	4
.LBB9_13:
	leaq	(%r10,%rsi), %rdi
	decq	%rdi
	decq	%rsi
	cmpq	$-1, %rdi
	je	.LBB9_24
.LBB9_14:
	leaq	(%rcx,%rsi), %rdi
	movzbl	(%rax,%rdi), %edi
	cmpl	$32, %edi
	je	.LBB9_13
	cmpl	$9, %edi
	je	.LBB9_13
	addq	%rsi, %r10
	cmpq	$4, %r10
	jne	.LBB9_24
	leal	-65(%r11), %r10d
	cmpb	$26, %r10b
	setb	%r10b
	shlb	$5, %r10b
	orb	%r11b, %r10b
	cmpb	$98, %r10b
	jne	.LBB9_24
	movzbl	1(%r9), %r10d
	leal	-65(%r10), %r11d
	cmpb	$26, %r11b
	setb	%r11b
	shlb	$5, %r11b
	orb	%r10b, %r11b
	cmpb	$121, %r11b
	jne	.LBB9_24
	movzbl	2(%r9), %r10d
	leal	-65(%r10), %r11d
	cmpb	$26, %r11b
	setb	%r11b
	shlb	$5, %r11b
	orb	%r10b, %r11b
	cmpb	$116, %r11b
	jne	.LBB9_24
	movzbl	3(%r9), %r10d
	leal	-65(%r10), %r11d
	cmpb	$26, %r11b
	setb	%r11b
	shlb	$5, %r11b
	orb	%r10b, %r11b
	cmpb	$101, %r11b
	jne	.LBB9_24
	movzbl	4(%r9), %r9d
	leal	-65(%r9), %r10d
	cmpb	$26, %r10b
	setb	%r10b
	shlb	$5, %r10b
	orb	%r9b, %r10b
	cmpb	$115, %r10b
	jne	.LBB9_24
	incq	%rax
	movb	$1, %sil
	cmpq	%rdx, %rax
	jae	.LBB9_25
	leaq	-1(%rcx), %r14
	movl	$8, %ebx
	movq	$0, 48(%rsp)
	movq	%r14, 128(%rsp)
	jmp	.LBB9_37
.LBB9_24:
	xorl	%esi, %esi
.LBB9_25:
	movq	64(%rsp), %rax
	movq	72(%rsp), %rcx
.LBB9_26:
	testq	%rax, %rax
	je	.LBB9_30
	movabsq	$768614336404564651, %rdx
	cmpq	%rdx, %rax
	jae	.LBB9_100
	movabsq	$384307168202282326, %rdx
	cmpq	%rdx, %rax
	jae	.LBB9_101
	shlq	$3, %rax
	leaq	(%rax,%rax,2), %rdx
	movq	$8, 56(%rsp)
	leaq	136(%rsp), %rax
	movq	%rdx, (%rax)
	movq	56(%rsp), %r8
	testq	%r8, %r8
	jne	.LBB9_31
	jmp	.LBB9_33
.LBB9_30:
	leaq	56(%rsp), %rax
	xorl	%edx, %edx
	movq	%rdx, (%rax)
	movq	56(%rsp), %r8
	testq	%r8, %r8
	je	.LBB9_33
.LBB9_31:
	movq	136(%rsp), %rdx
	testq	%rdx, %rdx
	je	.LBB9_33
	callq	_RNvCs6d6XRwTwhVh_7___rustc14___rust_dealloc
.LBB9_33:
	movl	%esi, %eax
	.seh_startepilogue
	addq	$144, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB9_34:
	leaq	alloc_a28e8c8fd5088943a8b5d44af697ff83(%rip), %rcx
	leaq	alloc_56c01fe01d1a47ca560ad2a33d46aaec(%rip), %r9
	movl	$559, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
.LBB9_35:
	movq	%r15, %rbx
.LBB9_36:
	addq	%rdi, %r9
	movq	%r9, %rax
	cmpq	%rdx, %r9
	jae	.LBB9_104
.LBB9_37:
	leaq	1(%rax), %r9
	cmpq	%r9, %rdx
	cmovaq	%rdx, %r9
	xorl	%r11d, %r11d
	movq	%rax, %rdi
	xorl	%r10d, %r10d
	jmp	.LBB9_40
.LBB9_38:
	xorl	%r10d, %r10d
.LBB9_39:
	incq	%rdi
	cmpq	%rdi, %r9
	je	.LBB9_51
.LBB9_40:
	movzbl	(%rcx,%rdi), %ebp
	movzbl	%bpl, %esi
	testb	$1, %r11b
	je	.LBB9_45
	movb	$1, %r11b
	testb	$1, %r10b
	jne	.LBB9_38
	cmpb	$34, %bpl
	je	.LBB9_48
	cmpl	$92, %esi
	jne	.LBB9_38
	movb	$1, %r10b
	movb	$1, %r11b
	jmp	.LBB9_39
.LBB9_45:
	cmpl	$34, %esi
	je	.LBB9_47
	cmpl	$44, %esi
	jne	.LBB9_49
	jmp	.LBB9_52
.LBB9_47:
	movb	$1, %r11b
	jmp	.LBB9_39
.LBB9_48:
	xorl	%r10d, %r10d
.LBB9_49:
	xorl	%r11d, %r11d
	jmp	.LBB9_39
.LBB9_51:
	movq	%r9, %rdi
	xorl	%r9d, %r9d
	jmp	.LBB9_53
.LBB9_52:
	movl	$1, %r9d
.LBB9_53:
	movq	%rdi, %r11
	subq	%rax, %r11
	je	.LBB9_36
	leaq	(%rcx,%rax), %rsi
	leaq	(%r14,%rax), %r10
	notq	%rax
	addq	%rdi, %rax
	jmp	.LBB9_56
.LBB9_55:
	incq	%rsi
	decq	%rax
	incq	%r10
	decq	%r11
	je	.LBB9_36
.LBB9_56:
	movzbl	(%rsi), %ebp
	cmpl	$9, %ebp
	je	.LBB9_55
	cmpl	$32, %ebp
	je	.LBB9_55
	movq	%rbx, %r15
	leaq	(%rcx,%rdi), %rbx
	jmp	.LBB9_60
.LBB9_59:
	decq	%rbx
	decq	%r11
	addq	$-1, %rax
	jae	.LBB9_35
.LBB9_60:
	movzbl	-1(%rbx), %ebp
	cmpl	$32, %ebp
	je	.LBB9_59
	cmpl	$9, %ebp
	je	.LBB9_59
	leaq	1(%rax), %r12
	xorl	%r14d, %r14d
.LBB9_63:
	cmpb	$45, (%rsi,%r14)
	je	.LBB9_65
	incq	%r14
	incq	%r10
	decq	%r11
	jne	.LBB9_63
	jmp	.LBB9_103
.LBB9_65:
	movq	%r9, 120(%rsp)
	movq	%rdi, 112(%rsp)
	movq	%r15, 88(%rsp)
	movq	%rcx, 104(%rsp)
	movq	%rdx, 96(%rsp)
	movq	%r8, 40(%rsp)
	cmpq	%r12, %r14
	jae	.LBB9_102
	movq	%rax, %rdi
	movq	%r14, %rax
	movq	$-1, %r15
	testq	%r14, %r14
	je	.LBB9_78
	xorl	%r8d, %r8d
	movq	%rsi, %rcx
	jmp	.LBB9_69
.LBB9_68:
	incq	%r8
	cmpq	%r8, %rax
	je	.LBB9_78
.LBB9_69:
	movzbl	(%rcx,%r8), %edx
	cmpl	$9, %edx
	je	.LBB9_68
	cmpl	$32, %edx
	je	.LBB9_68
	addq	%r8, %rcx
	movq	%rax, %rdx
	subq	%r8, %rdx
	jmp	.LBB9_73
.LBB9_72:
	decq	%rdx
	decq	%r10
	testq	%rdx, %rdx
	je	.LBB9_77
.LBB9_73:
	movzbl	(%r10), %eax
	cmpl	$32, %eax
	je	.LBB9_72
	cmpl	$9, %eax
	je	.LBB9_72
	callq	_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser10legacy_i64
	testb	$1, %al
	je	.LBB9_107
	movq	%rdx, %r15
.LBB9_77:
	movq	%r14, %rax
.LBB9_78:
	movq	%rdi, %rdx
	subq	%rax, %rdx
	jne	.LBB9_84
.LBB9_79:
	movq	$-1, %rsi
	cmpq	$-1, %r15
	je	.LBB9_107
	movq	$-1, %rdi
	testq	%rsi, %rsi
	jg	.LBB9_82
.LBB9_81:
	testq	%r15, %r15
	js	.LBB9_107
.LBB9_82:
	movq	48(%rsp), %rax
	cmpq	64(%rsp), %rax
	je	.LBB9_97
.LBB9_83:
	leaq	(%rax,%rax,2), %rcx
	movq	88(%rsp), %rbx
	movq	%r15, (%rbx,%rcx,8)
	movq	%rdi, 8(%rbx,%rcx,8)
	movq	%rsi, 16(%rbx,%rcx,8)
	incq	%rax
	movq	%rax, 48(%rsp)
	movq	%rax, 80(%rsp)
	movq	40(%rsp), %r8
	movq	96(%rsp), %rdx
	movq	104(%rsp), %rcx
	movq	128(%rsp), %r14
	movq	112(%rsp), %rdi
	movq	120(%rsp), %r9
	jmp	.LBB9_36
.LBB9_84:
	leaq	(%rsi,%rax), %rcx
	incq	%rcx
	jmp	.LBB9_86
.LBB9_85:
	incq	%rcx
	decq	%rdx
	je	.LBB9_79
.LBB9_86:
	movzbl	(%rcx), %eax
	cmpl	$9, %eax
	je	.LBB9_85
	cmpl	$32, %eax
	je	.LBB9_85
	xorl	%eax, %eax
	jmp	.LBB9_90
.LBB9_89:
	decq	%rax
	movq	%rdx, %r8
	addq	%rax, %r8
	je	.LBB9_79
.LBB9_90:
	movzbl	-1(%rbx,%rax), %r8d
	cmpl	$32, %r8d
	je	.LBB9_89
	cmpl	$9, %r8d
	je	.LBB9_89
	addq	%rax, %rdx
	callq	_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser10legacy_i64
	testb	$1, %al
	je	.LBB9_107
	movq	%rdx, %rdi
	cmpq	$-1, %r15
	je	.LBB9_98
	testq	%r15, %r15
	js	.LBB9_107
	movq	$-1, %rsi
	cmpq	$-1, %rdi
	je	.LBB9_99
	cmpq	%r15, %rdi
	jge	.LBB9_82
	jmp	.LBB9_107
.LBB9_97:
	leaq	64(%rsp), %rcx
	callq	_RNvMs7_NtCs8tsiLsQ9XHg_5alloc7raw_vecINtB5_6RawVecNtCsh1eR4S1pMdQ_9range_ffi11ParsedRangeE8grow_oneBO_
	movq	48(%rsp), %rax
	movq	72(%rsp), %rcx
	movq	%rcx, 88(%rsp)
	jmp	.LBB9_83
.LBB9_98:
	movq	%rdi, %rsi
	movq	$-1, %rdi
	testq	%rsi, %rsi
	jle	.LBB9_81
	jmp	.LBB9_82
.LBB9_99:
	movq	$-1, %rdi
	jmp	.LBB9_82
.LBB9_100:
	leaq	alloc_db07ae5a9ce650d9b7cc970d048e6f0c(%rip), %rcx
	leaq	alloc_ad088eaa3dc0ae68b11fd72bfcf5e34b(%rip), %r9
	movl	$373, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
.LBB9_101:
	leaq	alloc_1be5ea12ba708d9a11b6e93a7d387a75(%rip), %rcx
	leaq	alloc_dade1aed0d0fe800cb3ecdb07302e098(%rip), %r9
	movl	$563, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
.LBB9_102:
	leaq	alloc_64e308ef4babfeb8b6220184de794a17(%rip), %rcx
	leaq	alloc_1d1b1e35bb489427b2bdc9752de92226(%rip), %r9
	movl	$443, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
.LBB9_103:
	xorl	%esi, %esi
	jmp	.LBB9_105
.LBB9_104:
	movb	$1, %sil
.LBB9_105:
	movq	64(%rsp), %rax
	movq	72(%rsp), %rcx
	movq	48(%rsp), %rdx
	testq	%rdx, %rdx
	je	.LBB9_26
	movq	%rcx, (%r8)
	movq	%rdx, 8(%r8)
	movq	%rax, 16(%r8)
	orb	$2, %sil
	jmp	.LBB9_33
.LBB9_107:
	xorl	%esi, %esi
	movq	40(%rsp), %r8
	jmp	.LBB9_105
	.seh_endproc

	.def	rustium_http_range_list_drop;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,rustium_http_range_list_drop,unique,10
	.globl	rustium_http_range_list_drop
	.p2align	4
rustium_http_range_list_drop:
.seh_proc rustium_http_range_list_drop
	subq	$56, %rsp
	.seh_stackalloc 56
	.seh_endprologue
	movq	16(%rcx), %rax
	cmpq	%rax, 8(%rcx)
	ja	.LBB10_1
	movq	(%rcx), %rcx
	testq	%rcx, %rcx
	je	.LBB10_4
	testq	%rax, %rax
	je	.LBB10_6
	movabsq	$768614336404564651, %rdx
	cmpq	%rdx, %rax
	jae	.LBB10_8
	movabsq	$384307168202282326, %rdx
	cmpq	%rdx, %rax
	jae	.LBB10_10
	shlq	$3, %rax
	leaq	(%rax,%rax,2), %rax
	movq	$8, 40(%rsp)
	leaq	48(%rsp), %rdx
	movq	%rax, (%rdx)
	movq	40(%rsp), %r8
	testq	%r8, %r8
	jne	.LBB10_13
	jmp	.LBB10_14
.LBB10_6:
	leaq	40(%rsp), %rdx
	xorl	%eax, %eax
	movq	%rax, (%rdx)
	movq	40(%rsp), %r8
	testq	%r8, %r8
	je	.LBB10_14
.LBB10_13:
	movq	48(%rsp), %rdx
	testq	%rdx, %rdx
	je	.LBB10_14
	.seh_startepilogue
	addq	$56, %rsp
	.seh_endepilogue
	jmp	_RNvCs6d6XRwTwhVh_7___rustc14___rust_dealloc
.LBB10_14:
	.seh_startepilogue
	addq	$56, %rsp
	.seh_endepilogue
	retq
.LBB10_1:
	leaq	alloc_82a99021b1306c9239507412b95c0e74(%rip), %rcx
	leaq	alloc_5b8d19018527d26ed8c47fbaf3eafd4f(%rip), %r9
	movl	$411, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
.LBB10_4:
	leaq	alloc_560a59ed819b9d9a5841f6e731c4c8e5(%rip), %rcx
	leaq	alloc_91244a802f615a731e570cd82aa5f107(%rip), %r9
	movl	$421, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
.LBB10_8:
	leaq	alloc_db07ae5a9ce650d9b7cc970d048e6f0c(%rip), %rcx
	leaq	alloc_ad088eaa3dc0ae68b11fd72bfcf5e34b(%rip), %r9
	movl	$373, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
.LBB10_10:
	leaq	alloc_1be5ea12ba708d9a11b6e93a7d387a75(%rip), %rcx
	leaq	alloc_dade1aed0d0fe800cb3ecdb07302e098(%rip), %r9
	movl	$563, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
	.seh_endproc

	.section	.rdata,"dr",one_only,alloc_9f2c9333733542a0fa241eb525d38504,unique,11
alloc_9f2c9333733542a0fa241eb525d38504:
	.asciz	"D:\\Rustium\\net\\http\\http_range_parser.rs"

	.section	.rdata,"dr",one_only,alloc_c712be591025e6a1f0f9ed6c6808275b,unique,12
alloc_c712be591025e6a1f0f9ed6c6808275b:
	.asciz	"D:\\Rustium\\third_party\\rust\\chromium_crates_io\\vendor\\memchr-v2\\src\\arch\\generic\\memchr.rs"

	.section	.rdata,"dr",one_only,alloc_a59d8fe4279b26f926811f91f116a398,unique,13
	.p2align	3, 0x0
alloc_a59d8fe4279b26f926811f91f116a398:
	.quad	alloc_c712be591025e6a1f0f9ed6c6808275b
	.asciz	"Z\000\000\000\000\000\000\000s\004\000\000\t\000\000"

	.section	.rdata,"dr",one_only,alloc_87e6578268e354c4f2747b30d32a9b4e,unique,14
alloc_87e6578268e354c4f2747b30d32a9b4e:
	.asciz	"library\\core\\src\\slice\\iter.rs"

	.section	.rdata,"dr",one_only,alloc_1d1b1e35bb489427b2bdc9752de92226,unique,15
	.p2align	3, 0x0
alloc_1d1b1e35bb489427b2bdc9752de92226:
	.quad	alloc_87e6578268e354c4f2747b30d32a9b4e
	.asciz	"\036\000\000\000\000\000\000\000\214\000\000\000\001\000\000"

	.section	.rdata,"dr",one_only,alloc_1bb48cd636a7e77d2a1a241c967005fc,unique,16
	.p2align	3, 0x0
alloc_1bb48cd636a7e77d2a1a241c967005fc:
	.quad	alloc_9f2c9333733542a0fa241eb525d38504
	.asciz	"(\000\000\000\000\000\000\000\335\000\000\000\025\000\000"

	.section	.rdata,"dr",one_only,alloc_cd7dc146611f1efd96d87a1399113f8c,unique,17
	.p2align	3, 0x0
alloc_cd7dc146611f1efd96d87a1399113f8c:
	.quad	alloc_9f2c9333733542a0fa241eb525d38504
	.asciz	"(\000\000\000\000\000\000\000\336\000\000\0002\000\000"

	.section	.rdata,"dr",one_only,alloc_6ca9fc8d99acf98ecf00d162e0ad6d5e,unique,18
	.p2align	3, 0x0
alloc_6ca9fc8d99acf98ecf00d162e0ad6d5e:
	.quad	alloc_9f2c9333733542a0fa241eb525d38504
	.asciz	"(\000\000\000\000\000\000\000\335\000\000\0002\000\000"

	.section	.rdata,"dr",one_only,alloc_16cbcd9a81ccfa6f0d62eca93b6e0394,unique,19
	.p2align	3, 0x0
alloc_16cbcd9a81ccfa6f0d62eca93b6e0394:
	.quad	alloc_9f2c9333733542a0fa241eb525d38504
	.asciz	"(\000\000\000\000\000\000\000\332\000\000\000\030\000\000"

	.section	.rdata,"dr",one_only,alloc_5fd5ad9d8a4f43eaaa74e75f1fc82bac,unique,20
	.p2align	3, 0x0
alloc_5fd5ad9d8a4f43eaaa74e75f1fc82bac:
	.quad	alloc_9f2c9333733542a0fa241eb525d38504
	.asciz	"(\000\000\000\000\000\000\000\331\000\000\000.\000\000"

	.section	.rdata,"dr",one_only,alloc_f9be6c591f7e00dc1cf1dc33e68f267a,unique,21
	.p2align	3, 0x0
alloc_f9be6c591f7e00dc1cf1dc33e68f267a:
	.quad	alloc_9f2c9333733542a0fa241eb525d38504
	.asciz	"(\000\000\000\000\000\000\000\350\000\000\000D\000\000"

	.section	.rdata,"dr",one_only,alloc_0a48ea62e5579eec5969b23ab3020878,unique,22
	.p2align	3, 0x0
alloc_0a48ea62e5579eec5969b23ab3020878:
	.quad	alloc_9f2c9333733542a0fa241eb525d38504
	.asciz	"(\000\000\000\000\000\000\000\356\000\000\000F\000\000"

	.section	.rdata,"dr",one_only,alloc_3c266a9d2054e14c937438e9636b5cb5,unique,23
alloc_3c266a9d2054e14c937438e9636b5cb5:
	.asciz	"D:\\Rustium\\net\\http\\http_range_ffi.rs"

	.section	.rdata,"dr",one_only,alloc_56c01fe01d1a47ca560ad2a33d46aaec,unique,24
	.p2align	3, 0x0
alloc_56c01fe01d1a47ca560ad2a33d46aaec:
	.quad	alloc_3c266a9d2054e14c937438e9636b5cb5
	.asciz	"%\000\000\000\000\000\000\0008\000\000\000\022\000\000"

	.section	.rdata,"dr",one_only,alloc_6b2d6f9c10483c97dd45df2e37fdbaf3,unique,25
alloc_6b2d6f9c10483c97dd45df2e37fdbaf3:
	.asciz	"library\\alloc\\src\\alloc.rs"

	.section	.rdata,"dr",one_only,alloc_1b98de0e82d923a9daff35d520cf360d,unique,26
	.p2align	3, 0x0
alloc_1b98de0e82d923a9daff35d520cf360d:
	.quad	alloc_6b2d6f9c10483c97dd45df2e37fdbaf3
	.asciz	"\032\000\000\000\000\000\000\000~\001\000\000\021\000\000"

	.section	.rdata,"dr",one_only,alloc_24f4768e38f126368567621cf7f11fcd,unique,27
alloc_24f4768e38f126368567621cf7f11fcd:
	.asciz	"library\\alloc\\src\\raw_vec\\mod.rs"

	.section	.rdata,"dr",one_only,alloc_ad088eaa3dc0ae68b11fd72bfcf5e34b,unique,28
	.p2align	3, 0x0
alloc_ad088eaa3dc0ae68b11fd72bfcf5e34b:
	.quad	alloc_24f4768e38f126368567621cf7f11fcd
	.asciz	" \000\000\000\000\000\000\000\230\002\000\0005\000\000"

	.section	.rdata,"dr",one_only,alloc_dade1aed0d0fe800cb3ecdb07302e098,unique,29
	.p2align	3, 0x0
alloc_dade1aed0d0fe800cb3ecdb07302e098:
	.quad	alloc_24f4768e38f126368567621cf7f11fcd
	.asciz	" \000\000\000\000\000\000\000\231\002\000\000\036\000\000"

	.section	.rdata,"dr",one_only,alloc_5a885d3db7500f26d581e948d37c49fe,unique,30
	.p2align	3, 0x0
alloc_5a885d3db7500f26d581e948d37c49fe:
	.quad	alloc_24f4768e38f126368567621cf7f11fcd
	.asciz	" \000\000\000\000\000\000\000C\002\000\000\021\000\000"

	.section	.rdata,"dr",one_only,alloc_df10a442b0b4a87147a8f65479b3c67a,unique,31
	.p2align	3, 0x0
alloc_df10a442b0b4a87147a8f65479b3c67a:
	.quad	alloc_9f2c9333733542a0fa241eb525d38504
	.asciz	"(\000\000\000\000\000\000\000\251\000\000\000\036\000\000"

	.section	.rdata,"dr",one_only,alloc_1be5ea12ba708d9a11b6e93a7d387a75,unique,32
alloc_1be5ea12ba708d9a11b6e93a7d387a75:
	.ascii	"unsafe precondition(s) violated: Layout::from_size_align_unchecked requires that align is a power of 2 and the rounded-up allocation size does not exceed isize::MAX\n\nThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety."

	.section	.rdata,"dr",one_only,alloc_560a59ed819b9d9a5841f6e731c4c8e5,unique,33
alloc_560a59ed819b9d9a5841f6e731c4c8e5:
	.ascii	"unsafe precondition(s) violated: NonNull::new_unchecked requires that the pointer is non-null\n\nThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety."

	.section	.rdata,"dr",one_only,alloc_db07ae5a9ce650d9b7cc970d048e6f0c,unique,34
alloc_db07ae5a9ce650d9b7cc970d048e6f0c:
	.ascii	"unsafe precondition(s) violated: usize::unchecked_mul cannot overflow\n\nThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety."

	.section	.rdata,"dr",one_only,alloc_82a99021b1306c9239507412b95c0e74,unique,35
alloc_82a99021b1306c9239507412b95c0e74:
	.ascii	"unsafe precondition(s) violated: Vec::from_raw_parts_in requires that length <= capacity\n\nThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety."

	.section	.rdata,"dr",one_only,alloc_64e308ef4babfeb8b6220184de794a17,unique,36
alloc_64e308ef4babfeb8b6220184de794a17:
	.ascii	"unsafe precondition(s) violated: hint::assert_unchecked must never be called when the condition is false\n\nThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety."

	.section	.rdata,"dr",one_only,alloc_75fb06c2453febd814e73f5f2e72ae38,unique,37
alloc_75fb06c2453febd814e73f5f2e72ae38:
	.ascii	"unsafe precondition(s) violated: hint::unreachable_unchecked must never be reached\n\nThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety."

	.section	.rdata,"dr",one_only,alloc_a28e8c8fd5088943a8b5d44af697ff83,unique,38
alloc_a28e8c8fd5088943a8b5d44af697ff83:
	.ascii	"unsafe precondition(s) violated: slice::from_raw_parts requires the pointer to be aligned and non-null, and the total size of the slice not to exceed `isize::MAX`\n\nThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety."

	.section	.rdata,"dr",one_only,alloc_03e70bdcab636393a4206dfdf6ac4e05,unique,39
alloc_03e70bdcab636393a4206dfdf6ac4e05:
	.asciz	"D:\\Rustium\\third_party\\rust\\chromium_crates_io\\vendor\\memchr-v2\\src\\ext.rs"

	.section	.rdata,"dr",one_only,alloc_6d855724149bc5132e1bc43bfd525250,unique,40
	.p2align	3, 0x0
alloc_6d855724149bc5132e1bc43bfd525250:
	.quad	alloc_03e70bdcab636393a4206dfdf6ac4e05
	.asciz	"J\000\000\000\000\000\000\000\027\000\000\0003\000\000"

	.section	.rdata,"dr",one_only,alloc_2728436149d2d0d1e5775c8099d441a1,unique,41
alloc_2728436149d2d0d1e5775c8099d441a1:
	.asciz	"library\\alloc\\src\\vec\\mod.rs"

	.section	.rdata,"dr",one_only,alloc_5b8d19018527d26ed8c47fbaf3eafd4f,unique,42
	.p2align	3, 0x0
alloc_5b8d19018527d26ed8c47fbaf3eafd4f:
	.quad	alloc_2728436149d2d0d1e5775c8099d441a1
	.asciz	"\034\000\000\000\000\000\000\000m\004\000\000\t\000\000"

	.section	.rdata,"dr",one_only,alloc_91244a802f615a731e570cd82aa5f107,unique,43
	.p2align	3, 0x0
alloc_91244a802f615a731e570cd82aa5f107:
	.quad	alloc_24f4768e38f126368567621cf7f11fcd
	.asciz	" \000\000\000\000\000\000\000k\002\000\000\036\000\000"

	.section	.gfids$y,"dr"
	.symidx	__CxxFrameHandler3
	.section	.giats$y,"dr"
	.section	.gljmp$y,"dr"
