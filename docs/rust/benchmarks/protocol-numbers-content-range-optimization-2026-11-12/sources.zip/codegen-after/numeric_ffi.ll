; ModuleID = 'numeric_ffi.db33e3d5a3958eec-cgu.0'
source_filename = "numeric_ffi.db33e3d5a3958eec-cgu.0"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc"

@alloc_83bc31b2c75b61bc5cd021623002fec0 = private unnamed_addr constant [47 x i8] c"D:\\Rustium\\net\\base\\parse_number_native_ffi.rs\00", align 1, !guid !0
@alloc_14547586b6d8a2ddcb70cace56ee43cc = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_83bc31b2c75b61bc5cd021623002fec0, [16 x i8] c".\00\00\00\00\00\00\00#\00\00\00\16\00\00\00" }>, align 8, !guid !1
@alloc_ce8e0a0d52777a5d2d5dc56ded7b0c08 = private unnamed_addr constant [33 x i8] c"library\\core\\src\\ptr\\non_null.rs\00", align 1, !guid !2
@alloc_18226a1c5efd974bf041c2c59bdf25ca = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_ce8e0a0d52777a5d2d5dc56ded7b0c08, [16 x i8] c" \00\00\00\00\00\00\00\80\03\00\00 \00\00\00" }>, align 8, !guid !3
@alloc_87e6578268e354c4f2747b30d32a9b4e = private unnamed_addr constant [31 x i8] c"library\\core\\src\\slice\\iter.rs\00", align 1, !guid !4
@alloc_1d1b1e35bb489427b2bdc9752de92226 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_87e6578268e354c4f2747b30d32a9b4e, [16 x i8] c"\1E\00\00\00\00\00\00\00\8C\00\00\00\01\00\00\00" }>, align 8, !guid !5
@alloc_de4e626d456b04760e72bc785ed7e52a = private unnamed_addr constant [201 x i8] c"unsafe precondition(s) violated: ptr::offset_from_unsigned requires `self >= origin`\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !6
@alloc_a28e8c8fd5088943a8b5d44af697ff83 = private unnamed_addr constant [279 x i8] c"unsafe precondition(s) violated: slice::from_raw_parts requires the pointer to be aligned and non-null, and the total size of the slice not to exceed `isize::MAX`\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !7

; <parse_number_core::SliceBytes as parse_number_core::NumberBytes>::remaining_digits
; Function Attrs: inlinehint nounwind uwtable
define internal fastcc noundef zeroext i1 @_RNvXs1_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtB5_11NumberBytes16remaining_digits(ptr noundef nonnull %0, ptr noundef %1) unnamed_addr #0 personality ptr @__CxxFrameHandler3 !guid !12 {
start:
  call void @llvm.assume(i1 true) [ "nonnull"(ptr %1) ]
  %_3.not.i = icmp ult ptr %1, %0
  br i1 %_3.not.i, label %bb2.i, label %_RNvNvMNtNtCs9l4wcBNbII5_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_check.exit, !prof !13

bb2.i:                                            ; preds = %start
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_de4e626d456b04760e72bc785ed7e52a, ptr noundef nonnull inttoptr (i64 403 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_18226a1c5efd974bf041c2c59bdf25ca) #5
  unreachable

_RNvNvMNtNtCs9l4wcBNbII5_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_check.exit: ; preds = %start
  %2 = ptrtoint ptr %1 to i64
  %3 = ptrtoint ptr %0 to i64
  %4 = sub nuw i64 %2, %3
  %_7.not.i = icmp slt i64 %4, 0
  br i1 %_7.not.i, label %bb5.i, label %_RNvNvNtNtCs9l4wcBNbII5_4core5slice3raw14from_raw_parts18precondition_check.exit, !prof !13

bb5.i:                                            ; preds = %_RNvNvMNtNtCs9l4wcBNbII5_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_check.exit
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_a28e8c8fd5088943a8b5d44af697ff83, ptr noundef nonnull inttoptr (i64 559 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_1d1b1e35bb489427b2bdc9752de92226) #5, !noalias !14
  unreachable

_RNvNvNtNtCs9l4wcBNbII5_4core5slice3raw14from_raw_parts18precondition_check.exit: ; preds = %_RNvNvMNtNtCs9l4wcBNbII5_4core3ptr9const_ptrPp20offset_from_unsigned18precondition_check.exit
  %_61.i = and i64 %4, 9223372036854775792
  %data.i.i = getelementptr inbounds nuw i8, ptr %0, i64 %_61.i
  %len.i.i = and i64 %4, 15
  %new_len2.i = and i64 %4, 9223372036854775792
  %_19 = getelementptr inbounds nuw i8, ptr %0, i64 %new_len2.i
  %_2625 = icmp samesign eq i64 %new_len2.i, 0
  br i1 %_2625, label %bb9, label %bb10

bb2:                                              ; preds = %bb10
  %_32 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.026, i64 16
  %_26 = icmp eq ptr %_32, %_19
  br i1 %_26, label %bb9, label %bb10

bb10:                                             ; preds = %_RNvNvNtNtCs9l4wcBNbII5_4core5slice3raw14from_raw_parts18precondition_check.exit, %bb2
  %iter.sroa.0.026 = phi ptr [ %_32, %bb2 ], [ %0, %_RNvNvNtNtCs9l4wcBNbII5_4core5slice3raw14from_raw_parts18precondition_check.exit ]
  %5 = load <16 x i8>, ptr %iter.sroa.0.026, align 1
  %6 = add <16 x i8> %5, splat (i8 -58)
  %7 = icmp ult <16 x i8> %6, splat (i8 -10)
  %8 = bitcast <16 x i1> %7 to i16
  %.not = icmp eq i16 %8, 0
  br i1 %.not, label %bb2, label %bb7

bb9:                                              ; preds = %bb2, %_RNvNvNtNtCs9l4wcBNbII5_4core5slice3raw14from_raw_parts18precondition_check.exit
  %_46 = getelementptr inbounds nuw i8, ptr %data.i.i, i64 %len.i.i
  %_12.i27 = icmp samesign eq i64 %len.i.i, 0
  br i1 %_12.i27, label %bb7, label %bb13.i

bb13.i:                                           ; preds = %bb13.i, %bb9
  %_221.i28 = phi ptr [ %_22.i, %bb13.i ], [ %data.i.i, %bb9 ]
  %ptr.val.i = load i8, ptr %_221.i28, align 1, !noalias !17, !noundef !20
  %9 = add i8 %ptr.val.i, -48
  %_0.sroa.0.0.i.i.i = icmp ult i8 %9, 10
  %_0.sroa.0.0.i.i.i.not = xor i1 %_0.sroa.0.0.i.i.i, true
  %_22.i = getelementptr inbounds nuw i8, ptr %_221.i28, i64 1
  %_12.i = icmp eq ptr %_22.i, %_46
  %or.cond = select i1 %_0.sroa.0.0.i.i.i.not, i1 true, i1 %_12.i
  br i1 %or.cond, label %bb7, label %bb13.i

bb7:                                              ; preds = %bb10, %bb13.i, %bb9
  %_0.sroa.0.0 = phi i1 [ %_0.sroa.0.0.i.i.i, %bb13.i ], [ true, %bb9 ], [ false, %bb10 ]
  ret i1 %_0.sroa.0.0
}

; Function Attrs: nounwind uwtable
define noundef zeroext i1 @rustium_parse_number_native_i32(ptr noundef %input, i64 noundef %len, i32 noundef %format, ptr nofree noundef writeonly captures(none) %output, ptr nofree noundef writeonly captures(address_is_null) %error) unnamed_addr #1 personality ptr @__CxxFrameHandler3 !guid !21 {
start:
  %0 = icmp eq i64 %len, 0
  br i1 %0, label %bb2.i.thread, label %bb14.i

bb2.i.thread:                                     ; preds = %start
  %_11.i6.not = icmp eq ptr %error, null
  br i1 %_11.i6.not, label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchlNvCs4A2AHSyUD2M_17parse_number_core9parse_i32EB2_.exit, label %bb11.i

bb14.i:                                           ; preds = %start
  %_12.not.i = icmp eq ptr %input, null
  %_7.not.i = icmp slt i64 %len, 0
  %or.cond = or i1 %_12.not.i, %_7.not.i
  br i1 %or.cond, label %bb5.i3, label %bb8.i.i.i, !prof !22

bb5.i3:                                           ; preds = %bb14.i
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_a28e8c8fd5088943a8b5d44af697ff83, ptr noundef nonnull inttoptr (i64 559 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_14547586b6d8a2ddcb70cace56ee43cc) #5
  unreachable

bb8.i.i.i:                                        ; preds = %bb14.i
  %_11.i.not = icmp eq ptr %error, null
  %_14.i.i.i = getelementptr inbounds nuw i8, ptr %input, i64 %len
  %1 = load i8, ptr %input, align 1, !alias.scope !23, !noundef !20
  switch i8 %1, label %bb17.i.i.i.i [
    i8 45, label %bb2.i.i.i
    i8 48, label %bb2.i.i.i
  ]

bb17.i.i.i.i:                                     ; preds = %bb8.i.i.i
  %digit.i.i.i.i = add i8 %1, -48
  %_11.i.i.i.i = icmp ugt i8 %digit.i.i.i.i, 9
  br i1 %_11.i.i.i.i, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread, label %bb11.i.i.i.i

bb11.i.i.i.i:                                     ; preds = %bb17.i.i.i.i
  %_15.i.i.i.i = zext nneg i8 %digit.i.i.i.i to i64
  %_5.i.not12.i.i.i.i.i = icmp samesign eq i64 %len, 1
  br i1 %_5.i.not12.i.i.i.i.i, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit, label %bb4.i.i.i.preheader.i.i

bb4.i.i.i.preheader.i.i:                          ; preds = %bb11.i.i.i.i
  %_11.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %input, i64 1
  br label %bb4.i.i.i.i.i

bb4.i.i.i.i.i:                                    ; preds = %bb20.i.i.i.i.i, %bb4.i.i.i.preheader.i.i
  %value.sroa.0.014.i.i.i.i.i = phi i64 [ %2, %bb20.i.i.i.i.i ], [ %_15.i.i.i.i, %bb4.i.i.i.preheader.i.i ]
  %bytes.sroa.0.013.i.i.i.i.i = phi ptr [ %_11.i.i.i.i.i.i, %bb20.i.i.i.i.i ], [ %_11.i.i.i.i.i, %bb4.i.i.i.preheader.i.i ]
  %_11.i.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %bytes.sroa.0.013.i.i.i.i.i, i64 1
  %_13.i.i.i.i.i.i = load i8, ptr %bytes.sroa.0.013.i.i.i.i.i, align 1, !alias.scope !23, !noalias !30, !noundef !20
  %_10.i.i.i.i.i = add i8 %_13.i.i.i.i.i.i, -48
  %digit.i.i.i.i.i = zext nneg i8 %_10.i.i.i.i.i to i64
  %_11.i4.i.i.i.i = icmp ugt i8 %_10.i.i.i.i.i, 9
  br i1 %_11.i4.i.i.i.i, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread, label %bb7.i.i.i.i.i

bb7.i.i.i.i.i:                                    ; preds = %bb4.i.i.i.i.i
  %_12.i.i.i.i.i = icmp ugt i64 %value.sroa.0.014.i.i.i.i.i, 214748364
  br i1 %_12.i.i.i.i.i, label %bb12.i.i.i.i.i, label %bb9.i.i.i.i.i

bb9.i.i.i.i.i:                                    ; preds = %bb7.i.i.i.i.i
  %_15.i.i.i.i.i = icmp eq i64 %value.sroa.0.014.i.i.i.i.i, 214748364
  %_17.i.i.i.i.i = icmp samesign ugt i8 %_10.i.i.i.i.i, 7
  %or.cond.i.i.i.i.i = and i1 %_15.i.i.i.i.i, %_17.i.i.i.i.i
  br i1 %or.cond.i.i.i.i.i, label %bb12.i.i.i.i.i, label %bb20.i.i.i.i.i

bb20.i.i.i.i.i:                                   ; preds = %bb9.i.i.i.i.i
  %_21.i.i.i.i.i = mul nuw nsw i64 %value.sroa.0.014.i.i.i.i.i, 10
  %2 = add nuw nsw i64 %_21.i.i.i.i.i, %digit.i.i.i.i.i
  %_5.i.not.i.i.i.i.i = icmp eq ptr %_11.i.i.i.i.i.i, %_14.i.i.i
  br i1 %_5.i.not.i.i.i.i.i, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit, label %bb4.i.i.i.i.i

bb12.i.i.i.i.i:                                   ; preds = %bb9.i.i.i.i.i, %bb7.i.i.i.i.i
  br i1 %_11.i.not, label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchlNvCs4A2AHSyUD2M_17parse_number_core9parse_i32EB2_.exit, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread47

bb2.i.i.i:                                        ; preds = %bb8.i.i.i, %bb8.i.i.i
  %_11.i.i2.i.i.i = getelementptr inbounds nuw i8, ptr %input, i64 1
  %3 = and i32 %format, -2
  %strict.sroa.0.0.i.i.i.i = icmp eq i32 %3, 2
  %negative.i.i.i.i = icmp eq i8 %1, 45
  %4 = add nsw i8 %1, -48
  %or.cond.i4.i.i.i = icmp ult i8 %4, 10
  br i1 %or.cond.i4.i.i.i, label %bb15.i.i.i.i, label %bb10.i.i.i.i

bb10.i.i.i.i:                                     ; preds = %bb2.i.i.i
  br i1 %negative.i.i.i.i, label %switch.early.test.i.i.i.i, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread

switch.early.test.i.i.i.i:                        ; preds = %bb10.i.i.i.i
  switch i32 %format, label %bb12.i.i.i.i [
    i32 2, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread
    i32 0, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread
  ]

bb12.i.i.i.i:                                     ; preds = %switch.early.test.i.i.i.i
  %_5.i23.not.i.i.i.i = icmp samesign eq i64 %len, 1
  br i1 %_5.i23.not.i.i.i.i, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread, label %bb52.i.i.i.i

bb52.i.i.i.i:                                     ; preds = %bb12.i.i.i.i
  %_11.i26.i.i.i.i = getelementptr inbounds nuw i8, ptr %input, i64 2
  %_13.i27.i.i.i.i = load i8, ptr %_11.i.i2.i.i.i, align 1, !alias.scope !23, !noalias !37, !noundef !20
  br label %bb15.i.i.i.i

bb15.i.i.i.i:                                     ; preds = %bb52.i.i.i.i, %bb2.i.i.i
  %bytes.sroa.0.0.i.i.i.i = phi ptr [ %_11.i.i2.i.i.i, %bb2.i.i.i ], [ %_11.i26.i.i.i.i, %bb52.i.i.i.i ]
  %first.sroa.0.0.i.i.i.i = phi i8 [ 48, %bb2.i.i.i ], [ %_13.i27.i.i.i.i, %bb52.i.i.i.i ]
  %5 = icmp eq i8 %first.sroa.0.0.i.i.i.i, 48
  %or.cond4.i.i.i.i = and i1 %strict.sroa.0.0.i.i.i.i, %5
  br i1 %or.cond4.i.i.i.i, label %bb17.i26.i.i.i, label %bb25.i.i.i.i

bb25.i.i.i.i:                                     ; preds = %bb15.i.i.i.i
  br i1 %5, label %bb28.i.i.i.i.preheader, label %bb34.i.i.i.i

bb28.i.i.i.i.preheader:                           ; preds = %bb25.i.i.i.i
  %_5.i39.not.i.i.i.i81 = icmp eq ptr %bytes.sroa.0.0.i.i.i.i, %_14.i.i.i
  br i1 %_5.i39.not.i.i.i.i81, label %bb6.i, label %bb30.i.i.i.i

bb17.i26.i.i.i:                                   ; preds = %bb15.i.i.i.i
  %_5.i31.not.i.i.i.i = icmp ne ptr %bytes.sroa.0.0.i.i.i.i, %_14.i.i.i
  %or.cond98.not.i.i.i.i = select i1 %negative.i.i.i.i, i1 true, i1 %_5.i31.not.i.i.i.i
  br i1 %or.cond98.not.i.i.i.i, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread, label %bb6.i

bb28.i.i.i.i:                                     ; preds = %bb30.i.i.i.i
  %_5.i39.not.i.i.i.i = icmp eq ptr %_11.i42.i.i.i.i, %_14.i.i.i
  br i1 %_5.i39.not.i.i.i.i, label %bb6.i, label %bb30.i.i.i.i

bb30.i.i.i.i:                                     ; preds = %bb28.i.i.i.i.preheader, %bb28.i.i.i.i
  %bytes.sroa.0.1.i.i.i.i82 = phi ptr [ %_11.i42.i.i.i.i, %bb28.i.i.i.i ], [ %bytes.sroa.0.0.i.i.i.i, %bb28.i.i.i.i.preheader ]
  %_11.i42.i.i.i.i = getelementptr inbounds nuw i8, ptr %bytes.sroa.0.1.i.i.i.i82, i64 1
  %_13.i43.i.i.i.i = load i8, ptr %bytes.sroa.0.1.i.i.i.i82, align 1, !alias.scope !23, !noalias !42, !noundef !20
  %6 = icmp eq i8 %_13.i43.i.i.i.i, 48
  br i1 %6, label %bb28.i.i.i.i, label %bb34.i.i.i.i

bb34.i.i.i.i:                                     ; preds = %bb30.i.i.i.i, %bb25.i.i.i.i
  %bytes.sroa.0.2.i.i.i.i = phi ptr [ %bytes.sroa.0.0.i.i.i.i, %bb25.i.i.i.i ], [ %_11.i42.i.i.i.i, %bb30.i.i.i.i ]
  %first.sroa.0.1.i.i.i.i = phi i8 [ %first.sroa.0.0.i.i.i.i, %bb25.i.i.i.i ], [ %_13.i43.i.i.i.i, %bb30.i.i.i.i ]
  %_28.i.i.i.i = add i8 %first.sroa.0.1.i.i.i.i, -48
  %digit.i5.i.i.i = zext i8 %_28.i.i.i.i to i64
  %_29.i.i.i.i = icmp ugt i8 %_28.i.i.i.i, 9
  br i1 %_29.i.i.i.i, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread, label %bb36.i.i.i.i

bb36.i.i.i.i:                                     ; preds = %bb34.i.i.i.i
  %_5.i.not12.i46.i.i.i.i = icmp eq ptr %bytes.sroa.0.2.i.i.i.i, %_14.i.i.i
  br i1 %negative.i.i.i.i, label %bb37.i.i.i.i, label %bb38.i.i.i.i

bb38.i.i.i.i:                                     ; preds = %bb36.i.i.i.i
  br i1 %_5.i.not12.i46.i.i.i.i, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit, label %bb4.i.i6.i.i.i

bb4.i.i6.i.i.i:                                   ; preds = %bb38.i.i.i.i, %bb20.i.i19.i.i.i
  %value.sroa.0.014.i.i7.i.i.i = phi i64 [ %7, %bb20.i.i19.i.i.i ], [ %digit.i5.i.i.i, %bb38.i.i.i.i ]
  %bytes.sroa.0.013.i.i8.i.i.i = phi ptr [ %_11.i.i.i9.i.i.i, %bb20.i.i19.i.i.i ], [ %bytes.sroa.0.2.i.i.i.i, %bb38.i.i.i.i ]
  %_11.i.i.i9.i.i.i = getelementptr inbounds nuw i8, ptr %bytes.sroa.0.013.i.i8.i.i.i, i64 1
  %_13.i.i.i10.i.i.i = load i8, ptr %bytes.sroa.0.013.i.i8.i.i.i, align 1, !alias.scope !23, !noalias !45, !noundef !20
  %_10.i.i11.i.i.i = add i8 %_13.i.i.i10.i.i.i, -48
  %digit.i.i12.i.i.i = zext nneg i8 %_10.i.i11.i.i.i to i64
  %_11.i45.i.i.i.i = icmp ugt i8 %_10.i.i11.i.i.i, 9
  br i1 %_11.i45.i.i.i.i, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread, label %bb7.i.i13.i.i.i

bb7.i.i13.i.i.i:                                  ; preds = %bb4.i.i6.i.i.i
  %_12.i.i14.i.i.i = icmp ugt i64 %value.sroa.0.014.i.i7.i.i.i, 214748364
  br i1 %_12.i.i14.i.i.i, label %bb12.i.i22.i.i.i, label %bb9.i.i15.i.i.i

bb9.i.i15.i.i.i:                                  ; preds = %bb7.i.i13.i.i.i
  %_15.i.i16.i.i.i = icmp eq i64 %value.sroa.0.014.i.i7.i.i.i, 214748364
  %_17.i.i17.i.i.i = icmp samesign ugt i8 %_10.i.i11.i.i.i, 7
  %or.cond.i.i18.i.i.i = and i1 %_15.i.i16.i.i.i, %_17.i.i17.i.i.i
  br i1 %or.cond.i.i18.i.i.i, label %bb12.i.i22.i.i.i, label %bb20.i.i19.i.i.i

bb20.i.i19.i.i.i:                                 ; preds = %bb9.i.i15.i.i.i
  %_21.i.i20.i.i.i = mul nuw nsw i64 %value.sroa.0.014.i.i7.i.i.i, 10
  %7 = add nuw nsw i64 %_21.i.i20.i.i.i, %digit.i.i12.i.i.i
  %_5.i.not.i.i21.i.i.i = icmp eq ptr %_11.i.i.i9.i.i.i, %_14.i.i.i
  br i1 %_5.i.not.i.i21.i.i.i, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit, label %bb4.i.i6.i.i.i

bb12.i.i22.i.i.i:                                 ; preds = %bb9.i.i15.i.i.i, %bb7.i.i13.i.i.i
  br i1 %_11.i.not, label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchlNvCs4A2AHSyUD2M_17parse_number_core9parse_i32EB2_.exit, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread47

bb37.i.i.i.i:                                     ; preds = %bb36.i.i.i.i
  br i1 %_5.i.not12.i46.i.i.i.i, label %bb5.thread57.i.i, label %bb4.i47.i.i.i.i

bb4.i47.i.i.i.i:                                  ; preds = %bb37.i.i.i.i, %bb20.i61.i.i.i.i
  %value.sroa.0.014.i48.i.i.i.i = phi i64 [ %8, %bb20.i61.i.i.i.i ], [ %digit.i5.i.i.i, %bb37.i.i.i.i ]
  %bytes.sroa.0.013.i49.i.i.i.i = phi ptr [ %_11.i.i50.i.i.i.i, %bb20.i61.i.i.i.i ], [ %bytes.sroa.0.2.i.i.i.i, %bb37.i.i.i.i ]
  %_11.i.i50.i.i.i.i = getelementptr inbounds nuw i8, ptr %bytes.sroa.0.013.i49.i.i.i.i, i64 1
  %_13.i.i51.i.i.i.i = load i8, ptr %bytes.sroa.0.013.i49.i.i.i.i, align 1, !alias.scope !23, !noalias !50, !noundef !20
  %_10.i52.i.i.i.i = add i8 %_13.i.i51.i.i.i.i, -48
  %digit.i53.i.i.i.i = zext nneg i8 %_10.i52.i.i.i.i to i64
  %_11.i54.i.i.i.i = icmp ugt i8 %_10.i52.i.i.i.i, 9
  br i1 %_11.i54.i.i.i.i, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread, label %bb7.i55.i.i.i.i

bb7.i55.i.i.i.i:                                  ; preds = %bb4.i47.i.i.i.i
  %_12.i56.i.i.i.i = icmp ugt i64 %value.sroa.0.014.i48.i.i.i.i, 214748364
  br i1 %_12.i56.i.i.i.i, label %bb12.i67.i.i.i.i, label %bb9.i57.i.i.i.i

bb9.i57.i.i.i.i:                                  ; preds = %bb7.i55.i.i.i.i
  %_15.i58.i.i.i.i = icmp eq i64 %value.sroa.0.014.i48.i.i.i.i, 214748364
  %_17.i59.i.i.i.i = icmp eq i8 %_10.i52.i.i.i.i, 9
  %or.cond.i60.i.i.i.i = and i1 %_15.i58.i.i.i.i, %_17.i59.i.i.i.i
  br i1 %or.cond.i60.i.i.i.i, label %bb12.i67.i.i.i.i, label %bb20.i61.i.i.i.i

bb20.i61.i.i.i.i:                                 ; preds = %bb9.i57.i.i.i.i
  %_21.i62.i.i.i.i = mul nuw nsw i64 %value.sroa.0.014.i48.i.i.i.i, 10
  %8 = add nuw nsw i64 %_21.i62.i.i.i.i, %digit.i53.i.i.i.i
  %_5.i.not.i63.i.i.i.i = icmp eq ptr %_11.i.i50.i.i.i.i, %_14.i.i.i
  br i1 %_5.i.not.i63.i.i.i.i, label %bb5.thread57.i.i, label %bb4.i47.i.i.i.i

bb12.i67.i.i.i.i:                                 ; preds = %bb9.i57.i.i.i.i, %bb7.i55.i.i.i.i
  br i1 %_11.i.not, label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchlNvCs4A2AHSyUD2M_17parse_number_core9parse_i32EB2_.exit, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread47

bb5.thread57.i.i:                                 ; preds = %bb20.i61.i.i.i.i, %bb37.i.i.i.i
  %_4.sroa.0.0.ph56.i.i = phi i64 [ %digit.i5.i.i.i, %bb37.i.i.i.i ], [ %8, %bb20.i61.i.i.i.i ]
  %9 = sub nsw i64 0, %_4.sroa.0.0.ph56.i.i
  br label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit

_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread: ; preds = %bb4.i.i6.i.i.i, %bb4.i47.i.i.i.i, %bb4.i.i.i.i.i, %switch.early.test.i.i.i.i, %switch.early.test.i.i.i.i, %bb10.i.i.i.i, %bb34.i.i.i.i, %bb17.i26.i.i.i, %bb12.i.i.i.i, %bb17.i.i.i.i
  br i1 %_11.i.not, label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchlNvCs4A2AHSyUD2M_17parse_number_core9parse_i32EB2_.exit, label %bb11.i

_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit: ; preds = %bb20.i.i19.i.i.i, %bb20.i.i.i.i.i, %bb11.i.i.i.i, %bb38.i.i.i.i, %bb5.thread57.i.i
  %10 = phi i64 [ %_15.i.i.i.i, %bb11.i.i.i.i ], [ %2, %bb20.i.i.i.i.i ], [ %9, %bb5.thread57.i.i ], [ %digit.i5.i.i.i, %bb38.i.i.i.i ], [ %7, %bb20.i.i19.i.i.i ]
  %11 = trunc i64 %10 to i32
  br label %bb6.i

_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread47: ; preds = %bb12.i.i.i.i.i, %bb12.i.i22.i.i.i, %bb12.i67.i.i.i.i
  %_11.i.i.i.i.lcssa63.sink.i.i = phi ptr [ %_11.i.i.i.i.i.i, %bb12.i.i.i.i.i ], [ %_11.i.i.i9.i.i.i, %bb12.i.i22.i.i.i ], [ %_11.i.i50.i.i.i.i, %bb12.i67.i.i.i.i ]
  %.sink.i.i = phi i32 [ 0, %bb12.i.i.i.i.i ], [ 0, %bb12.i.i22.i.i.i ], [ 1, %bb12.i67.i.i.i.i ]
; call <parse_number_core::SliceBytes as parse_number_core::NumberBytes>::remaining_digits
  %_19.i.i.i.i.i = tail call fastcc noundef zeroext i1 @_RNvXs1_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtB5_11NumberBytes16remaining_digits(ptr noundef nonnull %_11.i.i.i.i.lcssa63.sink.i.i, ptr noundef nonnull readonly %_14.i.i.i) #6, !noalias !55
  %12 = select i1 %_19.i.i.i.i.i, i32 %.sink.i.i, i32 2
  br label %bb11.i

bb6.i:                                            ; preds = %bb28.i.i.i.i, %bb28.i.i.i.i.preheader, %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit, %bb17.i26.i.i.i
  %_0.sroa.3.0.insert.insert.i.i52 = phi i32 [ 0, %bb17.i26.i.i.i ], [ %11, %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit ], [ 0, %bb28.i.i.i.i.preheader ], [ 0, %bb28.i.i.i.i ]
  store i32 %_0.sroa.3.0.insert.insert.i.i52, ptr %output, align 4
  br label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchlNvCs4A2AHSyUD2M_17parse_number_core9parse_i32EB2_.exit

bb11.i:                                           ; preds = %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread, %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread47, %bb2.i.thread
  %value.sroa.0.0.i = phi i32 [ %12, %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread47 ], [ 2, %bb2.i.thread ], [ 2, %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread ]
  store i32 %value.sroa.0.0.i, ptr %error, align 4
  br label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchlNvCs4A2AHSyUD2M_17parse_number_core9parse_i32EB2_.exit

_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchlNvCs4A2AHSyUD2M_17parse_number_core9parse_i32EB2_.exit: ; preds = %bb12.i.i22.i.i.i, %bb12.i67.i.i.i.i, %bb12.i.i.i.i.i, %bb2.i.thread, %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread, %bb6.i, %bb11.i
  %_0.sroa.0.0.i = phi i1 [ false, %bb12.i.i22.i.i.i ], [ true, %bb6.i ], [ false, %bb11.i ], [ false, %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread ], [ false, %bb2.i.thread ], [ false, %bb12.i.i.i.i.i ], [ false, %bb12.i67.i.i.i.i ]
  ret i1 %_0.sroa.0.0.i
}

; Function Attrs: nounwind uwtable
define noundef zeroext i1 @rustium_parse_number_native_i64(ptr noundef %input, i64 noundef %len, i32 noundef %format, ptr nofree noundef writeonly captures(none) %output, ptr nofree noundef writeonly captures(address_is_null) %error) unnamed_addr #1 personality ptr @__CxxFrameHandler3 !guid !57 {
start:
  %0 = icmp eq i64 %len, 0
  br i1 %0, label %bb2.i.thread, label %bb14.i

bb2.i.thread:                                     ; preds = %start
  %_11.i7.not = icmp eq ptr %error, null
  br i1 %_11.i7.not, label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchxNvCs4A2AHSyUD2M_17parse_number_core9parse_i64EB2_.exit, label %bb11.i

bb14.i:                                           ; preds = %start
  %_12.not.i = icmp eq ptr %input, null
  %_7.not.i = icmp slt i64 %len, 0
  %or.cond = or i1 %_12.not.i, %_7.not.i
  br i1 %or.cond, label %bb5.i3, label %bb8.i.i.i, !prof !22

bb5.i3:                                           ; preds = %bb14.i
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_a28e8c8fd5088943a8b5d44af697ff83, ptr noundef nonnull inttoptr (i64 559 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_14547586b6d8a2ddcb70cace56ee43cc) #5
  unreachable

bb8.i.i.i:                                        ; preds = %bb14.i
  %_11.i.not = icmp eq ptr %error, null
  %_14.i.i.i = getelementptr inbounds nuw i8, ptr %input, i64 %len
  %1 = load i8, ptr %input, align 1, !alias.scope !58, !noundef !20
  switch i8 %1, label %bb17.i.i.i.i [
    i8 45, label %bb2.i.i.i
    i8 48, label %bb2.i.i.i
  ]

bb17.i.i.i.i:                                     ; preds = %bb8.i.i.i
  %digit.i.i.i.i = add i8 %1, -48
  %_11.i.i.i.i = icmp ugt i8 %digit.i.i.i.i, 9
  br i1 %_11.i.i.i.i, label %bb5.i, label %bb11.i.i.i.i

bb11.i.i.i.i:                                     ; preds = %bb17.i.i.i.i
  %_15.i.i.i.i = zext nneg i8 %digit.i.i.i.i to i64
  %_5.i.not12.i.i.i.i.i = icmp samesign eq i64 %len, 1
  br i1 %_5.i.not12.i.i.i.i.i, label %bb6.i, label %bb4.i.i.i.preheader.i.i

bb4.i.i.i.preheader.i.i:                          ; preds = %bb11.i.i.i.i
  %_11.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %input, i64 1
  br label %bb4.i.i.i.i.i

bb4.i.i.i.i.i:                                    ; preds = %bb20.i.i.i.i.i, %bb4.i.i.i.preheader.i.i
  %value.sroa.0.014.i.i.i.i.i = phi i64 [ %2, %bb20.i.i.i.i.i ], [ %_15.i.i.i.i, %bb4.i.i.i.preheader.i.i ]
  %bytes.sroa.0.013.i.i.i.i.i = phi ptr [ %_11.i.i.i.i.i.i, %bb20.i.i.i.i.i ], [ %_11.i.i.i.i.i, %bb4.i.i.i.preheader.i.i ]
  %_11.i.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %bytes.sroa.0.013.i.i.i.i.i, i64 1
  %_13.i.i.i.i.i.i = load i8, ptr %bytes.sroa.0.013.i.i.i.i.i, align 1, !alias.scope !58, !noalias !65, !noundef !20
  %_10.i.i.i.i.i = add i8 %_13.i.i.i.i.i.i, -48
  %digit.i.i.i.i.i = zext nneg i8 %_10.i.i.i.i.i to i64
  %_11.i4.i.i.i.i = icmp ugt i8 %_10.i.i.i.i.i, 9
  br i1 %_11.i4.i.i.i.i, label %bb5.i, label %bb7.i.i.i.i.i

bb7.i.i.i.i.i:                                    ; preds = %bb4.i.i.i.i.i
  %_12.i.i.i.i.i = icmp ugt i64 %value.sroa.0.014.i.i.i.i.i, 922337203685477580
  br i1 %_12.i.i.i.i.i, label %bb12.i.i.i.i.i, label %bb9.i.i.i.i.i

bb9.i.i.i.i.i:                                    ; preds = %bb7.i.i.i.i.i
  %_15.i.i.i.i.i = icmp eq i64 %value.sroa.0.014.i.i.i.i.i, 922337203685477580
  %_17.i.i.i.i.i = icmp samesign ugt i8 %_10.i.i.i.i.i, 7
  %or.cond.i.i.i.i.i = and i1 %_15.i.i.i.i.i, %_17.i.i.i.i.i
  br i1 %or.cond.i.i.i.i.i, label %bb12.i.i.i.i.i, label %bb20.i.i.i.i.i

bb20.i.i.i.i.i:                                   ; preds = %bb9.i.i.i.i.i
  %_21.i.i.i.i.i = mul nuw nsw i64 %value.sroa.0.014.i.i.i.i.i, 10
  %2 = add nuw i64 %_21.i.i.i.i.i, %digit.i.i.i.i.i
  %_5.i.not.i.i.i.i.i = icmp eq ptr %_11.i.i.i.i.i.i, %_14.i.i.i
  br i1 %_5.i.not.i.i.i.i.i, label %bb6.i, label %bb4.i.i.i.i.i

bb12.i.i.i.i.i:                                   ; preds = %bb9.i.i.i.i.i, %bb7.i.i.i.i.i
  br i1 %_11.i.not, label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchxNvCs4A2AHSyUD2M_17parse_number_core9parse_i64EB2_.exit, label %bb7.i

bb2.i.i.i:                                        ; preds = %bb8.i.i.i, %bb8.i.i.i
  %_11.i.i2.i.i.i = getelementptr inbounds nuw i8, ptr %input, i64 1
  %3 = and i32 %format, -2
  %strict.sroa.0.0.i.i.i.i = icmp eq i32 %3, 2
  %negative.i.i.i.i = icmp eq i8 %1, 45
  %4 = add nsw i8 %1, -48
  %or.cond.i4.i.i.i = icmp ult i8 %4, 10
  br i1 %or.cond.i4.i.i.i, label %bb15.i.i.i.i, label %bb10.i.i.i.i

bb10.i.i.i.i:                                     ; preds = %bb2.i.i.i
  br i1 %negative.i.i.i.i, label %switch.early.test.i.i.i.i, label %bb5.i

switch.early.test.i.i.i.i:                        ; preds = %bb10.i.i.i.i
  switch i32 %format, label %bb12.i.i.i.i [
    i32 2, label %bb5.i
    i32 0, label %bb5.i
  ]

bb12.i.i.i.i:                                     ; preds = %switch.early.test.i.i.i.i
  %_5.i23.not.i.i.i.i = icmp samesign eq i64 %len, 1
  br i1 %_5.i23.not.i.i.i.i, label %bb5.i, label %bb52.i.i.i.i

bb52.i.i.i.i:                                     ; preds = %bb12.i.i.i.i
  %_11.i26.i.i.i.i = getelementptr inbounds nuw i8, ptr %input, i64 2
  %_13.i27.i.i.i.i = load i8, ptr %_11.i.i2.i.i.i, align 1, !alias.scope !58, !noalias !72, !noundef !20
  br label %bb15.i.i.i.i

bb15.i.i.i.i:                                     ; preds = %bb52.i.i.i.i, %bb2.i.i.i
  %bytes.sroa.0.0.i.i.i.i = phi ptr [ %_11.i.i2.i.i.i, %bb2.i.i.i ], [ %_11.i26.i.i.i.i, %bb52.i.i.i.i ]
  %first.sroa.0.0.i.i.i.i = phi i8 [ 48, %bb2.i.i.i ], [ %_13.i27.i.i.i.i, %bb52.i.i.i.i ]
  %5 = icmp eq i8 %first.sroa.0.0.i.i.i.i, 48
  %or.cond4.i.i.i.i = and i1 %strict.sroa.0.0.i.i.i.i, %5
  br i1 %or.cond4.i.i.i.i, label %bb17.i26.i.i.i, label %bb25.i.i.i.i

bb25.i.i.i.i:                                     ; preds = %bb15.i.i.i.i
  br i1 %5, label %bb28.i.i.i.i.preheader, label %bb34.i.i.i.i

bb28.i.i.i.i.preheader:                           ; preds = %bb25.i.i.i.i
  %_5.i39.not.i.i.i.i74 = icmp eq ptr %bytes.sroa.0.0.i.i.i.i, %_14.i.i.i
  br i1 %_5.i39.not.i.i.i.i74, label %bb6.i, label %bb30.i.i.i.i

bb17.i26.i.i.i:                                   ; preds = %bb15.i.i.i.i
  %_5.i31.not.i.i.i.i = icmp ne ptr %bytes.sroa.0.0.i.i.i.i, %_14.i.i.i
  %or.cond98.not.i.i.i.i = select i1 %negative.i.i.i.i, i1 true, i1 %_5.i31.not.i.i.i.i
  br i1 %or.cond98.not.i.i.i.i, label %bb5.i, label %bb6.i

bb28.i.i.i.i:                                     ; preds = %bb30.i.i.i.i
  %_5.i39.not.i.i.i.i = icmp eq ptr %_11.i42.i.i.i.i, %_14.i.i.i
  br i1 %_5.i39.not.i.i.i.i, label %bb6.i, label %bb30.i.i.i.i

bb30.i.i.i.i:                                     ; preds = %bb28.i.i.i.i.preheader, %bb28.i.i.i.i
  %bytes.sroa.0.1.i.i.i.i75 = phi ptr [ %_11.i42.i.i.i.i, %bb28.i.i.i.i ], [ %bytes.sroa.0.0.i.i.i.i, %bb28.i.i.i.i.preheader ]
  %_11.i42.i.i.i.i = getelementptr inbounds nuw i8, ptr %bytes.sroa.0.1.i.i.i.i75, i64 1
  %_13.i43.i.i.i.i = load i8, ptr %bytes.sroa.0.1.i.i.i.i75, align 1, !alias.scope !58, !noalias !77, !noundef !20
  %6 = icmp eq i8 %_13.i43.i.i.i.i, 48
  br i1 %6, label %bb28.i.i.i.i, label %bb34.i.i.i.i

bb34.i.i.i.i:                                     ; preds = %bb30.i.i.i.i, %bb25.i.i.i.i
  %bytes.sroa.0.2.i.i.i.i = phi ptr [ %bytes.sroa.0.0.i.i.i.i, %bb25.i.i.i.i ], [ %_11.i42.i.i.i.i, %bb30.i.i.i.i ]
  %first.sroa.0.1.i.i.i.i = phi i8 [ %first.sroa.0.0.i.i.i.i, %bb25.i.i.i.i ], [ %_13.i43.i.i.i.i, %bb30.i.i.i.i ]
  %_28.i.i.i.i = add i8 %first.sroa.0.1.i.i.i.i, -48
  %digit.i5.i.i.i = zext i8 %_28.i.i.i.i to i64
  %_29.i.i.i.i = icmp ugt i8 %_28.i.i.i.i, 9
  br i1 %_29.i.i.i.i, label %bb5.i, label %bb36.i.i.i.i

bb36.i.i.i.i:                                     ; preds = %bb34.i.i.i.i
  %_5.i.not12.i46.i.i.i.i = icmp eq ptr %bytes.sroa.0.2.i.i.i.i, %_14.i.i.i
  br i1 %negative.i.i.i.i, label %bb37.i.i.i.i, label %bb38.i.i.i.i

bb38.i.i.i.i:                                     ; preds = %bb36.i.i.i.i
  br i1 %_5.i.not12.i46.i.i.i.i, label %bb6.i, label %bb4.i.i6.i.i.i

bb4.i.i6.i.i.i:                                   ; preds = %bb38.i.i.i.i, %bb20.i.i19.i.i.i
  %value.sroa.0.014.i.i7.i.i.i = phi i64 [ %7, %bb20.i.i19.i.i.i ], [ %digit.i5.i.i.i, %bb38.i.i.i.i ]
  %bytes.sroa.0.013.i.i8.i.i.i = phi ptr [ %_11.i.i.i9.i.i.i, %bb20.i.i19.i.i.i ], [ %bytes.sroa.0.2.i.i.i.i, %bb38.i.i.i.i ]
  %_11.i.i.i9.i.i.i = getelementptr inbounds nuw i8, ptr %bytes.sroa.0.013.i.i8.i.i.i, i64 1
  %_13.i.i.i10.i.i.i = load i8, ptr %bytes.sroa.0.013.i.i8.i.i.i, align 1, !alias.scope !58, !noalias !80, !noundef !20
  %_10.i.i11.i.i.i = add i8 %_13.i.i.i10.i.i.i, -48
  %digit.i.i12.i.i.i = zext nneg i8 %_10.i.i11.i.i.i to i64
  %_11.i45.i.i.i.i = icmp ugt i8 %_10.i.i11.i.i.i, 9
  br i1 %_11.i45.i.i.i.i, label %bb5.i, label %bb7.i.i13.i.i.i

bb7.i.i13.i.i.i:                                  ; preds = %bb4.i.i6.i.i.i
  %_12.i.i14.i.i.i = icmp ugt i64 %value.sroa.0.014.i.i7.i.i.i, 922337203685477580
  br i1 %_12.i.i14.i.i.i, label %bb12.i.i22.i.i.i, label %bb9.i.i15.i.i.i

bb9.i.i15.i.i.i:                                  ; preds = %bb7.i.i13.i.i.i
  %_15.i.i16.i.i.i = icmp eq i64 %value.sroa.0.014.i.i7.i.i.i, 922337203685477580
  %_17.i.i17.i.i.i = icmp samesign ugt i8 %_10.i.i11.i.i.i, 7
  %or.cond.i.i18.i.i.i = and i1 %_15.i.i16.i.i.i, %_17.i.i17.i.i.i
  br i1 %or.cond.i.i18.i.i.i, label %bb12.i.i22.i.i.i, label %bb20.i.i19.i.i.i

bb20.i.i19.i.i.i:                                 ; preds = %bb9.i.i15.i.i.i
  %_21.i.i20.i.i.i = mul nuw nsw i64 %value.sroa.0.014.i.i7.i.i.i, 10
  %7 = add nuw i64 %_21.i.i20.i.i.i, %digit.i.i12.i.i.i
  %_5.i.not.i.i21.i.i.i = icmp eq ptr %_11.i.i.i9.i.i.i, %_14.i.i.i
  br i1 %_5.i.not.i.i21.i.i.i, label %bb6.i, label %bb4.i.i6.i.i.i

bb12.i.i22.i.i.i:                                 ; preds = %bb9.i.i15.i.i.i, %bb7.i.i13.i.i.i
  br i1 %_11.i.not, label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchxNvCs4A2AHSyUD2M_17parse_number_core9parse_i64EB2_.exit, label %bb7.i

bb37.i.i.i.i:                                     ; preds = %bb36.i.i.i.i
  br i1 %_5.i.not12.i46.i.i.i.i, label %bb5.thread56.i.i, label %bb4.i47.i.i.i.i

bb4.i47.i.i.i.i:                                  ; preds = %bb37.i.i.i.i, %bb20.i61.i.i.i.i
  %value.sroa.0.014.i48.i.i.i.i = phi i64 [ %8, %bb20.i61.i.i.i.i ], [ %digit.i5.i.i.i, %bb37.i.i.i.i ]
  %bytes.sroa.0.013.i49.i.i.i.i = phi ptr [ %_11.i.i50.i.i.i.i, %bb20.i61.i.i.i.i ], [ %bytes.sroa.0.2.i.i.i.i, %bb37.i.i.i.i ]
  %_11.i.i50.i.i.i.i = getelementptr inbounds nuw i8, ptr %bytes.sroa.0.013.i49.i.i.i.i, i64 1
  %_13.i.i51.i.i.i.i = load i8, ptr %bytes.sroa.0.013.i49.i.i.i.i, align 1, !alias.scope !58, !noalias !85, !noundef !20
  %_10.i52.i.i.i.i = add i8 %_13.i.i51.i.i.i.i, -48
  %digit.i53.i.i.i.i = zext nneg i8 %_10.i52.i.i.i.i to i64
  %_11.i54.i.i.i.i = icmp ugt i8 %_10.i52.i.i.i.i, 9
  br i1 %_11.i54.i.i.i.i, label %bb5.i, label %bb7.i55.i.i.i.i

bb7.i55.i.i.i.i:                                  ; preds = %bb4.i47.i.i.i.i
  %_12.i56.i.i.i.i = icmp ugt i64 %value.sroa.0.014.i48.i.i.i.i, 922337203685477580
  br i1 %_12.i56.i.i.i.i, label %bb12.i67.i.i.i.i, label %bb9.i57.i.i.i.i

bb9.i57.i.i.i.i:                                  ; preds = %bb7.i55.i.i.i.i
  %_15.i58.i.i.i.i = icmp eq i64 %value.sroa.0.014.i48.i.i.i.i, 922337203685477580
  %_17.i59.i.i.i.i = icmp eq i8 %_10.i52.i.i.i.i, 9
  %or.cond.i60.i.i.i.i = and i1 %_15.i58.i.i.i.i, %_17.i59.i.i.i.i
  br i1 %or.cond.i60.i.i.i.i, label %bb12.i67.i.i.i.i, label %bb20.i61.i.i.i.i

bb20.i61.i.i.i.i:                                 ; preds = %bb9.i57.i.i.i.i
  %_21.i62.i.i.i.i = mul nuw nsw i64 %value.sroa.0.014.i48.i.i.i.i, 10
  %8 = add nuw i64 %_21.i62.i.i.i.i, %digit.i53.i.i.i.i
  %_5.i.not.i63.i.i.i.i = icmp eq ptr %_11.i.i50.i.i.i.i, %_14.i.i.i
  br i1 %_5.i.not.i63.i.i.i.i, label %bb5.thread56.i.i, label %bb4.i47.i.i.i.i

bb12.i67.i.i.i.i:                                 ; preds = %bb9.i57.i.i.i.i, %bb7.i55.i.i.i.i
  br i1 %_11.i.not, label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchxNvCs4A2AHSyUD2M_17parse_number_core9parse_i64EB2_.exit, label %bb7.i

bb5.thread56.i.i:                                 ; preds = %bb20.i61.i.i.i.i, %bb37.i.i.i.i
  %_4.sroa.0.0.ph55.i.i = phi i64 [ %digit.i5.i.i.i, %bb37.i.i.i.i ], [ %8, %bb20.i61.i.i.i.i ]
  %9 = sub i64 0, %_4.sroa.0.0.ph55.i.i
  br label %bb6.i

bb5.i:                                            ; preds = %bb4.i.i6.i.i.i, %bb4.i47.i.i.i.i, %bb4.i.i.i.i.i, %bb17.i.i.i.i, %bb34.i.i.i.i, %bb17.i26.i.i.i, %bb12.i.i.i.i, %switch.early.test.i.i.i.i, %switch.early.test.i.i.i.i, %bb10.i.i.i.i
  br i1 %_11.i.not, label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchxNvCs4A2AHSyUD2M_17parse_number_core9parse_i64EB2_.exit, label %bb11.i

bb6.i:                                            ; preds = %bb28.i.i.i.i, %bb20.i.i19.i.i.i, %bb20.i.i.i.i.i, %bb28.i.i.i.i.preheader, %bb17.i26.i.i.i, %bb5.thread56.i.i, %bb38.i.i.i.i, %bb11.i.i.i.i
  %result.i.sroa.64.0 = phi i64 [ 0, %bb28.i.i.i.i.preheader ], [ 0, %bb17.i26.i.i.i ], [ %7, %bb20.i.i19.i.i.i ], [ %9, %bb5.thread56.i.i ], [ %digit.i5.i.i.i, %bb38.i.i.i.i ], [ %_15.i.i.i.i, %bb11.i.i.i.i ], [ %2, %bb20.i.i.i.i.i ], [ 0, %bb28.i.i.i.i ]
  store i64 %result.i.sroa.64.0, ptr %output, align 8
  br label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchxNvCs4A2AHSyUD2M_17parse_number_core9parse_i64EB2_.exit

bb7.i:                                            ; preds = %bb12.i.i.i.i.i, %bb12.i.i22.i.i.i, %bb12.i67.i.i.i.i
  %_11.i.i.i.i.lcssa62.sink.i.i = phi ptr [ %_11.i.i.i.i.i.i, %bb12.i.i.i.i.i ], [ %_11.i.i.i9.i.i.i, %bb12.i.i22.i.i.i ], [ %_11.i.i50.i.i.i.i, %bb12.i67.i.i.i.i ]
  %.sink.i.i = phi i32 [ 0, %bb12.i.i.i.i.i ], [ 0, %bb12.i.i22.i.i.i ], [ 1, %bb12.i67.i.i.i.i ]
; call <parse_number_core::SliceBytes as parse_number_core::NumberBytes>::remaining_digits
  %_19.i.i.i.i.i = tail call fastcc noundef zeroext i1 @_RNvXs1_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtB5_11NumberBytes16remaining_digits(ptr noundef nonnull %_11.i.i.i.i.lcssa62.sink.i.i, ptr noundef nonnull readonly %_14.i.i.i) #6, !noalias !90
  %switch.idx.cast = select i1 %_19.i.i.i.i.i, i32 %.sink.i.i, i32 2
  br label %bb11.i

bb11.i:                                           ; preds = %bb5.i, %bb2.i.thread, %bb7.i
  %value.sroa.0.0.i = phi i32 [ %switch.idx.cast, %bb7.i ], [ 2, %bb2.i.thread ], [ 2, %bb5.i ]
  store i32 %value.sroa.0.0.i, ptr %error, align 4
  br label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchxNvCs4A2AHSyUD2M_17parse_number_core9parse_i64EB2_.exit

_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchxNvCs4A2AHSyUD2M_17parse_number_core9parse_i64EB2_.exit: ; preds = %bb12.i.i22.i.i.i, %bb12.i67.i.i.i.i, %bb12.i.i.i.i.i, %bb2.i.thread, %bb5.i, %bb6.i, %bb11.i
  %_0.sroa.0.0.i = phi i1 [ false, %bb5.i ], [ true, %bb6.i ], [ false, %bb11.i ], [ false, %bb2.i.thread ], [ false, %bb12.i.i.i.i.i ], [ false, %bb12.i67.i.i.i.i ], [ false, %bb12.i.i22.i.i.i ]
  ret i1 %_0.sroa.0.0.i
}

; Function Attrs: nounwind uwtable
define noundef zeroext i1 @rustium_parse_number_native_u32(ptr noundef %input, i64 noundef %len, i32 noundef %format, ptr nofree noundef writeonly captures(none) %output, ptr nofree noundef writeonly captures(address_is_null) %error) unnamed_addr #1 personality ptr @__CxxFrameHandler3 !guid !94 {
start:
  %0 = icmp eq i64 %len, 0
  br i1 %0, label %bb2.i.thread, label %bb14.i

bb2.i.thread:                                     ; preds = %start
  %_11.i6.not = icmp eq ptr %error, null
  br i1 %_11.i6.not, label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchmNvCs4A2AHSyUD2M_17parse_number_core9parse_u32EB2_.exit, label %bb11.i

bb14.i:                                           ; preds = %start
  %_12.not.i = icmp eq ptr %input, null
  %_7.not.i = icmp slt i64 %len, 0
  %or.cond = or i1 %_12.not.i, %_7.not.i
  br i1 %or.cond, label %bb5.i3, label %bb17.i.i.i, !prof !22

bb5.i3:                                           ; preds = %bb14.i
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_a28e8c8fd5088943a8b5d44af697ff83, ptr noundef nonnull inttoptr (i64 559 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_14547586b6d8a2ddcb70cace56ee43cc) #5
  unreachable

bb17.i.i.i:                                       ; preds = %bb14.i
  %_11.i.not = icmp eq ptr %error, null
  %_12.i.i = getelementptr inbounds nuw i8, ptr %input, i64 %len
  %_11.i.i.i.i = getelementptr inbounds nuw i8, ptr %input, i64 1
  %_13.i.i.i.i = load i8, ptr %input, align 1, !alias.scope !95, !noalias !100, !noundef !20
  %digit.i.i.i = add i8 %_13.i.i.i.i, -48
  %_11.i.i.i = icmp ugt i8 %digit.i.i.i, 9
  br i1 %_11.i.i.i, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread, label %bb4.i.i.i

bb4.i.i.i:                                        ; preds = %bb17.i.i.i
  %_7.i.i = icmp eq i32 %format, 2
  %1 = icmp eq i8 %digit.i.i.i, 0
  %or.cond.i.i.i = and i1 %_7.i.i, %1
  br i1 %or.cond.i.i.i, label %bb6.i.i.i, label %bb11.i.i.i

bb11.i.i.i:                                       ; preds = %bb4.i.i.i
  %_15.i.i.i = zext nneg i8 %digit.i.i.i to i64
  %_5.i.not12.i.i.i.i = icmp samesign eq i64 %len, 1
  br i1 %_5.i.not12.i.i.i.i, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit, label %bb4.i.i.i.i

bb4.i.i.i.i:                                      ; preds = %bb11.i.i.i, %bb20.i.i.i.i
  %value.sroa.0.014.i.i.i.i = phi i64 [ %2, %bb20.i.i.i.i ], [ %_15.i.i.i, %bb11.i.i.i ]
  %bytes.sroa.0.013.i.i.i.i = phi ptr [ %_11.i.i.i.i.i, %bb20.i.i.i.i ], [ %_11.i.i.i.i, %bb11.i.i.i ]
  %_11.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %bytes.sroa.0.013.i.i.i.i, i64 1
  %_13.i.i.i.i.i = load i8, ptr %bytes.sroa.0.013.i.i.i.i, align 1, !alias.scope !95, !noalias !105, !noundef !20
  %_10.i.i.i.i = add i8 %_13.i.i.i.i.i, -48
  %digit.i.i.i.i = zext nneg i8 %_10.i.i.i.i to i64
  %_11.i4.i.i.i = icmp ugt i8 %_10.i.i.i.i, 9
  br i1 %_11.i4.i.i.i, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread, label %bb7.i.i.i.i

bb7.i.i.i.i:                                      ; preds = %bb4.i.i.i.i
  %_12.i.i.i.i = icmp ugt i64 %value.sroa.0.014.i.i.i.i, 429496729
  br i1 %_12.i.i.i.i, label %bb12.i.i.i.i, label %bb9.i.i.i.i

bb9.i.i.i.i:                                      ; preds = %bb7.i.i.i.i
  %_15.i.i.i.i = icmp eq i64 %value.sroa.0.014.i.i.i.i, 429496729
  %_17.i.i.i.i = icmp samesign ugt i8 %_10.i.i.i.i, 5
  %or.cond.i.i.i.i = and i1 %_15.i.i.i.i, %_17.i.i.i.i
  br i1 %or.cond.i.i.i.i, label %bb12.i.i.i.i, label %bb20.i.i.i.i

bb20.i.i.i.i:                                     ; preds = %bb9.i.i.i.i
  %_21.i.i.i.i = mul nuw nsw i64 %value.sroa.0.014.i.i.i.i, 10
  %2 = add nuw nsw i64 %_21.i.i.i.i, %digit.i.i.i.i
  %_5.i.not.i.i.i.i = icmp eq ptr %_11.i.i.i.i.i, %_12.i.i
  br i1 %_5.i.not.i.i.i.i, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit, label %bb4.i.i.i.i

bb12.i.i.i.i:                                     ; preds = %bb9.i.i.i.i, %bb7.i.i.i.i
  br i1 %_11.i.not, label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchmNvCs4A2AHSyUD2M_17parse_number_core9parse_u32EB2_.exit, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread27

bb6.i.i.i:                                        ; preds = %bb4.i.i.i
  %_5.i7.not.i.i.i = icmp samesign eq i64 %len, 1
  br i1 %_5.i7.not.i.i.i, label %bb6.i, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread

_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread: ; preds = %bb4.i.i.i.i, %bb17.i.i.i, %bb6.i.i.i
  br i1 %_11.i.not, label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchmNvCs4A2AHSyUD2M_17parse_number_core9parse_u32EB2_.exit, label %bb11.i

_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit: ; preds = %bb20.i.i.i.i, %bb11.i.i.i
  %_4.sroa.102.0.i.i = phi i64 [ %_15.i.i.i, %bb11.i.i.i ], [ %2, %bb20.i.i.i.i ]
  %3 = trunc i64 %_4.sroa.102.0.i.i to i32
  br label %bb6.i

_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread27: ; preds = %bb12.i.i.i.i
; call <parse_number_core::SliceBytes as parse_number_core::NumberBytes>::remaining_digits
  %_19.i.i.i.i = tail call fastcc noundef zeroext i1 @_RNvXs1_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtB5_11NumberBytes16remaining_digits(ptr noundef nonnull %_11.i.i.i.i.i, ptr noundef nonnull readonly %_12.i.i) #6, !noalias !110
  %4 = select i1 %_19.i.i.i.i, i32 0, i32 2
  br label %bb11.i

bb6.i:                                            ; preds = %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit, %bb6.i.i.i
  %_0.sroa.3.0.insert.insert.i.i32 = phi i32 [ 0, %bb6.i.i.i ], [ %3, %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit ]
  store i32 %_0.sroa.3.0.insert.insert.i.i32, ptr %output, align 4
  br label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchmNvCs4A2AHSyUD2M_17parse_number_core9parse_u32EB2_.exit

bb11.i:                                           ; preds = %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread, %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread27, %bb2.i.thread
  %value.sroa.0.0.i = phi i32 [ %4, %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread27 ], [ 2, %bb2.i.thread ], [ 2, %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread ]
  store i32 %value.sroa.0.0.i, ptr %error, align 4
  br label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchmNvCs4A2AHSyUD2M_17parse_number_core9parse_u32EB2_.exit

_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchmNvCs4A2AHSyUD2M_17parse_number_core9parse_u32EB2_.exit: ; preds = %bb12.i.i.i.i, %bb2.i.thread, %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread, %bb6.i, %bb11.i
  %_0.sroa.0.0.i = phi i1 [ false, %bb12.i.i.i.i ], [ true, %bb6.i ], [ false, %bb11.i ], [ false, %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread ], [ false, %bb2.i.thread ]
  ret i1 %_0.sroa.0.0.i
}

; Function Attrs: nounwind uwtable
define noundef zeroext i1 @rustium_parse_number_native_u64(ptr noundef %input, i64 noundef %len, i32 noundef %format, ptr nofree noundef writeonly captures(none) %output, ptr nofree noundef writeonly captures(address_is_null) %error) unnamed_addr #1 personality ptr @__CxxFrameHandler3 !guid !111 {
start:
  %0 = icmp eq i64 %len, 0
  br i1 %0, label %bb16.i.i.i, label %bb14.i

bb14.i:                                           ; preds = %start
  %_12.not.i = icmp eq ptr %input, null
  %_7.not.i = icmp slt i64 %len, 0
  %or.cond = or i1 %_12.not.i, %_7.not.i
  br i1 %or.cond, label %bb5.i3, label %bb17.i.i.i, !prof !22

bb5.i3:                                           ; preds = %bb14.i
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_a28e8c8fd5088943a8b5d44af697ff83, ptr noundef nonnull inttoptr (i64 559 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_14547586b6d8a2ddcb70cace56ee43cc) #5
  unreachable

bb17.i.i.i:                                       ; preds = %bb14.i
  %_11.i.not = icmp eq ptr %error, null
  %_11.i.i = getelementptr inbounds nuw i8, ptr %input, i64 %len
  %_11.i.i.i.i = getelementptr inbounds nuw i8, ptr %input, i64 1
  %_13.i.i.i.i = load i8, ptr %input, align 1, !alias.scope !112, !noalias !117, !noundef !20
  %digit.i.i.i = add i8 %_13.i.i.i.i, -48
  %_11.i.i.i = icmp ugt i8 %digit.i.i.i, 9
  br i1 %_11.i.i.i, label %bb5.i, label %bb4.i.i.i

bb16.i.i.i:                                       ; preds = %start
  %_11.i7.not = icmp eq ptr %error, null
  br i1 %_11.i7.not, label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchyNvCs4A2AHSyUD2M_17parse_number_core9parse_u64EB2_.exit, label %bb8.i

bb4.i.i.i:                                        ; preds = %bb17.i.i.i
  %_6.i.i = icmp eq i32 %format, 2
  %1 = icmp eq i8 %digit.i.i.i, 0
  %or.cond.i.i.i = and i1 %_6.i.i, %1
  br i1 %or.cond.i.i.i, label %bb6.i.i.i, label %bb11.i.i.i

bb11.i.i.i:                                       ; preds = %bb4.i.i.i
  %_15.i.i.i = zext nneg i8 %digit.i.i.i to i64
  %_5.i.not12.i.i.i.i = icmp samesign eq i64 %len, 1
  br i1 %_5.i.not12.i.i.i.i, label %bb6.i, label %bb4.i.i.i.i

bb4.i.i.i.i:                                      ; preds = %bb11.i.i.i, %bb20.i.i.i.i
  %value.sroa.0.014.i.i.i.i = phi i64 [ %2, %bb20.i.i.i.i ], [ %_15.i.i.i, %bb11.i.i.i ]
  %bytes.sroa.0.013.i.i.i.i = phi ptr [ %_11.i.i.i.i.i, %bb20.i.i.i.i ], [ %_11.i.i.i.i, %bb11.i.i.i ]
  %_11.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %bytes.sroa.0.013.i.i.i.i, i64 1
  %_13.i.i.i.i.i = load i8, ptr %bytes.sroa.0.013.i.i.i.i, align 1, !alias.scope !112, !noalias !122, !noundef !20
  %_10.i.i.i.i = add i8 %_13.i.i.i.i.i, -48
  %digit.i.i.i.i = zext nneg i8 %_10.i.i.i.i to i64
  %_11.i4.i.i.i = icmp ugt i8 %_10.i.i.i.i, 9
  br i1 %_11.i4.i.i.i, label %bb5.i, label %bb7.i.i.i.i

bb7.i.i.i.i:                                      ; preds = %bb4.i.i.i.i
  %_12.i.i.i.i = icmp ugt i64 %value.sroa.0.014.i.i.i.i, 1844674407370955161
  br i1 %_12.i.i.i.i, label %bb12.i.i.i.i, label %bb9.i.i.i.i

bb9.i.i.i.i:                                      ; preds = %bb7.i.i.i.i
  %_15.i.i.i.i = icmp eq i64 %value.sroa.0.014.i.i.i.i, 1844674407370955161
  %_17.i.i.i.i = icmp samesign ugt i8 %_10.i.i.i.i, 5
  %or.cond.i.i.i.i = and i1 %_15.i.i.i.i, %_17.i.i.i.i
  br i1 %or.cond.i.i.i.i, label %bb12.i.i.i.i, label %bb20.i.i.i.i

bb20.i.i.i.i:                                     ; preds = %bb9.i.i.i.i
  %_21.i.i.i.i = mul nuw i64 %value.sroa.0.014.i.i.i.i, 10
  %2 = add i64 %_21.i.i.i.i, %digit.i.i.i.i
  %_5.i.not.i.i.i.i = icmp eq ptr %_11.i.i.i.i.i, %_11.i.i
  br i1 %_5.i.not.i.i.i.i, label %bb6.i, label %bb4.i.i.i.i

bb12.i.i.i.i:                                     ; preds = %bb9.i.i.i.i, %bb7.i.i.i.i
  br i1 %_11.i.not, label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchyNvCs4A2AHSyUD2M_17parse_number_core9parse_u64EB2_.exit, label %bb7.i

bb6.i.i.i:                                        ; preds = %bb4.i.i.i
  %_5.i7.not.i.i.i = icmp samesign eq i64 %len, 1
  br i1 %_5.i7.not.i.i.i, label %bb6.i, label %bb8.i.i.i

bb8.i.i.i:                                        ; preds = %bb6.i.i.i
  br i1 %_11.i.not, label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchyNvCs4A2AHSyUD2M_17parse_number_core9parse_u64EB2_.exit, label %bb8.i

bb5.i:                                            ; preds = %bb4.i.i.i.i, %bb17.i.i.i
  br i1 %_11.i.not, label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchyNvCs4A2AHSyUD2M_17parse_number_core9parse_u64EB2_.exit, label %bb8.i

bb6.i:                                            ; preds = %bb20.i.i.i.i, %bb11.i.i.i, %bb6.i.i.i
  %result.i.sroa.104.0 = phi i64 [ %_15.i.i.i, %bb11.i.i.i ], [ 0, %bb6.i.i.i ], [ %2, %bb20.i.i.i.i ]
  store i64 %result.i.sroa.104.0, ptr %output, align 8
  br label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchyNvCs4A2AHSyUD2M_17parse_number_core9parse_u64EB2_.exit

bb7.i:                                            ; preds = %bb12.i.i.i.i
; call <parse_number_core::SliceBytes as parse_number_core::NumberBytes>::remaining_digits
  %_19.i.i.i.i = tail call fastcc noundef zeroext i1 @_RNvXs1_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtB5_11NumberBytes16remaining_digits(ptr noundef nonnull %_11.i.i.i.i.i, ptr noundef nonnull readonly %_11.i.i) #6, !noalias !127
  br i1 %_19.i.i.i.i, label %bb11.i, label %bb8.i

bb8.i:                                            ; preds = %bb7.i, %bb8.i.i.i, %bb16.i.i.i, %bb5.i
  br label %bb11.i

bb11.i:                                           ; preds = %bb7.i, %bb8.i
  %value.sroa.0.0.i = phi i32 [ 2, %bb8.i ], [ 0, %bb7.i ]
  store i32 %value.sroa.0.0.i, ptr %error, align 4
  br label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchyNvCs4A2AHSyUD2M_17parse_number_core9parse_u64EB2_.exit

_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchyNvCs4A2AHSyUD2M_17parse_number_core9parse_u64EB2_.exit: ; preds = %bb12.i.i.i.i, %bb8.i.i.i, %bb16.i.i.i, %bb5.i, %bb6.i, %bb11.i
  %_0.sroa.0.0.i = phi i1 [ false, %bb5.i ], [ true, %bb6.i ], [ false, %bb11.i ], [ false, %bb8.i.i.i ], [ false, %bb16.i.i.i ], [ false, %bb12.i.i.i.i ]
  ret i1 %_0.sroa.0.0.i
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #2

declare i32 @__CxxFrameHandler3(...) unnamed_addr #3

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind uwtable
declare void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull, ptr noundef nonnull, i1 noundef zeroext, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #4

attributes #0 = { inlinehint nounwind uwtable "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #1 = { nounwind uwtable "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #3 = { "target-cpu"="x86-64" }
attributes #4 = { cold noinline noreturn nounwind uwtable "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #5 = { noreturn nounwind }
attributes #6 = { nounwind }

!llvm.module.flags = !{!8, !9, !10}
!llvm.ident = !{!11}

!0 = !{i64 -3503158100470851476}
!1 = !{i64 -7163794490950503885}
!2 = !{i64 2184210303826323234}
!3 = !{i64 6165558784850197061}
!4 = !{i64 2019833075342934635}
!5 = !{i64 7815803183694710301}
!6 = !{i64 -1198223166051234772}
!7 = !{i64 2826628553247914406}
!8 = !{i32 8, !"PIC Level", i32 2}
!9 = !{i32 7, !"uwtable", i32 2}
!10 = !{i32 2, !"cfguard", i32 2}
!11 = !{!"rustc version 1.101.0-nightly (41b321963 2026-10-29) (96a18bf5ffa2b24f9cf3d1c731a9eb121c1acad9-4-llvmorg-24-init-17044-gc3223914 chromium)"}
!12 = !{i64 7113128125050202306}
!13 = !{!"branch_weights", !"expected", i32 1, i32 2000}
!14 = !{!15}
!15 = distinct !{!15, !16, !"_RNvMs2H_NtNtCs9l4wcBNbII5_4core5slice4iterINtB6_4IterhE10make_sliceCsiOOgJ5cnKHw_11numeric_ffi: %self"}
!16 = distinct !{!16, i1 true, !"_RNvMs2H_NtNtCs9l4wcBNbII5_4core5slice4iterINtB6_4IterhE10make_sliceCsiOOgJ5cnKHw_11numeric_ffi"}
!17 = !{!18}
!18 = distinct !{!18, !19, !"_RINvXs2J_NtNtCs9l4wcBNbII5_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator3allNvMs4_NtBb_3numh14is_ascii_digitECsiOOgJ5cnKHw_11numeric_ffi: %self"}
!19 = distinct !{!19, i1 true, !"_RINvXs2J_NtNtCs9l4wcBNbII5_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator3allNvMs4_NtBb_3numh14is_ascii_digitECsiOOgJ5cnKHw_11numeric_ffi"}
!20 = !{}
!21 = !{i64 8319556262770079865}
!22 = !{!"branch_weights", i32 6003000, i32 -294967296}
!23 = !{!24, !26, !28}
!24 = distinct !{!24, !25, !"_RINvCs4A2AHSyUD2M_17parse_number_core11parse_sliceKy7fffffff_Ky80000000_ECsiOOgJ5cnKHw_11numeric_ffi: %input.0"}
!25 = distinct !{!25, i1 true, !"_RINvCs4A2AHSyUD2M_17parse_number_core11parse_sliceKy7fffffff_Ky80000000_ECsiOOgJ5cnKHw_11numeric_ffi"}
!26 = distinct !{!26, !27, !"_RNvCs4A2AHSyUD2M_17parse_number_core9parse_i32: %input.0"}
!27 = distinct !{!27, i1 true, !"_RNvCs4A2AHSyUD2M_17parse_number_core9parse_i32"}
!28 = distinct !{!28, !29, !"_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi: argument 0"}
!29 = distinct !{!29, i1 true, !"_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi"}
!30 = !{!31, !33, !35}
!31 = distinct !{!31, !32, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next: %self"}
!32 = distinct !{!32, i1 true, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next"}
!33 = distinct !{!33, !34, !"_RINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy7fffffff_NtB2_10SliceBytesECsiOOgJ5cnKHw_11numeric_ffi: %_0"}
!34 = distinct !{!34, i1 true, !"_RINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy7fffffff_NtB2_10SliceBytesECsiOOgJ5cnKHw_11numeric_ffi"}
!35 = distinct !{!35, !36, !"_RINvCs4A2AHSyUD2M_17parse_number_core14parse_unsignedKy7fffffff_NtB2_10SliceBytesECsiOOgJ5cnKHw_11numeric_ffi: %_0"}
!36 = distinct !{!36, i1 true, !"_RINvCs4A2AHSyUD2M_17parse_number_core14parse_unsignedKy7fffffff_NtB2_10SliceBytesECsiOOgJ5cnKHw_11numeric_ffi"}
!37 = !{!38, !40}
!38 = distinct !{!38, !39, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next: %self"}
!39 = distinct !{!39, i1 true, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next"}
!40 = distinct !{!40, !41, !"_RINvCs4A2AHSyUD2M_17parse_number_core5parseKy7fffffff_Ky80000000_NtB2_10SliceBytesECsiOOgJ5cnKHw_11numeric_ffi: %_0"}
!41 = distinct !{!41, i1 true, !"_RINvCs4A2AHSyUD2M_17parse_number_core5parseKy7fffffff_Ky80000000_NtB2_10SliceBytesECsiOOgJ5cnKHw_11numeric_ffi"}
!42 = !{!43, !40}
!43 = distinct !{!43, !44, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next: %self"}
!44 = distinct !{!44, i1 true, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next"}
!45 = !{!46, !48, !40}
!46 = distinct !{!46, !47, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next: %self"}
!47 = distinct !{!47, i1 true, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next"}
!48 = distinct !{!48, !49, !"_RINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy7fffffff_NtB2_10SliceBytesECsiOOgJ5cnKHw_11numeric_ffi: %_0"}
!49 = distinct !{!49, i1 true, !"_RINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy7fffffff_NtB2_10SliceBytesECsiOOgJ5cnKHw_11numeric_ffi"}
!50 = !{!51, !53, !40}
!51 = distinct !{!51, !52, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next: %self"}
!52 = distinct !{!52, i1 true, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next"}
!53 = distinct !{!53, !54, !"_RINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy80000000_NtB2_10SliceBytesECsiOOgJ5cnKHw_11numeric_ffi: %_0"}
!54 = distinct !{!54, i1 true, !"_RINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy80000000_NtB2_10SliceBytesECsiOOgJ5cnKHw_11numeric_ffi"}
!55 = !{!56}
!56 = distinct !{!56, !25, !"_RINvCs4A2AHSyUD2M_17parse_number_core11parse_sliceKy7fffffff_Ky80000000_ECsiOOgJ5cnKHw_11numeric_ffi: %_0"}
!57 = !{i64 6076576142214827742}
!58 = !{!59, !61, !63}
!59 = distinct !{!59, !60, !"_RINvCs4A2AHSyUD2M_17parse_number_core11parse_sliceKy7fffffffffffffff_Ky8000000000000000_ECsiOOgJ5cnKHw_11numeric_ffi: %input.0"}
!60 = distinct !{!60, i1 true, !"_RINvCs4A2AHSyUD2M_17parse_number_core11parse_sliceKy7fffffffffffffff_Ky8000000000000000_ECsiOOgJ5cnKHw_11numeric_ffi"}
!61 = distinct !{!61, !62, !"_RNvCs4A2AHSyUD2M_17parse_number_core9parse_i64: %input.0"}
!62 = distinct !{!62, i1 true, !"_RNvCs4A2AHSyUD2M_17parse_number_core9parse_i64"}
!63 = distinct !{!63, !64, !"_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i64INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi: argument 1"}
!64 = distinct !{!64, i1 true, !"_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i64INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi"}
!65 = !{!66, !68, !70}
!66 = distinct !{!66, !67, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next: %self"}
!67 = distinct !{!67, i1 true, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next"}
!68 = distinct !{!68, !69, !"_RINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy7fffffffffffffff_NtB2_10SliceBytesECsiOOgJ5cnKHw_11numeric_ffi: %_0"}
!69 = distinct !{!69, i1 true, !"_RINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy7fffffffffffffff_NtB2_10SliceBytesECsiOOgJ5cnKHw_11numeric_ffi"}
!70 = distinct !{!70, !71, !"_RINvCs4A2AHSyUD2M_17parse_number_core14parse_unsignedKy7fffffffffffffff_NtB2_10SliceBytesECsiOOgJ5cnKHw_11numeric_ffi: %_0"}
!71 = distinct !{!71, i1 true, !"_RINvCs4A2AHSyUD2M_17parse_number_core14parse_unsignedKy7fffffffffffffff_NtB2_10SliceBytesECsiOOgJ5cnKHw_11numeric_ffi"}
!72 = !{!73, !75}
!73 = distinct !{!73, !74, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next: %self"}
!74 = distinct !{!74, i1 true, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next"}
!75 = distinct !{!75, !76, !"_RINvCs4A2AHSyUD2M_17parse_number_core5parseKy7fffffffffffffff_Ky8000000000000000_NtB2_10SliceBytesECsiOOgJ5cnKHw_11numeric_ffi: %_0"}
!76 = distinct !{!76, i1 true, !"_RINvCs4A2AHSyUD2M_17parse_number_core5parseKy7fffffffffffffff_Ky8000000000000000_NtB2_10SliceBytesECsiOOgJ5cnKHw_11numeric_ffi"}
!77 = !{!78, !75}
!78 = distinct !{!78, !79, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next: %self"}
!79 = distinct !{!79, i1 true, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next"}
!80 = !{!81, !83, !75}
!81 = distinct !{!81, !82, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next: %self"}
!82 = distinct !{!82, i1 true, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next"}
!83 = distinct !{!83, !84, !"_RINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy7fffffffffffffff_NtB2_10SliceBytesECsiOOgJ5cnKHw_11numeric_ffi: %_0"}
!84 = distinct !{!84, i1 true, !"_RINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy7fffffffffffffff_NtB2_10SliceBytesECsiOOgJ5cnKHw_11numeric_ffi"}
!85 = !{!86, !88, !75}
!86 = distinct !{!86, !87, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next: %self"}
!87 = distinct !{!87, i1 true, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next"}
!88 = distinct !{!88, !89, !"_RINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy8000000000000000_NtB2_10SliceBytesECsiOOgJ5cnKHw_11numeric_ffi: %_0"}
!89 = distinct !{!89, i1 true, !"_RINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy8000000000000000_NtB2_10SliceBytesECsiOOgJ5cnKHw_11numeric_ffi"}
!90 = !{!91, !92, !93}
!91 = distinct !{!91, !60, !"_RINvCs4A2AHSyUD2M_17parse_number_core11parse_sliceKy7fffffffffffffff_Ky8000000000000000_ECsiOOgJ5cnKHw_11numeric_ffi: %_0"}
!92 = distinct !{!92, !62, !"_RNvCs4A2AHSyUD2M_17parse_number_core9parse_i64: %_0"}
!93 = distinct !{!93, !64, !"_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i64INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi: %_0"}
!94 = !{i64 -5003817264122049413}
!95 = !{!96, !98}
!96 = distinct !{!96, !97, !"_RNvCs4A2AHSyUD2M_17parse_number_core9parse_u32: %input.0"}
!97 = distinct !{!97, i1 true, !"_RNvCs4A2AHSyUD2M_17parse_number_core9parse_u32"}
!98 = distinct !{!98, !99, !"_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi: argument 0"}
!99 = distinct !{!99, i1 true, !"_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi"}
!100 = !{!101, !103}
!101 = distinct !{!101, !102, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next: %self"}
!102 = distinct !{!102, i1 true, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next"}
!103 = distinct !{!103, !104, !"_RINvCs4A2AHSyUD2M_17parse_number_core14parse_unsignedKyffffffff_NtB2_10SliceBytesECsiOOgJ5cnKHw_11numeric_ffi: %_0"}
!104 = distinct !{!104, i1 true, !"_RINvCs4A2AHSyUD2M_17parse_number_core14parse_unsignedKyffffffff_NtB2_10SliceBytesECsiOOgJ5cnKHw_11numeric_ffi"}
!105 = !{!106, !108, !103}
!106 = distinct !{!106, !107, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next: %self"}
!107 = distinct !{!107, i1 true, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next"}
!108 = distinct !{!108, !109, !"_RINvCs4A2AHSyUD2M_17parse_number_core10accumulateKyffffffff_NtB2_10SliceBytesECsiOOgJ5cnKHw_11numeric_ffi: %_0"}
!109 = distinct !{!109, i1 true, !"_RINvCs4A2AHSyUD2M_17parse_number_core10accumulateKyffffffff_NtB2_10SliceBytesECsiOOgJ5cnKHw_11numeric_ffi"}
!110 = !{!108, !103}
!111 = !{i64 7517475993067217578}
!112 = !{!113, !115}
!113 = distinct !{!113, !114, !"_RNvCs4A2AHSyUD2M_17parse_number_core9parse_u64: %input.0"}
!114 = distinct !{!114, i1 true, !"_RNvCs4A2AHSyUD2M_17parse_number_core9parse_u64"}
!115 = distinct !{!115, !116, !"_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u64INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi: argument 1"}
!116 = distinct !{!116, i1 true, !"_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u64INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi"}
!117 = !{!118, !120}
!118 = distinct !{!118, !119, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next: %self"}
!119 = distinct !{!119, i1 true, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next"}
!120 = distinct !{!120, !121, !"_RINvCs4A2AHSyUD2M_17parse_number_core14parse_unsignedKyffffffffffffffff_NtB2_10SliceBytesECsiOOgJ5cnKHw_11numeric_ffi: %_0"}
!121 = distinct !{!121, i1 true, !"_RINvCs4A2AHSyUD2M_17parse_number_core14parse_unsignedKyffffffffffffffff_NtB2_10SliceBytesECsiOOgJ5cnKHw_11numeric_ffi"}
!122 = !{!123, !125, !120}
!123 = distinct !{!123, !124, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next: %self"}
!124 = distinct !{!124, i1 true, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next"}
!125 = distinct !{!125, !126, !"_RINvCs4A2AHSyUD2M_17parse_number_core10accumulateKyffffffffffffffff_NtB2_10SliceBytesECsiOOgJ5cnKHw_11numeric_ffi: %_0"}
!126 = distinct !{!126, i1 true, !"_RINvCs4A2AHSyUD2M_17parse_number_core10accumulateKyffffffffffffffff_NtB2_10SliceBytesECsiOOgJ5cnKHw_11numeric_ffi"}
!127 = !{!125, !120, !128, !129}
!128 = distinct !{!128, !114, !"_RNvCs4A2AHSyUD2M_17parse_number_core9parse_u64: %_0"}
!129 = distinct !{!129, !116, !"_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u64INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi: %_0"}
