; ModuleID = 'range_ffi.c63e0d924bc54e24-cgu.0'
source_filename = "range_ffi.c63e0d924bc54e24-cgu.0"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc"

%"core::sync::atomic::Atomic<*mut ()>" = type { %"core::cell::UnsafeCell<core::sync::atomic::private::Align8<*mut ()>>" }
%"core::cell::UnsafeCell<core::sync::atomic::private::Align8<*mut ()>>" = type { %"core::sync::atomic::private::Align8<*mut ()>" }
%"core::sync::atomic::private::Align8<*mut ()>" = type { ptr }

@alloc_9f2c9333733542a0fa241eb525d38504 = private unnamed_addr constant [41 x i8] c"D:\\Rustium\\net\\http\\http_range_parser.rs\00", align 1, !guid !0
@alloc_c712be591025e6a1f0f9ed6c6808275b = private unnamed_addr constant [91 x i8] c"D:\\Rustium\\third_party\\rust\\chromium_crates_io\\vendor\\memchr-v2\\src\\arch\\generic\\memchr.rs\00", align 1, !guid !1
@alloc_a59d8fe4279b26f926811f91f116a398 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_c712be591025e6a1f0f9ed6c6808275b, [16 x i8] c"Z\00\00\00\00\00\00\00s\04\00\00\09\00\00\00" }>, align 8, !guid !2
@alloc_87e6578268e354c4f2747b30d32a9b4e = private unnamed_addr constant [31 x i8] c"library\\core\\src\\slice\\iter.rs\00", align 1, !guid !3
@alloc_1d1b1e35bb489427b2bdc9752de92226 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_87e6578268e354c4f2747b30d32a9b4e, [16 x i8] c"\1E\00\00\00\00\00\00\00\8C\00\00\00\01\00\00\00" }>, align 8, !guid !4
@alloc_1bb48cd636a7e77d2a1a241c967005fc = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9f2c9333733542a0fa241eb525d38504, [16 x i8] c"(\00\00\00\00\00\00\00\DD\00\00\00\15\00\00\00" }>, align 8, !guid !5
@alloc_cd7dc146611f1efd96d87a1399113f8c = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9f2c9333733542a0fa241eb525d38504, [16 x i8] c"(\00\00\00\00\00\00\00\DE\00\00\002\00\00\00" }>, align 8, !guid !6
@alloc_6ca9fc8d99acf98ecf00d162e0ad6d5e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9f2c9333733542a0fa241eb525d38504, [16 x i8] c"(\00\00\00\00\00\00\00\DD\00\00\002\00\00\00" }>, align 8, !guid !7
@alloc_16cbcd9a81ccfa6f0d62eca93b6e0394 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9f2c9333733542a0fa241eb525d38504, [16 x i8] c"(\00\00\00\00\00\00\00\DA\00\00\00\18\00\00\00" }>, align 8, !guid !8
@alloc_5fd5ad9d8a4f43eaaa74e75f1fc82bac = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9f2c9333733542a0fa241eb525d38504, [16 x i8] c"(\00\00\00\00\00\00\00\D9\00\00\00.\00\00\00" }>, align 8, !guid !9
@alloc_f9be6c591f7e00dc1cf1dc33e68f267a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9f2c9333733542a0fa241eb525d38504, [16 x i8] c"(\00\00\00\00\00\00\00\E8\00\00\00D\00\00\00" }>, align 8, !guid !10
@alloc_0a48ea62e5579eec5969b23ab3020878 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9f2c9333733542a0fa241eb525d38504, [16 x i8] c"(\00\00\00\00\00\00\00\EE\00\00\00F\00\00\00" }>, align 8, !guid !11
@_RNvNvNtNtNtCskuZNHgLkVkS_6memchr4arch6x86_646memchr10memchr_raw2FN = external dllimport local_unnamed_addr global %"core::sync::atomic::Atomic<*mut ()>"
@alloc_3c266a9d2054e14c937438e9636b5cb5 = private unnamed_addr constant [38 x i8] c"D:\\Rustium\\net\\http\\http_range_ffi.rs\00", align 1, !guid !12
@alloc_56c01fe01d1a47ca560ad2a33d46aaec = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_3c266a9d2054e14c937438e9636b5cb5, [16 x i8] c"%\00\00\00\00\00\00\008\00\00\00\12\00\00\00" }>, align 8, !guid !13
@alloc_6b2d6f9c10483c97dd45df2e37fdbaf3 = private unnamed_addr constant [27 x i8] c"library\\alloc\\src\\alloc.rs\00", align 1, !guid !14
@alloc_1b98de0e82d923a9daff35d520cf360d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_6b2d6f9c10483c97dd45df2e37fdbaf3, [16 x i8] c"\1A\00\00\00\00\00\00\00~\01\00\00\11\00\00\00" }>, align 8, !guid !15
@alloc_24f4768e38f126368567621cf7f11fcd = private unnamed_addr constant [33 x i8] c"library\\alloc\\src\\raw_vec\\mod.rs\00", align 1, !guid !16
@alloc_ad088eaa3dc0ae68b11fd72bfcf5e34b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_24f4768e38f126368567621cf7f11fcd, [16 x i8] c" \00\00\00\00\00\00\00\98\02\00\005\00\00\00" }>, align 8, !guid !17
@alloc_dade1aed0d0fe800cb3ecdb07302e098 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_24f4768e38f126368567621cf7f11fcd, [16 x i8] c" \00\00\00\00\00\00\00\99\02\00\00\1E\00\00\00" }>, align 8, !guid !18
@alloc_5a885d3db7500f26d581e948d37c49fe = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_24f4768e38f126368567621cf7f11fcd, [16 x i8] c" \00\00\00\00\00\00\00C\02\00\00\11\00\00\00" }>, align 8, !guid !19
@alloc_df10a442b0b4a87147a8f65479b3c67a = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_9f2c9333733542a0fa241eb525d38504, [16 x i8] c"(\00\00\00\00\00\00\00\A9\00\00\00\1E\00\00\00" }>, align 8, !guid !20
@alloc_1be5ea12ba708d9a11b6e93a7d387a75 = private unnamed_addr constant [281 x i8] c"unsafe precondition(s) violated: Layout::from_size_align_unchecked requires that align is a power of 2 and the rounded-up allocation size does not exceed isize::MAX\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !21
@alloc_560a59ed819b9d9a5841f6e731c4c8e5 = private unnamed_addr constant [210 x i8] c"unsafe precondition(s) violated: NonNull::new_unchecked requires that the pointer is non-null\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !22
@alloc_db07ae5a9ce650d9b7cc970d048e6f0c = private unnamed_addr constant [186 x i8] c"unsafe precondition(s) violated: usize::unchecked_mul cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !23
@alloc_82a99021b1306c9239507412b95c0e74 = private unnamed_addr constant [205 x i8] c"unsafe precondition(s) violated: Vec::from_raw_parts_in requires that length <= capacity\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !24
@alloc_64e308ef4babfeb8b6220184de794a17 = private unnamed_addr constant [221 x i8] c"unsafe precondition(s) violated: hint::assert_unchecked must never be called when the condition is false\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !25
@alloc_75fb06c2453febd814e73f5f2e72ae38 = private unnamed_addr constant [199 x i8] c"unsafe precondition(s) violated: hint::unreachable_unchecked must never be reached\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !26
@alloc_a28e8c8fd5088943a8b5d44af697ff83 = private unnamed_addr constant [279 x i8] c"unsafe precondition(s) violated: slice::from_raw_parts requires the pointer to be aligned and non-null, and the total size of the slice not to exceed `isize::MAX`\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !27
@alloc_03e70bdcab636393a4206dfdf6ac4e05 = private unnamed_addr constant [75 x i8] c"D:\\Rustium\\third_party\\rust\\chromium_crates_io\\vendor\\memchr-v2\\src\\ext.rs\00", align 1, !guid !28
@alloc_6d855724149bc5132e1bc43bfd525250 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_03e70bdcab636393a4206dfdf6ac4e05, [16 x i8] c"J\00\00\00\00\00\00\00\17\00\00\003\00\00\00" }>, align 8, !guid !29
@alloc_2728436149d2d0d1e5775c8099d441a1 = private unnamed_addr constant [29 x i8] c"library\\alloc\\src\\vec\\mod.rs\00", align 1, !guid !30
@alloc_5b8d19018527d26ed8c47fbaf3eafd4f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_2728436149d2d0d1e5775c8099d441a1, [16 x i8] c"\1C\00\00\00\00\00\00\00m\04\00\00\09\00\00\00" }>, align 8, !guid !31
@alloc_91244a802f615a731e570cd82aa5f107 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_24f4768e38f126368567621cf7f11fcd, [16 x i8] c" \00\00\00\00\00\00\00k\02\00\00\1E\00\00\00" }>, align 8, !guid !32

; parse_number_core::parse_slice::<9223372036854775807, 9223372036854775808>
; Function Attrs: inlinehint nofree norecurse nosync nounwind memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable
define internal fastcc void @_RINvCs4A2AHSyUD2M_17parse_number_core11parse_sliceKy7fffffffffffffff_Ky8000000000000000_ECsh1eR4S1pMdQ_9range_ffi(ptr dead_on_unwind noalias nofree noundef nonnull writable writeonly align 8 captures(none) dereferenceable(16) %_0, ptr noalias nofree noundef nonnull readonly captures(address) %input.0, i64 noundef range(i64 0, -9223372036854775808) %input.1, i32 noundef range(i32 0, 2) %format) unnamed_addr #0 !guid !37 {
start:
  %_14 = getelementptr inbounds nuw i8, ptr %input.0, i64 %input.1
  %cond = icmp eq i64 %input.1, 0
  br i1 %cond, label %bb12, label %bb8

bb8:                                              ; preds = %start
  %0 = load i8, ptr %input.0, align 1, !noundef !38
  switch i8 %0, label %bb17.i [
    i8 45, label %bb2
    i8 48, label %bb2
  ]

bb17.i:                                           ; preds = %bb8
  %digit.i = add i8 %0, -48
  %_11.i = icmp ugt i8 %digit.i, 9
  br i1 %_11.i, label %bb12, label %bb11.i

bb11.i:                                           ; preds = %bb17.i
  %_15.i = zext nneg i8 %digit.i to i64
  %_5.i.not11.i.i = icmp samesign eq i64 %input.1, 1
  br i1 %_5.i.not11.i.i, label %bb13, label %bb4.i.i.preheader

bb4.i.i.preheader:                                ; preds = %bb11.i
  %_11.i.i = getelementptr inbounds nuw i8, ptr %input.0, i64 1
  br label %bb4.i.i

bb4.i.i:                                          ; preds = %bb4.i.i.preheader, %bb20.i.i
  %value.sroa.0.013.i.i = phi i64 [ %1, %bb20.i.i ], [ %_15.i, %bb4.i.i.preheader ]
  %bytes.sroa.0.012.i.i = phi ptr [ %_11.i.i.i, %bb20.i.i ], [ %_11.i.i, %bb4.i.i.preheader ]
  %_11.i.i.i = getelementptr inbounds nuw i8, ptr %bytes.sroa.0.012.i.i, i64 1
  %_13.i.i.i = load i8, ptr %bytes.sroa.0.012.i.i, align 1, !noalias !39, !noundef !38
  %_10.i.i = add i8 %_13.i.i.i, -48
  %digit.i.i = zext nneg i8 %_10.i.i to i64
  %_11.i4.i = icmp ugt i8 %_10.i.i, 9
  br i1 %_11.i4.i, label %bb12, label %bb7.i.i

bb7.i.i:                                          ; preds = %bb4.i.i
  %_12.i.i = icmp ugt i64 %value.sroa.0.013.i.i, 922337203685477580
  br i1 %_12.i.i, label %bb12, label %bb9.i.i

bb9.i.i:                                          ; preds = %bb7.i.i
  %_15.i.i = icmp eq i64 %value.sroa.0.013.i.i, 922337203685477580
  %_17.i.i = icmp samesign ugt i8 %_10.i.i, 7
  %or.cond.i.i = and i1 %_15.i.i, %_17.i.i
  br i1 %or.cond.i.i, label %bb12, label %bb20.i.i

bb20.i.i:                                         ; preds = %bb9.i.i
  %_21.i.i = mul nuw nsw i64 %value.sroa.0.013.i.i, 10
  %1 = add nuw i64 %_21.i.i, %digit.i.i
  %_5.i.not.i.i = icmp eq ptr %_11.i.i.i, %_14
  br i1 %_5.i.not.i.i, label %bb13, label %bb4.i.i

bb2:                                              ; preds = %bb8, %bb8
  tail call void @llvm.experimental.noalias.scope.decl(metadata !46)
  %_11.i.i2 = getelementptr inbounds nuw i8, ptr %input.0, i64 1
  %negative.i = icmp eq i8 %0, 45
  %2 = add nsw i8 %0, -48
  %or.cond.i = icmp ult i8 %2, 10
  br i1 %or.cond.i, label %bb28.i.preheader, label %bb10.i

bb10.i:                                           ; preds = %bb2
  %3 = icmp ne i32 %format, 0
  %or.cond3.not.i = and i1 %3, %negative.i
  br i1 %or.cond3.not.i, label %bb12.i, label %bb14.i

bb14.i:                                           ; preds = %bb10.i
  store i8 3, ptr %_0, align 8, !alias.scope !46
  %4 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i8 2, ptr %4, align 8, !alias.scope !46
  br label %bb7

bb12.i:                                           ; preds = %bb10.i
  %_5.i23.not.i = icmp samesign eq i64 %input.1, 1
  br i1 %_5.i23.not.i, label %bb51.i, label %bb25.i

bb51.i:                                           ; preds = %bb12.i
  store i8 3, ptr %_0, align 8, !alias.scope !46
  %5 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i8 2, ptr %5, align 8, !alias.scope !46
  br label %bb7

bb25.i:                                           ; preds = %bb12.i
  %_11.i26.i = getelementptr inbounds nuw i8, ptr %input.0, i64 2
  %_13.i27.i = load i8, ptr %_11.i.i2, align 1, !noalias !49, !noundef !38
  %6 = icmp eq i8 %_13.i27.i, 48
  br i1 %6, label %bb28.i.preheader, label %bb34.i

bb28.i.preheader:                                 ; preds = %bb2, %bb25.i
  %bytes.sroa.0.0.i32 = phi ptr [ %_11.i26.i, %bb25.i ], [ %_11.i.i2, %bb2 ]
  %_5.i31.not.i3 = icmp eq ptr %bytes.sroa.0.0.i32, %_14
  br i1 %_5.i31.not.i3, label %bb31.i, label %bb30.i

bb28.i:                                           ; preds = %bb30.i
  %_5.i31.not.i = icmp eq ptr %_11.i34.i, %_14
  br i1 %_5.i31.not.i, label %bb31.i, label %bb30.i

bb30.i:                                           ; preds = %bb28.i.preheader, %bb28.i
  %bytes.sroa.0.1.i4 = phi ptr [ %_11.i34.i, %bb28.i ], [ %bytes.sroa.0.0.i32, %bb28.i.preheader ]
  %_11.i34.i = getelementptr inbounds nuw i8, ptr %bytes.sroa.0.1.i4, i64 1
  %_13.i35.i = load i8, ptr %bytes.sroa.0.1.i4, align 1, !noalias !52, !noundef !38
  %7 = icmp eq i8 %_13.i35.i, 48
  br i1 %7, label %bb28.i, label %bb34.i

bb31.i:                                           ; preds = %bb28.i, %bb28.i.preheader
  store i64 0, ptr %_0, align 8, !alias.scope !46
  %8 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  %9 = zext i1 %negative.i to i8
  store i8 %9, ptr %8, align 8, !alias.scope !46
  br label %bb7

bb34.i:                                           ; preds = %bb30.i, %bb25.i
  %bytes.sroa.0.2.i = phi ptr [ %_11.i26.i, %bb25.i ], [ %_11.i34.i, %bb30.i ]
  %first.sroa.0.1.i = phi i8 [ %_13.i27.i, %bb25.i ], [ %_13.i35.i, %bb30.i ]
  %_28.i = add i8 %first.sroa.0.1.i, -48
  %digit.i4 = zext i8 %_28.i to i64
  %_29.i = icmp ugt i8 %_28.i, 9
  br i1 %_29.i, label %bb35.i, label %bb36.i

bb36.i:                                           ; preds = %bb34.i
  %_5.i.not11.i38.i = icmp eq ptr %bytes.sroa.0.2.i, %_14
  br i1 %negative.i, label %bb37.i, label %bb38.i

bb35.i:                                           ; preds = %bb34.i
  store i8 3, ptr %_0, align 8, !alias.scope !46
  %10 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i8 2, ptr %10, align 8, !alias.scope !46
  br label %bb7

bb38.i:                                           ; preds = %bb36.i
  br i1 %_5.i.not11.i38.i, label %bb61.i, label %bb4.i.i5

bb4.i.i5:                                         ; preds = %bb38.i, %bb20.i.i18
  %value.sroa.0.013.i.i6 = phi i64 [ %11, %bb20.i.i18 ], [ %digit.i4, %bb38.i ]
  %bytes.sroa.0.012.i.i7 = phi ptr [ %_11.i.i.i8, %bb20.i.i18 ], [ %bytes.sroa.0.2.i, %bb38.i ]
  %_11.i.i.i8 = getelementptr inbounds nuw i8, ptr %bytes.sroa.0.012.i.i7, i64 1
  %_13.i.i.i9 = load i8, ptr %bytes.sroa.0.012.i.i7, align 1, !noalias !55, !noundef !38
  %_10.i.i10 = add i8 %_13.i.i.i9, -48
  %digit.i.i11 = zext nneg i8 %_10.i.i10 to i64
  %_11.i37.i = icmp ugt i8 %_10.i.i10, 9
  br i1 %_11.i37.i, label %bb60.i, label %bb7.i.i12

bb7.i.i12:                                        ; preds = %bb4.i.i5
  %_12.i.i13 = icmp ugt i64 %value.sroa.0.013.i.i6, 922337203685477580
  br i1 %_12.i.i13, label %bb60.i, label %bb9.i.i14

bb9.i.i14:                                        ; preds = %bb7.i.i12
  %_15.i.i15 = icmp eq i64 %value.sroa.0.013.i.i6, 922337203685477580
  %_17.i.i16 = icmp samesign ugt i8 %_10.i.i10, 7
  %or.cond.i.i17 = and i1 %_15.i.i15, %_17.i.i16
  br i1 %or.cond.i.i17, label %bb60.i, label %bb20.i.i18

bb20.i.i18:                                       ; preds = %bb9.i.i14
  %_21.i.i19 = mul nuw nsw i64 %value.sroa.0.013.i.i6, 10
  %11 = add nuw i64 %_21.i.i19, %digit.i.i11
  %_5.i.not.i.i20 = icmp eq ptr %_11.i.i.i8, %_14
  br i1 %_5.i.not.i.i20, label %bb61.i, label %bb4.i.i5

bb37.i:                                           ; preds = %bb36.i
  br i1 %_5.i.not11.i38.i, label %bb54.i, label %bb4.i39.i

bb4.i39.i:                                        ; preds = %bb37.i, %bb20.i53.i
  %value.sroa.0.013.i40.i = phi i64 [ %12, %bb20.i53.i ], [ %digit.i4, %bb37.i ]
  %bytes.sroa.0.012.i41.i = phi ptr [ %_11.i.i42.i, %bb20.i53.i ], [ %bytes.sroa.0.2.i, %bb37.i ]
  %_11.i.i42.i = getelementptr inbounds nuw i8, ptr %bytes.sroa.0.012.i41.i, i64 1
  %_13.i.i43.i = load i8, ptr %bytes.sroa.0.012.i41.i, align 1, !noalias !60, !noundef !38
  %_10.i44.i = add i8 %_13.i.i43.i, -48
  %digit.i45.i = zext nneg i8 %_10.i44.i to i64
  %_11.i46.i = icmp ugt i8 %_10.i44.i, 9
  br i1 %_11.i46.i, label %bb53.i, label %bb7.i47.i

bb7.i47.i:                                        ; preds = %bb4.i39.i
  %_12.i48.i = icmp ugt i64 %value.sroa.0.013.i40.i, 922337203685477580
  br i1 %_12.i48.i, label %bb53.i, label %bb9.i49.i

bb9.i49.i:                                        ; preds = %bb7.i47.i
  %_15.i50.i = icmp eq i64 %value.sroa.0.013.i40.i, 922337203685477580
  %_17.i51.i = icmp eq i8 %_10.i44.i, 9
  %or.cond.i52.i = and i1 %_15.i50.i, %_17.i51.i
  br i1 %or.cond.i52.i, label %bb53.i, label %bb20.i53.i

bb20.i53.i:                                       ; preds = %bb9.i49.i
  %_21.i54.i = mul nuw nsw i64 %value.sroa.0.013.i40.i, 10
  %12 = add nuw i64 %_21.i54.i, %digit.i45.i
  %_5.i.not.i55.i = icmp eq ptr %_11.i.i42.i, %_14
  br i1 %_5.i.not.i55.i, label %bb54.i, label %bb4.i39.i

bb60.i:                                           ; preds = %bb9.i.i14, %bb7.i.i12, %bb4.i.i5
  %_33.sroa.4.0.ph.i = phi i8 [ 1, %bb7.i.i12 ], [ 1, %bb9.i.i14 ], [ 3, %bb4.i.i5 ]
  store i8 %_33.sroa.4.0.ph.i, ptr %_0, align 8, !alias.scope !46
  %13 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i8 2, ptr %13, align 8, !alias.scope !46
  br label %bb7

bb61.i:                                           ; preds = %bb20.i.i18, %bb38.i
  %_33.sroa.762.0.i = phi i64 [ %digit.i4, %bb38.i ], [ %11, %bb20.i.i18 ]
  store i64 %_33.sroa.762.0.i, ptr %_0, align 8, !alias.scope !46
  %14 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i8 0, ptr %14, align 8, !alias.scope !46
  br label %bb7

bb53.i:                                           ; preds = %bb9.i49.i, %bb7.i47.i, %bb4.i39.i
  %15 = phi i8 [ 3, %bb4.i39.i ], [ 2, %bb7.i47.i ], [ 2, %bb9.i49.i ]
  store i8 %15, ptr %_0, align 8, !alias.scope !46
  %16 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i8 2, ptr %16, align 8, !alias.scope !46
  br label %bb7

bb54.i:                                           ; preds = %bb20.i53.i, %bb37.i
  %_31.sroa.861.0.i = phi i64 [ %digit.i4, %bb37.i ], [ %12, %bb20.i53.i ]
  store i64 %_31.sroa.861.0.i, ptr %_0, align 8, !alias.scope !46
  %17 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i8 1, ptr %17, align 8, !alias.scope !46
  br label %bb7

bb7:                                              ; preds = %bb13, %bb12, %bb54.i, %bb53.i, %bb61.i, %bb60.i, %bb35.i, %bb31.i, %bb51.i, %bb14.i
  ret void

bb12:                                             ; preds = %bb4.i.i, %bb9.i.i, %bb7.i.i, %start, %bb17.i
  %_7.sroa.4.0.ph = phi i8 [ 3, %bb17.i ], [ 3, %start ], [ 3, %bb4.i.i ], [ 1, %bb9.i.i ], [ 1, %bb7.i.i ]
  store i8 %_7.sroa.4.0.ph, ptr %_0, align 8
  %18 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i8 2, ptr %18, align 8
  br label %bb7

bb13:                                             ; preds = %bb20.i.i, %bb11.i
  %_7.sroa.921.0 = phi i64 [ %_15.i, %bb11.i ], [ %1, %bb20.i.i ]
  store i64 %_7.sroa.921.0, ptr %_0, align 8
  %19 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i8 0, ptr %19, align 8
  br label %bb7
}

; range_ffi::bytes
; Function Attrs: nounwind uwtable
define { ptr, i64 } @_RNvCsh1eR4S1pMdQ_9range_ffi5bytes(ptr noundef %view.0, i64 noundef %view.1) unnamed_addr #1 personality ptr @__CxxFrameHandler3 !guid !65 {
start:
  %0 = icmp eq i64 %view.1, 0
  br i1 %0, label %bb3, label %bb2

bb2:                                              ; preds = %start
  %_12.not.i = icmp ne ptr %view.0, null
  %_7.i = icmp sgt i64 %view.1, -1
  %or.cond.i = and i1 %_12.not.i, %_7.i
  br i1 %or.cond.i, label %bb3, label %bb5.i, !prof !66

bb5.i:                                            ; preds = %bb2
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_a28e8c8fd5088943a8b5d44af697ff83, ptr noundef nonnull inttoptr (i64 559 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_56c01fe01d1a47ca560ad2a33d46aaec) #16
  unreachable

bb3:                                              ; preds = %bb2, %start
  %_0.sroa.0.0 = phi ptr [ inttoptr (i64 1 to ptr), %start ], [ %view.0, %bb2 ]
  %1 = insertvalue { ptr, i64 } poison, ptr %_0.sroa.0.0, 0
  %2 = insertvalue { ptr, i64 } %1, i64 %view.1, 1
  ret { ptr, i64 } %2
}

; <alloc::raw_vec::RawVec<range_ffi::ParsedRange>>::grow_one
; Function Attrs: cold noinline nounwind uwtable
define void @_RNvMs7_NtCs8tsiLsQ9XHg_5alloc7raw_vecINtB5_6RawVecNtCsh1eR4S1pMdQ_9range_ffi11ParsedRangeE8grow_oneBO_(ptr noalias nofree noundef align 8 captures(none) dereferenceable(16) %self) unnamed_addr #2 !guid !67 {
start:
  %self1 = load i64, ptr %self, align 8, !range !68, !noundef !38
; call <alloc::raw_vec::RawVecInner>::grow_amortized
  %0 = tail call fastcc { i64, i64 } @_RNvMs8_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14grow_amortizedCsh1eR4S1pMdQ_9range_ffi(ptr noalias nofree noundef align 8 dereferenceable(16) %self, i64 noundef %self1) #17
  %1 = extractvalue { i64, i64 } %0, 0
  %.not = icmp eq i64 %1, -1
  br i1 %.not, label %bb3, label %bb2, !prof !69

bb2:                                              ; preds = %start
  %2 = extractvalue { i64, i64 } %0, 1
; call alloc::raw_vec::handle_error
  tail call void @_RNvNtCs8tsiLsQ9XHg_5alloc7raw_vec12handle_error(i64 noundef %1, i64 %2) #16
  unreachable

bb3:                                              ; preds = %start
  ret void
}

; <alloc::raw_vec::RawVecInner>::finish_grow
; Function Attrs: cold nounwind uwtable
define internal fastcc void @_RNvMs8_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsh1eR4S1pMdQ_9range_ffi(ptr dead_on_unwind noalias nofree noundef nonnull writable writeonly align 8 captures(none) dereferenceable(24) %_0, i64 %self.0.val, ptr %self.8.val, i64 noundef range(i64 4, -1) %cap) unnamed_addr #3 !guid !70 {
start:
  %_10.sroa.5 = alloca i64, align 8
  %_10.sroa.8 = alloca i64, align 8
  %_32.0 = mul nuw nsw i64 %cap, 24
  %or.cond.not = icmp ugt i64 %cap, 384307168202282325
  br i1 %or.cond.not, label %bb14, label %bb12, !prof !71

bb12:                                             ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %_10.sroa.5)
  call void @llvm.lifetime.start.p0(ptr nonnull %_10.sroa.8)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !72)
  %0 = icmp eq i64 %self.0.val, 0
  br i1 %0, label %_RNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCsh1eR4S1pMdQ_9range_ffi.exit, label %bb4.i

bb4.i:                                            ; preds = %bb12
  %_7.1.i.i = icmp samesign ugt i64 %self.0.val, 768614336404564650
  br i1 %_7.1.i.i, label %bb1.i.i, label %_RNvNvMs9_NtCs9l4wcBNbII5_4core3numj13unchecked_mul18precondition_check.exit.i, !prof !75

bb1.i.i:                                          ; preds = %bb4.i
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_db07ae5a9ce650d9b7cc970d048e6f0c, ptr noundef nonnull inttoptr (i64 373 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_ad088eaa3dc0ae68b11fd72bfcf5e34b) #16, !noalias !72
  unreachable

_RNvNvMs9_NtCs9l4wcBNbII5_4core3numj13unchecked_mul18precondition_check.exit.i: ; preds = %bb4.i
  %_3.i.i = icmp samesign ult i64 %self.0.val, 384307168202282326
  br i1 %_3.i.i, label %_RNvNvMNtNtCs9l4wcBNbII5_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_check.exit.i, label %bb2.i.i, !prof !69

bb2.i.i:                                          ; preds = %_RNvNvMs9_NtCs9l4wcBNbII5_4core3numj13unchecked_mul18precondition_check.exit.i
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_1be5ea12ba708d9a11b6e93a7d387a75, ptr noundef nonnull inttoptr (i64 563 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_dade1aed0d0fe800cb3ecdb07302e098) #16, !noalias !72
  unreachable

_RNvNvMNtNtCs9l4wcBNbII5_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_check.exit.i: ; preds = %_RNvNvMs9_NtCs9l4wcBNbII5_4core3numj13unchecked_mul18precondition_check.exit.i
  %alloc_size.i = mul nuw nsw i64 %self.0.val, 24
  call void @llvm.assume(i1 true) [ "nonnull"(ptr %self.8.val) ]
  store i64 8, ptr %_10.sroa.5, align 8, !alias.scope !72
  br label %_RNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCsh1eR4S1pMdQ_9range_ffi.exit

_RNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCsh1eR4S1pMdQ_9range_ffi.exit: ; preds = %bb12, %_RNvNvMNtNtCs9l4wcBNbII5_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_check.exit.i
  %_10.sroa.0.0 = phi ptr [ undef, %bb12 ], [ %self.8.val, %_RNvNvMNtNtCs9l4wcBNbII5_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_check.exit.i ]
  %.sink.i.sroa.phi = phi ptr [ %_10.sroa.5, %bb12 ], [ %_10.sroa.8, %_RNvNvMNtNtCs9l4wcBNbII5_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_check.exit.i ]
  %alloc_size.sink.i = phi i64 [ 0, %bb12 ], [ %alloc_size.i, %_RNvNvMNtNtCs9l4wcBNbII5_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_check.exit.i ]
  store i64 %alloc_size.sink.i, ptr %.sink.i.sroa.phi, align 8, !alias.scope !72
  %_10.sroa.5.0._10.sroa.5.0._10.sroa.5.0._10.sroa.5.8. = load i64, ptr %_10.sroa.5, align 8, !range !76, !noundef !38
  %.not = icmp eq i64 %_10.sroa.5.0._10.sroa.5.0._10.sroa.5.0._10.sroa.5.8., 0
  br i1 %.not, label %bb4.i.i, label %bb3

bb14:                                             ; preds = %start
  %1 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 0, ptr %1, align 8
  br label %bb8

bb3:                                              ; preds = %_RNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCsh1eR4S1pMdQ_9range_ffi.exit
  call void @llvm.assume(i1 true) [ "nonnull"(ptr %_10.sroa.0.0) ]
  %_10.sroa.8.0._10.sroa.8.0._10.sroa.8.0._10.sroa.8.16.old_layout.1 = load i64, ptr %_10.sroa.8, align 8, !noundef !38
  %cond = icmp eq i64 %_10.sroa.5.0._10.sroa.5.0._10.sroa.5.0._10.sroa.5.8., 8
  br i1 %cond, label %_RNvNvNtCs9l4wcBNbII5_4core4hint16assert_unchecked18precondition_check.exit, label %bb1.i, !prof !69

bb1.i:                                            ; preds = %bb3
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_64e308ef4babfeb8b6220184de794a17, ptr noundef nonnull inttoptr (i64 443 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_5a885d3db7500f26d581e948d37c49fe) #16
  unreachable

_RNvNvNtCs9l4wcBNbII5_4core4hint16assert_unchecked18precondition_check.exit: ; preds = %bb3
  %2 = icmp eq i64 %_10.sroa.8.0._10.sroa.8.0._10.sroa.8.0._10.sroa.8.16.old_layout.1, 0
  br i1 %2, label %bb4.i.i.i, label %bb3.i.i

bb4.i.i.i:                                        ; preds = %_RNvNvNtCs9l4wcBNbII5_4core4hint16assert_unchecked18precondition_check.exit
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  tail call void @_RNvCs6d6XRwTwhVh_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #17
; call __rustc::__rust_alloc
  %3 = tail call noundef align 8 ptr @_RNvCs6d6XRwTwhVh_7___rustc12___rust_alloc(i64 noundef range(i64 0, 9223372036854775801) %_32.0, i64 noundef 8) #17
  br label %_RNvXs1_NtCs8tsiLsQ9XHg_5alloc5allocNtB5_6GlobalNtNtCs9l4wcBNbII5_4core5alloc9Allocator4grow.exit

bb3.i.i:                                          ; preds = %_RNvNvNtCs9l4wcBNbII5_4core4hint16assert_unchecked18precondition_check.exit
  %cond.not.i.i = icmp ult i64 %_32.0, %_10.sroa.8.0._10.sroa.8.0._10.sroa.8.0._10.sroa.8.16.old_layout.1
  br i1 %cond.not.i.i, label %bb1.i.i.i, label %_RNvNvNtCs9l4wcBNbII5_4core4hint16assert_unchecked18precondition_check.exit.i.i, !prof !75

bb1.i.i.i:                                        ; preds = %bb3.i.i
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_64e308ef4babfeb8b6220184de794a17, ptr noundef nonnull inttoptr (i64 443 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_1b98de0e82d923a9daff35d520cf360d) #16
  unreachable

_RNvNvNtCs9l4wcBNbII5_4core4hint16assert_unchecked18precondition_check.exit.i.i: ; preds = %bb3.i.i
; call __rustc::__rust_realloc
  %raw_ptr.i.i = tail call noundef align 8 ptr @_RNvCs6d6XRwTwhVh_7___rustc14___rust_realloc(ptr noundef nonnull %_10.sroa.0.0, i64 noundef %_10.sroa.8.0._10.sroa.8.0._10.sroa.8.0._10.sroa.8.16.old_layout.1, i64 noundef 8, i64 noundef range(i64 0, 9223372036854775801) %_32.0) #17
  br label %_RNvXs1_NtCs8tsiLsQ9XHg_5alloc5allocNtB5_6GlobalNtNtCs9l4wcBNbII5_4core5alloc9Allocator4grow.exit

_RNvXs1_NtCs8tsiLsQ9XHg_5alloc5allocNtB5_6GlobalNtNtCs9l4wcBNbII5_4core5alloc9Allocator4grow.exit: ; preds = %bb4.i.i.i, %_RNvNvNtCs9l4wcBNbII5_4core4hint16assert_unchecked18precondition_check.exit.i.i
  %_0.sroa.0.0.i.i = phi ptr [ %raw_ptr.i.i, %_RNvNvNtCs9l4wcBNbII5_4core4hint16assert_unchecked18precondition_check.exit.i.i ], [ %3, %bb4.i.i.i ]
  call void @llvm.lifetime.end.p0(ptr nonnull %_10.sroa.5)
  call void @llvm.lifetime.end.p0(ptr nonnull %_10.sroa.8)
  br label %bb7

bb4.i.i:                                          ; preds = %_RNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCsh1eR4S1pMdQ_9range_ffi.exit
  call void @llvm.lifetime.end.p0(ptr nonnull %_10.sroa.5)
  call void @llvm.lifetime.end.p0(ptr nonnull %_10.sroa.8)
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  tail call void @_RNvCs6d6XRwTwhVh_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #17
; call __rustc::__rust_alloc
  %4 = tail call noundef align 8 ptr @_RNvCs6d6XRwTwhVh_7___rustc12___rust_alloc(i64 noundef range(i64 0, 9223372036854775801) %_32.0, i64 noundef 8) #17
  br label %bb7

bb7:                                              ; preds = %bb4.i.i, %_RNvXs1_NtCs8tsiLsQ9XHg_5alloc5allocNtB5_6GlobalNtNtCs9l4wcBNbII5_4core5alloc9Allocator4grow.exit
  %_0.sroa.0.0.i.i.pn = phi ptr [ %_0.sroa.0.0.i.i, %_RNvXs1_NtCs8tsiLsQ9XHg_5alloc5allocNtB5_6GlobalNtNtCs9l4wcBNbII5_4core5alloc9Allocator4grow.exit ], [ %4, %bb4.i.i ]
  %5 = icmp eq ptr %_0.sroa.0.0.i.i.pn, null
  %6 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  %7 = getelementptr inbounds nuw i8, ptr %_0, i64 16
  br i1 %5, label %bb18, label %bb19

bb18:                                             ; preds = %bb7
  store i64 8, ptr %6, align 8
  store i64 %_32.0, ptr %7, align 8
  br label %bb8

bb19:                                             ; preds = %bb7
  store ptr %_0.sroa.0.0.i.i.pn, ptr %6, align 8
  store i64 %_32.0, ptr %7, align 8
  br label %bb8

bb8:                                              ; preds = %bb19, %bb18, %bb14
  %.sink = phi i64 [ 0, %bb19 ], [ 1, %bb18 ], [ 1, %bb14 ]
  store i64 %.sink, ptr %_0, align 8
  ret void
}

; <alloc::raw_vec::RawVecInner>::grow_amortized
; Function Attrs: cold nounwind uwtable
define internal fastcc { i64, i64 } @_RNvMs8_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14grow_amortizedCsh1eR4S1pMdQ_9range_ffi(ptr noalias nofree noundef nonnull align 8 captures(none) dereferenceable(16) %self, i64 noundef range(i64 0, -9223372036854775808) %len) unnamed_addr #3 !guid !77 {
start:
  %self3 = alloca [24 x i8], align 8
  %_25.0 = add nuw i64 %len, 1
  %self5 = load i64, ptr %self, align 8, !range !68, !noundef !38
  %v16 = shl nuw i64 %self5, 1
  %cap = tail call i64 @llvm.umax.i64(i64 %v16, i64 %_25.0)
  %cap7 = tail call i64 @llvm.umax.i64(i64 %cap, i64 4)
  call void @llvm.lifetime.start.p0(ptr nonnull %self3)
  %0 = getelementptr inbounds nuw i8, ptr %self, i64 8
  %self.val15 = load ptr, ptr %0, align 8
; call <alloc::raw_vec::RawVecInner>::finish_grow
  call fastcc void @_RNvMs8_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsh1eR4S1pMdQ_9range_ffi(ptr noalias nofree noundef align 8 captures(none) dereferenceable(24) %self3, i64 %self5, ptr %self.val15, i64 noundef %cap7) #17
  %_37 = load i64, ptr %self3, align 8, !range !78, !noundef !38
  %1 = trunc nuw i64 %_37 to i1
  %2 = getelementptr inbounds nuw i8, ptr %self3, i64 8
  br i1 %1, label %bb18, label %bb19

bb6:                                              ; preds = %bb18, %bb19
  %_0.sroa.5.0 = phi i64 [ undef, %bb19 ], [ %e.1, %bb18 ]
  %_0.sroa.0.0 = phi i64 [ -1, %bb19 ], [ %e.0, %bb18 ]
  %3 = insertvalue { i64, i64 } poison, i64 %_0.sroa.0.0, 0
  %4 = insertvalue { i64, i64 } %3, i64 %_0.sroa.5.0, 1
  ret { i64, i64 } %4

bb18:                                             ; preds = %start
  %e.0 = load i64, ptr %2, align 8, !range !76, !noundef !38
  %5 = getelementptr inbounds nuw i8, ptr %self3, i64 16
  %e.1 = load i64, ptr %5, align 8
  call void @llvm.lifetime.end.p0(ptr nonnull %self3)
  br label %bb6

bb19:                                             ; preds = %start
  %v.0 = load ptr, ptr %2, align 8, !nonnull !38, !noundef !38
  call void @llvm.lifetime.end.p0(ptr nonnull %self3)
  store ptr %v.0, ptr %0, align 8
  %6 = icmp sgt i64 %cap7, -1
  tail call void @llvm.assume(i1 %6)
  store i64 %cap7, ptr %self, align 8
  br label %bb6
}

; range_ffi::http_range_parser::legacy_i64
; Function Attrs: inlinehint nofree norecurse nosync nounwind memory(argmem: read, inaccessiblemem: readwrite) uwtable
define internal fastcc { i64, i64 } @_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser10legacy_i64(ptr noalias nofree noundef nonnull readonly captures(address) %input.0, i64 noundef range(i64 0, -9223372036854775808) %input.1) unnamed_addr #4 personality ptr @__CxxFrameHandler3 !guid !79 {
start:
  %_23 = alloca [16 x i8], align 8
  %_16 = alloca [16 x i8], align 8
  %_5.not.i = icmp eq i64 %input.1, 0
  br i1 %_5.not.i, label %_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13compact_zeros.exit, label %bb9.i

bb9.i:                                            ; preds = %start
  %data.i.i.i = getelementptr inbounds nuw i8, ptr %input.0, i64 1
  %len.i.i.i = add nsw i64 %input.1, -1
  %lhsc.i = load i8, ptr %input.0, align 1, !alias.scope !80
  %_0.i.i = icmp eq i8 %lhsc.i, 43
  br i1 %_0.i.i, label %bb2, label %bb6

bb2:                                              ; preds = %bb9.i
  %_11.not = icmp eq i64 %len.i.i.i, 0
  br i1 %_11.not, label %bb8, label %bb9

bb6:                                              ; preds = %bb9.i
  %_25.i = icmp samesign ugt i64 %input.1, 16
  br i1 %_25.i, label %_RNvMNtCs9l4wcBNbII5_4core5sliceSh11starts_withCsh1eR4S1pMdQ_9range_ffi.exit.i, label %_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13compact_zeros.exit

_RNvMNtCs9l4wcBNbII5_4core5sliceSh11starts_withCsh1eR4S1pMdQ_9range_ffi.exit.i: ; preds = %bb6, %bb9.i5
  %input.sroa.0.07.i = phi ptr [ %_15.i, %bb9.i5 ], [ %input.0, %bb6 ]
  %input.sroa.7.06.i = phi i64 [ %_11.i, %bb9.i5 ], [ %input.1, %bb6 ]
  %0 = load i128, ptr %input.sroa.0.07.i, align 1
  %1 = icmp ne i128 64053151420411946063694043751862251568, %0
  %2 = zext i1 %1 to i32
  %_0.i.i.i = icmp eq i32 %2, 0
  br i1 %_0.i.i.i, label %bb9.i5, label %_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13compact_zeros.exit

bb9.i5:                                           ; preds = %_RNvMNtCs9l4wcBNbII5_4core5sliceSh11starts_withCsh1eR4S1pMdQ_9range_ffi.exit.i
  %_11.i = add nsw i64 %input.sroa.7.06.i, -16
  %_15.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.07.i, i64 16
  %_2.i = icmp ugt i64 %_11.i, 16
  br i1 %_2.i, label %_RNvMNtCs9l4wcBNbII5_4core5sliceSh11starts_withCsh1eR4S1pMdQ_9range_ffi.exit.i, label %_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13compact_zeros.exit

_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13compact_zeros.exit: ; preds = %_RNvMNtCs9l4wcBNbII5_4core5sliceSh11starts_withCsh1eR4S1pMdQ_9range_ffi.exit.i, %bb9.i5, %start, %bb6
  %input.sroa.7.0.lcssa.i = phi i64 [ %input.1, %bb6 ], [ 0, %start ], [ %_11.i, %bb9.i5 ], [ %input.sroa.7.06.i, %_RNvMNtCs9l4wcBNbII5_4core5sliceSh11starts_withCsh1eR4S1pMdQ_9range_ffi.exit.i ]
  %input.sroa.0.0.lcssa.i = phi ptr [ %input.0, %bb6 ], [ %input.0, %start ], [ %_15.i, %bb9.i5 ], [ %input.sroa.0.07.i, %_RNvMNtCs9l4wcBNbII5_4core5sliceSh11starts_withCsh1eR4S1pMdQ_9range_ffi.exit.i ]
  call void @llvm.lifetime.start.p0(ptr nonnull %_23)
; call parse_number_core::parse_slice::<9223372036854775807, 9223372036854775808>
  call fastcc void @_RINvCs4A2AHSyUD2M_17parse_number_core11parse_sliceKy7fffffffffffffff_Ky8000000000000000_ECsh1eR4S1pMdQ_9range_ffi(ptr noalias nofree noundef align 8 captures(address) dereferenceable(16) %_23, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %input.sroa.0.0.lcssa.i, i64 noundef %input.sroa.7.0.lcssa.i, i32 noundef 1) #17
  %3 = getelementptr inbounds nuw i8, ptr %_23, i64 8
  %4 = load i8, ptr %3, align 8, !range !83, !noundef !38
  %5 = icmp eq i8 %4, 2
  br i1 %5, label %bb22, label %bb23

bb9:                                              ; preds = %bb2
  %6 = load i8, ptr %data.i.i.i, align 1, !noundef !38
  %7 = add i8 %6, -48
  %or.cond = icmp ult i8 %7, 10
  br i1 %or.cond, label %bb3, label %bb8

bb3:                                              ; preds = %bb9
  %_25.i6 = icmp samesign ugt i64 %input.1, 17
  br i1 %_25.i6, label %_RNvMNtCs9l4wcBNbII5_4core5sliceSh11starts_withCsh1eR4S1pMdQ_9range_ffi.exit.i9, label %_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13compact_zeros.exit18

_RNvMNtCs9l4wcBNbII5_4core5sliceSh11starts_withCsh1eR4S1pMdQ_9range_ffi.exit.i9: ; preds = %bb3, %bb9.i14
  %input.sroa.0.07.i10 = phi ptr [ %_15.i16, %bb9.i14 ], [ %data.i.i.i, %bb3 ]
  %input.sroa.7.06.i11 = phi i64 [ %_11.i15, %bb9.i14 ], [ %len.i.i.i, %bb3 ]
  %8 = load i128, ptr %input.sroa.0.07.i10, align 1
  %9 = icmp ne i128 64053151420411946063694043751862251568, %8
  %10 = zext i1 %9 to i32
  %_0.i.i.i13 = icmp eq i32 %10, 0
  br i1 %_0.i.i.i13, label %bb9.i14, label %_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13compact_zeros.exit18

bb9.i14:                                          ; preds = %_RNvMNtCs9l4wcBNbII5_4core5sliceSh11starts_withCsh1eR4S1pMdQ_9range_ffi.exit.i9
  %_11.i15 = add nsw i64 %input.sroa.7.06.i11, -16
  %_15.i16 = getelementptr inbounds nuw i8, ptr %input.sroa.0.07.i10, i64 16
  %_2.i17 = icmp ugt i64 %_11.i15, 16
  br i1 %_2.i17, label %_RNvMNtCs9l4wcBNbII5_4core5sliceSh11starts_withCsh1eR4S1pMdQ_9range_ffi.exit.i9, label %_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13compact_zeros.exit18

_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13compact_zeros.exit18: ; preds = %_RNvMNtCs9l4wcBNbII5_4core5sliceSh11starts_withCsh1eR4S1pMdQ_9range_ffi.exit.i9, %bb9.i14, %bb3
  %input.sroa.7.0.lcssa.i7 = phi i64 [ %len.i.i.i, %bb3 ], [ %_11.i15, %bb9.i14 ], [ %input.sroa.7.06.i11, %_RNvMNtCs9l4wcBNbII5_4core5sliceSh11starts_withCsh1eR4S1pMdQ_9range_ffi.exit.i9 ]
  %input.sroa.0.0.lcssa.i8 = phi ptr [ %data.i.i.i, %bb3 ], [ %_15.i16, %bb9.i14 ], [ %input.sroa.0.07.i10, %_RNvMNtCs9l4wcBNbII5_4core5sliceSh11starts_withCsh1eR4S1pMdQ_9range_ffi.exit.i9 ]
  call void @llvm.lifetime.start.p0(ptr nonnull %_16)
; call parse_number_core::parse_slice::<9223372036854775807, 9223372036854775808>
  call fastcc void @_RINvCs4A2AHSyUD2M_17parse_number_core11parse_sliceKy7fffffffffffffff_Ky8000000000000000_ECsh1eR4S1pMdQ_9range_ffi(ptr noalias nofree noundef align 8 captures(address) dereferenceable(16) %_16, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %input.sroa.0.0.lcssa.i8, i64 noundef %input.sroa.7.0.lcssa.i7, i32 noundef 0) #17
  %11 = getelementptr inbounds nuw i8, ptr %_16, i64 8
  %12 = load i8, ptr %11, align 8, !range !83, !noundef !38
  %13 = icmp eq i8 %12, 2
  br i1 %13, label %bb15, label %bb16

bb8:                                              ; preds = %bb23, %bb22, %bb16, %bb15, %bb2, %bb9
  %_0.sroa.6.0 = phi i64 [ undef, %bb2 ], [ %_18.sroa.0.0, %bb16 ], [ undef, %bb9 ], [ undef, %bb15 ], [ undef, %bb22 ], [ %_25.sroa.0.0, %bb23 ]
  %_0.sroa.0.0 = phi i64 [ 0, %bb2 ], [ 1, %bb16 ], [ 0, %bb9 ], [ 0, %bb15 ], [ 0, %bb22 ], [ 1, %bb23 ]
  %14 = insertvalue { i64, i64 } poison, i64 %_0.sroa.0.0, 0
  %15 = insertvalue { i64, i64 } %14, i64 %_0.sroa.6.0, 1
  ret { i64, i64 } %15

bb15:                                             ; preds = %_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13compact_zeros.exit18
  call void @llvm.lifetime.end.p0(ptr nonnull %_16)
  br label %bb8

bb16:                                             ; preds = %_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13compact_zeros.exit18
  %_20 = load i64, ptr %_16, align 8, !noundef !38
  %_21 = trunc nuw i8 %12 to i1
  %16 = sub i64 0, %_20
  %_18.sroa.0.0 = select i1 %_21, i64 %16, i64 %_20
  call void @llvm.lifetime.end.p0(ptr nonnull %_16)
  br label %bb8

bb22:                                             ; preds = %_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13compact_zeros.exit
  call void @llvm.lifetime.end.p0(ptr nonnull %_23)
  br label %bb8

bb23:                                             ; preds = %_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13compact_zeros.exit
  %_27 = load i64, ptr %_23, align 8, !noundef !38
  %_28 = trunc nuw i8 %4 to i1
  %17 = sub i64 0, %_27
  %_25.sroa.0.0 = select i1 %_28, i64 %17, i64 %_27
  call void @llvm.lifetime.end.p0(ptr nonnull %_23)
  br label %bb8
}

; core::hint::unreachable_unchecked::precondition_check
; Function Attrs: cold inlinehint noreturn nounwind uwtable
define internal fastcc void @_RNvNvNtCs9l4wcBNbII5_4core4hint21unreachable_unchecked18precondition_check(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) %0) unnamed_addr #5 !guid !84 {
start:
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_75fb06c2453febd814e73f5f2e72ae38, ptr noundef nonnull inttoptr (i64 399 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(24) %0) #16
  unreachable
}

; Function Attrs: nounwind uwtable
define noundef zeroext i1 @rustium_http_range_content(ptr noundef %data, i64 noundef %len, ptr nofree noundef captures(none) initializes((0, 8)) %first, ptr nofree noundef captures(none) initializes((0, 8)) %last, ptr nofree noundef writeonly captures(none) initializes((0, 8)) %length) unnamed_addr #1 personality ptr @__CxxFrameHandler3 !guid !85 {
start:
  store i64 -1, ptr %length, align 8, !noalias !86
  store i64 -1, ptr %last, align 8, !noalias !91
  store i64 -1, ptr %first, align 8, !noalias !94
  %0 = icmp eq i64 %len, 0
  br i1 %0, label %_RINvMNtCs9l4wcBNbII5_4core6optionINtB3_6OptionjE6map_orjNCNCINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB11_14ForeignContentE0s0_0EB11_.exit.i.i.i, label %bb2.i.i.i

bb2.i.i.i:                                        ; preds = %start
  %_12.not.i.i.i.i = icmp ne ptr %data, null
  %_7.i.i.i.i = icmp sgt i64 %len, -1
  %or.cond.i.i.i.i = and i1 %_12.not.i.i.i.i, %_7.i.i.i.i
  br i1 %or.cond.i.i.i.i, label %_RNvCsh1eR4S1pMdQ_9range_ffi5bytes.exit.i.i, label %bb5.i.i.i.i, !prof !66

bb5.i.i.i.i:                                      ; preds = %bb2.i.i.i
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_a28e8c8fd5088943a8b5d44af697ff83, ptr noundef nonnull inttoptr (i64 559 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_56c01fe01d1a47ca560ad2a33d46aaec) #16, !noalias !97
  unreachable

_RNvCsh1eR4S1pMdQ_9range_ffi5bytes.exit.i.i:      ; preds = %bb2.i.i.i
  tail call void @llvm.experimental.noalias.scope.decl(metadata !102)
  %_48.i.i.i = getelementptr inbounds nuw i8, ptr %data, i64 %len
  br label %bb23.i.i.i.i

bb23.i.i.i.i:                                     ; preds = %bb7.i.i.i.i, %_RNvCsh1eR4S1pMdQ_9range_ffi5bytes.exit.i.i
  %i.sroa.0.08.i.i.i.i = phi i64 [ %1, %bb7.i.i.i.i ], [ 0, %_RNvCsh1eR4S1pMdQ_9range_ffi5bytes.exit.i.i ]
  %_3957.i.i.i.i = phi ptr [ %_39.i.i.i.i, %bb7.i.i.i.i ], [ %data, %_RNvCsh1eR4S1pMdQ_9range_ffi5bytes.exit.i.i ]
  %ptr.val.i.i.i.i = load i8, ptr %_3957.i.i.i.i, align 1, !alias.scope !102, !noalias !105, !noundef !38
  switch i8 %ptr.val.i.i.i.i, label %bb6.i.i.i.i [
    i8 32, label %bb7.i.i.i.i
    i8 9, label %bb7.i.i.i.i
  ]

bb7.i.i.i.i:                                      ; preds = %bb23.i.i.i.i, %bb23.i.i.i.i
  %_39.i.i.i.i = getelementptr inbounds nuw i8, ptr %_3957.i.i.i.i, i64 1
  %1 = add nuw nsw i64 %i.sroa.0.08.i.i.i.i, 1
  %_29.i.i.i.i = icmp eq ptr %_39.i.i.i.i, %_48.i.i.i
  br i1 %_29.i.i.i.i, label %bb6.preheader.i.i.i.i, label %bb23.i.i.i.i

bb6.i.i.i.i:                                      ; preds = %bb23.i.i.i.i
  %cond.i.i.i.i = icmp samesign ult i64 %i.sroa.0.08.i.i.i.i, %len
  br i1 %cond.i.i.i.i, label %bb6.preheader.i.i.i.i, label %bb1.i.i.i.i.i, !prof !69

bb1.i.i.i.i.i:                                    ; preds = %bb6.i.i.i.i
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_64e308ef4babfeb8b6220184de794a17, ptr noundef nonnull inttoptr (i64 443 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_1d1b1e35bb489427b2bdc9752de92226) #16, !noalias !108
  unreachable

bb6.preheader.i.i.i.i:                            ; preds = %bb7.i.i.i.i, %bb6.i.i.i.i
  %_0.sroa.0.0.i.i.i.i = phi i64 [ %i.sroa.0.08.i.i.i.i, %bb6.i.i.i.i ], [ %len, %bb7.i.i.i.i ]
  br label %bb6.i24.i.i.i

bb6.i24.i.i.i:                                    ; preds = %bb4.backedge.i.i.i.i, %bb6.preheader.i.i.i.i
  %i.sroa.0.09.i.i.i.i = phi i64 [ %2, %bb4.backedge.i.i.i.i ], [ %len, %bb6.preheader.i.i.i.i ]
  %_6.i78.i.i.i.i = phi ptr [ %_23.i.i.i.i.i, %bb4.backedge.i.i.i.i ], [ %_48.i.i.i, %bb6.preheader.i.i.i.i ]
  %_23.i.i.i.i.i = getelementptr inbounds i8, ptr %_6.i78.i.i.i.i, i64 -1
  %2 = add nsw i64 %i.sroa.0.09.i.i.i.i, -1
  %.val.i.i.i.i = load i8, ptr %_23.i.i.i.i.i, align 1, !alias.scope !102, !noalias !110, !noundef !38
  switch i8 %.val.i.i.i.i, label %bb8.i.i.i.i [
    i8 32, label %bb4.backedge.i.i.i.i
    i8 9, label %bb4.backedge.i.i.i.i
  ]

bb4.backedge.i.i.i.i:                             ; preds = %bb6.i24.i.i.i, %bb6.i24.i.i.i
  %3 = icmp eq ptr %data, %_23.i.i.i.i.i
  br i1 %3, label %_RINvMNtCs9l4wcBNbII5_4core6optionINtB3_6OptionjE6map_orjNCNCINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB11_14ForeignContentE0s0_0EB11_.exit.i.i.i, label %bb6.i24.i.i.i

bb8.i.i.i.i:                                      ; preds = %bb6.i24.i.i.i
  %cond.i27.i.i.i = icmp ult i64 %2, %len
  br i1 %cond.i27.i.i.i, label %_RINvMNtCs9l4wcBNbII5_4core6optionINtB3_6OptionjE6map_orjNCNCINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB11_14ForeignContentE0s0_0EB11_.exit.i.i.i, label %bb1.i.i28.i.i.i, !prof !69

bb1.i.i28.i.i.i:                                  ; preds = %bb8.i.i.i.i
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_64e308ef4babfeb8b6220184de794a17, ptr noundef nonnull inttoptr (i64 443 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_1d1b1e35bb489427b2bdc9752de92226) #16, !noalias !113
  unreachable

_RINvMNtCs9l4wcBNbII5_4core6optionINtB3_6OptionjE6map_orjNCNCINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB11_14ForeignContentE0s0_0EB11_.exit.i.i.i: ; preds = %bb4.backedge.i.i.i.i, %bb8.i.i.i.i, %start
  %_0.sroa.0.0.i3.i.i = phi ptr [ inttoptr (i64 1 to ptr), %start ], [ %data, %bb8.i.i.i.i ], [ %data, %bb4.backedge.i.i.i.i ]
  %begin.sroa.0.09599.i.i.i = phi i64 [ 0, %start ], [ %_0.sroa.0.0.i.i.i.i, %bb8.i.i.i.i ], [ %_0.sroa.0.0.i.i.i.i, %bb4.backedge.i.i.i.i ]
  %_0.sroa.0.0.i30.i.i.i = phi i64 [ 0, %start ], [ %i.sroa.0.09.i.i.i.i, %bb8.i.i.i.i ], [ %_0.sroa.0.0.i.i.i.i, %bb4.backedge.i.i.i.i ]
  %_66.i.i.i = icmp ult i64 %_0.sroa.0.0.i30.i.i.i, %begin.sroa.0.09599.i.i.i
  %_62.not.i.i.i = icmp ugt i64 %_0.sroa.0.0.i30.i.i.i, %len
  %or.cond.i.i.i = or i1 %_66.i.i.i, %_62.not.i.i.i
  br i1 %or.cond.i.i.i, label %bb25.i.i.i, label %bb24.i.i.i, !prof !114

bb25.i.i.i:                                       ; preds = %_RINvMNtCs9l4wcBNbII5_4core6optionINtB3_6OptionjE6map_orjNCNCINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB11_14ForeignContentE0s0_0EB11_.exit.i.i.i
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCs9l4wcBNbII5_4core5slice5index16slice_index_fail(i64 noundef %begin.sroa.0.09599.i.i.i, i64 noundef %_0.sroa.0.0.i30.i.i.i, i64 noundef range(i64 0, -9223372036854775808) %len, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_5fd5ad9d8a4f43eaaa74e75f1fc82bac) #16, !noalias !115
  unreachable

bb24.i.i.i:                                       ; preds = %_RINvMNtCs9l4wcBNbII5_4core6optionINtB3_6OptionjE6map_orjNCNCINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB11_14ForeignContentE0s0_0EB11_.exit.i.i.i
  %_67.i.i.i = sub nuw nsw i64 %_0.sroa.0.0.i30.i.i.i, %begin.sroa.0.09599.i.i.i
  %_69.i.i.i = getelementptr inbounds nuw i8, ptr %_0.sroa.0.0.i3.i.i, i64 %begin.sroa.0.09599.i.i.i
  tail call void @llvm.experimental.noalias.scope.decl(metadata !116)
  %_3.i.i.i.i = icmp samesign ult i64 %_67.i.i.i, 17
  %_13.i.i.i.i = getelementptr inbounds nuw i8, ptr %_0.sroa.0.0.i3.i.i, i64 %_0.sroa.0.0.i30.i.i.i
  br i1 %_3.i.i.i.i, label %bb1.i.i.i.i, label %bb3.i31.i.i.i

bb3.i31.i.i.i:                                    ; preds = %bb24.i.i.i
  %4 = load atomic ptr, ptr @_RNvNvNtNtNtCskuZNHgLkVkS_6memchr4arch6x86_646memchr10memchr_raw2FN monotonic, align 8, !noalias !119, !nonnull !38, !noundef !38
  %5 = tail call { i64, ptr } %4(i8 noundef 32, ptr noundef nonnull readonly %_69.i.i.i, ptr noundef nonnull readonly %_13.i.i.i.i) #17, !noalias !122, !inline_history !123
  %6 = extractvalue { i64, ptr } %5, 0
  %7 = trunc nuw i64 %6 to i1
  br i1 %7, label %bb8.i.i.i.i.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB4_14ForeignContentEB4_.exit

bb8.i.i.i.i.i:                                    ; preds = %bb3.i31.i.i.i
  %8 = extractvalue { i64, ptr } %5, 1
  %9 = ptrtoint ptr %8 to i64
  %10 = ptrtoint ptr %_69.i.i.i to i64
  %11 = sub i64 %9, %10
  %_8.i.i.i.i.i = icmp sgt i64 %11, -1
  br i1 %_8.i.i.i.i.i, label %_RNvXNtCskuZNHgLkVkS_6memchr3extPhNtB2_7Pointer8distanceCsh1eR4S1pMdQ_9range_ffi.exit.i.i.i.i, label %bb6.i.i.i.i.i, !prof !69

bb6.i.i.i.i.i:                                    ; preds = %bb8.i.i.i.i.i
; call core::hint::unreachable_unchecked::precondition_check
  tail call fastcc void @_RNvNvNtCs9l4wcBNbII5_4core4hint21unreachable_unchecked18precondition_check(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_6d855724149bc5132e1bc43bfd525250) #17, !noalias !115
  unreachable

_RNvXNtCskuZNHgLkVkS_6memchr3extPhNtB2_7Pointer8distanceCsh1eR4S1pMdQ_9range_ffi.exit.i.i.i.i: ; preds = %bb8.i.i.i.i.i
  %_13.not.i.i.i.i.i = icmp samesign ult i64 %11, %_67.i.i.i
  br i1 %_13.not.i.i.i.i.i, label %bb33.i.i.i, label %bb4.i.i.i.i.i, !prof !69

bb4.i.i.i.i.i:                                    ; preds = %_RNvXNtCskuZNHgLkVkS_6memchr3extPhNtB2_7Pointer8distanceCsh1eR4S1pMdQ_9range_ffi.exit.i.i.i.i
; call core::hint::unreachable_unchecked::precondition_check
  tail call fastcc void @_RNvNvNtCs9l4wcBNbII5_4core4hint21unreachable_unchecked18precondition_check(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_a59d8fe4279b26f926811f91f116a398) #17, !noalias !115
  unreachable

bb1.i.i.i.i:                                      ; preds = %bb24.i.i.i
  %_296.i.i.i.i.i = icmp eq i64 %_0.sroa.0.0.i30.i.i.i, %begin.sroa.0.09599.i.i.i
  br i1 %_296.i.i.i.i.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB4_14ForeignContentEB4_.exit, label %bb23.i.i.i.i.i

bb23.i.i.i.i.i:                                   ; preds = %bb1.i.i.i.i, %bb7.i.i.i.i.i
  %i.sroa.0.08.i.i.i.i.i = phi i64 [ %12, %bb7.i.i.i.i.i ], [ 0, %bb1.i.i.i.i ]
  %_3957.i.i.i.i.i = phi ptr [ %_39.i.i.i.i.i, %bb7.i.i.i.i.i ], [ %_69.i.i.i, %bb1.i.i.i.i ]
  %ptr.val.i.i.i.i.i = load i8, ptr %_3957.i.i.i.i.i, align 1, !alias.scope !124, !noalias !125, !noundef !38
  %_0.i.i.i.i.i.i = icmp eq i8 %ptr.val.i.i.i.i.i, 32
  br i1 %_0.i.i.i.i.i.i, label %bb6.i5.i.i.i.i, label %bb7.i.i.i.i.i

bb7.i.i.i.i.i:                                    ; preds = %bb23.i.i.i.i.i
  %_39.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %_3957.i.i.i.i.i, i64 1
  %12 = add nuw nsw i64 %i.sroa.0.08.i.i.i.i.i, 1
  %_29.i.i.i.i.i = icmp eq ptr %_39.i.i.i.i.i, %_13.i.i.i.i
  br i1 %_29.i.i.i.i.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB4_14ForeignContentEB4_.exit, label %bb23.i.i.i.i.i

bb6.i5.i.i.i.i:                                   ; preds = %bb23.i.i.i.i.i
  %cond.i.i.i.i.i = icmp samesign ult i64 %i.sroa.0.08.i.i.i.i.i, %_67.i.i.i
  br i1 %cond.i.i.i.i.i, label %bb33.i.i.i, label %bb1.i.i.i.i.i.i, !prof !69

bb1.i.i.i.i.i.i:                                  ; preds = %bb6.i5.i.i.i.i
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_64e308ef4babfeb8b6220184de794a17, ptr noundef nonnull inttoptr (i64 443 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_1d1b1e35bb489427b2bdc9752de92226) #16, !noalias !129
  unreachable

bb33.i.i.i:                                       ; preds = %bb6.i5.i.i.i.i, %_RNvXNtCskuZNHgLkVkS_6memchr3extPhNtB2_7Pointer8distanceCsh1eR4S1pMdQ_9range_ffi.exit.i.i.i.i
  %_0.sroa.3.0.i3.pn.i.i.i.i = phi i64 [ %11, %_RNvXNtCskuZNHgLkVkS_6memchr3extPhNtB2_7Pointer8distanceCsh1eR4S1pMdQ_9range_ffi.exit.i.i.i.i ], [ %i.sroa.0.08.i.i.i.i.i, %bb6.i5.i.i.i.i ]
  %_20.0.i.i.i = add nuw i64 %_0.sroa.3.0.i3.pn.i.i.i.i, %begin.sroa.0.09599.i.i.i
  %_74.not.i.i.i = icmp ugt i64 %_20.0.i.i.i, %len
  br i1 %_74.not.i.i.i, label %bb31.i.i.i, label %bb30.i.i.i, !prof !75

bb31.i.i.i:                                       ; preds = %bb33.i.i.i
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCs9l4wcBNbII5_4core5slice5index16slice_index_fail(i64 noundef %begin.sroa.0.09599.i.i.i, i64 noundef %_20.0.i.i.i, i64 noundef range(i64 0, -9223372036854775808) %len, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_16cbcd9a81ccfa6f0d62eca93b6e0394) #16, !noalias !115
  unreachable

bb30.i.i.i:                                       ; preds = %bb33.i.i.i
  %_13.not8.i.i.i.i = icmp eq i64 %_0.sroa.3.0.i3.pn.i.i.i.i, 0
  br i1 %_13.not8.i.i.i.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB4_14ForeignContentEB4_.exit, label %bb8.i33.i.i.i

bb8.i33.i.i.i:                                    ; preds = %bb30.i.i.i, %bb13.i.i.i.i
  %input.sroa.0.010.i.i.i.i = phi ptr [ %_24.i.i.i.i, %bb13.i.i.i.i ], [ %_69.i.i.i, %bb30.i.i.i ]
  %input.sroa.10.09.i.i.i.i = phi i64 [ %_20.i.i.i.i, %bb13.i.i.i.i ], [ %_0.sroa.3.0.i3.pn.i.i.i.i, %bb30.i.i.i ]
  %_16.i.i.i.i = load i8, ptr %input.sroa.0.010.i.i.i.i, align 1, !alias.scope !130, !noalias !97, !noundef !38
  switch i8 %_16.i.i.i.i, label %bb14.i.i.i.i [
    i8 32, label %bb13.i.i.i.i
    i8 9, label %bb13.i.i.i.i
  ]

bb14.i.i.i.i:                                     ; preds = %bb8.i33.i.i.i, %bb18.i.i.i.i
  %input.sroa.10.115.i.i.i.i = phi i64 [ %13, %bb18.i.i.i.i ], [ %input.sroa.10.09.i.i.i.i, %bb8.i33.i.i.i ]
  %13 = add nsw i64 %input.sroa.10.115.i.i.i.i, -1
  %_27.i.i.i.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.010.i.i.i.i, i64 %13
  %_29.i36.i.i.i = load i8, ptr %_27.i.i.i.i, align 1, !alias.scope !130, !noalias !97, !noundef !38
  switch i8 %_29.i36.i.i.i, label %_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4trim.exit.i.i.i [
    i8 32, label %bb18.i.i.i.i
    i8 9, label %bb18.i.i.i.i
  ]

bb18.i.i.i.i:                                     ; preds = %bb14.i.i.i.i, %bb14.i.i.i.i
  %_26.not.i.i.i.i = icmp eq i64 %13, 0
  br i1 %_26.not.i.i.i.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB4_14ForeignContentEB4_.exit, label %bb14.i.i.i.i

bb13.i.i.i.i:                                     ; preds = %bb8.i33.i.i.i, %bb8.i33.i.i.i
  %_20.i.i.i.i = add nsw i64 %input.sroa.10.09.i.i.i.i, -1
  %_24.i.i.i.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.010.i.i.i.i, i64 1
  %_13.not.i.i.i.i = icmp eq i64 %_20.i.i.i.i, 0
  br i1 %_13.not.i.i.i.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB4_14ForeignContentEB4_.exit, label %bb8.i33.i.i.i

_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4trim.exit.i.i.i: ; preds = %bb14.i.i.i.i
  %14 = icmp eq i64 %input.sroa.10.115.i.i.i.i, 5
  br i1 %14, label %bb39.i.i.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB4_14ForeignContentEB4_.exit

bb39.i.i.i:                                       ; preds = %_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4trim.exit.i.i.i
  %15 = add i8 %_16.i.i.i.i, -65
  %16 = icmp ult i8 %15, 26
  %17 = select i1 %16, i8 32, i8 0
  %_18.sroa.0.0.i.i.i.i = or i8 %17, %_16.i.i.i.i
  %_11.i.i.i.i = icmp eq i8 %_18.sroa.0.0.i.i.i.i, 98
  br i1 %_11.i.i.i.i, label %bb1.1.i.i.i.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB4_14ForeignContentEB4_.exit

bb1.1.i.i.i.i:                                    ; preds = %bb39.i.i.i
  %rest_a.0.i.i.i.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.010.i.i.i.i, i64 1
  %_14.1.i.i.i.i = load i8, ptr %rest_a.0.i.i.i.i, align 1, !alias.scope !133, !noalias !97, !noundef !38
  %18 = add i8 %_14.1.i.i.i.i, -65
  %19 = icmp ult i8 %18, 26
  %20 = select i1 %19, i8 32, i8 0
  %_18.sroa.0.0.1.i.i.i.i = or i8 %20, %_14.1.i.i.i.i
  %_11.1.i.i.i.i = icmp eq i8 %_18.sroa.0.0.1.i.i.i.i, 121
  br i1 %_11.1.i.i.i.i, label %bb1.2.i.i.i.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB4_14ForeignContentEB4_.exit

bb1.2.i.i.i.i:                                    ; preds = %bb1.1.i.i.i.i
  %rest_a.0.1.i.i.i.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.010.i.i.i.i, i64 2
  %_14.2.i.i.i.i = load i8, ptr %rest_a.0.1.i.i.i.i, align 1, !alias.scope !133, !noalias !97, !noundef !38
  %21 = add i8 %_14.2.i.i.i.i, -65
  %22 = icmp ult i8 %21, 26
  %23 = select i1 %22, i8 32, i8 0
  %_18.sroa.0.0.2.i.i.i.i = or i8 %23, %_14.2.i.i.i.i
  %_11.2.i.i.i.i = icmp eq i8 %_18.sroa.0.0.2.i.i.i.i, 116
  br i1 %_11.2.i.i.i.i, label %bb1.3.i.i.i.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB4_14ForeignContentEB4_.exit

bb1.3.i.i.i.i:                                    ; preds = %bb1.2.i.i.i.i
  %rest_a.0.2.i.i.i.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.010.i.i.i.i, i64 3
  %_14.3.i.i.i.i = load i8, ptr %rest_a.0.2.i.i.i.i, align 1, !alias.scope !133, !noalias !97, !noundef !38
  %24 = add i8 %_14.3.i.i.i.i, -65
  %25 = icmp ult i8 %24, 26
  %26 = select i1 %25, i8 32, i8 0
  %_18.sroa.0.0.3.i.i.i.i = or i8 %26, %_14.3.i.i.i.i
  %_11.3.i.i.i.i = icmp eq i8 %_18.sroa.0.0.3.i.i.i.i, 101
  br i1 %_11.3.i.i.i.i, label %_RNvMNtNtCs9l4wcBNbII5_4core5slice5asciiSh27eq_ignore_ascii_case_simple.exit.i.i.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB4_14ForeignContentEB4_.exit

_RNvMNtNtCs9l4wcBNbII5_4core5slice5asciiSh27eq_ignore_ascii_case_simple.exit.i.i.i: ; preds = %bb1.3.i.i.i.i
  %rest_a.0.3.i.i.i.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.010.i.i.i.i, i64 4
  %_14.4.i.i.i.i = load i8, ptr %rest_a.0.3.i.i.i.i, align 1, !alias.scope !133, !noalias !97, !noundef !38
  %27 = add i8 %_14.4.i.i.i.i, -65
  %28 = icmp ult i8 %27, 26
  %29 = select i1 %28, i8 32, i8 0
  %_18.sroa.0.0.4.i.i.i.i = or i8 %29, %_14.4.i.i.i.i
  %_11.4.i.i.i.i = icmp eq i8 %_18.sroa.0.0.4.i.i.i.i, 115
  br i1 %_11.4.i.i.i.i, label %bb8.i.i.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB4_14ForeignContentEB4_.exit

bb8.i.i.i:                                        ; preds = %_RNvMNtNtCs9l4wcBNbII5_4core5slice5asciiSh27eq_ignore_ascii_case_simple.exit.i.i.i
  %_27.0.i.i.i = add nuw i64 %_20.0.i.i.i, 1
  %_87.not.i.i.i = icmp ugt i64 %_0.sroa.0.0.i30.i.i.i, %_20.0.i.i.i
  br i1 %_87.not.i.i.i, label %bb41.i.i.i, label %bb40.i.i.i, !prof !69

bb41.i.i.i:                                       ; preds = %bb8.i.i.i
  %_88.i.i.i = sub nuw nsw i64 %_0.sroa.0.0.i30.i.i.i, %_27.0.i.i.i
  %_90.i.i.i = getelementptr inbounds nuw i8, ptr %_0.sroa.0.0.i3.i.i, i64 %_27.0.i.i.i
  tail call void @llvm.experimental.noalias.scope.decl(metadata !136)
  %_3.i38.i.i.i = icmp samesign ult i64 %_88.i.i.i, 17
  br i1 %_3.i38.i.i.i, label %bb1.i51.i.i.i, label %bb3.i40.i.i.i

bb3.i40.i.i.i:                                    ; preds = %bb41.i.i.i
  %30 = load atomic ptr, ptr @_RNvNvNtNtNtCskuZNHgLkVkS_6memchr4arch6x86_646memchr10memchr_raw2FN monotonic, align 8, !noalias !139, !nonnull !38, !noundef !38
  %31 = tail call { i64, ptr } %30(i8 noundef 45, ptr noundef nonnull readonly %_90.i.i.i, ptr noundef nonnull readonly %_13.i.i.i.i) #17, !noalias !142, !inline_history !123
  %32 = extractvalue { i64, ptr } %31, 0
  %33 = trunc nuw i64 %32 to i1
  br i1 %33, label %bb8.i.i45.i.i.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB4_14ForeignContentEB4_.exit

bb8.i.i45.i.i.i:                                  ; preds = %bb3.i40.i.i.i
  %34 = extractvalue { i64, ptr } %31, 1
  %35 = ptrtoint ptr %34 to i64
  %36 = ptrtoint ptr %_90.i.i.i to i64
  %37 = sub i64 %35, %36
  %_8.i.i46.i.i.i = icmp sgt i64 %37, -1
  br i1 %_8.i.i46.i.i.i, label %_RNvXNtCskuZNHgLkVkS_6memchr3extPhNtB2_7Pointer8distanceCsh1eR4S1pMdQ_9range_ffi.exit.i48.i.i.i, label %bb6.i.i47.i.i.i, !prof !69

bb6.i.i47.i.i.i:                                  ; preds = %bb8.i.i45.i.i.i
; call core::hint::unreachable_unchecked::precondition_check
  tail call fastcc void @_RNvNvNtCs9l4wcBNbII5_4core4hint21unreachable_unchecked18precondition_check(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_6d855724149bc5132e1bc43bfd525250) #17, !noalias !115
  unreachable

_RNvXNtCskuZNHgLkVkS_6memchr3extPhNtB2_7Pointer8distanceCsh1eR4S1pMdQ_9range_ffi.exit.i48.i.i.i: ; preds = %bb8.i.i45.i.i.i
  %_13.not.i.i49.i.i.i = icmp samesign ult i64 %37, %_88.i.i.i
  br i1 %_13.not.i.i49.i.i.i, label %bb43.i.i.i, label %bb4.i.i50.i.i.i, !prof !69

bb4.i.i50.i.i.i:                                  ; preds = %_RNvXNtCskuZNHgLkVkS_6memchr3extPhNtB2_7Pointer8distanceCsh1eR4S1pMdQ_9range_ffi.exit.i48.i.i.i
; call core::hint::unreachable_unchecked::precondition_check
  tail call fastcc void @_RNvNvNtCs9l4wcBNbII5_4core4hint21unreachable_unchecked18precondition_check(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_a59d8fe4279b26f926811f91f116a398) #17, !noalias !115
  unreachable

bb1.i51.i.i.i:                                    ; preds = %bb41.i.i.i
  %_296.i.i52.i.i.i = icmp eq i64 %_0.sroa.0.0.i30.i.i.i, %_27.0.i.i.i
  br i1 %_296.i.i52.i.i.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB4_14ForeignContentEB4_.exit, label %bb23.i.i53.i.i.i

bb23.i.i53.i.i.i:                                 ; preds = %bb1.i51.i.i.i, %bb7.i.i58.i.i.i
  %i.sroa.0.08.i.i54.i.i.i = phi i64 [ %38, %bb7.i.i58.i.i.i ], [ 0, %bb1.i51.i.i.i ]
  %_3957.i.i55.i.i.i = phi ptr [ %_39.i.i59.i.i.i, %bb7.i.i58.i.i.i ], [ %_90.i.i.i, %bb1.i51.i.i.i ]
  %ptr.val.i.i56.i.i.i = load i8, ptr %_3957.i.i55.i.i.i, align 1, !alias.scope !143, !noalias !144, !noundef !38
  %_0.i.i.i57.i.i.i = icmp eq i8 %ptr.val.i.i56.i.i.i, 45
  br i1 %_0.i.i.i57.i.i.i, label %bb6.i5.i61.i.i.i, label %bb7.i.i58.i.i.i

bb7.i.i58.i.i.i:                                  ; preds = %bb23.i.i53.i.i.i
  %_39.i.i59.i.i.i = getelementptr inbounds nuw i8, ptr %_3957.i.i55.i.i.i, i64 1
  %38 = add nuw nsw i64 %i.sroa.0.08.i.i54.i.i.i, 1
  %_29.i.i60.i.i.i = icmp eq ptr %_39.i.i59.i.i.i, %_13.i.i.i.i
  br i1 %_29.i.i60.i.i.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB4_14ForeignContentEB4_.exit, label %bb23.i.i53.i.i.i

bb6.i5.i61.i.i.i:                                 ; preds = %bb23.i.i53.i.i.i
  %cond.i.i62.i.i.i = icmp samesign ult i64 %i.sroa.0.08.i.i54.i.i.i, %_88.i.i.i
  br i1 %cond.i.i62.i.i.i, label %bb43.i.i.i, label %bb1.i.i.i63.i.i.i, !prof !69

bb1.i.i.i63.i.i.i:                                ; preds = %bb6.i5.i61.i.i.i
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_64e308ef4babfeb8b6220184de794a17, ptr noundef nonnull inttoptr (i64 443 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_1d1b1e35bb489427b2bdc9752de92226) #16, !noalias !148
  unreachable

bb40.i.i.i:                                       ; preds = %bb8.i.i.i
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCs9l4wcBNbII5_4core5slice5index16slice_index_fail(i64 noundef %_27.0.i.i.i, i64 noundef %_0.sroa.0.0.i30.i.i.i, i64 noundef range(i64 0, -9223372036854775808) %len, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_6ca9fc8d99acf98ecf00d162e0ad6d5e) #16, !noalias !115
  unreachable

bb43.i.i.i:                                       ; preds = %bb6.i5.i61.i.i.i, %_RNvXNtCskuZNHgLkVkS_6memchr3extPhNtB2_7Pointer8distanceCsh1eR4S1pMdQ_9range_ffi.exit.i48.i.i.i
  %_0.sroa.3.0.i3.pn.i42.i.i.i = phi i64 [ %37, %_RNvXNtCskuZNHgLkVkS_6memchr3extPhNtB2_7Pointer8distanceCsh1eR4S1pMdQ_9range_ffi.exit.i48.i.i.i ], [ %i.sroa.0.08.i.i54.i.i.i, %bb6.i5.i61.i.i.i ]
  %_33.0.i.i.i = add nuw i64 %_0.sroa.3.0.i3.pn.i42.i.i.i, %_27.0.i.i.i
  %_33.1.not.i.i.i = icmp ugt i64 %_33.0.i.i.i, %_20.0.i.i.i
  br i1 %_33.1.not.i.i.i, label %bb14.i.i.i, label %panic4.i.i.i

panic4.i.i.i:                                     ; preds = %bb43.i.i.i
; call core::panicking::panic_const::panic_const_add_overflow
  tail call void @_RNvNtNtCs9l4wcBNbII5_4core9panicking11panic_const24panic_const_add_overflow(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_1bb48cd636a7e77d2a1a241c967005fc) #16, !noalias !115
  unreachable

bb14.i.i.i:                                       ; preds = %bb43.i.i.i
  %_36.0.i.i.i = add nuw i64 %_33.0.i.i.i, 1
  %_98.not.i.i.i = icmp ugt i64 %_0.sroa.0.0.i30.i.i.i, %_33.0.i.i.i
  br i1 %_98.not.i.i.i, label %bb45.i.i.i, label %bb44.i.i.i, !prof !69

bb45.i.i.i:                                       ; preds = %bb14.i.i.i
  %_99.i.i.i = sub nuw nsw i64 %_0.sroa.0.0.i30.i.i.i, %_36.0.i.i.i
  %_101.i.i.i = getelementptr inbounds nuw i8, ptr %_0.sroa.0.0.i3.i.i, i64 %_36.0.i.i.i
  tail call void @llvm.experimental.noalias.scope.decl(metadata !149)
  %_3.i65.i.i.i = icmp samesign ult i64 %_99.i.i.i, 17
  br i1 %_3.i65.i.i.i, label %bb1.i78.i.i.i, label %bb3.i67.i.i.i

bb3.i67.i.i.i:                                    ; preds = %bb45.i.i.i
  %39 = load atomic ptr, ptr @_RNvNvNtNtNtCskuZNHgLkVkS_6memchr4arch6x86_646memchr10memchr_raw2FN monotonic, align 8, !noalias !152, !nonnull !38, !noundef !38
  %40 = tail call { i64, ptr } %39(i8 noundef 47, ptr noundef nonnull readonly %_101.i.i.i, ptr noundef nonnull readonly %_13.i.i.i.i) #17, !noalias !155, !inline_history !123
  %41 = extractvalue { i64, ptr } %40, 0
  %42 = trunc nuw i64 %41 to i1
  br i1 %42, label %bb8.i.i72.i.i.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB4_14ForeignContentEB4_.exit

bb8.i.i72.i.i.i:                                  ; preds = %bb3.i67.i.i.i
  %43 = extractvalue { i64, ptr } %40, 1
  %44 = ptrtoint ptr %43 to i64
  %45 = ptrtoint ptr %_101.i.i.i to i64
  %46 = sub i64 %44, %45
  %_8.i.i73.i.i.i = icmp sgt i64 %46, -1
  br i1 %_8.i.i73.i.i.i, label %_RNvXNtCskuZNHgLkVkS_6memchr3extPhNtB2_7Pointer8distanceCsh1eR4S1pMdQ_9range_ffi.exit.i75.i.i.i, label %bb6.i.i74.i.i.i, !prof !69

bb6.i.i74.i.i.i:                                  ; preds = %bb8.i.i72.i.i.i
; call core::hint::unreachable_unchecked::precondition_check
  tail call fastcc void @_RNvNvNtCs9l4wcBNbII5_4core4hint21unreachable_unchecked18precondition_check(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_6d855724149bc5132e1bc43bfd525250) #17, !noalias !115
  unreachable

_RNvXNtCskuZNHgLkVkS_6memchr3extPhNtB2_7Pointer8distanceCsh1eR4S1pMdQ_9range_ffi.exit.i75.i.i.i: ; preds = %bb8.i.i72.i.i.i
  %_13.not.i.i76.i.i.i = icmp samesign ult i64 %46, %_99.i.i.i
  br i1 %_13.not.i.i76.i.i.i, label %bb3.i, label %bb4.i.i77.i.i.i, !prof !69

bb4.i.i77.i.i.i:                                  ; preds = %_RNvXNtCskuZNHgLkVkS_6memchr3extPhNtB2_7Pointer8distanceCsh1eR4S1pMdQ_9range_ffi.exit.i75.i.i.i
; call core::hint::unreachable_unchecked::precondition_check
  tail call fastcc void @_RNvNvNtCs9l4wcBNbII5_4core4hint21unreachable_unchecked18precondition_check(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_a59d8fe4279b26f926811f91f116a398) #17, !noalias !115
  unreachable

bb1.i78.i.i.i:                                    ; preds = %bb45.i.i.i
  %_296.i.i79.i.i.i = icmp eq i64 %_0.sroa.0.0.i30.i.i.i, %_36.0.i.i.i
  br i1 %_296.i.i79.i.i.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB4_14ForeignContentEB4_.exit, label %bb23.i.i80.i.i.i

bb23.i.i80.i.i.i:                                 ; preds = %bb1.i78.i.i.i, %bb7.i.i85.i.i.i
  %i.sroa.0.08.i.i81.i.i.i = phi i64 [ %47, %bb7.i.i85.i.i.i ], [ 0, %bb1.i78.i.i.i ]
  %_3957.i.i82.i.i.i = phi ptr [ %_39.i.i86.i.i.i, %bb7.i.i85.i.i.i ], [ %_101.i.i.i, %bb1.i78.i.i.i ]
  %ptr.val.i.i83.i.i.i = load i8, ptr %_3957.i.i82.i.i.i, align 1, !alias.scope !156, !noalias !157, !noundef !38
  %_0.i.i.i84.i.i.i = icmp eq i8 %ptr.val.i.i83.i.i.i, 47
  br i1 %_0.i.i.i84.i.i.i, label %bb6.i5.i88.i.i.i, label %bb7.i.i85.i.i.i

bb7.i.i85.i.i.i:                                  ; preds = %bb23.i.i80.i.i.i
  %_39.i.i86.i.i.i = getelementptr inbounds nuw i8, ptr %_3957.i.i82.i.i.i, i64 1
  %47 = add nuw nsw i64 %i.sroa.0.08.i.i81.i.i.i, 1
  %_29.i.i87.i.i.i = icmp eq ptr %_39.i.i86.i.i.i, %_13.i.i.i.i
  br i1 %_29.i.i87.i.i.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB4_14ForeignContentEB4_.exit, label %bb23.i.i80.i.i.i

bb6.i5.i88.i.i.i:                                 ; preds = %bb23.i.i80.i.i.i
  %cond.i.i89.i.i.i = icmp samesign ult i64 %i.sroa.0.08.i.i81.i.i.i, %_99.i.i.i
  br i1 %cond.i.i89.i.i.i, label %bb3.i, label %bb1.i.i.i90.i.i.i, !prof !69

bb1.i.i.i90.i.i.i:                                ; preds = %bb6.i5.i88.i.i.i
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_64e308ef4babfeb8b6220184de794a17, ptr noundef nonnull inttoptr (i64 443 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_1d1b1e35bb489427b2bdc9752de92226) #16, !noalias !161
  unreachable

bb44.i.i.i:                                       ; preds = %bb14.i.i.i
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCs9l4wcBNbII5_4core5slice5index16slice_index_fail(i64 noundef %_36.0.i.i.i, i64 noundef %_0.sroa.0.0.i30.i.i.i, i64 noundef range(i64 0, -9223372036854775808) %len, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_cd7dc146611f1efd96d87a1399113f8c) #16, !noalias !115
  unreachable

bb3.i:                                            ; preds = %bb6.i5.i88.i.i.i, %_RNvXNtCskuZNHgLkVkS_6memchr3extPhNtB2_7Pointer8distanceCsh1eR4S1pMdQ_9range_ffi.exit.i75.i.i.i
  %_0.sroa.3.0.i3.pn.i69.i.i.i = phi i64 [ %46, %_RNvXNtCskuZNHgLkVkS_6memchr3extPhNtB2_7Pointer8distanceCsh1eR4S1pMdQ_9range_ffi.exit.i75.i.i.i ], [ %i.sroa.0.08.i.i81.i.i.i, %bb6.i5.i88.i.i.i ]
  %_42.0.i.i.i = add nuw i64 %_0.sroa.3.0.i3.pn.i69.i.i.i, %_36.0.i.i.i
  %_12.not.i.i.i8.i = icmp ne ptr %data, null
  %_7.i.i.i9.i = icmp sgt i64 %len, -1
  %or.cond.i.i.i10.i = and i1 %_12.not.i.i.i8.i, %_7.i.i.i9.i
  br i1 %or.cond.i.i.i10.i, label %bb4.i.i.i, label %bb5.i.i.i11.i, !prof !66

bb5.i.i.i11.i:                                    ; preds = %bb3.i
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_a28e8c8fd5088943a8b5d44af697ff83, ptr noundef nonnull inttoptr (i64 559 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_56c01fe01d1a47ca560ad2a33d46aaec) #16, !noalias !162
  unreachable

bb4.i.i.i:                                        ; preds = %bb3.i
  %48 = getelementptr inbounds nuw i8, ptr %data, i64 %_20.0.i.i.i
  %_20.i.i.i = getelementptr inbounds nuw i8, ptr %48, i64 1
  %_13.not8.i.i.i14.i = icmp eq i64 %_0.sroa.3.0.i3.pn.i42.i.i.i, 0
  br i1 %_13.not8.i.i.i14.i, label %_RINvXCsh1eR4S1pMdQ_9range_ffiNtB3_14ForeignContentNtNtB3_17http_range_parser13ContentSource10with_bytesINtNtCs9l4wcBNbII5_4core6option6OptionxENCINvBO_13parse_contentBr_Es_0EB3_.exit.i, label %bb8.preheader.i.i.i.i

bb8.preheader.i.i.i.i:                            ; preds = %bb4.i.i.i
  %scevgep.i.i.i.i = getelementptr i8, ptr %data, i64 %_33.0.i.i.i
  br label %bb8.i.i.i15.i

bb8.i.i.i15.i:                                    ; preds = %bb13.i.i.i19.i, %bb8.preheader.i.i.i.i
  %input.sroa.0.010.i.i.i16.i = phi ptr [ %_24.i.i.i21.i, %bb13.i.i.i19.i ], [ %_20.i.i.i, %bb8.preheader.i.i.i.i ]
  %input.sroa.10.09.i.i.i17.i = phi i64 [ %_20.i.i.i20.i, %bb13.i.i.i19.i ], [ %_0.sroa.3.0.i3.pn.i42.i.i.i, %bb8.preheader.i.i.i.i ]
  %_16.i.i.i18.i = load i8, ptr %input.sroa.0.010.i.i.i16.i, align 1, !alias.scope !163, !noalias !162, !noundef !38
  switch i8 %_16.i.i.i18.i, label %bb14.i.i.i24.i [
    i8 32, label %bb13.i.i.i19.i
    i8 9, label %bb13.i.i.i19.i
  ]

bb14.i.i.i24.i:                                   ; preds = %bb8.i.i.i15.i, %bb18.i.i.i28.i
  %input.sroa.10.115.i.i.i25.i = phi i64 [ %49, %bb18.i.i.i28.i ], [ %input.sroa.10.09.i.i.i17.i, %bb8.i.i.i15.i ]
  %49 = add nsw i64 %input.sroa.10.115.i.i.i25.i, -1
  %_27.i.i.i26.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.010.i.i.i16.i, i64 %49
  %_29.i.i.i27.i = load i8, ptr %_27.i.i.i26.i, align 1, !alias.scope !163, !noalias !162, !noundef !38
  switch i8 %_29.i.i.i27.i, label %_RINvXCsh1eR4S1pMdQ_9range_ffiNtB3_14ForeignContentNtNtB3_17http_range_parser13ContentSource10with_bytesINtNtCs9l4wcBNbII5_4core6option6OptionxENCINvBO_13parse_contentBr_Es_0EB3_.exit.i [
    i8 32, label %bb18.i.i.i28.i
    i8 9, label %bb18.i.i.i28.i
  ]

bb18.i.i.i28.i:                                   ; preds = %bb14.i.i.i24.i, %bb14.i.i.i24.i
  %_26.not.i.i.i29.i = icmp eq i64 %49, 0
  br i1 %_26.not.i.i.i29.i, label %_RINvXCsh1eR4S1pMdQ_9range_ffiNtB3_14ForeignContentNtNtB3_17http_range_parser13ContentSource10with_bytesINtNtCs9l4wcBNbII5_4core6option6OptionxENCINvBO_13parse_contentBr_Es_0EB3_.exit.i, label %bb14.i.i.i24.i

bb13.i.i.i19.i:                                   ; preds = %bb8.i.i.i15.i, %bb8.i.i.i15.i
  %_20.i.i.i20.i = add nsw i64 %input.sroa.10.09.i.i.i17.i, -1
  %_24.i.i.i21.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.010.i.i.i16.i, i64 1
  %_13.not.i.i.i22.i = icmp eq i64 %_20.i.i.i20.i, 0
  br i1 %_13.not.i.i.i22.i, label %_RINvXCsh1eR4S1pMdQ_9range_ffiNtB3_14ForeignContentNtNtB3_17http_range_parser13ContentSource10with_bytesINtNtCs9l4wcBNbII5_4core6option6OptionxENCINvBO_13parse_contentBr_Es_0EB3_.exit.i, label %bb8.i.i.i15.i

_RINvXCsh1eR4S1pMdQ_9range_ffiNtB3_14ForeignContentNtNtB3_17http_range_parser13ContentSource10with_bytesINtNtCs9l4wcBNbII5_4core6option6OptionxENCINvBO_13parse_contentBr_Es_0EB3_.exit.i: ; preds = %bb13.i.i.i19.i, %bb18.i.i.i28.i, %bb14.i.i.i24.i, %bb4.i.i.i
  %input.sroa.0.0.lcssa22.i.i.i.i = phi ptr [ %input.sroa.0.010.i.i.i16.i, %bb18.i.i.i28.i ], [ %_20.i.i.i, %bb4.i.i.i ], [ %input.sroa.0.010.i.i.i16.i, %bb14.i.i.i24.i ], [ %scevgep.i.i.i.i, %bb13.i.i.i19.i ]
  %input.sroa.10.1.lcssa.i.i.i.i = phi i64 [ 0, %bb18.i.i.i28.i ], [ 0, %bb4.i.i.i ], [ %input.sroa.10.115.i.i.i25.i, %bb14.i.i.i24.i ], [ 0, %bb13.i.i.i19.i ]
; call range_ffi::http_range_parser::legacy_i64
  %50 = tail call fastcc { i64, i64 } @_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser10legacy_i64(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %input.sroa.0.0.lcssa22.i.i.i.i, i64 noundef %input.sroa.10.1.lcssa.i.i.i.i) #17, !noalias !162
  %51 = extractvalue { i64, i64 } %50, 0
  %52 = trunc nuw i64 %51 to i1
  br i1 %52, label %bb1.i.i.i31.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB4_14ForeignContentEB4_.exit

bb1.i.i.i31.i:                                    ; preds = %_RINvXCsh1eR4S1pMdQ_9range_ffiNtB3_14ForeignContentNtNtB3_17http_range_parser13ContentSource10with_bytesINtNtCs9l4wcBNbII5_4core6option6OptionxENCINvBO_13parse_contentBr_Es_0EB3_.exit.i
  %53 = extractvalue { i64, i64 } %50, 1
  store i64 %53, ptr %first, align 8, !noalias !168
  tail call void @llvm.experimental.noalias.scope.decl(metadata !171)
  %_11.not.i.i.i.i = icmp ugt i64 %_42.0.i.i.i, %len
  br i1 %_11.not.i.i.i.i, label %bb6.i.i.i37.i, label %bb4.i.i.i.i, !prof !114

bb4.i.i.i.i:                                      ; preds = %bb1.i.i.i31.i
  %_20.i.i.i33.i = getelementptr inbounds nuw i8, ptr %data, i64 %_36.0.i.i.i
  %_13.not8.i.i.i.i.i = icmp eq i64 %_0.sroa.3.0.i3.pn.i69.i.i.i, 0
  br i1 %_13.not8.i.i.i.i.i, label %_RINvXCsh1eR4S1pMdQ_9range_ffiNtB3_14ForeignContentNtNtB3_17http_range_parser13ContentSource10with_bytesINtNtCs9l4wcBNbII5_4core6option6OptionxENCNCINvBO_13parse_contentBr_Es0_00EB3_.exit.i.i, label %bb8.preheader.i.i.i.i.i

bb8.preheader.i.i.i.i.i:                          ; preds = %bb4.i.i.i.i
  %scevgep.i.i.i.i.i = getelementptr i8, ptr %data, i64 %_42.0.i.i.i
  br label %bb8.i.i.i.i34.i

bb8.i.i.i.i34.i:                                  ; preds = %bb13.i.i.i.i.i, %bb8.preheader.i.i.i.i.i
  %input.sroa.0.010.i.i.i.i.i = phi ptr [ %_24.i.i.i.i.i, %bb13.i.i.i.i.i ], [ %_20.i.i.i33.i, %bb8.preheader.i.i.i.i.i ]
  %input.sroa.10.09.i.i.i.i.i = phi i64 [ %_20.i.i.i.i.i, %bb13.i.i.i.i.i ], [ %_0.sroa.3.0.i3.pn.i69.i.i.i, %bb8.preheader.i.i.i.i.i ]
  %_16.i.i.i.i.i = load i8, ptr %input.sroa.0.010.i.i.i.i.i, align 1, !alias.scope !174, !noalias !177, !noundef !38
  switch i8 %_16.i.i.i.i.i, label %bb14.i.i.i.i.i [
    i8 32, label %bb13.i.i.i.i.i
    i8 9, label %bb13.i.i.i.i.i
  ]

bb14.i.i.i.i.i:                                   ; preds = %bb8.i.i.i.i34.i, %bb18.i.i.i.i.i
  %input.sroa.10.115.i.i.i.i.i = phi i64 [ %54, %bb18.i.i.i.i.i ], [ %input.sroa.10.09.i.i.i.i.i, %bb8.i.i.i.i34.i ]
  %54 = add nsw i64 %input.sroa.10.115.i.i.i.i.i, -1
  %_27.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.010.i.i.i.i.i, i64 %54
  %_29.i.i.i.i36.i = load i8, ptr %_27.i.i.i.i.i, align 1, !alias.scope !174, !noalias !177, !noundef !38
  switch i8 %_29.i.i.i.i36.i, label %_RINvXCsh1eR4S1pMdQ_9range_ffiNtB3_14ForeignContentNtNtB3_17http_range_parser13ContentSource10with_bytesINtNtCs9l4wcBNbII5_4core6option6OptionxENCNCINvBO_13parse_contentBr_Es0_00EB3_.exit.i.i [
    i8 32, label %bb18.i.i.i.i.i
    i8 9, label %bb18.i.i.i.i.i
  ]

bb18.i.i.i.i.i:                                   ; preds = %bb14.i.i.i.i.i, %bb14.i.i.i.i.i
  %_26.not.i.i.i.i.i = icmp eq i64 %54, 0
  br i1 %_26.not.i.i.i.i.i, label %_RINvXCsh1eR4S1pMdQ_9range_ffiNtB3_14ForeignContentNtNtB3_17http_range_parser13ContentSource10with_bytesINtNtCs9l4wcBNbII5_4core6option6OptionxENCNCINvBO_13parse_contentBr_Es0_00EB3_.exit.i.i, label %bb14.i.i.i.i.i

bb13.i.i.i.i.i:                                   ; preds = %bb8.i.i.i.i34.i, %bb8.i.i.i.i34.i
  %_20.i.i.i.i.i = add nsw i64 %input.sroa.10.09.i.i.i.i.i, -1
  %_24.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.010.i.i.i.i.i, i64 1
  %_13.not.i.i.i.i35.i = icmp eq i64 %_20.i.i.i.i.i, 0
  br i1 %_13.not.i.i.i.i35.i, label %_RINvXCsh1eR4S1pMdQ_9range_ffiNtB3_14ForeignContentNtNtB3_17http_range_parser13ContentSource10with_bytesINtNtCs9l4wcBNbII5_4core6option6OptionxENCNCINvBO_13parse_contentBr_Es0_00EB3_.exit.i.i, label %bb8.i.i.i.i34.i

bb6.i.i.i37.i:                                    ; preds = %bb1.i.i.i31.i
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCs9l4wcBNbII5_4core5slice5index16slice_index_fail(i64 noundef %_36.0.i.i.i, i64 noundef %_42.0.i.i.i, i64 noundef range(i64 0, -9223372036854775808) %len, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_f9be6c591f7e00dc1cf1dc33e68f267a) #16, !noalias !180
  unreachable

_RINvXCsh1eR4S1pMdQ_9range_ffiNtB3_14ForeignContentNtNtB3_17http_range_parser13ContentSource10with_bytesINtNtCs9l4wcBNbII5_4core6option6OptionxENCNCINvBO_13parse_contentBr_Es0_00EB3_.exit.i.i: ; preds = %bb13.i.i.i.i.i, %bb18.i.i.i.i.i, %bb14.i.i.i.i.i, %bb4.i.i.i.i
  %input.sroa.0.0.lcssa22.i.i.i.i.i = phi ptr [ %input.sroa.0.010.i.i.i.i.i, %bb18.i.i.i.i.i ], [ %_20.i.i.i33.i, %bb4.i.i.i.i ], [ %input.sroa.0.010.i.i.i.i.i, %bb14.i.i.i.i.i ], [ %scevgep.i.i.i.i.i, %bb13.i.i.i.i.i ]
  %input.sroa.10.1.lcssa.i.i.i.i.i = phi i64 [ 0, %bb18.i.i.i.i.i ], [ 0, %bb4.i.i.i.i ], [ %input.sroa.10.115.i.i.i.i.i, %bb14.i.i.i.i.i ], [ 0, %bb13.i.i.i.i.i ]
; call range_ffi::http_range_parser::legacy_i64
  %55 = tail call fastcc { i64, i64 } @_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser10legacy_i64(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %input.sroa.0.0.lcssa22.i.i.i.i.i, i64 noundef %input.sroa.10.1.lcssa.i.i.i.i.i) #17, !noalias !177
  %56 = extractvalue { i64, i64 } %55, 0
  %57 = trunc nuw i64 %56 to i1
  br i1 %57, label %bb3.i.i, label %bb9.i

bb3.i.i:                                          ; preds = %_RINvXCsh1eR4S1pMdQ_9range_ffiNtB3_14ForeignContentNtNtB3_17http_range_parser13ContentSource10with_bytesINtNtCs9l4wcBNbII5_4core6option6OptionxENCNCINvBO_13parse_contentBr_Es0_00EB3_.exit.i.i
  %58 = extractvalue { i64, i64 } %55, 1
  store i64 %58, ptr %last, align 8, !noalias !181
  %_0.i8.i.i = load i64, ptr %first, align 8, !noalias !184, !noundef !38
  %_8.i.i = icmp slt i64 %58, %_0.i8.i.i
  br i1 %_8.i.i, label %bb9.i, label %bb1.i.i18.i.i

bb1.i.i18.i.i:                                    ; preds = %bb3.i.i
  tail call void @llvm.experimental.noalias.scope.decl(metadata !187)
  %_7.0.i.i16.i.i = add nuw i64 %_42.0.i.i.i, 1
  %_17.i.i19.i.not.i = icmp ugt i64 %_0.sroa.0.0.i30.i.i.i, %_42.0.i.i.i
  br i1 %_17.i.i19.i.not.i, label %bb4.i.i22.i.i, label %bb6.i.i45.i.i, !prof !190

bb4.i.i22.i.i:                                    ; preds = %bb1.i.i18.i.i
  %_18.i.i23.i.i = sub nuw i64 %_0.sroa.0.0.i30.i.i.i, %_7.0.i.i16.i.i
  %_20.i.i24.i.i = getelementptr inbounds nuw i8, ptr %data, i64 %_7.0.i.i16.i.i
  %_13.not8.i.i.i25.i.i = icmp eq i64 %_18.i.i23.i.i, 0
  br i1 %_13.not8.i.i.i25.i.i, label %_RINvXCsh1eR4S1pMdQ_9range_ffiNtB3_14ForeignContentNtNtB3_17http_range_parser13ContentSource10with_bytesINtNtCs9l4wcBNbII5_4core6option6OptionxENCNCINvBO_13parse_contentBr_Es0_0s_0EB3_.exit.i.i, label %bb8.preheader.i.i.i26.i.i

bb8.preheader.i.i.i26.i.i:                        ; preds = %bb4.i.i22.i.i
  %scevgep.i.i.i27.i.i = getelementptr i8, ptr %data, i64 %_0.sroa.0.0.i30.i.i.i
  br label %bb8.i.i.i28.i.i

bb8.i.i.i28.i.i:                                  ; preds = %bb13.i.i.i32.i.i, %bb8.preheader.i.i.i26.i.i
  %input.sroa.0.010.i.i.i29.i.i = phi ptr [ %_24.i.i.i34.i.i, %bb13.i.i.i32.i.i ], [ %_20.i.i24.i.i, %bb8.preheader.i.i.i26.i.i ]
  %input.sroa.10.09.i.i.i30.i.i = phi i64 [ %_20.i.i.i33.i.i, %bb13.i.i.i32.i.i ], [ %_18.i.i23.i.i, %bb8.preheader.i.i.i26.i.i ]
  %_16.i.i.i31.i.i = load i8, ptr %input.sroa.0.010.i.i.i29.i.i, align 1, !alias.scope !191, !noalias !177, !noundef !38
  switch i8 %_16.i.i.i31.i.i, label %bb14.i.i.i39.i.i [
    i8 32, label %bb13.i.i.i32.i.i
    i8 9, label %bb13.i.i.i32.i.i
  ]

bb14.i.i.i39.i.i:                                 ; preds = %bb8.i.i.i28.i.i, %bb18.i.i.i43.i.i
  %input.sroa.10.115.i.i.i40.i.i = phi i64 [ %59, %bb18.i.i.i43.i.i ], [ %input.sroa.10.09.i.i.i30.i.i, %bb8.i.i.i28.i.i ]
  %59 = add nsw i64 %input.sroa.10.115.i.i.i40.i.i, -1
  %_27.i.i.i41.i.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.010.i.i.i29.i.i, i64 %59
  %_29.i.i.i42.i.i = load i8, ptr %_27.i.i.i41.i.i, align 1, !alias.scope !191, !noalias !177, !noundef !38
  switch i8 %_29.i.i.i42.i.i, label %_RINvXCsh1eR4S1pMdQ_9range_ffiNtB3_14ForeignContentNtNtB3_17http_range_parser13ContentSource10with_bytesINtNtCs9l4wcBNbII5_4core6option6OptionxENCNCINvBO_13parse_contentBr_Es0_0s_0EB3_.exit.i.i [
    i8 32, label %bb18.i.i.i43.i.i
    i8 9, label %bb18.i.i.i43.i.i
  ]

bb18.i.i.i43.i.i:                                 ; preds = %bb14.i.i.i39.i.i, %bb14.i.i.i39.i.i
  %_26.not.i.i.i44.i.i = icmp eq i64 %59, 0
  br i1 %_26.not.i.i.i44.i.i, label %_RINvXCsh1eR4S1pMdQ_9range_ffiNtB3_14ForeignContentNtNtB3_17http_range_parser13ContentSource10with_bytesINtNtCs9l4wcBNbII5_4core6option6OptionxENCNCINvBO_13parse_contentBr_Es0_0s_0EB3_.exit.i.i, label %bb14.i.i.i39.i.i

bb13.i.i.i32.i.i:                                 ; preds = %bb8.i.i.i28.i.i, %bb8.i.i.i28.i.i
  %_20.i.i.i33.i.i = add nsw i64 %input.sroa.10.09.i.i.i30.i.i, -1
  %_24.i.i.i34.i.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.010.i.i.i29.i.i, i64 1
  %_13.not.i.i.i35.i.i = icmp eq i64 %_20.i.i.i33.i.i, 0
  br i1 %_13.not.i.i.i35.i.i, label %_RINvXCsh1eR4S1pMdQ_9range_ffiNtB3_14ForeignContentNtNtB3_17http_range_parser13ContentSource10with_bytesINtNtCs9l4wcBNbII5_4core6option6OptionxENCNCINvBO_13parse_contentBr_Es0_0s_0EB3_.exit.i.i, label %bb8.i.i.i28.i.i

bb6.i.i45.i.i:                                    ; preds = %bb1.i.i18.i.i
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCs9l4wcBNbII5_4core5slice5index16slice_index_fail(i64 noundef %_7.0.i.i16.i.i, i64 noundef %_0.sroa.0.0.i30.i.i.i, i64 noundef range(i64 0, -9223372036854775808) %len, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_0a48ea62e5579eec5969b23ab3020878) #16, !noalias !194
  unreachable

_RINvXCsh1eR4S1pMdQ_9range_ffiNtB3_14ForeignContentNtNtB3_17http_range_parser13ContentSource10with_bytesINtNtCs9l4wcBNbII5_4core6option6OptionxENCNCINvBO_13parse_contentBr_Es0_0s_0EB3_.exit.i.i: ; preds = %bb13.i.i.i32.i.i, %bb18.i.i.i43.i.i, %bb14.i.i.i39.i.i, %bb4.i.i22.i.i
  %input.sroa.0.0.lcssa22.i.i.i36.i.i = phi ptr [ %input.sroa.0.010.i.i.i29.i.i, %bb18.i.i.i43.i.i ], [ %_20.i.i24.i.i, %bb4.i.i22.i.i ], [ %input.sroa.0.010.i.i.i29.i.i, %bb14.i.i.i39.i.i ], [ %scevgep.i.i.i27.i.i, %bb13.i.i.i32.i.i ]
  %input.sroa.10.1.lcssa.i.i.i37.i.i = phi i64 [ 0, %bb18.i.i.i43.i.i ], [ 0, %bb4.i.i22.i.i ], [ %input.sroa.10.115.i.i.i40.i.i, %bb14.i.i.i39.i.i ], [ 0, %bb13.i.i.i32.i.i ]
; call range_ffi::http_range_parser::legacy_i64
  %60 = tail call fastcc { i64, i64 } @_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser10legacy_i64(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %input.sroa.0.0.lcssa22.i.i.i36.i.i, i64 noundef %input.sroa.10.1.lcssa.i.i.i37.i.i) #17, !noalias !177
  %61 = extractvalue { i64, i64 } %60, 0
  %62 = trunc nuw i64 %61 to i1
  br i1 %62, label %_RNCINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB6_14ForeignContentEs0_0B6_.exit.i, label %bb9.i

_RNCINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB6_14ForeignContentEs0_0B6_.exit.i: ; preds = %_RINvXCsh1eR4S1pMdQ_9range_ffiNtB3_14ForeignContentNtNtB3_17http_range_parser13ContentSource10with_bytesINtNtCs9l4wcBNbII5_4core6option6OptionxENCNCINvBO_13parse_contentBr_Es0_0s_0EB3_.exit.i.i
  %63 = extractvalue { i64, i64 } %60, 1
  store i64 %63, ptr %length, align 8, !noalias !195
  %_0.i51.i.i = load i64, ptr %last, align 8, !noalias !198, !noundef !38
  %64 = icmp sgt i64 %63, %_0.i51.i.i
  br i1 %64, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB4_14ForeignContentEB4_.exit, label %bb9.i

bb9.i:                                            ; preds = %_RINvXCsh1eR4S1pMdQ_9range_ffiNtB3_14ForeignContentNtNtB3_17http_range_parser13ContentSource10with_bytesINtNtCs9l4wcBNbII5_4core6option6OptionxENCNCINvBO_13parse_contentBr_Es0_00EB3_.exit.i.i, %_RNCINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB6_14ForeignContentEs0_0B6_.exit.i, %_RINvXCsh1eR4S1pMdQ_9range_ffiNtB3_14ForeignContentNtNtB3_17http_range_parser13ContentSource10with_bytesINtNtCs9l4wcBNbII5_4core6option6OptionxENCNCINvBO_13parse_contentBr_Es0_0s_0EB3_.exit.i.i, %bb3.i.i
  store i64 -1, ptr %length, align 8, !noalias !201
  store i64 -1, ptr %last, align 8, !noalias !206
  store i64 -1, ptr %first, align 8, !noalias !209
  br label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB4_14ForeignContentEB4_.exit

_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB4_14ForeignContentEB4_.exit: ; preds = %bb7.i.i.i.i.i, %bb13.i.i.i.i, %bb18.i.i.i.i, %bb7.i.i58.i.i.i, %bb7.i.i85.i.i.i, %bb3.i31.i.i.i, %bb1.i.i.i.i, %bb30.i.i.i, %_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4trim.exit.i.i.i, %bb39.i.i.i, %bb1.1.i.i.i.i, %bb1.2.i.i.i.i, %bb1.3.i.i.i.i, %_RNvMNtNtCs9l4wcBNbII5_4core5slice5asciiSh27eq_ignore_ascii_case_simple.exit.i.i.i, %bb3.i40.i.i.i, %bb1.i51.i.i.i, %bb3.i67.i.i.i, %bb1.i78.i.i.i, %_RINvXCsh1eR4S1pMdQ_9range_ffiNtB3_14ForeignContentNtNtB3_17http_range_parser13ContentSource10with_bytesINtNtCs9l4wcBNbII5_4core6option6OptionxENCINvBO_13parse_contentBr_Es_0EB3_.exit.i, %_RNCINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB6_14ForeignContentEs0_0B6_.exit.i, %bb9.i
  %success.sroa.0.0.i = phi i1 [ true, %_RNCINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB6_14ForeignContentEs0_0B6_.exit.i ], [ false, %bb9.i ], [ false, %_RINvXCsh1eR4S1pMdQ_9range_ffiNtB3_14ForeignContentNtNtB3_17http_range_parser13ContentSource10with_bytesINtNtCs9l4wcBNbII5_4core6option6OptionxENCINvBO_13parse_contentBr_Es_0EB3_.exit.i ], [ false, %_RNvMNtNtCs9l4wcBNbII5_4core5slice5asciiSh27eq_ignore_ascii_case_simple.exit.i.i.i ], [ false, %bb1.i51.i.i.i ], [ false, %bb1.i.i.i.i ], [ false, %bb18.i.i.i.i ], [ false, %bb3.i31.i.i.i ], [ false, %bb7.i.i58.i.i.i ], [ false, %bb7.i.i85.i.i.i ], [ false, %bb1.1.i.i.i.i ], [ false, %bb1.2.i.i.i.i ], [ false, %bb1.3.i.i.i.i ], [ false, %bb39.i.i.i ], [ false, %bb30.i.i.i ], [ false, %_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4trim.exit.i.i.i ], [ false, %bb13.i.i.i.i ], [ false, %bb3.i40.i.i.i ], [ false, %bb1.i78.i.i.i ], [ false, %bb3.i67.i.i.i ], [ false, %bb7.i.i.i.i.i ]
  ret i1 %success.sroa.0.0.i
}

; Function Attrs: nounwind uwtable
define noundef zeroext i1 @rustium_http_range_fetch(ptr nofree noundef readonly captures(address) %data, i64 noundef %len, i1 noundef zeroext %whitespace, ptr nofree noundef writeonly captures(none) %output) unnamed_addr #1 personality ptr @__CxxFrameHandler3 !guid !212 {
start:
  %_27.i51.i = alloca [16 x i8], align 8
  %_27.i11.i = alloca [16 x i8], align 8
  %0 = icmp eq i64 %len, 0
  br i1 %0, label %bb5, label %bb2.i

bb2.i:                                            ; preds = %start
  %_12.not.i.i = icmp ne ptr %data, null
  %_7.i.i = icmp sgt i64 %len, -1
  %or.cond.i.i = and i1 %_12.not.i.i, %_7.i.i
  br i1 %or.cond.i.i, label %_RNvCsh1eR4S1pMdQ_9range_ffi5bytes.exit, label %bb5.i.i, !prof !66

bb5.i.i:                                          ; preds = %bb2.i
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_a28e8c8fd5088943a8b5d44af697ff83, ptr noundef nonnull inttoptr (i64 559 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_56c01fe01d1a47ca560ad2a33d46aaec) #16
  unreachable

_RNvCsh1eR4S1pMdQ_9range_ffi5bytes.exit:          ; preds = %bb2.i
  tail call void @llvm.experimental.noalias.scope.decl(metadata !213)
  %_4.not.i.i = icmp samesign ult i64 %len, 5
  br i1 %_4.not.i.i, label %bb5, label %_RNvMNtCs9l4wcBNbII5_4core5sliceSh11starts_withCsh1eR4S1pMdQ_9range_ffi.exit.i

_RNvMNtCs9l4wcBNbII5_4core5sliceSh11starts_withCsh1eR4S1pMdQ_9range_ffi.exit.i: ; preds = %_RNvCsh1eR4S1pMdQ_9range_ffi5bytes.exit
  %1 = load i32, ptr %data, align 1
  %2 = xor i32 1702132066, %1
  %3 = getelementptr i8, ptr %data, i64 4
  %4 = load i8, ptr %3, align 1
  %5 = zext i8 %4 to i32
  %6 = xor i32 115, %5
  %7 = or i32 %2, %6
  %8 = icmp ne i32 %7, 0
  %9 = zext i1 %8 to i32
  %_0.i.i.i = icmp eq i32 %9, 0
  br i1 %_0.i.i.i, label %bb2.i3, label %bb5

bb2.i3:                                           ; preds = %_RNvMNtCs9l4wcBNbII5_4core5sliceSh11starts_withCsh1eR4S1pMdQ_9range_ffi.exit.i
  %_174.i.i = icmp ne i64 %len, 5
  %or.cond.i.i4 = and i1 %whitespace, %_174.i.i
  br i1 %or.cond.i.i4, label %bb15.i.i, label %bb5.i.i5

bb5.i.i5:                                         ; preds = %bb15.i.i, %bb2.i3
  %_11.i.i = phi i64 [ 5, %bb2.i3 ], [ %_8.035.i.i, %bb15.i.i ]
  %_22.i.i = icmp samesign ult i64 %_11.i.i, %len
  br i1 %_22.i.i, label %bb19.i.i, label %bb5

bb15.i.i:                                         ; preds = %bb2.i3, %bb3.i.i
  %_8.035.i.i = phi i64 [ %_8.0.i.i, %bb3.i.i ], [ 5, %bb2.i3 ]
  %_19.i.i = getelementptr inbounds nuw i8, ptr %data, i64 %_8.035.i.i
  %_21.i.i = load i8, ptr %_19.i.i, align 1, !alias.scope !216, !noundef !38
  switch i8 %_21.i.i, label %bb5.i.i5 [
    i8 32, label %bb3.i.i
    i8 9, label %bb3.i.i
  ]

bb19.i.i:                                         ; preds = %bb5.i.i5
  %_24.i.i = getelementptr inbounds nuw i8, ptr %data, i64 %_11.i.i
  %_27.i.i = load i8, ptr %_24.i.i, align 1, !alias.scope !216, !noundef !38
  %_25.not.i.i = icmp eq i8 %_27.i.i, 61
  br i1 %_25.not.i.i, label %bb8.i.i, label %bb5

bb8.i.i:                                          ; preds = %bb19.i.i
  %_12.0.i.i = add nuw nsw i64 %_11.i.i, 1
  %_288.i.i = icmp samesign ult i64 %_12.0.i.i, %len
  %or.cond10.i.i = select i1 %whitespace, i1 %_288.i.i, i1 false
  br i1 %or.cond10.i.i, label %bb21.i.i, label %bb5.i

bb21.i.i:                                         ; preds = %bb8.i.i, %bb11.i.i
  %pos.sroa.0.1.i = phi i64 [ %_16.0.i.i, %bb11.i.i ], [ %_12.0.i.i, %bb8.i.i ]
  %_29.i.i = getelementptr inbounds nuw i8, ptr %data, i64 %pos.sroa.0.1.i
  %_31.i.i = load i8, ptr %_29.i.i, align 1, !alias.scope !216, !noundef !38
  switch i8 %_31.i.i, label %bb5.i [
    i8 32, label %bb11.i.i
    i8 9, label %bb11.i.i
  ]

bb11.i.i:                                         ; preds = %bb21.i.i, %bb21.i.i
  %_16.0.i.i = add nuw nsw i64 %pos.sroa.0.1.i, 1
  %exitcond11.not.i.i = icmp eq i64 %_16.0.i.i, %len
  br i1 %exitcond11.not.i.i, label %bb5, label %bb21.i.i

bb3.i.i:                                          ; preds = %bb15.i.i, %bb15.i.i
  %_8.0.i.i = add nuw nsw i64 %_8.035.i.i, 1
  %exitcond.not.i.i = icmp eq i64 %_8.0.i.i, %len
  br i1 %exitcond.not.i.i, label %bb5, label %bb15.i.i

bb5.i:                                            ; preds = %bb21.i.i, %bb8.i.i
  %pos.sroa.0.3.ph.i = phi i64 [ %_12.0.i.i, %bb8.i.i ], [ %pos.sroa.0.1.i, %bb21.i.i ]
  tail call void @llvm.experimental.noalias.scope.decl(metadata !219)
  %_135.i.i = icmp ult i64 %pos.sroa.0.3.ph.i, %len
  br i1 %_135.i.i, label %bb8.i13.i, label %_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13fetch_decimal.exit.i

bb8.i13.i:                                        ; preds = %bb5.i, %bb3.i18.i
  %pos.sroa.0.4.i = phi i64 [ %_6.0.i.i, %bb3.i18.i ], [ %pos.sroa.0.3.ph.i, %bb5.i ]
  %_15.i.i = getelementptr inbounds nuw i8, ptr %data, i64 %pos.sroa.0.4.i
  %10 = load i8, ptr %_15.i.i, align 1, !alias.scope !222, !noundef !38
  %11 = add i8 %10, -48
  %or.cond.i14.i = icmp ult i8 %11, 10
  br i1 %or.cond.i14.i, label %bb3.i18.i, label %bb4.i15.i

bb4.i15.i:                                        ; preds = %bb3.i18.i, %bb8.i13.i
  %pos.sroa.0.5.i = phi i64 [ %len, %bb3.i18.i ], [ %pos.sroa.0.4.i, %bb8.i13.i ]
  %_7.i.i6 = icmp eq i64 %pos.sroa.0.3.ph.i, %pos.sroa.0.5.i
  br i1 %_7.i.i6, label %_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13fetch_decimal.exit.i, label %bb6.i.i

bb6.i.i:                                          ; preds = %bb4.i15.i
  %_23.i.i = icmp ult i64 %pos.sroa.0.5.i, %pos.sroa.0.3.ph.i
  %_19.not.i.i = icmp ugt i64 %pos.sroa.0.5.i, %len
  %or.cond3.i.i = or i1 %_23.i.i, %_19.not.i.i
  br i1 %or.cond3.i.i, label %bb14.i.i, label %bb13.i.i, !prof !114

bb14.i.i:                                         ; preds = %bb6.i.i
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCs9l4wcBNbII5_4core5slice5index16slice_index_fail(i64 noundef %pos.sroa.0.3.ph.i, i64 noundef %pos.sroa.0.5.i, i64 noundef range(i64 0, -9223372036854775808) %len, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_df10a442b0b4a87147a8f65479b3c67a) #16, !noalias !223
  unreachable

bb13.i.i:                                         ; preds = %bb6.i.i
  %_24.i16.i = sub nuw nsw i64 %pos.sroa.0.5.i, %pos.sroa.0.3.ph.i
  %_26.i.i = getelementptr inbounds nuw i8, ptr %data, i64 %pos.sroa.0.3.ph.i
  call void @llvm.lifetime.start.p0(ptr nonnull %_27.i11.i), !noalias !223
; call parse_number_core::parse_slice::<9223372036854775807, 9223372036854775808>
  call fastcc void @_RINvCs4A2AHSyUD2M_17parse_number_core11parse_sliceKy7fffffffffffffff_Ky8000000000000000_ECsh1eR4S1pMdQ_9range_ffi(ptr noalias nofree noundef align 8 captures(address) dereferenceable(16) %_27.i11.i, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %_26.i.i, i64 noundef %_24.i16.i, i32 noundef 0) #17
  %12 = getelementptr inbounds nuw i8, ptr %_27.i11.i, i64 8
  %13 = load i8, ptr %12, align 8, !range !83, !noalias !223, !noundef !38
  %14 = icmp eq i8 %13, 2
  %_31.i17.i = load i64, ptr %_27.i11.i, align 8, !noalias !223
  %_32.i.i = trunc nuw i8 %13 to i1
  %15 = sub i64 0, %_31.i17.i
  %_29.sroa.0.0.i.i = select i1 %_32.i.i, i64 %15, i64 %_31.i17.i
  %_0.sroa.3.0.ph.i.i = select i1 %14, i64 9223372036854775807, i64 %_29.sroa.0.0.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_27.i11.i), !noalias !223
  br label %_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13fetch_decimal.exit.i

bb3.i18.i:                                        ; preds = %bb8.i13.i
  %_6.0.i.i = add i64 %pos.sroa.0.4.i, 1
  %exitcond.not.i19.i = icmp eq i64 %_6.0.i.i, %len
  br i1 %exitcond.not.i19.i, label %bb4.i15.i, label %bb8.i13.i

_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13fetch_decimal.exit.i: ; preds = %bb13.i.i, %bb4.i15.i, %bb5.i
  %pos.sroa.0.6.i = phi i64 [ %pos.sroa.0.3.ph.i, %bb4.i15.i ], [ %pos.sroa.0.5.i, %bb13.i.i ], [ %pos.sroa.0.3.ph.i, %bb5.i ]
  %_0.sroa.3.0.i.i = phi i64 [ undef, %bb4.i15.i ], [ %_0.sroa.3.0.ph.i.i, %bb13.i.i ], [ undef, %bb5.i ]
  %_0.sroa.0.0.i12.i = phi i1 [ false, %bb4.i15.i ], [ true, %bb13.i.i ], [ false, %bb5.i ]
  %_174.i21.i = icmp ult i64 %pos.sroa.0.6.i, %len
  %or.cond.i22.i = and i1 %whitespace, %_174.i21.i
  br i1 %or.cond.i22.i, label %bb15.i43.i, label %bb5.i23.i

bb5.i23.i:                                        ; preds = %bb15.i43.i, %_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13fetch_decimal.exit.i
  %_11.i24.i = phi i64 [ %pos.sroa.0.6.i, %_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13fetch_decimal.exit.i ], [ %_8.035.i44.i, %bb15.i43.i ]
  %_22.i25.i = icmp ult i64 %_11.i24.i, %len
  br i1 %_22.i25.i, label %bb19.i28.i, label %bb5

bb15.i43.i:                                       ; preds = %_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13fetch_decimal.exit.i, %bb3.i47.i
  %_8.035.i44.i = phi i64 [ %_8.0.i48.i, %bb3.i47.i ], [ %pos.sroa.0.6.i, %_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13fetch_decimal.exit.i ]
  %_19.i45.i = getelementptr inbounds nuw i8, ptr %data, i64 %_8.035.i44.i
  %_21.i46.i = load i8, ptr %_19.i45.i, align 1, !alias.scope !226, !noundef !38
  switch i8 %_21.i46.i, label %bb5.i23.i [
    i8 32, label %bb3.i47.i
    i8 9, label %bb3.i47.i
  ]

bb19.i28.i:                                       ; preds = %bb5.i23.i
  %_24.i29.i = getelementptr inbounds nuw i8, ptr %data, i64 %_11.i24.i
  %_27.i30.i = load i8, ptr %_24.i29.i, align 1, !alias.scope !226, !noundef !38
  %_25.not.i31.i = icmp eq i8 %_27.i30.i, 45
  br i1 %_25.not.i31.i, label %bb8.i32.i, label %bb5

bb8.i32.i:                                        ; preds = %bb19.i28.i
  %_12.0.i33.i = add nuw nsw i64 %_11.i24.i, 1
  %_288.i34.i = icmp ult i64 %_12.0.i33.i, %len
  %or.cond10.i35.i = select i1 %whitespace, i1 %_288.i34.i, i1 false
  br i1 %or.cond10.i35.i, label %bb21.i36.i, label %bb9.i

bb21.i36.i:                                       ; preds = %bb8.i32.i, %bb11.i40.i
  %pos.sroa.0.8.i = phi i64 [ %_16.0.i41.i, %bb11.i40.i ], [ %_12.0.i33.i, %bb8.i32.i ]
  %_29.i38.i = getelementptr inbounds nuw i8, ptr %data, i64 %pos.sroa.0.8.i
  %_31.i39.i = load i8, ptr %_29.i38.i, align 1, !alias.scope !226, !noundef !38
  switch i8 %_31.i39.i, label %bb9.i [
    i8 32, label %bb11.i40.i
    i8 9, label %bb11.i40.i
  ]

bb11.i40.i:                                       ; preds = %bb21.i36.i, %bb21.i36.i
  %_16.0.i41.i = add nuw nsw i64 %pos.sroa.0.8.i, 1
  %exitcond11.not.i42.i = icmp eq i64 %_16.0.i41.i, %len
  br i1 %exitcond11.not.i42.i, label %bb13.thread.i, label %bb21.i36.i

bb3.i47.i:                                        ; preds = %bb15.i43.i, %bb15.i43.i
  %_8.0.i48.i = add nuw nsw i64 %_8.035.i44.i, 1
  %exitcond.not.i49.i = icmp eq i64 %_8.0.i48.i, %len
  br i1 %exitcond.not.i49.i, label %bb5, label %bb15.i43.i

bb9.i:                                            ; preds = %bb21.i36.i, %bb8.i32.i
  %pos.sroa.0.10.ph.i = phi i64 [ %_12.0.i33.i, %bb8.i32.i ], [ %pos.sroa.0.8.i, %bb21.i36.i ]
  tail call void @llvm.experimental.noalias.scope.decl(metadata !229)
  %_135.i53.i = icmp ult i64 %pos.sroa.0.10.ph.i, %len
  br i1 %_135.i53.i, label %bb8.i56.i, label %_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13fetch_decimal.exit78.i

bb8.i56.i:                                        ; preds = %bb9.i, %bb3.i75.i
  %pos.sroa.0.11.i = phi i64 [ %_6.0.i76.i, %bb3.i75.i ], [ %pos.sroa.0.10.ph.i, %bb9.i ]
  %_15.i58.i = getelementptr inbounds nuw i8, ptr %data, i64 %pos.sroa.0.11.i
  %16 = load i8, ptr %_15.i58.i, align 1, !alias.scope !232, !noundef !38
  %17 = add i8 %16, -48
  %or.cond.i59.i = icmp ult i8 %17, 10
  br i1 %or.cond.i59.i, label %bb3.i75.i, label %bb4.i60.i

bb4.i60.i:                                        ; preds = %bb3.i75.i, %bb8.i56.i
  %pos.sroa.0.12.i = phi i64 [ %len, %bb3.i75.i ], [ %pos.sroa.0.11.i, %bb8.i56.i ]
  %_7.i62.i = icmp eq i64 %pos.sroa.0.10.ph.i, %pos.sroa.0.12.i
  br i1 %_7.i62.i, label %_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13fetch_decimal.exit78.i, label %bb6.i63.i

bb6.i63.i:                                        ; preds = %bb4.i60.i
  %_23.i64.i = icmp ult i64 %pos.sroa.0.12.i, %pos.sroa.0.10.ph.i
  %_19.not.i65.i = icmp ugt i64 %pos.sroa.0.12.i, %len
  %or.cond3.i66.i = or i1 %_23.i64.i, %_19.not.i65.i
  br i1 %or.cond3.i66.i, label %bb14.i74.i, label %bb13.i67.i, !prof !114

bb14.i74.i:                                       ; preds = %bb6.i63.i
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCs9l4wcBNbII5_4core5slice5index16slice_index_fail(i64 noundef %pos.sroa.0.10.ph.i, i64 noundef %pos.sroa.0.12.i, i64 noundef range(i64 0, -9223372036854775808) %len, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_df10a442b0b4a87147a8f65479b3c67a) #16, !noalias !233
  unreachable

bb13.i67.i:                                       ; preds = %bb6.i63.i
  %_24.i68.i = sub nuw nsw i64 %pos.sroa.0.12.i, %pos.sroa.0.10.ph.i
  %_26.i69.i = getelementptr inbounds nuw i8, ptr %data, i64 %pos.sroa.0.10.ph.i
  call void @llvm.lifetime.start.p0(ptr nonnull %_27.i51.i), !noalias !233
; call parse_number_core::parse_slice::<9223372036854775807, 9223372036854775808>
  call fastcc void @_RINvCs4A2AHSyUD2M_17parse_number_core11parse_sliceKy7fffffffffffffff_Ky8000000000000000_ECsh1eR4S1pMdQ_9range_ffi(ptr noalias nofree noundef align 8 captures(address) dereferenceable(16) %_27.i51.i, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %_26.i69.i, i64 noundef %_24.i68.i, i32 noundef 0) #17
  %18 = getelementptr inbounds nuw i8, ptr %_27.i51.i, i64 8
  %19 = load i8, ptr %18, align 8, !range !83, !noalias !233, !noundef !38
  %20 = icmp eq i8 %19, 2
  %_31.i70.i = load i64, ptr %_27.i51.i, align 8, !noalias !233
  %_32.i71.i = trunc nuw i8 %19 to i1
  %21 = sub i64 0, %_31.i70.i
  %_29.sroa.0.0.i72.i = select i1 %_32.i71.i, i64 %21, i64 %_31.i70.i
  %_0.sroa.3.0.ph.i73.i = select i1 %20, i64 9223372036854775807, i64 %_29.sroa.0.0.i72.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_27.i51.i), !noalias !233
  br label %_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13fetch_decimal.exit78.i

bb3.i75.i:                                        ; preds = %bb8.i56.i
  %_6.0.i76.i = add i64 %pos.sroa.0.11.i, 1
  %exitcond.not.i77.i = icmp eq i64 %_6.0.i76.i, %len
  br i1 %exitcond.not.i77.i, label %bb4.i60.i, label %bb8.i56.i

_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13fetch_decimal.exit78.i: ; preds = %bb13.i67.i, %bb4.i60.i, %bb9.i
  %pos.sroa.0.13.i = phi i64 [ %pos.sroa.0.10.ph.i, %bb4.i60.i ], [ %pos.sroa.0.12.i, %bb13.i67.i ], [ %pos.sroa.0.10.ph.i, %bb9.i ]
  %_0.sroa.3.0.i54.i = phi i64 [ undef, %bb4.i60.i ], [ %_0.sroa.3.0.ph.i73.i, %bb13.i67.i ], [ undef, %bb9.i ]
  %_0.sroa.0.0.i55.i = phi i1 [ false, %bb4.i60.i ], [ true, %bb13.i67.i ], [ false, %bb9.i ]
  %_14.not.i = icmp eq i64 %pos.sroa.0.13.i, %len
  br i1 %_14.not.i, label %bb13.i, label %bb5

bb13.i:                                           ; preds = %_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13fetch_decimal.exit78.i
  br i1 %_0.sroa.0.0.i12.i, label %bb17.i, label %bb15.i

bb13.thread.i:                                    ; preds = %bb11.i40.i
  br i1 %_0.sroa.0.0.i12.i, label %bb19.i, label %bb5

bb17.i:                                           ; preds = %bb13.i
  br i1 %_0.sroa.0.0.i55.i, label %bb3, label %bb19.i

bb15.i:                                           ; preds = %bb13.i
  br i1 %_0.sroa.0.0.i55.i, label %bb3, label %bb5

bb19.i:                                           ; preds = %bb17.i, %bb13.thread.i
  br label %bb3

bb3:                                              ; preds = %bb15.i, %bb19.i, %bb17.i
  %result.sroa.4.0 = phi i64 [ %_0.sroa.3.0.i.i, %bb19.i ], [ %_0.sroa.3.0.i.i, %bb17.i ], [ -1, %bb15.i ]
  %result.sroa.8.0 = phi i64 [ -1, %bb19.i ], [ %_0.sroa.3.0.i54.i, %bb17.i ], [ -1, %bb15.i ]
  %result.sroa.11.0 = phi i64 [ -1, %bb19.i ], [ -1, %bb17.i ], [ %_0.sroa.3.0.i54.i, %bb15.i ]
  store i64 %result.sroa.4.0, ptr %output, align 8
  %_9.sroa.4.0.output.sroa_idx = getelementptr inbounds nuw i8, ptr %output, i64 8
  store i64 %result.sroa.8.0, ptr %_9.sroa.4.0.output.sroa_idx, align 8
  %_9.sroa.5.0.output.sroa_idx = getelementptr inbounds nuw i8, ptr %output, i64 16
  store i64 %result.sroa.11.0, ptr %_9.sroa.5.0.output.sroa_idx, align 8
  br label %bb5

bb5:                                              ; preds = %bb3.i.i, %bb11.i.i, %bb3.i47.i, %start, %_RNvMNtCs9l4wcBNbII5_4core5sliceSh11starts_withCsh1eR4S1pMdQ_9range_ffi.exit.i, %_RNvCsh1eR4S1pMdQ_9range_ffi5bytes.exit, %bb13.thread.i, %bb5.i.i5, %bb19.i.i, %bb5.i23.i, %bb19.i28.i, %bb15.i, %_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13fetch_decimal.exit78.i, %bb3
  %22 = phi i1 [ true, %bb3 ], [ false, %_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13fetch_decimal.exit78.i ], [ false, %bb11.i.i ], [ false, %bb15.i ], [ false, %bb3.i47.i ], [ false, %start ], [ false, %_RNvMNtCs9l4wcBNbII5_4core5sliceSh11starts_withCsh1eR4S1pMdQ_9range_ffi.exit.i ], [ false, %bb19.i28.i ], [ false, %bb5.i23.i ], [ false, %bb19.i.i ], [ false, %bb5.i.i5 ], [ false, %bb13.thread.i ], [ false, %_RNvCsh1eR4S1pMdQ_9range_ffi5bytes.exit ], [ false, %bb3.i.i ]
  ret i1 %22
}

; Function Attrs: nounwind uwtable
define noundef zeroext range(i8 0, 4) i8 @rustium_http_range_list(ptr nofree noundef readonly captures(address) %data, i64 noundef %len, ptr nofree noundef writeonly captures(none) %output) unnamed_addr #1 personality ptr @__CxxFrameHandler3 !guid !235 {
start:
  %_3.sroa.5.i.i.i.i = alloca i64, align 8
  %_3.sroa.8.i.i.i.i = alloca i64, align 8
  %ranges = alloca [24 x i8], align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %ranges)
  store i64 0, ptr %ranges, align 8
  %0 = getelementptr inbounds nuw i8, ptr %ranges, i64 8
  store ptr inttoptr (i64 8 to ptr), ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %ranges, i64 16
  store i64 0, ptr %1, align 8
  %2 = icmp eq i64 %len, 0
  br i1 %2, label %bb3.thread, label %bb2.i

bb3.thread:                                       ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %_3.sroa.5.i.i.i.i)
  call void @llvm.lifetime.start.p0(ptr nonnull %_3.sroa.8.i.i.i.i)
  br label %_RNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCsh1eR4S1pMdQ_9range_ffi.exit.i.i.i.i

bb2.i:                                            ; preds = %start
  %_12.not.i.i = icmp ne ptr %data, null
  %_7.i.i = icmp sgt i64 %len, -1
  %or.cond.i.i = and i1 %_12.not.i.i, %_7.i.i
  br i1 %or.cond.i.i, label %_RNvCsh1eR4S1pMdQ_9range_ffi5bytes.exit, label %bb5.i.i, !prof !66

bb5.i.i:                                          ; preds = %bb2.i
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_a28e8c8fd5088943a8b5d44af697ff83, ptr noundef nonnull inttoptr (i64 559 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_56c01fe01d1a47ca560ad2a33d46aaec) #16
  unreachable

_RNvCsh1eR4S1pMdQ_9range_ffi5bytes.exit:          ; preds = %bb2.i
  tail call void @llvm.experimental.noalias.scope.decl(metadata !236)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !239)
  %_63.i = getelementptr inbounds nuw i8, ptr %data, i64 %len
  br label %bb23.i.i

bb23.i.i:                                         ; preds = %_RNvCsh1eR4S1pMdQ_9range_ffi5bytes.exit, %bb7.i.i
  %i.sroa.0.08.i.i = phi i64 [ %3, %bb7.i.i ], [ 0, %_RNvCsh1eR4S1pMdQ_9range_ffi5bytes.exit ]
  %_3957.i.i = phi ptr [ %_39.i.i, %bb7.i.i ], [ %data, %_RNvCsh1eR4S1pMdQ_9range_ffi5bytes.exit ]
  %ptr.val.i.i = load i8, ptr %_3957.i.i, align 1, !alias.scope !236, !noalias !241, !noundef !38
  %_0.i.i.i = icmp eq i8 %ptr.val.i.i, 61
  br i1 %_0.i.i.i, label %bb6.i.i, label %bb7.i.i

bb7.i.i:                                          ; preds = %bb23.i.i
  %_39.i.i = getelementptr inbounds nuw i8, ptr %_3957.i.i, i64 1
  %3 = add nuw nsw i64 %i.sroa.0.08.i.i, 1
  %_29.i.i = icmp eq ptr %_39.i.i, %_63.i
  br i1 %_29.i.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB4_23rustium_http_range_list0EB4_.exit.thread, label %bb23.i.i

bb6.i.i:                                          ; preds = %bb23.i.i
  %cond.i.i = icmp samesign ult i64 %i.sroa.0.08.i.i, %len
  br i1 %cond.i.i, label %bb69.i, label %bb1.i.i.i, !prof !69

bb1.i.i.i:                                        ; preds = %bb6.i.i
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_64e308ef4babfeb8b6220184de794a17, ptr noundef nonnull inttoptr (i64 443 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_1d1b1e35bb489427b2bdc9752de92226) #16, !noalias !244
  unreachable

bb69.i:                                           ; preds = %bb6.i.i
  %_13.not8.i.i = icmp eq i64 %i.sroa.0.08.i.i, 0
  br i1 %_13.not8.i.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB4_23rustium_http_range_list0EB4_.exit.thread, label %bb8.i.i

bb8.i.i:                                          ; preds = %bb69.i, %bb13.i.i
  %input.sroa.0.010.i.i = phi ptr [ %_24.i.i, %bb13.i.i ], [ %data, %bb69.i ]
  %input.sroa.10.09.i.i = phi i64 [ %_20.i.i, %bb13.i.i ], [ %i.sroa.0.08.i.i, %bb69.i ]
  %_16.i.i = load i8, ptr %input.sroa.0.010.i.i, align 1, !alias.scope !245, !noundef !38
  switch i8 %_16.i.i, label %bb14.i.i [
    i8 32, label %bb13.i.i
    i8 9, label %bb13.i.i
  ]

bb14.i.i:                                         ; preds = %bb8.i.i, %bb18.i.i
  %input.sroa.10.115.i.i = phi i64 [ %4, %bb18.i.i ], [ %input.sroa.10.09.i.i, %bb8.i.i ]
  %4 = add nsw i64 %input.sroa.10.115.i.i, -1
  %_27.i.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.010.i.i, i64 %4
  %_29.i33.i = load i8, ptr %_27.i.i, align 1, !alias.scope !245, !noundef !38
  switch i8 %_29.i33.i, label %_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4trim.exit.i [
    i8 32, label %bb18.i.i
    i8 9, label %bb18.i.i
  ]

bb18.i.i:                                         ; preds = %bb14.i.i, %bb14.i.i
  %_26.not.i.i = icmp eq i64 %4, 0
  br i1 %_26.not.i.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB4_23rustium_http_range_list0EB4_.exit.thread, label %bb14.i.i

bb13.i.i:                                         ; preds = %bb8.i.i, %bb8.i.i
  %_20.i.i = add nsw i64 %input.sroa.10.09.i.i, -1
  %_24.i.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.010.i.i, i64 1
  %_13.not.i.i = icmp eq i64 %_20.i.i, 0
  br i1 %_13.not.i.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB4_23rustium_http_range_list0EB4_.exit.thread, label %bb8.i.i

_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4trim.exit.i: ; preds = %bb14.i.i
  %5 = icmp eq i64 %input.sroa.10.115.i.i, 5
  br i1 %5, label %bb78.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB4_23rustium_http_range_list0EB4_.exit.thread

bb78.i:                                           ; preds = %_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4trim.exit.i
  %6 = add i8 %_16.i.i, -65
  %7 = icmp ult i8 %6, 26
  %8 = select i1 %7, i8 32, i8 0
  %_18.sroa.0.0.i.i = or i8 %8, %_16.i.i
  %_11.i.i = icmp eq i8 %_18.sroa.0.0.i.i, 98
  br i1 %_11.i.i, label %bb1.1.i.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB4_23rustium_http_range_list0EB4_.exit.thread

bb1.1.i.i:                                        ; preds = %bb78.i
  %rest_a.0.i.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.010.i.i, i64 1
  %_14.1.i.i = load i8, ptr %rest_a.0.i.i, align 1, !alias.scope !248, !noundef !38
  %9 = add i8 %_14.1.i.i, -65
  %10 = icmp ult i8 %9, 26
  %11 = select i1 %10, i8 32, i8 0
  %_18.sroa.0.0.1.i.i = or i8 %11, %_14.1.i.i
  %_11.1.i.i = icmp eq i8 %_18.sroa.0.0.1.i.i, 121
  br i1 %_11.1.i.i, label %bb1.2.i.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB4_23rustium_http_range_list0EB4_.exit.thread

bb1.2.i.i:                                        ; preds = %bb1.1.i.i
  %rest_a.0.1.i.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.010.i.i, i64 2
  %_14.2.i.i = load i8, ptr %rest_a.0.1.i.i, align 1, !alias.scope !248, !noundef !38
  %12 = add i8 %_14.2.i.i, -65
  %13 = icmp ult i8 %12, 26
  %14 = select i1 %13, i8 32, i8 0
  %_18.sroa.0.0.2.i.i = or i8 %14, %_14.2.i.i
  %_11.2.i.i = icmp eq i8 %_18.sroa.0.0.2.i.i, 116
  br i1 %_11.2.i.i, label %bb1.3.i.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB4_23rustium_http_range_list0EB4_.exit.thread

bb1.3.i.i:                                        ; preds = %bb1.2.i.i
  %rest_a.0.2.i.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.010.i.i, i64 3
  %_14.3.i.i = load i8, ptr %rest_a.0.2.i.i, align 1, !alias.scope !248, !noundef !38
  %15 = add i8 %_14.3.i.i, -65
  %16 = icmp ult i8 %15, 26
  %17 = select i1 %16, i8 32, i8 0
  %_18.sroa.0.0.3.i.i = or i8 %17, %_14.3.i.i
  %_11.3.i.i = icmp eq i8 %_18.sroa.0.0.3.i.i, 101
  br i1 %_11.3.i.i, label %_RNvMNtNtCs9l4wcBNbII5_4core5slice5asciiSh27eq_ignore_ascii_case_simple.exit.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB4_23rustium_http_range_list0EB4_.exit.thread

_RNvMNtNtCs9l4wcBNbII5_4core5slice5asciiSh27eq_ignore_ascii_case_simple.exit.i: ; preds = %bb1.3.i.i
  %rest_a.0.3.i.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.010.i.i, i64 4
  %_14.4.i.i = load i8, ptr %rest_a.0.3.i.i, align 1, !alias.scope !248, !noundef !38
  %18 = add i8 %_14.4.i.i, -65
  %19 = icmp ult i8 %18, 26
  %20 = select i1 %19, i8 32, i8 0
  %_18.sroa.0.0.4.i.i = or i8 %20, %_14.4.i.i
  %_11.4.i.i = icmp eq i8 %_18.sroa.0.0.4.i.i, 115
  br i1 %_11.4.i.i, label %bb7.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB4_23rustium_http_range_list0EB4_.exit.thread

bb7.i:                                            ; preds = %_RNvMNtNtCs9l4wcBNbII5_4core5slice5asciiSh27eq_ignore_ascii_case_simple.exit.i
  %_13.0.i = add nuw nsw i64 %i.sroa.0.08.i.i, 1
  %_14172.i = icmp samesign ult i64 %_13.0.i, %len
  br i1 %_14172.i, label %bb10.preheader.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB4_23rustium_http_range_list0EB4_.exit.thread

bb10.preheader.i:                                 ; preds = %bb7.i, %bb8.backedge.i
  %_14.i.i.i56 = phi ptr [ %_14.i.i.i57, %bb8.backedge.i ], [ inttoptr (i64 8 to ptr), %bb7.i ]
  %len.i.i.i = phi i64 [ %len.i.i.i54, %bb8.backedge.i ], [ 0, %bb7.i ]
  %pos.sroa.0.0173.i = phi i64 [ %pos.sroa.0.2207.i, %bb8.backedge.i ], [ %_13.0.i, %bb7.i ]
  %21 = add nuw nsw i64 %pos.sroa.0.0173.i, 1
  %umax.i = tail call i64 @llvm.umax.i64(i64 range(i64 0, -9223372036854775808) %len, i64 %21)
  br label %bb12.i

bb12.i:                                           ; preds = %bb28.i, %bb10.preheader.i
  %pos.sroa.0.1170.i = phi i64 [ %pos.sroa.0.0173.i, %bb10.preheader.i ], [ %_26.0.i, %bb28.i ]
  %quote.sroa.0.0169.i = phi i1 [ false, %bb10.preheader.i ], [ %quote.sroa.0.1.i, %bb28.i ]
  %escaped.sroa.0.0168.i = phi i1 [ false, %bb10.preheader.i ], [ %escaped.sroa.0.1.i, %bb28.i ]
  %22 = getelementptr inbounds nuw i8, ptr %data, i64 %pos.sroa.0.1170.i
  %byte.i = load i8, ptr %22, align 1, !alias.scope !236, !noundef !38
  br i1 %quote.sroa.0.0169.i, label %bb13.i, label %bb22.i

bb22.i:                                           ; preds = %bb12.i
  switch i8 %byte.i, label %bb28.i [
    i8 44, label %bb79.i
    i8 34, label %bb25.i
  ]

bb13.i:                                           ; preds = %bb12.i
  br i1 %escaped.sroa.0.0168.i, label %bb28.i, label %bb15.i

bb79.i:                                           ; preds = %bb28.i, %bb22.i
  %pos.sroa.0.1.lcssa.i = phi i64 [ %pos.sroa.0.1170.i, %bb22.i ], [ %umax.i, %bb28.i ]
  %_19.lcssa.i = phi i64 [ 1, %bb22.i ], [ 0, %bb28.i ]
  %_81.i = sub nuw nsw i64 %pos.sroa.0.1.lcssa.i, %pos.sroa.0.0173.i
  %_13.not8.i35.i = icmp eq i64 %_81.i, 0
  br i1 %_13.not8.i35.i, label %bb8.backedge.i, label %bb8.i38.i.preheader

bb8.i38.i.preheader:                              ; preds = %bb79.i
  %_83.i = getelementptr inbounds nuw i8, ptr %data, i64 %pos.sroa.0.0173.i
  br label %bb8.i38.i

bb8.i38.i:                                        ; preds = %bb8.i38.i.preheader, %bb13.i42.i
  %input.sroa.0.010.i39.i = phi ptr [ %_24.i44.i, %bb13.i42.i ], [ %_83.i, %bb8.i38.i.preheader ]
  %input.sroa.10.09.i40.i = phi i64 [ %_20.i43.i, %bb13.i42.i ], [ %_81.i, %bb8.i38.i.preheader ]
  %_16.i41.i = load i8, ptr %input.sroa.0.010.i39.i, align 1, !alias.scope !251, !noundef !38
  switch i8 %_16.i41.i, label %bb14.i50.i [
    i8 32, label %bb13.i42.i
    i8 9, label %bb13.i42.i
  ]

bb14.i50.i:                                       ; preds = %bb8.i38.i, %bb18.i54.i
  %input.sroa.10.115.i51.i = phi i64 [ %23, %bb18.i54.i ], [ %input.sroa.10.09.i40.i, %bb8.i38.i ]
  %23 = add nsw i64 %input.sroa.10.115.i51.i, -1
  %_27.i52.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.010.i39.i, i64 %23
  %_29.i53.i = load i8, ptr %_27.i52.i, align 1, !alias.scope !251, !noundef !38
  switch i8 %_29.i53.i, label %_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4trim.exit56.i [
    i8 32, label %bb18.i54.i
    i8 9, label %bb18.i54.i
  ]

bb18.i54.i:                                       ; preds = %bb14.i50.i, %bb14.i50.i
  %_26.not.i55.i = icmp eq i64 %23, 0
  br i1 %_26.not.i55.i, label %bb8.backedge.i, label %bb14.i50.i

bb13.i42.i:                                       ; preds = %bb8.i38.i, %bb8.i38.i
  %_20.i43.i = add nsw i64 %input.sroa.10.09.i40.i, -1
  %_24.i44.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.010.i39.i, i64 1
  %_13.not.i45.i = icmp eq i64 %_20.i43.i, 0
  br i1 %_13.not.i45.i, label %bb8.backedge.i, label %bb8.i38.i

_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4trim.exit56.i: ; preds = %bb14.i50.i
  %_88.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.010.i39.i, i64 %input.sroa.10.115.i51.i
  br label %bb23.i64.i

bb23.i64.i:                                       ; preds = %bb7.i70.i, %_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4trim.exit56.i
  %i.sroa.0.08.i65.i = phi i64 [ %24, %bb7.i70.i ], [ 0, %_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4trim.exit56.i ]
  %_3957.i66.i = phi ptr [ %_39.i67.i, %bb7.i70.i ], [ %input.sroa.0.010.i39.i, %_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4trim.exit56.i ]
  %ptr.val.i68.i = load i8, ptr %_3957.i66.i, align 1, !alias.scope !236, !noalias !254, !noundef !38
  %_0.i.i69.i = icmp eq i8 %ptr.val.i68.i, 45
  br i1 %_0.i.i69.i, label %bb6.i76.i, label %bb7.i70.i

bb7.i70.i:                                        ; preds = %bb23.i64.i
  %_39.i67.i = getelementptr inbounds nuw i8, ptr %_3957.i66.i, i64 1
  %24 = add nuw i64 %i.sroa.0.08.i65.i, 1
  %_29.i71.i = icmp eq ptr %_39.i67.i, %_88.i
  br i1 %_29.i71.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB4_23rustium_http_range_list0EB4_.exit, label %bb23.i64.i

bb6.i76.i:                                        ; preds = %bb23.i64.i
  %cond.i77.i = icmp ult i64 %i.sroa.0.08.i65.i, %input.sroa.10.115.i51.i
  br i1 %cond.i77.i, label %bb83.i, label %bb1.i.i78.i, !prof !69

bb1.i.i78.i:                                      ; preds = %bb6.i76.i
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_64e308ef4babfeb8b6220184de794a17, ptr noundef nonnull inttoptr (i64 443 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_1d1b1e35bb489427b2bdc9752de92226) #16, !noalias !257
  unreachable

bb83.i:                                           ; preds = %bb6.i76.i
  %_13.not8.i80.i = icmp eq i64 %i.sroa.0.08.i65.i, 0
  br i1 %_13.not8.i80.i, label %bb46.i, label %bb8.i83.i

bb8.i83.i:                                        ; preds = %bb83.i, %bb13.i87.i
  %input.sroa.0.010.i84.i = phi ptr [ %_24.i89.i, %bb13.i87.i ], [ %input.sroa.0.010.i39.i, %bb83.i ]
  %input.sroa.10.09.i85.i = phi i64 [ %_20.i88.i, %bb13.i87.i ], [ %i.sroa.0.08.i65.i, %bb83.i ]
  %_16.i86.i = load i8, ptr %input.sroa.0.010.i84.i, align 1, !alias.scope !258, !noundef !38
  switch i8 %_16.i86.i, label %bb14.i95.i [
    i8 32, label %bb13.i87.i
    i8 9, label %bb13.i87.i
  ]

bb14.i95.i:                                       ; preds = %bb8.i83.i, %bb18.i99.i
  %input.sroa.10.115.i96.i = phi i64 [ %25, %bb18.i99.i ], [ %input.sroa.10.09.i85.i, %bb8.i83.i ]
  %25 = add nsw i64 %input.sroa.10.115.i96.i, -1
  %_27.i97.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.010.i84.i, i64 %25
  %_29.i98.i = load i8, ptr %_27.i97.i, align 1, !alias.scope !258, !noundef !38
  switch i8 %_29.i98.i, label %bb42.i [
    i8 32, label %bb18.i99.i
    i8 9, label %bb18.i99.i
  ]

bb18.i99.i:                                       ; preds = %bb14.i95.i, %bb14.i95.i
  %_26.not.i100.i = icmp eq i64 %25, 0
  br i1 %_26.not.i100.i, label %bb46.i, label %bb14.i95.i

bb13.i87.i:                                       ; preds = %bb8.i83.i, %bb8.i83.i
  %_20.i88.i = add nsw i64 %input.sroa.10.09.i85.i, -1
  %_24.i89.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.010.i84.i, i64 1
  %_13.not.i90.i = icmp eq i64 %_20.i88.i, 0
  br i1 %_13.not.i90.i, label %bb46.i, label %bb8.i83.i

bb42.i:                                           ; preds = %bb14.i95.i
; call range_ffi::http_range_parser::legacy_i64
  %26 = tail call fastcc { i64, i64 } @_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser10legacy_i64(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %input.sroa.0.010.i84.i, i64 noundef %input.sroa.10.115.i96.i) #17, !noalias !239
  %27 = extractvalue { i64, i64 } %26, 0
  %28 = trunc nuw i64 %27 to i1
  br i1 %28, label %bb44.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB4_23rustium_http_range_list0EB4_.exit

bb46.i:                                           ; preds = %bb13.i87.i, %bb18.i99.i, %bb44.i, %bb83.i
  %range.sroa.0.0.i = phi i64 [ -1, %bb83.i ], [ %29, %bb44.i ], [ -1, %bb18.i99.i ], [ -1, %bb13.i87.i ]
  %_48.0.i = add nuw i64 %i.sroa.0.08.i65.i, 1
  %_102.i = sub nuw nsw i64 %input.sroa.10.115.i51.i, %_48.0.i
  %_13.not8.i102.i = icmp eq i64 %_102.i, 0
  br i1 %_13.not8.i102.i, label %bb49.i, label %bb8.i105.preheader.i

bb8.i105.preheader.i:                             ; preds = %bb46.i
  %_106.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.010.i39.i, i64 %_48.0.i
  br label %bb8.i105.i

bb44.i:                                           ; preds = %bb42.i
  %29 = extractvalue { i64, i64 } %26, 1
  br label %bb46.i

bb8.i105.i:                                       ; preds = %bb13.i109.i, %bb8.i105.preheader.i
  %input.sroa.0.010.i106.i = phi ptr [ %_24.i111.i, %bb13.i109.i ], [ %_106.i, %bb8.i105.preheader.i ]
  %input.sroa.10.09.i107.i = phi i64 [ %_20.i110.i, %bb13.i109.i ], [ %_102.i, %bb8.i105.preheader.i ]
  %_16.i108.i = load i8, ptr %input.sroa.0.010.i106.i, align 1, !alias.scope !261, !noundef !38
  switch i8 %_16.i108.i, label %bb14.i117.i [
    i8 32, label %bb13.i109.i
    i8 9, label %bb13.i109.i
  ]

bb14.i117.i:                                      ; preds = %bb8.i105.i, %bb18.i121.i
  %input.sroa.10.115.i118.i = phi i64 [ %30, %bb18.i121.i ], [ %input.sroa.10.09.i107.i, %bb8.i105.i ]
  %30 = add nsw i64 %input.sroa.10.115.i118.i, -1
  %_27.i119.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.010.i106.i, i64 %30
  %_29.i120.i = load i8, ptr %_27.i119.i, align 1, !alias.scope !261, !noundef !38
  switch i8 %_29.i120.i, label %bb50.i [
    i8 32, label %bb18.i121.i
    i8 9, label %bb18.i121.i
  ]

bb18.i121.i:                                      ; preds = %bb14.i117.i, %bb14.i117.i
  %_26.not.i122.i = icmp eq i64 %30, 0
  br i1 %_26.not.i122.i, label %bb49.i, label %bb14.i117.i

bb13.i109.i:                                      ; preds = %bb8.i105.i, %bb8.i105.i
  %_20.i110.i = add nsw i64 %input.sroa.10.09.i107.i, -1
  %_24.i111.i = getelementptr inbounds nuw i8, ptr %input.sroa.0.010.i106.i, i64 1
  %_13.not.i112.i = icmp eq i64 %_20.i110.i, 0
  br i1 %_13.not.i112.i, label %bb49.i, label %bb8.i105.i

bb50.i:                                           ; preds = %bb14.i117.i
; call range_ffi::http_range_parser::legacy_i64
  %31 = tail call fastcc { i64, i64 } @_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser10legacy_i64(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %input.sroa.0.010.i106.i, i64 noundef %input.sroa.10.115.i118.i) #17, !noalias !239
  %32 = extractvalue { i64, i64 } %31, 0
  %33 = extractvalue { i64, i64 } %31, 1
  %34 = trunc nuw i64 %32 to i1
  br i1 %34, label %bb52.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB4_23rustium_http_range_list0EB4_.exit

bb49.i:                                           ; preds = %bb13.i109.i, %bb18.i121.i, %bb46.i
  %35 = icmp eq i64 %range.sroa.0.0.i, -1
  br i1 %35, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB4_23rustium_http_range_list0EB4_.exit, label %bb96.i

bb52.i:                                           ; preds = %bb50.i
  %36 = icmp eq i64 %range.sroa.0.0.i, -1
  br i1 %36, label %bb96.i, label %bb90.i

bb96.i:                                           ; preds = %bb52.i, %bb49.i
  %range.sroa.10.0.i = phi i64 [ -1, %bb49.i ], [ %33, %bb52.i ]
  %37 = icmp sgt i64 %range.sroa.10.0.i, 0
  %38 = icmp sgt i64 %range.sroa.0.0.i, -1
  %or.cond30.i = select i1 %37, i1 true, i1 %38
  br i1 %or.cond30.i, label %bb58.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB4_23rustium_http_range_list0EB4_.exit

bb90.i:                                           ; preds = %bb52.i
  %39 = icmp sgt i64 %range.sroa.0.0.i, -1
  br i1 %39, label %bb91.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB4_23rustium_http_range_list0EB4_.exit

bb91.i:                                           ; preds = %bb90.i
  %40 = icmp eq i64 %33, -1
  br i1 %40, label %bb58.i, label %bb94.i

bb94.i:                                           ; preds = %bb91.i
  %_55.not.i = icmp slt i64 %33, %range.sroa.0.0.i
  br i1 %_55.not.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB4_23rustium_http_range_list0EB4_.exit, label %bb58.i

bb58.i:                                           ; preds = %bb94.i, %bb91.i, %bb96.i
  %range.sroa.10.3.i = phi i64 [ -1, %bb94.i ], [ %range.sroa.10.0.i, %bb96.i ], [ -1, %bb91.i ]
  %range.sroa.7.2.i = phi i64 [ %33, %bb94.i ], [ -1, %bb96.i ], [ -1, %bb91.i ]
  tail call void @llvm.experimental.noalias.scope.decl(metadata !264)
  %self1.i.i.i = load i64, ptr %ranges, align 8, !range !68, !alias.scope !267, !noalias !268, !noundef !38
  %_4.i.i.i = icmp eq i64 %len.i.i.i, %self1.i.i.i
  br i1 %_4.i.i.i, label %bb1.i.i125.i, label %_RNCNvCsh1eR4S1pMdQ_9range_ffi23rustium_http_range_list0B3_.exit.i

bb1.i.i125.i:                                     ; preds = %bb58.i
; call <alloc::raw_vec::RawVec<range_ffi::ParsedRange>>::grow_one
  call void @_RNvMs7_NtCs8tsiLsQ9XHg_5alloc7raw_vecINtB5_6RawVecNtCsh1eR4S1pMdQ_9range_ffi11ParsedRangeE8grow_oneBO_(ptr noalias nofree noundef nonnull align 8 dereferenceable(24) %ranges) #17, !noalias !271
  %_14.i.i.i.pre = load ptr, ptr %0, align 8, !alias.scope !267, !noalias !268
  br label %_RNCNvCsh1eR4S1pMdQ_9range_ffi23rustium_http_range_list0B3_.exit.i

_RNCNvCsh1eR4S1pMdQ_9range_ffi23rustium_http_range_list0B3_.exit.i: ; preds = %bb1.i.i125.i, %bb58.i
  %_14.i.i.i = phi ptr [ %_14.i.i.i.pre, %bb1.i.i125.i ], [ %_14.i.i.i56, %bb58.i ]
  %end.i.i.i = getelementptr inbounds nuw [24 x i8], ptr %_14.i.i.i, i64 %len.i.i.i
  store i64 %range.sroa.0.0.i, ptr %end.i.i.i, align 8, !noalias !273
  %_3.sroa.4.0.end.i.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %end.i.i.i, i64 8
  store i64 %range.sroa.7.2.i, ptr %_3.sroa.4.0.end.i.sroa_idx.i.i, align 8, !noalias !273
  %_3.sroa.5.0.end.i.sroa_idx.i.i = getelementptr inbounds nuw i8, ptr %end.i.i.i, i64 16
  store i64 %range.sroa.10.3.i, ptr %_3.sroa.5.0.end.i.sroa_idx.i.i, align 8, !noalias !273
  %41 = add i64 %len.i.i.i, 1
  store i64 %41, ptr %1, align 8, !alias.scope !267, !noalias !268
  br label %bb8.backedge.i

bb8.backedge.i:                                   ; preds = %bb13.i42.i, %bb18.i54.i, %bb79.i, %_RNCNvCsh1eR4S1pMdQ_9range_ffi23rustium_http_range_list0B3_.exit.i
  %_14.i.i.i57 = phi ptr [ %_14.i.i.i56, %bb18.i54.i ], [ %_14.i.i.i, %_RNCNvCsh1eR4S1pMdQ_9range_ffi23rustium_http_range_list0B3_.exit.i ], [ %_14.i.i.i56, %bb79.i ], [ %_14.i.i.i56, %bb13.i42.i ]
  %len.i.i.i54 = phi i64 [ %len.i.i.i, %bb18.i54.i ], [ %41, %_RNCNvCsh1eR4S1pMdQ_9range_ffi23rustium_http_range_list0B3_.exit.i ], [ %len.i.i.i, %bb79.i ], [ %len.i.i.i, %bb13.i42.i ]
  %pos.sroa.0.2207.i = add nuw i64 %_19.lcssa.i, %pos.sroa.0.1.lcssa.i
  %_14.i = icmp ult i64 %pos.sroa.0.2207.i, %len
  br i1 %_14.i, label %bb10.preheader.i, label %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB4_23rustium_http_range_list0EB4_.exit

bb25.i:                                           ; preds = %bb22.i
  br label %bb28.i

bb15.i:                                           ; preds = %bb13.i
  switch i8 %byte.i, label %bb28.i [
    i8 92, label %bb16.i
    i8 34, label %bb18.i
  ]

bb16.i:                                           ; preds = %bb15.i
  br label %bb28.i

bb18.i:                                           ; preds = %bb15.i
  br label %bb28.i

bb28.i:                                           ; preds = %bb18.i, %bb16.i, %bb15.i, %bb25.i, %bb13.i, %bb22.i
  %escaped.sroa.0.1.i = phi i1 [ %escaped.sroa.0.0168.i, %bb25.i ], [ false, %bb15.i ], [ true, %bb16.i ], [ false, %bb18.i ], [ %escaped.sroa.0.0168.i, %bb22.i ], [ false, %bb13.i ]
  %quote.sroa.0.1.i = phi i1 [ true, %bb25.i ], [ true, %bb15.i ], [ true, %bb16.i ], [ false, %bb18.i ], [ false, %bb22.i ], [ true, %bb13.i ]
  %_26.0.i = add i64 %pos.sroa.0.1170.i, 1
  %exitcond.not.i = icmp eq i64 %_26.0.i, %umax.i
  br i1 %exitcond.not.i, label %bb79.i, label %bb12.i

_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB4_23rustium_http_range_list0EB4_.exit.thread: ; preds = %bb7.i.i, %bb13.i.i, %bb18.i.i, %bb1.2.i.i, %bb1.1.i.i, %_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4trim.exit.i, %bb69.i, %_RNvMNtNtCs9l4wcBNbII5_4core5slice5asciiSh27eq_ignore_ascii_case_simple.exit.i, %bb7.i, %bb1.3.i.i, %bb78.i
  %_0.sroa.0.0.i2.ph.ph = phi i1 [ false, %bb18.i.i ], [ false, %bb78.i ], [ false, %bb1.3.i.i ], [ false, %bb13.i.i ], [ false, %bb1.2.i.i ], [ true, %bb7.i ], [ false, %_RNvMNtNtCs9l4wcBNbII5_4core5slice5asciiSh27eq_ignore_ascii_case_simple.exit.i ], [ false, %bb69.i ], [ false, %_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4trim.exit.i ], [ false, %bb1.1.i.i ], [ false, %bb7.i.i ]
  %ranges.val.pre72 = load i64, ptr %ranges, align 8, !range !68
  %ranges.val1.pre73 = load ptr, ptr %0, align 8
  br label %bb3

_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB4_23rustium_http_range_list0EB4_.exit: ; preds = %bb42.i, %bb50.i, %bb49.i, %bb96.i, %bb90.i, %bb94.i, %bb8.backedge.i, %bb7.i70.i
  %_16.pr = phi i64 [ %len.i.i.i, %bb7.i70.i ], [ %len.i.i.i, %bb96.i ], [ %len.i.i.i, %bb42.i ], [ %len.i.i.i, %bb50.i ], [ %len.i.i.i, %bb90.i ], [ %len.i.i.i54, %bb8.backedge.i ], [ %len.i.i.i, %bb94.i ], [ %len.i.i.i, %bb49.i ]
  %_0.sroa.0.0.i2.ph = phi i1 [ false, %bb7.i70.i ], [ false, %bb96.i ], [ false, %bb42.i ], [ false, %bb50.i ], [ false, %bb90.i ], [ true, %bb8.backedge.i ], [ false, %bb94.i ], [ false, %bb49.i ]
  %_17 = icmp ult i64 %_16.pr, 384307168202282326
  tail call void @llvm.assume(i1 %_17)
  %_10 = icmp eq i64 %_16.pr, 0
  %ranges.val.pre = load i64, ptr %ranges, align 8, !range !68
  %ranges.val1.pre = load ptr, ptr %0, align 8
  br i1 %_10, label %bb3, label %bb4

bb4:                                              ; preds = %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB4_23rustium_http_range_list0EB4_.exit
  store ptr %ranges.val1.pre, ptr %output, align 8
  %buffer.sroa.4.0.output.sroa_idx = getelementptr inbounds nuw i8, ptr %output, i64 8
  store i64 %_16.pr, ptr %buffer.sroa.4.0.output.sroa_idx, align 8
  %buffer.sroa.5.0.output.sroa_idx = getelementptr inbounds nuw i8, ptr %output, i64 16
  store i64 %ranges.val.pre, ptr %buffer.sroa.5.0.output.sroa_idx, align 8
  %_15 = zext i1 %_0.sroa.0.0.i2.ph to i8
  %42 = or disjoint i8 %_15, 2
  br label %bb6

bb3:                                              ; preds = %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB4_23rustium_http_range_list0EB4_.exit.thread, %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB4_23rustium_http_range_list0EB4_.exit
  %ranges.val1 = phi ptr [ %ranges.val1.pre, %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB4_23rustium_http_range_list0EB4_.exit ], [ %ranges.val1.pre73, %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB4_23rustium_http_range_list0EB4_.exit.thread ]
  %ranges.val = phi i64 [ %ranges.val.pre, %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB4_23rustium_http_range_list0EB4_.exit ], [ %ranges.val.pre72, %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB4_23rustium_http_range_list0EB4_.exit.thread ]
  %_0.sroa.0.0.i29 = phi i1 [ %_0.sroa.0.0.i2.ph, %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB4_23rustium_http_range_list0EB4_.exit ], [ %_0.sroa.0.0.i2.ph.ph, %_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB4_23rustium_http_range_list0EB4_.exit.thread ]
  call void @llvm.lifetime.start.p0(ptr nonnull %_3.sroa.5.i.i.i.i)
  call void @llvm.lifetime.start.p0(ptr nonnull %_3.sroa.8.i.i.i.i)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !274)
  %43 = icmp eq i64 %ranges.val, 0
  br i1 %43, label %_RNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCsh1eR4S1pMdQ_9range_ffi.exit.i.i.i.i, label %bb4.i.i.i.i.i

bb4.i.i.i.i.i:                                    ; preds = %bb3
  %_7.1.i.i.i.i.i.i = icmp samesign ugt i64 %ranges.val, 768614336404564650
  br i1 %_7.1.i.i.i.i.i.i, label %bb1.i.i.i.i.i.i, label %_RNvNvMs9_NtCs9l4wcBNbII5_4core3numj13unchecked_mul18precondition_check.exit.i.i.i.i.i, !prof !75

bb1.i.i.i.i.i.i:                                  ; preds = %bb4.i.i.i.i.i
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_db07ae5a9ce650d9b7cc970d048e6f0c, ptr noundef nonnull inttoptr (i64 373 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_ad088eaa3dc0ae68b11fd72bfcf5e34b) #16, !noalias !274
  unreachable

_RNvNvMs9_NtCs9l4wcBNbII5_4core3numj13unchecked_mul18precondition_check.exit.i.i.i.i.i: ; preds = %bb4.i.i.i.i.i
  %_3.i.i.i.i.i.i = icmp samesign ult i64 %ranges.val, 384307168202282326
  br i1 %_3.i.i.i.i.i.i, label %_RNvNvMNtNtCs9l4wcBNbII5_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_check.exit.i.i.i.i.i, label %bb2.i.i.i.i.i.i, !prof !69

bb2.i.i.i.i.i.i:                                  ; preds = %_RNvNvMs9_NtCs9l4wcBNbII5_4core3numj13unchecked_mul18precondition_check.exit.i.i.i.i.i
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_1be5ea12ba708d9a11b6e93a7d387a75, ptr noundef nonnull inttoptr (i64 563 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_dade1aed0d0fe800cb3ecdb07302e098) #16, !noalias !274
  unreachable

_RNvNvMNtNtCs9l4wcBNbII5_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_check.exit.i.i.i.i.i: ; preds = %_RNvNvMs9_NtCs9l4wcBNbII5_4core3numj13unchecked_mul18precondition_check.exit.i.i.i.i.i
  %alloc_size.i.i.i.i.i = mul nuw nsw i64 %ranges.val, 24
  call void @llvm.assume(i1 true) [ "nonnull"(ptr %ranges.val1) ]
  store i64 8, ptr %_3.sroa.5.i.i.i.i, align 8, !alias.scope !274
  br label %_RNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCsh1eR4S1pMdQ_9range_ffi.exit.i.i.i.i

_RNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCsh1eR4S1pMdQ_9range_ffi.exit.i.i.i.i: ; preds = %bb3.thread, %_RNvNvMNtNtCs9l4wcBNbII5_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_check.exit.i.i.i.i.i, %bb3
  %.shrunk = phi i1 [ %_0.sroa.0.0.i29, %bb3 ], [ %_0.sroa.0.0.i29, %_RNvNvMNtNtCs9l4wcBNbII5_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_check.exit.i.i.i.i.i ], [ false, %bb3.thread ]
  %_3.sroa.0.0.i.i.i.i = phi ptr [ undef, %bb3 ], [ %ranges.val1, %_RNvNvMNtNtCs9l4wcBNbII5_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_check.exit.i.i.i.i.i ], [ undef, %bb3.thread ]
  %.sink.i.sroa.phi.i.i.i.i = phi ptr [ %_3.sroa.5.i.i.i.i, %bb3 ], [ %_3.sroa.8.i.i.i.i, %_RNvNvMNtNtCs9l4wcBNbII5_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_check.exit.i.i.i.i.i ], [ %_3.sroa.5.i.i.i.i, %bb3.thread ]
  %alloc_size.sink.i.i.i.i.i = phi i64 [ 0, %bb3 ], [ %alloc_size.i.i.i.i.i, %_RNvNvMNtNtCs9l4wcBNbII5_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_check.exit.i.i.i.i.i ], [ 0, %bb3.thread ]
  %44 = zext i1 %.shrunk to i8
  store i64 %alloc_size.sink.i.i.i.i.i, ptr %.sink.i.sroa.phi.i.i.i.i, align 8, !alias.scope !274
  %_3.sroa.5.i.i.i.i.0._3.sroa.5.i.i.i.i.0._3.sroa.5.i.i.i.i.0._3.sroa.5.i.i.i.0._3.sroa.5.i.i.i.0._3.sroa.5.i.i.0._3.sroa.5.i.i.0._3.sroa.5.i.0._3.sroa.5.i.0._3.sroa.5.0._3.sroa.5.0._3.sroa.5.8..i.i.i.i = load i64, ptr %_3.sroa.5.i.i.i.i, align 8, !range !76, !noundef !38
  %.not.i.i.i.i = icmp eq i64 %_3.sroa.5.i.i.i.i.0._3.sroa.5.i.i.i.i.0._3.sroa.5.i.i.i.i.0._3.sroa.5.i.i.i.0._3.sroa.5.i.i.i.0._3.sroa.5.i.i.0._3.sroa.5.i.i.0._3.sroa.5.i.0._3.sroa.5.i.0._3.sroa.5.0._3.sroa.5.0._3.sroa.5.8..i.i.i.i, 0
  br i1 %.not.i.i.i.i, label %_RINvNtCs9l4wcBNbII5_4core3ptr9drop_glueINtNtCs8tsiLsQ9XHg_5alloc3vec3VecNtCsh1eR4S1pMdQ_9range_ffi11ParsedRangeEEB1a_.exit, label %bb2.i.i.i.i

bb2.i.i.i.i:                                      ; preds = %_RNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCsh1eR4S1pMdQ_9range_ffi.exit.i.i.i.i
  call void @llvm.assume(i1 true) [ "nonnull"(ptr %_3.sroa.0.0.i.i.i.i) ]
  %_3.sroa.8.i.i.i.i.0._3.sroa.8.i.i.i.i.0._3.sroa.8.i.i.i.i.0._3.sroa.8.i.i.i.0._3.sroa.8.i.i.i.0._3.sroa.8.i.i.0._3.sroa.8.i.i.0._3.sroa.8.i.0._3.sroa.8.i.0._3.sroa.8.0._3.sroa.8.0._3.sroa.8.16.layout.1.i.i.i.i = load i64, ptr %_3.sroa.8.i.i.i.i, align 8, !noundef !38
  %45 = icmp eq i64 %_3.sroa.8.i.i.i.i.0._3.sroa.8.i.i.i.i.0._3.sroa.8.i.i.i.i.0._3.sroa.8.i.i.i.0._3.sroa.8.i.i.i.0._3.sroa.8.i.i.0._3.sroa.8.i.i.0._3.sroa.8.i.0._3.sroa.8.i.0._3.sroa.8.0._3.sroa.8.0._3.sroa.8.16.layout.1.i.i.i.i, 0
  br i1 %45, label %_RINvNtCs9l4wcBNbII5_4core3ptr9drop_glueINtNtCs8tsiLsQ9XHg_5alloc3vec3VecNtCsh1eR4S1pMdQ_9range_ffi11ParsedRangeEEB1a_.exit, label %bb1.i.i.i.i.i

bb1.i.i.i.i.i:                                    ; preds = %bb2.i.i.i.i
; call __rustc::__rust_dealloc
  tail call void @_RNvCs6d6XRwTwhVh_7___rustc14___rust_dealloc(ptr noundef nonnull %_3.sroa.0.0.i.i.i.i, i64 noundef %_3.sroa.8.i.i.i.i.0._3.sroa.8.i.i.i.i.0._3.sroa.8.i.i.i.i.0._3.sroa.8.i.i.i.0._3.sroa.8.i.i.i.0._3.sroa.8.i.i.0._3.sroa.8.i.i.0._3.sroa.8.i.0._3.sroa.8.i.0._3.sroa.8.0._3.sroa.8.0._3.sroa.8.16.layout.1.i.i.i.i, i64 noundef range(i64 1, -9223372036854775807) %_3.sroa.5.i.i.i.i.0._3.sroa.5.i.i.i.i.0._3.sroa.5.i.i.i.i.0._3.sroa.5.i.i.i.0._3.sroa.5.i.i.i.0._3.sroa.5.i.i.0._3.sroa.5.i.i.0._3.sroa.5.i.0._3.sroa.5.i.0._3.sroa.5.0._3.sroa.5.0._3.sroa.5.8..i.i.i.i) #17
  br label %_RINvNtCs9l4wcBNbII5_4core3ptr9drop_glueINtNtCs8tsiLsQ9XHg_5alloc3vec3VecNtCsh1eR4S1pMdQ_9range_ffi11ParsedRangeEEB1a_.exit

_RINvNtCs9l4wcBNbII5_4core3ptr9drop_glueINtNtCs8tsiLsQ9XHg_5alloc3vec3VecNtCsh1eR4S1pMdQ_9range_ffi11ParsedRangeEEB1a_.exit: ; preds = %_RNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCsh1eR4S1pMdQ_9range_ffi.exit.i.i.i.i, %bb2.i.i.i.i, %bb1.i.i.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_3.sroa.5.i.i.i.i)
  call void @llvm.lifetime.end.p0(ptr nonnull %_3.sroa.8.i.i.i.i)
  br label %bb6

bb6:                                              ; preds = %_RINvNtCs9l4wcBNbII5_4core3ptr9drop_glueINtNtCs8tsiLsQ9XHg_5alloc3vec3VecNtCsh1eR4S1pMdQ_9range_ffi11ParsedRangeEEB1a_.exit, %bb4
  %_0.sroa.0.0 = phi i8 [ %44, %_RINvNtCs9l4wcBNbII5_4core3ptr9drop_glueINtNtCs8tsiLsQ9XHg_5alloc3vec3VecNtCsh1eR4S1pMdQ_9range_ffi11ParsedRangeEEB1a_.exit ], [ %42, %bb4 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %ranges)
  ret i8 %_0.sroa.0.0
}

; Function Attrs: nounwind uwtable
define void @rustium_http_range_list_drop(ptr noalias nofree noundef readonly align 8 captures(none) dead_on_return dereferenceable(24) %buffer) unnamed_addr #1 !guid !277 {
start:
  %_3.sroa.5.i.i.i.i = alloca i64, align 8
  %_3.sroa.8.i.i.i.i = alloca i64, align 8
  %_3 = load ptr, ptr %buffer, align 8, !noundef !38
  %0 = getelementptr inbounds nuw i8, ptr %buffer, i64 8
  %_4 = load i64, ptr %0, align 8, !noundef !38
  %1 = getelementptr inbounds nuw i8, ptr %buffer, i64 16
  %_5 = load i64, ptr %1, align 8, !noundef !38
  %_3.not.i = icmp ugt i64 %_4, %_5
  br i1 %_3.not.i, label %bb2.i, label %_RNvNvMs_NtCs8tsiLsQ9XHg_5alloc3vecINtB6_3VecppE17from_raw_parts_in18precondition_check.exit, !prof !75

bb2.i:                                            ; preds = %start
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_82a99021b1306c9239507412b95c0e74, ptr noundef nonnull inttoptr (i64 411 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_5b8d19018527d26ed8c47fbaf3eafd4f) #16
  unreachable

_RNvNvMs_NtCs8tsiLsQ9XHg_5alloc3vecINtB6_3VecppE17from_raw_parts_in18precondition_check.exit: ; preds = %start
  %2 = icmp sgt i64 %_5, -1
  tail call void @llvm.assume(i1 %2)
  %_2.i = icmp eq ptr %_3, null
  br i1 %_2.i, label %bb1.i, label %_RNvNvMs1_NtNtCs9l4wcBNbII5_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_check.exit, !prof !75

bb1.i:                                            ; preds = %_RNvNvMs_NtCs8tsiLsQ9XHg_5alloc3vecINtB6_3VecppE17from_raw_parts_in18precondition_check.exit
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_560a59ed819b9d9a5841f6e731c4c8e5, ptr noundef nonnull inttoptr (i64 421 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_91244a802f615a731e570cd82aa5f107) #16
  unreachable

_RNvNvMs1_NtNtCs9l4wcBNbII5_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_check.exit: ; preds = %_RNvNvMs_NtCs8tsiLsQ9XHg_5alloc3vecINtB6_3VecppE17from_raw_parts_in18precondition_check.exit
  call void @llvm.lifetime.start.p0(ptr nonnull %_3.sroa.5.i.i.i.i)
  call void @llvm.lifetime.start.p0(ptr nonnull %_3.sroa.8.i.i.i.i)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !278)
  %3 = icmp eq i64 %_5, 0
  br i1 %3, label %_RNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCsh1eR4S1pMdQ_9range_ffi.exit.i.i.i.i, label %bb4.i.i.i.i.i

bb4.i.i.i.i.i:                                    ; preds = %_RNvNvMs1_NtNtCs9l4wcBNbII5_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_check.exit
  %_7.1.i.i.i.i.i.i = icmp samesign ugt i64 %_5, 768614336404564650
  br i1 %_7.1.i.i.i.i.i.i, label %bb1.i.i.i.i.i.i, label %_RNvNvMs9_NtCs9l4wcBNbII5_4core3numj13unchecked_mul18precondition_check.exit.i.i.i.i.i, !prof !75

bb1.i.i.i.i.i.i:                                  ; preds = %bb4.i.i.i.i.i
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_db07ae5a9ce650d9b7cc970d048e6f0c, ptr noundef nonnull inttoptr (i64 373 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_ad088eaa3dc0ae68b11fd72bfcf5e34b) #16, !noalias !278
  unreachable

_RNvNvMs9_NtCs9l4wcBNbII5_4core3numj13unchecked_mul18precondition_check.exit.i.i.i.i.i: ; preds = %bb4.i.i.i.i.i
  %_3.i.i.i.i.i.i = icmp samesign ult i64 %_5, 384307168202282326
  br i1 %_3.i.i.i.i.i.i, label %_RNvNvMNtNtCs9l4wcBNbII5_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_check.exit.i.i.i.i.i, label %bb2.i.i.i.i.i.i, !prof !69

bb2.i.i.i.i.i.i:                                  ; preds = %_RNvNvMs9_NtCs9l4wcBNbII5_4core3numj13unchecked_mul18precondition_check.exit.i.i.i.i.i
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_1be5ea12ba708d9a11b6e93a7d387a75, ptr noundef nonnull inttoptr (i64 563 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_dade1aed0d0fe800cb3ecdb07302e098) #16, !noalias !278
  unreachable

_RNvNvMNtNtCs9l4wcBNbII5_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_check.exit.i.i.i.i.i: ; preds = %_RNvNvMs9_NtCs9l4wcBNbII5_4core3numj13unchecked_mul18precondition_check.exit.i.i.i.i.i
  %alloc_size.i.i.i.i.i = mul nuw nsw i64 %_5, 24
  store i64 8, ptr %_3.sroa.5.i.i.i.i, align 8, !alias.scope !278
  br label %_RNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCsh1eR4S1pMdQ_9range_ffi.exit.i.i.i.i

_RNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCsh1eR4S1pMdQ_9range_ffi.exit.i.i.i.i: ; preds = %_RNvNvMNtNtCs9l4wcBNbII5_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_check.exit.i.i.i.i.i, %_RNvNvMs1_NtNtCs9l4wcBNbII5_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_check.exit
  %.sink.i.sroa.phi.i.i.i.i = phi ptr [ %_3.sroa.5.i.i.i.i, %_RNvNvMs1_NtNtCs9l4wcBNbII5_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_check.exit ], [ %_3.sroa.8.i.i.i.i, %_RNvNvMNtNtCs9l4wcBNbII5_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_check.exit.i.i.i.i.i ]
  %alloc_size.sink.i.i.i.i.i = phi i64 [ 0, %_RNvNvMs1_NtNtCs9l4wcBNbII5_4core3ptr8non_nullINtB7_7NonNullpE13new_unchecked18precondition_check.exit ], [ %alloc_size.i.i.i.i.i, %_RNvNvMNtNtCs9l4wcBNbII5_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_check.exit.i.i.i.i.i ]
  store i64 %alloc_size.sink.i.i.i.i.i, ptr %.sink.i.sroa.phi.i.i.i.i, align 8, !alias.scope !278
  %_3.sroa.5.i.i.i.i.0._3.sroa.5.i.i.i.i.0._3.sroa.5.i.i.i.i.0._3.sroa.5.i.i.i.0._3.sroa.5.i.i.i.0._3.sroa.5.i.i.0._3.sroa.5.i.i.0._3.sroa.5.i.0._3.sroa.5.i.0._3.sroa.5.0._3.sroa.5.0._3.sroa.5.8..i.i.i.i = load i64, ptr %_3.sroa.5.i.i.i.i, align 8, !range !76, !noundef !38
  %.not.i.i.i.i = icmp eq i64 %_3.sroa.5.i.i.i.i.0._3.sroa.5.i.i.i.i.0._3.sroa.5.i.i.i.i.0._3.sroa.5.i.i.i.0._3.sroa.5.i.i.i.0._3.sroa.5.i.i.0._3.sroa.5.i.i.0._3.sroa.5.i.0._3.sroa.5.i.0._3.sroa.5.0._3.sroa.5.0._3.sroa.5.8..i.i.i.i, 0
  br i1 %.not.i.i.i.i, label %_RINvNtCs9l4wcBNbII5_4core3ptr9drop_glueINtNtCs8tsiLsQ9XHg_5alloc3vec3VecNtCsh1eR4S1pMdQ_9range_ffi11ParsedRangeEEB1a_.exit, label %bb2.i.i.i.i

bb2.i.i.i.i:                                      ; preds = %_RNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCsh1eR4S1pMdQ_9range_ffi.exit.i.i.i.i
  %_3.sroa.8.i.i.i.i.0._3.sroa.8.i.i.i.i.0._3.sroa.8.i.i.i.i.0._3.sroa.8.i.i.i.0._3.sroa.8.i.i.i.0._3.sroa.8.i.i.0._3.sroa.8.i.i.0._3.sroa.8.i.0._3.sroa.8.i.0._3.sroa.8.0._3.sroa.8.0._3.sroa.8.16.layout.1.i.i.i.i = load i64, ptr %_3.sroa.8.i.i.i.i, align 8, !noundef !38
  %4 = icmp eq i64 %_3.sroa.8.i.i.i.i.0._3.sroa.8.i.i.i.i.0._3.sroa.8.i.i.i.i.0._3.sroa.8.i.i.i.0._3.sroa.8.i.i.i.0._3.sroa.8.i.i.0._3.sroa.8.i.i.0._3.sroa.8.i.0._3.sroa.8.i.0._3.sroa.8.0._3.sroa.8.0._3.sroa.8.16.layout.1.i.i.i.i, 0
  br i1 %4, label %_RINvNtCs9l4wcBNbII5_4core3ptr9drop_glueINtNtCs8tsiLsQ9XHg_5alloc3vec3VecNtCsh1eR4S1pMdQ_9range_ffi11ParsedRangeEEB1a_.exit, label %bb1.i.i.i.i.i

bb1.i.i.i.i.i:                                    ; preds = %bb2.i.i.i.i
; call __rustc::__rust_dealloc
  tail call void @_RNvCs6d6XRwTwhVh_7___rustc14___rust_dealloc(ptr noundef nonnull %_3, i64 noundef %_3.sroa.8.i.i.i.i.0._3.sroa.8.i.i.i.i.0._3.sroa.8.i.i.i.i.0._3.sroa.8.i.i.i.0._3.sroa.8.i.i.i.0._3.sroa.8.i.i.0._3.sroa.8.i.i.0._3.sroa.8.i.0._3.sroa.8.i.0._3.sroa.8.0._3.sroa.8.0._3.sroa.8.16.layout.1.i.i.i.i, i64 noundef range(i64 1, -9223372036854775807) %_3.sroa.5.i.i.i.i.0._3.sroa.5.i.i.i.i.0._3.sroa.5.i.i.i.i.0._3.sroa.5.i.i.i.0._3.sroa.5.i.i.i.0._3.sroa.5.i.i.0._3.sroa.5.i.i.0._3.sroa.5.i.0._3.sroa.5.i.0._3.sroa.5.0._3.sroa.5.0._3.sroa.5.8..i.i.i.i) #17
  br label %_RINvNtCs9l4wcBNbII5_4core3ptr9drop_glueINtNtCs8tsiLsQ9XHg_5alloc3vec3VecNtCsh1eR4S1pMdQ_9range_ffi11ParsedRangeEEB1a_.exit

_RINvNtCs9l4wcBNbII5_4core3ptr9drop_glueINtNtCs8tsiLsQ9XHg_5alloc3vec3VecNtCsh1eR4S1pMdQ_9range_ffi11ParsedRangeEEB1a_.exit: ; preds = %_RNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCsh1eR4S1pMdQ_9range_ffi.exit.i.i.i.i, %bb2.i.i.i.i, %bb1.i.i.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_3.sroa.5.i.i.i.i)
  call void @llvm.lifetime.end.p0(ptr nonnull %_3.sroa.8.i.i.i.i)
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #6

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #6

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #7

declare i32 @__CxxFrameHandler3(...) unnamed_addr #8

; core::panicking::panic_const::panic_const_add_overflow
; Function Attrs: cold noinline noreturn nounwind uwtable
declare void @_RNvNtNtCs9l4wcBNbII5_4core9panicking11panic_const24panic_const_add_overflow(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #9

; core::slice::index::slice_index_fail
; Function Attrs: cold noinline noreturn nounwind uwtable
declare void @_RNvNtNtCs9l4wcBNbII5_4core5slice5index16slice_index_fail(i64 noundef, i64 noundef, i64 noundef, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #9

; __rustc::__rust_dealloc
; Function Attrs: nounwind allockind("free") uwtable
declare void @_RNvCs6d6XRwTwhVh_7___rustc14___rust_dealloc(ptr allocptr noundef nonnull captures(address), i64 noundef, i64 noundef range(i64 1, -9223372036854775807)) unnamed_addr #10

; __rustc::__rust_realloc
; Function Attrs: nounwind allockind("realloc,aligned") allocsize(3) uwtable
declare noalias noundef ptr @_RNvCs6d6XRwTwhVh_7___rustc14___rust_realloc(ptr allocptr noundef nonnull, i64 noundef, i64 allocalign noundef range(i64 1, -9223372036854775807), i64 noundef) unnamed_addr #11

; __rustc::__rust_no_alloc_shim_is_unstable_v2
; Function Attrs: nounwind uwtable
declare void @_RNvCs6d6XRwTwhVh_7___rustc35___rust_no_alloc_shim_is_unstable_v2() unnamed_addr #1

; __rustc::__rust_alloc
; Function Attrs: nounwind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable
declare noalias noundef ptr @_RNvCs6d6XRwTwhVh_7___rustc12___rust_alloc(i64 noundef, i64 allocalign noundef range(i64 1, -9223372036854775807)) unnamed_addr #12

; alloc::raw_vec::handle_error
; Function Attrs: cold minsize noreturn nounwind optsize uwtable
declare void @_RNvNtCs8tsiLsQ9XHg_5alloc7raw_vec12handle_error(i64 noundef range(i64 0, -9223372036854775807), i64) unnamed_addr #13

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umax.i64(i64, i64) #14

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind uwtable
declare void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull, ptr noundef nonnull, i1 noundef zeroext, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #9

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #15

attributes #0 = { inlinehint nofree norecurse nosync nounwind memory(argmem: readwrite, inaccessiblemem: readwrite) uwtable "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #1 = { nounwind uwtable "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #2 = { cold noinline nounwind uwtable "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #3 = { cold nounwind uwtable "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #4 = { inlinehint nofree norecurse nosync nounwind memory(argmem: read, inaccessiblemem: readwrite) uwtable "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #5 = { cold inlinehint noreturn nounwind uwtable "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #6 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #7 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #8 = { "target-cpu"="x86-64" }
attributes #9 = { cold noinline noreturn nounwind uwtable "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #10 = { nounwind allockind("free") uwtable "alloc-family"="__rust_alloc" "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #11 = { nounwind allockind("realloc,aligned") allocsize(3) uwtable "alloc-family"="__rust_alloc" "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #12 = { nounwind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "alloc-variant-zeroed"="_RNvCs6d6XRwTwhVh_7___rustc19___rust_alloc_zeroed" "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #13 = { cold minsize noreturn nounwind optsize uwtable "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #14 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #15 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #16 = { noreturn nounwind }
attributes #17 = { nounwind }

!llvm.module.flags = !{!33, !34, !35}
!llvm.ident = !{!36}

!0 = !{i64 2114354070475772421}
!1 = !{i64 -2042946609839593024}
!2 = !{i64 7477331088201467480}
!3 = !{i64 -1327769725697012767}
!4 = !{i64 4436366349608062544}
!5 = !{i64 4018937782562631355}
!6 = !{i64 340894586683391427}
!7 = !{i64 4159692597751017996}
!8 = !{i64 5458439795124862575}
!9 = !{i64 -7306622292623447933}
!10 = !{i64 -2943288650290681803}
!11 = !{i64 3950082891367633723}
!12 = !{i64 6315200628507695477}
!13 = !{i64 6388218212790770413}
!14 = !{i64 5245677602216057886}
!15 = !{i64 6861751255062736784}
!16 = !{i64 554655798682551698}
!17 = !{i64 2217117733618704966}
!18 = !{i64 4406491430526135142}
!19 = !{i64 -4628910326884422949}
!20 = !{i64 -4084258926205129325}
!21 = !{i64 -1607979181215696218}
!22 = !{i64 -4504609495221168028}
!23 = !{i64 -2292288856180232477}
!24 = !{i64 7624044617664194734}
!25 = !{i64 -4159011811447758322}
!26 = !{i64 -4675449544195109085}
!27 = !{i64 -1335447914488952694}
!28 = !{i64 5759478409352863247}
!29 = !{i64 -1999277830068891741}
!30 = !{i64 2314782044854659146}
!31 = !{i64 4281127754609539386}
!32 = !{i64 -4429264700361465245}
!33 = !{i32 8, !"PIC Level", i32 2}
!34 = !{i32 7, !"uwtable", i32 2}
!35 = !{i32 2, !"cfguard", i32 2}
!36 = !{!"rustc version 1.101.0-nightly (41b321963 2026-10-29) (96a18bf5ffa2b24f9cf3d1c731a9eb121c1acad9-4-llvmorg-24-init-17044-gc3223914 chromium)"}
!37 = !{i64 -4342141829753534549}
!38 = !{}
!39 = !{!40, !42, !44}
!40 = distinct !{!40, !41, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next: %self"}
!41 = distinct !{!41, i1 true, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next"}
!42 = distinct !{!42, !43, !"_RINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy7fffffffffffffff_NtB2_10SliceBytesECsh1eR4S1pMdQ_9range_ffi: %_0"}
!43 = distinct !{!43, i1 true, !"_RINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy7fffffffffffffff_NtB2_10SliceBytesECsh1eR4S1pMdQ_9range_ffi"}
!44 = distinct !{!44, !45, !"_RINvCs4A2AHSyUD2M_17parse_number_core14parse_unsignedKy7fffffffffffffff_NtB2_10SliceBytesECsh1eR4S1pMdQ_9range_ffi: %_0"}
!45 = distinct !{!45, i1 true, !"_RINvCs4A2AHSyUD2M_17parse_number_core14parse_unsignedKy7fffffffffffffff_NtB2_10SliceBytesECsh1eR4S1pMdQ_9range_ffi"}
!46 = !{!47}
!47 = distinct !{!47, !48, !"_RINvCs4A2AHSyUD2M_17parse_number_core5parseKy7fffffffffffffff_Ky8000000000000000_NtB2_10SliceBytesECsh1eR4S1pMdQ_9range_ffi: %_0"}
!48 = distinct !{!48, i1 true, !"_RINvCs4A2AHSyUD2M_17parse_number_core5parseKy7fffffffffffffff_Ky8000000000000000_NtB2_10SliceBytesECsh1eR4S1pMdQ_9range_ffi"}
!49 = !{!50, !47}
!50 = distinct !{!50, !51, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next: %self"}
!51 = distinct !{!51, i1 true, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next"}
!52 = !{!53, !47}
!53 = distinct !{!53, !54, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next: %self"}
!54 = distinct !{!54, i1 true, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next"}
!55 = !{!56, !58, !47}
!56 = distinct !{!56, !57, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next: %self"}
!57 = distinct !{!57, i1 true, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next"}
!58 = distinct !{!58, !59, !"_RINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy7fffffffffffffff_NtB2_10SliceBytesECsh1eR4S1pMdQ_9range_ffi: %_0"}
!59 = distinct !{!59, i1 true, !"_RINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy7fffffffffffffff_NtB2_10SliceBytesECsh1eR4S1pMdQ_9range_ffi"}
!60 = !{!61, !63, !47}
!61 = distinct !{!61, !62, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next: %self"}
!62 = distinct !{!62, i1 true, !"_RNvXs0_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next"}
!63 = distinct !{!63, !64, !"_RINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy8000000000000000_NtB2_10SliceBytesECsh1eR4S1pMdQ_9range_ffi: %_0"}
!64 = distinct !{!64, i1 true, !"_RINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy8000000000000000_NtB2_10SliceBytesECsh1eR4S1pMdQ_9range_ffi"}
!65 = !{i64 -8918261103973000796}
!66 = !{!"branch_weights", i32 -294967296, i32 6003000}
!67 = !{i64 8683441065103507816}
!68 = !{i64 0, i64 -9223372036854775808}
!69 = !{!"branch_weights", !"expected", i32 2000, i32 1}
!70 = !{i64 -2219347802154798030}
!71 = !{!"branch_weights", i32 2002, i32 2000}
!72 = !{!73}
!73 = distinct !{!73, !74, !"_RNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCsh1eR4S1pMdQ_9range_ffi: %_0"}
!74 = distinct !{!74, i1 true, !"_RNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCsh1eR4S1pMdQ_9range_ffi"}
!75 = !{!"branch_weights", !"expected", i32 1, i32 2000}
!76 = !{i64 0, i64 -9223372036854775807}
!77 = !{i64 6243110563821617354}
!78 = !{i64 0, i64 2}
!79 = !{i64 3974250378196094715}
!80 = !{!81}
!81 = distinct !{!81, !82, !"_RINvMNtCs9l4wcBNbII5_4core5sliceSh12strip_prefixAhj1_ECsh1eR4S1pMdQ_9range_ffi: %self.0"}
!82 = distinct !{!82, i1 true, !"_RINvMNtCs9l4wcBNbII5_4core5sliceSh12strip_prefixAhj1_ECsh1eR4S1pMdQ_9range_ffi"}
!83 = !{i8 0, i8 3}
!84 = !{i64 6453776343060943444}
!85 = !{i64 -6417443686114866332}
!86 = !{!87, !89}
!87 = distinct !{!87, !88, !"_RNvXCsh1eR4S1pMdQ_9range_ffiNtB2_14ForeignContentNtNtB2_17http_range_parser13ContentSource5write: %self"}
!88 = distinct !{!88, i1 true, !"_RNvXCsh1eR4S1pMdQ_9range_ffiNtB2_14ForeignContentNtNtB2_17http_range_parser13ContentSource5write"}
!89 = distinct !{!89, !90, !"_RNvYNtCsh1eR4S1pMdQ_9range_ffi14ForeignContentNtNtB4_17http_range_parser13ContentSource5resetB4_: %self"}
!90 = distinct !{!90, i1 true, !"_RNvYNtCsh1eR4S1pMdQ_9range_ffi14ForeignContentNtNtB4_17http_range_parser13ContentSource5resetB4_"}
!91 = !{!92, !89}
!92 = distinct !{!92, !93, !"_RNvXCsh1eR4S1pMdQ_9range_ffiNtB2_14ForeignContentNtNtB2_17http_range_parser13ContentSource5write: %self:It1"}
!93 = distinct !{!93, i1 true, !"_RNvXCsh1eR4S1pMdQ_9range_ffiNtB2_14ForeignContentNtNtB2_17http_range_parser13ContentSource5write"}
!94 = !{!95, !89}
!95 = distinct !{!95, !96, !"_RNvXCsh1eR4S1pMdQ_9range_ffiNtB2_14ForeignContentNtNtB2_17http_range_parser13ContentSource5write: %self:It2"}
!96 = distinct !{!96, i1 true, !"_RNvXCsh1eR4S1pMdQ_9range_ffiNtB2_14ForeignContentNtNtB2_17http_range_parser13ContentSource5write"}
!97 = !{!98, !100}
!98 = distinct !{!98, !99, !"_RINvXCsh1eR4S1pMdQ_9range_ffiNtB3_14ForeignContentNtNtB3_17http_range_parser13ContentSource10with_bytesINtNtCs9l4wcBNbII5_4core6option6OptionTjjjjEENCINvBO_13parse_contentBr_E0EB3_: %_0"}
!99 = distinct !{!99, i1 true, !"_RINvXCsh1eR4S1pMdQ_9range_ffiNtB3_14ForeignContentNtNtB3_17http_range_parser13ContentSource10with_bytesINtNtCs9l4wcBNbII5_4core6option6OptionTjjjjEENCINvBO_13parse_contentBr_E0EB3_"}
!100 = distinct !{!100, !101, !"_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB4_14ForeignContentEB4_: %source"}
!101 = distinct !{!101, i1 true, !"_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB4_14ForeignContentEB4_"}
!102 = !{!103}
!103 = distinct !{!103, !104, !"_RNCINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB6_14ForeignContentE0B6_: %input.0"}
!104 = distinct !{!104, i1 true, !"_RNCINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB6_14ForeignContentE0B6_"}
!105 = !{!106, !98, !100}
!106 = distinct !{!106, !107, !"_RINvXs2J_NtNtCs9l4wcBNbII5_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator8positionNCNCINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB1P_14ForeignContentE00EB1P_: %self"}
!107 = distinct !{!107, i1 true, !"_RINvXs2J_NtNtCs9l4wcBNbII5_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator8positionNCNCINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB1P_14ForeignContentE00EB1P_"}
!108 = !{!106, !109, !98, !100}
!109 = distinct !{!109, !104, !"_RNCINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB6_14ForeignContentE0B6_: %_0"}
!110 = !{!111, !98, !100}
!111 = distinct !{!111, !112, !"_RINvXs2J_NtNtCs9l4wcBNbII5_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator9rpositionNCNCINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB1Q_14ForeignContentE0s_0EB1Q_: %self"}
!112 = distinct !{!112, i1 true, !"_RINvXs2J_NtNtCs9l4wcBNbII5_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator9rpositionNCNCINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB1Q_14ForeignContentE0s_0EB1Q_"}
!113 = !{!111, !109, !98, !100}
!114 = !{!"branch_weights", i32 4001, i32 4000000}
!115 = !{!109, !98, !100}
!116 = !{!117}
!117 = distinct !{!117, !118, !"_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4find: %input.0"}
!118 = distinct !{!118, i1 true, !"_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4find"}
!119 = !{!120, !117, !109, !103, !98, !100}
!120 = distinct !{!120, !121, !"_RNCNvNtCskuZNHgLkVkS_6memchr6memchr6memchr0Csh1eR4S1pMdQ_9range_ffi: %_1"}
!121 = distinct !{!121, i1 true, !"_RNCNvNtCskuZNHgLkVkS_6memchr6memchr6memchr0Csh1eR4S1pMdQ_9range_ffi"}
!122 = !{!120, !109, !98, !100}
!123 = distinct !{null, null, null, null, null}
!124 = !{!117, !103}
!125 = !{!126, !128, !98, !100}
!126 = distinct !{!126, !127, !"_RINvXs2J_NtNtCs9l4wcBNbII5_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator8positionNCNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4find0EB1M_: %self"}
!127 = distinct !{!127, i1 true, !"_RINvXs2J_NtNtCs9l4wcBNbII5_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator8positionNCNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4find0EB1M_"}
!128 = distinct !{!128, !127, !"_RINvXs2J_NtNtCs9l4wcBNbII5_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator8positionNCNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4find0EB1M_: argument 1"}
!129 = !{!126, !128, !117, !109, !98, !100}
!130 = !{!131, !103}
!131 = distinct !{!131, !132, !"_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4trim: argument 0"}
!132 = distinct !{!132, i1 true, !"_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4trim"}
!133 = !{!134, !103}
!134 = distinct !{!134, !135, !"_RNvMNtNtCs9l4wcBNbII5_4core5slice5asciiSh27eq_ignore_ascii_case_simple: argument 0"}
!135 = distinct !{!135, i1 true, !"_RNvMNtNtCs9l4wcBNbII5_4core5slice5asciiSh27eq_ignore_ascii_case_simple"}
!136 = !{!137}
!137 = distinct !{!137, !138, !"_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4find: %input.0"}
!138 = distinct !{!138, i1 true, !"_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4find"}
!139 = !{!140, !137, !109, !103, !98, !100}
!140 = distinct !{!140, !141, !"_RNCNvNtCskuZNHgLkVkS_6memchr6memchr6memchr0Csh1eR4S1pMdQ_9range_ffi: %_1"}
!141 = distinct !{!141, i1 true, !"_RNCNvNtCskuZNHgLkVkS_6memchr6memchr6memchr0Csh1eR4S1pMdQ_9range_ffi"}
!142 = !{!140, !109, !98, !100}
!143 = !{!137, !103}
!144 = !{!145, !147, !98, !100}
!145 = distinct !{!145, !146, !"_RINvXs2J_NtNtCs9l4wcBNbII5_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator8positionNCNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4find0EB1M_: %self"}
!146 = distinct !{!146, i1 true, !"_RINvXs2J_NtNtCs9l4wcBNbII5_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator8positionNCNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4find0EB1M_"}
!147 = distinct !{!147, !146, !"_RINvXs2J_NtNtCs9l4wcBNbII5_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator8positionNCNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4find0EB1M_: argument 1"}
!148 = !{!145, !147, !137, !109, !98, !100}
!149 = !{!150}
!150 = distinct !{!150, !151, !"_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4find: %input.0"}
!151 = distinct !{!151, i1 true, !"_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4find"}
!152 = !{!153, !150, !109, !103, !98, !100}
!153 = distinct !{!153, !154, !"_RNCNvNtCskuZNHgLkVkS_6memchr6memchr6memchr0Csh1eR4S1pMdQ_9range_ffi: %_1"}
!154 = distinct !{!154, i1 true, !"_RNCNvNtCskuZNHgLkVkS_6memchr6memchr6memchr0Csh1eR4S1pMdQ_9range_ffi"}
!155 = !{!153, !109, !98, !100}
!156 = !{!150, !103}
!157 = !{!158, !160, !98, !100}
!158 = distinct !{!158, !159, !"_RINvXs2J_NtNtCs9l4wcBNbII5_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator8positionNCNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4find0EB1M_: %self"}
!159 = distinct !{!159, i1 true, !"_RINvXs2J_NtNtCs9l4wcBNbII5_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator8positionNCNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4find0EB1M_"}
!160 = distinct !{!160, !159, !"_RINvXs2J_NtNtCs9l4wcBNbII5_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator8positionNCNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4find0EB1M_: argument 1"}
!161 = !{!158, !160, !150, !109, !98, !100}
!162 = !{!100}
!163 = !{!164, !166}
!164 = distinct !{!164, !165, !"_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4trim: argument 0"}
!165 = distinct !{!165, i1 true, !"_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4trim"}
!166 = distinct !{!166, !167, !"_RNCINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB6_14ForeignContentEs_0B6_: %input.0"}
!167 = distinct !{!167, i1 true, !"_RNCINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB6_14ForeignContentEs_0B6_"}
!168 = !{!169, !100}
!169 = distinct !{!169, !170, !"_RNvXCsh1eR4S1pMdQ_9range_ffiNtB2_14ForeignContentNtNtB2_17http_range_parser13ContentSource5write: %self"}
!170 = distinct !{!170, i1 true, !"_RNvXCsh1eR4S1pMdQ_9range_ffiNtB2_14ForeignContentNtNtB2_17http_range_parser13ContentSource5write"}
!171 = !{!172}
!172 = distinct !{!172, !173, !"_RNCNCINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB8_14ForeignContentEs0_00B8_: %input.0"}
!173 = distinct !{!173, i1 true, !"_RNCNCINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB8_14ForeignContentEs0_00B8_"}
!174 = !{!175, !172}
!175 = distinct !{!175, !176, !"_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4trim: argument 0"}
!176 = distinct !{!176, i1 true, !"_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4trim"}
!177 = !{!178, !100}
!178 = distinct !{!178, !179, !"_RNCINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB6_14ForeignContentEs0_0B6_: %_1"}
!179 = distinct !{!179, i1 true, !"_RNCINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB6_14ForeignContentEs0_0B6_"}
!180 = !{!172, !178, !100}
!181 = !{!182, !178, !100}
!182 = distinct !{!182, !183, !"_RNvXCsh1eR4S1pMdQ_9range_ffiNtB2_14ForeignContentNtNtB2_17http_range_parser13ContentSource5write: %self"}
!183 = distinct !{!183, i1 true, !"_RNvXCsh1eR4S1pMdQ_9range_ffiNtB2_14ForeignContentNtNtB2_17http_range_parser13ContentSource5write"}
!184 = !{!185, !178, !100}
!185 = distinct !{!185, !186, !"_RNvXCsh1eR4S1pMdQ_9range_ffiNtB2_14ForeignContentNtNtB2_17http_range_parser13ContentSource4read: %self"}
!186 = distinct !{!186, i1 true, !"_RNvXCsh1eR4S1pMdQ_9range_ffiNtB2_14ForeignContentNtNtB2_17http_range_parser13ContentSource4read"}
!187 = !{!188}
!188 = distinct !{!188, !189, !"_RNCNCINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB8_14ForeignContentEs0_0s_0B8_: %input.0"}
!189 = distinct !{!189, i1 true, !"_RNCNCINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13parse_contentNtB8_14ForeignContentEs0_0s_0B8_"}
!190 = !{!"branch_weights", i32 4000000, i32 4001}
!191 = !{!192, !188}
!192 = distinct !{!192, !193, !"_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4trim: argument 0"}
!193 = distinct !{!193, i1 true, !"_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4trim"}
!194 = !{!188, !178, !100}
!195 = !{!196, !178, !100}
!196 = distinct !{!196, !197, !"_RNvXCsh1eR4S1pMdQ_9range_ffiNtB2_14ForeignContentNtNtB2_17http_range_parser13ContentSource5write: %self"}
!197 = distinct !{!197, i1 true, !"_RNvXCsh1eR4S1pMdQ_9range_ffiNtB2_14ForeignContentNtNtB2_17http_range_parser13ContentSource5write"}
!198 = !{!199, !178, !100}
!199 = distinct !{!199, !200, !"_RNvXCsh1eR4S1pMdQ_9range_ffiNtB2_14ForeignContentNtNtB2_17http_range_parser13ContentSource4read: %self"}
!200 = distinct !{!200, i1 true, !"_RNvXCsh1eR4S1pMdQ_9range_ffiNtB2_14ForeignContentNtNtB2_17http_range_parser13ContentSource4read"}
!201 = !{!202, !204, !100}
!202 = distinct !{!202, !203, !"_RNvXCsh1eR4S1pMdQ_9range_ffiNtB2_14ForeignContentNtNtB2_17http_range_parser13ContentSource5write: %self"}
!203 = distinct !{!203, i1 true, !"_RNvXCsh1eR4S1pMdQ_9range_ffiNtB2_14ForeignContentNtNtB2_17http_range_parser13ContentSource5write"}
!204 = distinct !{!204, !205, !"_RNvYNtCsh1eR4S1pMdQ_9range_ffi14ForeignContentNtNtB4_17http_range_parser13ContentSource5resetB4_: %self"}
!205 = distinct !{!205, i1 true, !"_RNvYNtCsh1eR4S1pMdQ_9range_ffi14ForeignContentNtNtB4_17http_range_parser13ContentSource5resetB4_"}
!206 = !{!207, !204, !100}
!207 = distinct !{!207, !208, !"_RNvXCsh1eR4S1pMdQ_9range_ffiNtB2_14ForeignContentNtNtB2_17http_range_parser13ContentSource5write: %self:It1"}
!208 = distinct !{!208, i1 true, !"_RNvXCsh1eR4S1pMdQ_9range_ffiNtB2_14ForeignContentNtNtB2_17http_range_parser13ContentSource5write"}
!209 = !{!210, !204, !100}
!210 = distinct !{!210, !211, !"_RNvXCsh1eR4S1pMdQ_9range_ffiNtB2_14ForeignContentNtNtB2_17http_range_parser13ContentSource5write: %self:It2"}
!211 = distinct !{!211, i1 true, !"_RNvXCsh1eR4S1pMdQ_9range_ffiNtB2_14ForeignContentNtNtB2_17http_range_parser13ContentSource5write"}
!212 = !{i64 1605756219370389853}
!213 = !{!214}
!214 = distinct !{!214, !215, !"_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser11parse_fetch: %input.0"}
!215 = distinct !{!215, i1 true, !"_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser11parse_fetch"}
!216 = !{!217, !214}
!217 = distinct !{!217, !218, !"_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser9delimiter: %input.0"}
!218 = distinct !{!218, i1 true, !"_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser9delimiter"}
!219 = !{!220}
!220 = distinct !{!220, !221, !"_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13fetch_decimal: %input.0"}
!221 = distinct !{!221, i1 true, !"_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13fetch_decimal"}
!222 = !{!220, !214}
!223 = !{!220, !224, !225, !214}
!224 = distinct !{!224, !221, !"_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13fetch_decimal: %pos"}
!225 = distinct !{!225, !215, !"_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser11parse_fetch: %_0"}
!226 = !{!227, !214}
!227 = distinct !{!227, !228, !"_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser9delimiter: %input.0"}
!228 = distinct !{!228, i1 true, !"_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser9delimiter"}
!229 = !{!230}
!230 = distinct !{!230, !231, !"_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13fetch_decimal: %input.0"}
!231 = distinct !{!231, i1 true, !"_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13fetch_decimal"}
!232 = !{!230, !214}
!233 = !{!230, !234, !225, !214}
!234 = distinct !{!234, !231, !"_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13fetch_decimal: %pos"}
!235 = !{i64 1130326065316513249}
!236 = !{!237}
!237 = distinct !{!237, !238, !"_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB4_23rustium_http_range_list0EB4_: %input.0"}
!238 = distinct !{!238, i1 true, !"_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB4_23rustium_http_range_list0EB4_"}
!239 = !{!240}
!240 = distinct !{!240, !238, !"_RINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB4_23rustium_http_range_list0EB4_: argument 1"}
!241 = !{!242}
!242 = distinct !{!242, !243, !"_RINvXs2J_NtNtCs9l4wcBNbII5_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator8positionNCINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB1N_23rustium_http_range_list0E0EB1N_: %self"}
!243 = distinct !{!243, i1 true, !"_RINvXs2J_NtNtCs9l4wcBNbII5_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator8positionNCINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB1N_23rustium_http_range_list0E0EB1N_"}
!244 = !{!242, !237, !240}
!245 = !{!246, !237}
!246 = distinct !{!246, !247, !"_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4trim: argument 0"}
!247 = distinct !{!247, i1 true, !"_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4trim"}
!248 = !{!249, !237}
!249 = distinct !{!249, !250, !"_RNvMNtNtCs9l4wcBNbII5_4core5slice5asciiSh27eq_ignore_ascii_case_simple: argument 0"}
!250 = distinct !{!250, i1 true, !"_RNvMNtNtCs9l4wcBNbII5_4core5slice5asciiSh27eq_ignore_ascii_case_simple"}
!251 = !{!252, !237}
!252 = distinct !{!252, !253, !"_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4trim: argument 0"}
!253 = distinct !{!253, i1 true, !"_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4trim"}
!254 = !{!255}
!255 = distinct !{!255, !256, !"_RINvXs2J_NtNtCs9l4wcBNbII5_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator8positionNCINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB1N_23rustium_http_range_list0Es_0EB1N_: %self"}
!256 = distinct !{!256, i1 true, !"_RINvXs2J_NtNtCs9l4wcBNbII5_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator8positionNCINvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser12parse_rangesNCNvB1N_23rustium_http_range_list0Es_0EB1N_"}
!257 = !{!255, !237, !240}
!258 = !{!259, !237}
!259 = distinct !{!259, !260, !"_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4trim: argument 0"}
!260 = distinct !{!260, i1 true, !"_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4trim"}
!261 = !{!262, !237}
!262 = distinct !{!262, !263, !"_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4trim: argument 0"}
!263 = distinct !{!263, i1 true, !"_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser4trim"}
!264 = !{!265}
!265 = distinct !{!265, !266, !"_RNvMsG_NtCs8tsiLsQ9XHg_5alloc3vecINtB5_3VecNtCsh1eR4S1pMdQ_9range_ffi11ParsedRangeE8push_mutBH_: %self"}
!266 = distinct !{!266, i1 true, !"_RNvMsG_NtCs8tsiLsQ9XHg_5alloc3vecINtB5_3VecNtCsh1eR4S1pMdQ_9range_ffi11ParsedRangeE8push_mutBH_"}
!267 = !{!265, !240}
!268 = !{!269}
!269 = distinct !{!269, !270, !"_RNCNvCsh1eR4S1pMdQ_9range_ffi23rustium_http_range_list0B3_: %range"}
!270 = distinct !{!270, i1 true, !"_RNCNvCsh1eR4S1pMdQ_9range_ffi23rustium_http_range_list0B3_"}
!271 = !{!272, !269, !237}
!272 = distinct !{!272, !266, !"_RNvMsG_NtCs8tsiLsQ9XHg_5alloc3vecINtB5_3VecNtCsh1eR4S1pMdQ_9range_ffi11ParsedRangeE8push_mutBH_: %value"}
!273 = !{!265, !269, !237, !240}
!274 = !{!275}
!275 = distinct !{!275, !276, !"_RNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCsh1eR4S1pMdQ_9range_ffi: %_0"}
!276 = distinct !{!276, i1 true, !"_RNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCsh1eR4S1pMdQ_9range_ffi"}
!277 = !{i64 -5268127801410235539}
!278 = !{!279}
!279 = distinct !{!279, !280, !"_RNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCsh1eR4S1pMdQ_9range_ffi: %_0"}
!280 = distinct !{!280, i1 true, !"_RNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCsh1eR4S1pMdQ_9range_ffi"}
