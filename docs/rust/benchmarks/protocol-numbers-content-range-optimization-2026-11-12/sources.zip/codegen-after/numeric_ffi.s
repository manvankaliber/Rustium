	.def	@feat.00;
	.scl	3;
	.type	0;
	.endef
	.globl	@feat.00
@feat.00 = 2048
	.att_syntax
	.file	"numeric_ffi.db33e3d5a3958eec-cgu.0"
	.def	_RNvXs1_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtB5_11NumberBytes16remaining_digits;
	.scl	3;
	.type	32;
	.endef
	.globl	__xmm@c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6
	.section	.rdata,"dr",discard,__xmm@c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6
	.p2align	4, 0x0
__xmm@c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6:
	.zero	16,198
	.globl	__xmm@f5f5f5f5f5f5f5f5f5f5f5f5f5f5f5f5
	.section	.rdata,"dr",discard,__xmm@f5f5f5f5f5f5f5f5f5f5f5f5f5f5f5f5
	.p2align	4, 0x0
__xmm@f5f5f5f5f5f5f5f5f5f5f5f5f5f5f5f5:
	.zero	16,245
	.section	.text,"xr",one_only,_RNvXs1_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtB5_11NumberBytes16remaining_digits,unique,0
	.p2align	4
_RNvXs1_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtB5_11NumberBytes16remaining_digits:
.seh_proc _RNvXs1_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtB5_11NumberBytes16remaining_digits
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	subq	%rcx, %rdx
	jb	.LBB0_12
	js	.LBB0_13
	movabsq	$9223372036854775792, %rax
	andq	%rdx, %rax
	je	.LBB0_6
	xorl	%r8d, %r8d
	movdqa	__xmm@c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6c6(%rip), %xmm0
	movdqa	__xmm@f5f5f5f5f5f5f5f5f5f5f5f5f5f5f5f5(%rip), %xmm1
	.p2align	4
.LBB0_4:
	movdqu	(%rcx,%r8), %xmm2
	paddb	%xmm0, %xmm2
	movdqa	%xmm2, %xmm3
	pminub	%xmm1, %xmm3
	pcmpeqb	%xmm2, %xmm3
	pmovmskb	%xmm3, %r9d
	testl	%r9d, %r9d
	jne	.LBB0_10
	addq	$16, %r8
	cmpq	%r8, %rax
	jne	.LBB0_4
.LBB0_6:
	andl	$15, %edx
	je	.LBB0_11
	addq	%rax, %rcx
	decq	%rdx
	xorl	%r8d, %r8d
	.p2align	4
.LBB0_8:
	movzbl	(%rcx,%r8), %eax
	addb	$-48, %al
	cmpb	$10, %al
	setb	%al
	setae	%r9b
	cmpq	%r8, %rdx
	sete	%r10b
	orb	%r9b, %r10b
	incq	%r8
	cmpb	$1, %r10b
	jne	.LBB0_8
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB0_10:
	xorl	%eax, %eax
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB0_11:
	movb	$1, %al
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB0_12:
	leaq	alloc_de4e626d456b04760e72bc785ed7e52a(%rip), %rcx
	leaq	alloc_18226a1c5efd974bf041c2c59bdf25ca(%rip), %r9
	movl	$403, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
.LBB0_13:
	leaq	alloc_a28e8c8fd5088943a8b5d44af697ff83(%rip), %rcx
	leaq	alloc_1d1b1e35bb489427b2bdc9752de92226(%rip), %r9
	movl	$559, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
	.seh_endproc

	.def	rustium_parse_number_native_i32;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,rustium_parse_number_native_i32,unique,1
	.globl	rustium_parse_number_native_i32
	.p2align	4
rustium_parse_number_native_i32:
.seh_proc rustium_parse_number_native_i32
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	96(%rsp), %r10
	testq	%rdx, %rdx
	je	.LBB1_28
	movq	%rdx, %rax
	testq	%rcx, %rcx
	setne	%dl
	testq	%rax, %rax
	setns	%r11b
	testb	%r11b, %dl
	je	.LBB1_51
	leaq	(%rcx,%rax), %rdx
	movzbl	(%rcx), %r11d
	cmpl	$45, %r11d
	je	.LBB1_4
	cmpl	$48, %r11d
	jne	.LBB1_12
.LBB1_4:
	leal	-48(%r11), %esi
	cmpb	$10, %sil
	jae	.LBB1_8
	incq	%rcx
	movb	$48, %al
.LBB1_6:
	andl	$-2, %r8d
	cmpl	$2, %r8d
	sete	%r8b
	cmpb	$48, %al
	sete	%bl
	testb	%bl, %r8b
	je	.LBB1_23
	cmpb	$45, %r11b
	sete	%al
	cmpq	%rdx, %rcx
	setne	%cl
	xorl	%r8d, %r8d
	orb	%al, %cl
	jne	.LBB1_28
	jmp	.LBB1_43
.LBB1_8:
	cmpb	$45, %r11b
	jne	.LBB1_28
	testl	$-3, %r8d
	je	.LBB1_28
	cmpq	$1, %rax
	je	.LBB1_28
	movzbl	1(%rcx), %eax
	addq	$2, %rcx
	jmp	.LBB1_6
.LBB1_12:
	leal	-48(%r11), %r8d
	cmpb	$9, %r8b
	ja	.LBB1_28
	movzbl	%r8b, %r8d
	decq	%rax
	je	.LBB1_43
	addq	$2, %rcx
	jmp	.LBB1_16
	.p2align	4
.LBB1_15:
	movzbl	%r11b, %r11d
	leaq	(%r8,%r8,4), %r8
	leaq	(%r11,%r8,2), %r8
	incq	%rcx
	decq	%rax
	je	.LBB1_43
.LBB1_16:
	movzbl	-1(%rcx), %r11d
	addb	$-48, %r11b
	cmpb	$9, %r11b
	ja	.LBB1_28
	cmpq	$214748364, %r8
	ja	.LBB1_20
	jne	.LBB1_15
	cmpb	$7, %r11b
	jbe	.LBB1_15
.LBB1_20:
	xorl	%eax, %eax
	testq	%r10, %r10
	je	.LBB1_31
	movl	$0, 36(%rsp)
.LBB1_22:
	callq	_RNvXs1_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtB5_11NumberBytes16remaining_digits
	testb	%al, %al
	movl	$2, %eax
	cmovnel	36(%rsp), %eax
	movq	96(%rsp), %r10
	jmp	.LBB1_29
.LBB1_23:
	cmpb	$48, %al
	jne	.LBB1_27
	xorl	%r8d, %r8d
	.p2align	4
.LBB1_25:
	cmpq	%rdx, %rcx
	je	.LBB1_43
	movzbl	(%rcx), %eax
	incq	%rcx
	cmpb	$48, %al
	je	.LBB1_25
.LBB1_27:
	addb	$-48, %al
	cmpb	$9, %al
	jbe	.LBB1_32
.LBB1_28:
	movl	$2, %eax
	testq	%r10, %r10
	je	.LBB1_30
.LBB1_29:
	movl	%eax, (%r10)
.LBB1_30:
	xorl	%eax, %eax
.LBB1_31:
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rsi
	.seh_endepilogue
	retq
.LBB1_32:
	movzbl	%al, %r8d
	cmpb	$45, %r11b
	jne	.LBB1_42
	cmpq	%rdx, %rcx
	jne	.LBB1_36
.LBB1_34:
	negq	%r8
	jmp	.LBB1_43
.LBB1_35:
	movzbl	%r11b, %ecx
	leaq	(%r8,%r8,4), %r8
	leaq	(%rcx,%r8,2), %r8
	movq	%rax, %rcx
	cmpq	%rdx, %rax
	je	.LBB1_34
.LBB1_36:
	movzbl	(%rcx), %r11d
	addb	$-48, %r11b
	cmpb	$9, %r11b
	ja	.LBB1_28
	leaq	1(%rcx), %rax
	cmpq	$214748364, %r8
	ja	.LBB1_40
	jne	.LBB1_35
	cmpb	$9, %r11b
	jne	.LBB1_35
.LBB1_40:
	testq	%r10, %r10
	je	.LBB1_30
	incq	%rcx
	movl	$1, 36(%rsp)
	jmp	.LBB1_22
.LBB1_42:
	cmpq	%rdx, %rcx
	jne	.LBB1_45
.LBB1_43:
	movl	%r8d, (%r9)
	movb	$1, %al
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rsi
	.seh_endepilogue
	retq
.LBB1_44:
	movzbl	%r11b, %ecx
	leaq	(%r8,%r8,4), %r8
	leaq	(%rcx,%r8,2), %r8
	movq	%rax, %rcx
	cmpq	%rdx, %rax
	je	.LBB1_43
.LBB1_45:
	movzbl	(%rcx), %r11d
	addb	$-48, %r11b
	cmpb	$9, %r11b
	ja	.LBB1_28
	leaq	1(%rcx), %rax
	cmpq	$214748364, %r8
	ja	.LBB1_49
	jne	.LBB1_44
	cmpb	$7, %r11b
	jbe	.LBB1_44
.LBB1_49:
	xorl	%eax, %eax
	testq	%r10, %r10
	je	.LBB1_31
	movl	$0, 36(%rsp)
	incq	%rcx
	jmp	.LBB1_22
.LBB1_51:
	leaq	alloc_a28e8c8fd5088943a8b5d44af697ff83(%rip), %rcx
	leaq	alloc_14547586b6d8a2ddcb70cace56ee43cc(%rip), %r9
	movl	$559, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
	.seh_endproc

	.def	rustium_parse_number_native_i64;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,rustium_parse_number_native_i64,unique,2
	.globl	rustium_parse_number_native_i64
	.p2align	4
rustium_parse_number_native_i64:
.seh_proc rustium_parse_number_native_i64
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	96(%rsp), %r10
	testq	%rdx, %rdx
	je	.LBB2_29
	movq	%rdx, %rax
	testq	%rcx, %rcx
	setne	%dl
	testq	%rax, %rax
	setns	%r11b
	testb	%r11b, %dl
	je	.LBB2_54
	leaq	(%rcx,%rax), %rdx
	movzbl	(%rcx), %r11d
	cmpl	$45, %r11d
	je	.LBB2_4
	cmpl	$48, %r11d
	jne	.LBB2_13
.LBB2_4:
	leal	-48(%r11), %esi
	cmpb	$10, %sil
	jae	.LBB2_9
	incq	%rcx
	movb	$48, %al
.LBB2_6:
	andl	$-2, %r8d
	cmpl	$2, %r8d
	sete	%r8b
	cmpb	$48, %al
	sete	%bl
	testb	%bl, %r8b
	je	.LBB2_24
	cmpb	$45, %r11b
	sete	%al
	cmpq	%rdx, %rcx
	setne	%cl
	orb	%al, %cl
	jne	.LBB2_29
	xorl	%r8d, %r8d
	jmp	.LBB2_53
.LBB2_9:
	cmpb	$45, %r11b
	jne	.LBB2_29
	testl	$-3, %r8d
	je	.LBB2_29
	cmpq	$1, %rax
	je	.LBB2_29
	movzbl	1(%rcx), %eax
	addq	$2, %rcx
	jmp	.LBB2_6
.LBB2_13:
	leal	-48(%r11), %r8d
	cmpb	$9, %r8b
	ja	.LBB2_29
	movzbl	%r8b, %r8d
	decq	%rax
	je	.LBB2_53
	addq	$2, %rcx
	movabsq	$922337203685477580, %r11
	jmp	.LBB2_17
	.p2align	4
.LBB2_16:
	movzbl	%bl, %esi
	leaq	(%r8,%r8,4), %r8
	leaq	(%rsi,%r8,2), %r8
	incq	%rcx
	decq	%rax
	je	.LBB2_53
.LBB2_17:
	movzbl	-1(%rcx), %ebx
	addb	$-48, %bl
	cmpb	$9, %bl
	ja	.LBB2_29
	cmpq	%r11, %r8
	ja	.LBB2_21
	jne	.LBB2_16
	cmpb	$7, %bl
	jbe	.LBB2_16
.LBB2_21:
	xorl	%eax, %eax
	testq	%r10, %r10
	je	.LBB2_32
	movl	$0, 36(%rsp)
.LBB2_23:
	callq	_RNvXs1_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtB5_11NumberBytes16remaining_digits
	testb	%al, %al
	movl	$2, %eax
	cmovnel	36(%rsp), %eax
	movq	96(%rsp), %r10
	jmp	.LBB2_30
.LBB2_24:
	cmpb	$48, %al
	jne	.LBB2_28
	xorl	%r8d, %r8d
	.p2align	4
.LBB2_26:
	cmpq	%rdx, %rcx
	je	.LBB2_53
	movzbl	(%rcx), %eax
	incq	%rcx
	cmpb	$48, %al
	je	.LBB2_26
.LBB2_28:
	addb	$-48, %al
	cmpb	$9, %al
	jbe	.LBB2_33
.LBB2_29:
	movl	$2, %eax
	testq	%r10, %r10
	je	.LBB2_31
.LBB2_30:
	movl	%eax, (%r10)
.LBB2_31:
	xorl	%eax, %eax
.LBB2_32:
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rsi
	.seh_endepilogue
	retq
.LBB2_33:
	movzbl	%al, %r8d
	cmpb	$45, %r11b
	jne	.LBB2_43
	cmpq	%rdx, %rcx
	je	.LBB2_52
	movabsq	$922337203685477580, %rax
	jmp	.LBB2_37
.LBB2_36:
	movzbl	%bl, %ecx
	leaq	(%r8,%r8,4), %r8
	leaq	(%rcx,%r8,2), %r8
	movq	%r11, %rcx
	cmpq	%rdx, %r11
	je	.LBB2_52
.LBB2_37:
	movzbl	(%rcx), %ebx
	addb	$-48, %bl
	cmpb	$9, %bl
	ja	.LBB2_29
	leaq	1(%rcx), %r11
	cmpq	%rax, %r8
	ja	.LBB2_41
	jne	.LBB2_36
	cmpb	$9, %bl
	jne	.LBB2_36
.LBB2_41:
	testq	%r10, %r10
	je	.LBB2_31
	incq	%rcx
	movl	$1, 36(%rsp)
	jmp	.LBB2_23
.LBB2_43:
	cmpq	%rdx, %rcx
	je	.LBB2_53
	movabsq	$922337203685477580, %rax
	jmp	.LBB2_46
.LBB2_45:
	movzbl	%bl, %ecx
	leaq	(%r8,%r8,4), %r8
	leaq	(%rcx,%r8,2), %r8
	movq	%r11, %rcx
	cmpq	%rdx, %r11
	je	.LBB2_53
.LBB2_46:
	movzbl	(%rcx), %ebx
	addb	$-48, %bl
	cmpb	$9, %bl
	ja	.LBB2_29
	leaq	1(%rcx), %r11
	cmpq	%rax, %r8
	ja	.LBB2_50
	jne	.LBB2_45
	cmpb	$7, %bl
	jbe	.LBB2_45
.LBB2_50:
	xorl	%eax, %eax
	testq	%r10, %r10
	je	.LBB2_32
	movl	$0, 36(%rsp)
	incq	%rcx
	jmp	.LBB2_23
.LBB2_52:
	negq	%r8
.LBB2_53:
	movq	%r8, (%r9)
	movb	$1, %al
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rsi
	.seh_endepilogue
	retq
.LBB2_54:
	leaq	alloc_a28e8c8fd5088943a8b5d44af697ff83(%rip), %rcx
	leaq	alloc_14547586b6d8a2ddcb70cace56ee43cc(%rip), %r9
	movl	$559, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
	.seh_endproc

	.def	rustium_parse_number_native_u32;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,rustium_parse_number_native_u32,unique,3
	.globl	rustium_parse_number_native_u32
	.p2align	4
rustium_parse_number_native_u32:
.seh_proc rustium_parse_number_native_u32
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	80(%rsp), %rax
	testq	%rdx, %rdx
	je	.LBB3_3
	testq	%rcx, %rcx
	setne	%r10b
	testq	%rdx, %rdx
	setns	%r11b
	testb	%r11b, %r10b
	je	.LBB3_19
	movzbl	(%rcx), %r10d
	addb	$-48, %r10b
	cmpb	$9, %r10b
	jbe	.LBB3_7
.LBB3_3:
	movl	$2, %ecx
	testq	%rax, %rax
	je	.LBB3_5
.LBB3_4:
	movl	%ecx, (%rax)
.LBB3_5:
	xorl	%eax, %eax
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB3_7:
	cmpl	$2, %r8d
	sete	%r8b
	testb	%r10b, %r10b
	sete	%r11b
	testb	%r11b, %r8b
	je	.LBB3_9
	xorl	%r8d, %r8d
	cmpq	$1, %rdx
	jne	.LBB3_3
	jmp	.LBB3_18
.LBB3_9:
	movzbl	%r10b, %r8d
	movq	%rdx, %r10
	decq	%r10
	je	.LBB3_18
	addq	%rcx, %rdx
	addq	$2, %rcx
	jmp	.LBB3_12
	.p2align	4
.LBB3_11:
	movzbl	%r11b, %r11d
	leaq	(%r8,%r8,4), %r8
	leaq	(%r11,%r8,2), %r8
	incq	%rcx
	decq	%r10
	je	.LBB3_18
.LBB3_12:
	movzbl	-1(%rcx), %r11d
	addb	$-48, %r11b
	cmpb	$9, %r11b
	ja	.LBB3_3
	cmpq	$429496729, %r8
	ja	.LBB3_16
	jne	.LBB3_11
	cmpb	$5, %r11b
	jbe	.LBB3_11
.LBB3_16:
	testq	%rax, %rax
	je	.LBB3_5
	callq	_RNvXs1_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtB5_11NumberBytes16remaining_digits
	xorb	$1, %al
	movzbl	%al, %ecx
	movq	80(%rsp), %rax
	addl	%ecx, %ecx
	jmp	.LBB3_4
.LBB3_18:
	movl	%r8d, (%r9)
	movb	$1, %al
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB3_19:
	leaq	alloc_a28e8c8fd5088943a8b5d44af697ff83(%rip), %rcx
	leaq	alloc_14547586b6d8a2ddcb70cace56ee43cc(%rip), %r9
	movl	$559, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
	.seh_endproc

	.def	rustium_parse_number_native_u64;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,rustium_parse_number_native_u64,unique,4
	.globl	rustium_parse_number_native_u64
	.p2align	4
rustium_parse_number_native_u64:
.seh_proc rustium_parse_number_native_u64
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	96(%rsp), %r10
	testq	%rdx, %rdx
	je	.LBB4_3
	testq	%rcx, %rcx
	setne	%al
	testq	%rdx, %rdx
	setns	%r11b
	testb	%r11b, %al
	je	.LBB4_21
	movzbl	(%rcx), %eax
	addb	$-48, %al
	cmpb	$9, %al
	jbe	.LBB4_8
.LBB4_3:
	testq	%r10, %r10
	je	.LBB4_6
.LBB4_4:
	movl	$2, %ecx
.LBB4_5:
	movl	%ecx, (%r10)
.LBB4_6:
	xorl	%eax, %eax
.LBB4_7:
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rsi
	.seh_endepilogue
	retq
.LBB4_8:
	cmpl	$2, %r8d
	sete	%r8b
	testb	%al, %al
	sete	%r11b
	testb	%r11b, %r8b
	je	.LBB4_11
	cmpq	$1, %rdx
	jne	.LBB4_3
	xorl	%eax, %eax
	jmp	.LBB4_20
.LBB4_11:
	movzbl	%al, %eax
	movq	%rdx, %r8
	decq	%r8
	je	.LBB4_20
	addq	%rcx, %rdx
	addq	$2, %rcx
	movabsq	$1844674407370955161, %r11
	jmp	.LBB4_14
	.p2align	4
.LBB4_13:
	movzbl	%bl, %esi
	leaq	(%rax,%rax,4), %rax
	leaq	(%rsi,%rax,2), %rax
	incq	%rcx
	decq	%r8
	je	.LBB4_20
.LBB4_14:
	movzbl	-1(%rcx), %ebx
	addb	$-48, %bl
	cmpb	$9, %bl
	ja	.LBB4_3
	cmpq	%r11, %rax
	ja	.LBB4_18
	jne	.LBB4_13
	cmpb	$5, %bl
	jbe	.LBB4_13
.LBB4_18:
	xorl	%eax, %eax
	testq	%r10, %r10
	je	.LBB4_7
	movq	%r10, %rbx
	callq	_RNvXs1_Cs4A2AHSyUD2M_17parse_number_coreNtB5_10SliceBytesNtB5_11NumberBytes16remaining_digits
	movq	%rbx, %r10
	xorl	%ecx, %ecx
	testb	%al, %al
	je	.LBB4_4
	jmp	.LBB4_5
.LBB4_20:
	movq	%rax, (%r9)
	movb	$1, %al
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rsi
	.seh_endepilogue
	retq
.LBB4_21:
	leaq	alloc_a28e8c8fd5088943a8b5d44af697ff83(%rip), %rcx
	leaq	alloc_14547586b6d8a2ddcb70cace56ee43cc(%rip), %r9
	movl	$559, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
	.seh_endproc

	.section	.rdata,"dr",one_only,alloc_83bc31b2c75b61bc5cd021623002fec0,unique,5
alloc_83bc31b2c75b61bc5cd021623002fec0:
	.asciz	"D:\\Rustium\\net\\base\\parse_number_native_ffi.rs"

	.section	.rdata,"dr",one_only,alloc_14547586b6d8a2ddcb70cace56ee43cc,unique,6
	.p2align	3, 0x0
alloc_14547586b6d8a2ddcb70cace56ee43cc:
	.quad	alloc_83bc31b2c75b61bc5cd021623002fec0
	.asciz	".\000\000\000\000\000\000\000#\000\000\000\026\000\000"

	.section	.rdata,"dr",one_only,alloc_ce8e0a0d52777a5d2d5dc56ded7b0c08,unique,7
alloc_ce8e0a0d52777a5d2d5dc56ded7b0c08:
	.asciz	"library\\core\\src\\ptr\\non_null.rs"

	.section	.rdata,"dr",one_only,alloc_18226a1c5efd974bf041c2c59bdf25ca,unique,8
	.p2align	3, 0x0
alloc_18226a1c5efd974bf041c2c59bdf25ca:
	.quad	alloc_ce8e0a0d52777a5d2d5dc56ded7b0c08
	.asciz	" \000\000\000\000\000\000\000\200\003\000\000 \000\000"

	.section	.rdata,"dr",one_only,alloc_87e6578268e354c4f2747b30d32a9b4e,unique,9
alloc_87e6578268e354c4f2747b30d32a9b4e:
	.asciz	"library\\core\\src\\slice\\iter.rs"

	.section	.rdata,"dr",one_only,alloc_1d1b1e35bb489427b2bdc9752de92226,unique,10
	.p2align	3, 0x0
alloc_1d1b1e35bb489427b2bdc9752de92226:
	.quad	alloc_87e6578268e354c4f2747b30d32a9b4e
	.asciz	"\036\000\000\000\000\000\000\000\214\000\000\000\001\000\000"

	.section	.rdata,"dr",one_only,alloc_de4e626d456b04760e72bc785ed7e52a,unique,11
alloc_de4e626d456b04760e72bc785ed7e52a:
	.ascii	"unsafe precondition(s) violated: ptr::offset_from_unsigned requires `self >= origin`\n\nThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety."

	.section	.rdata,"dr",one_only,alloc_a28e8c8fd5088943a8b5d44af697ff83,unique,12
alloc_a28e8c8fd5088943a8b5d44af697ff83:
	.ascii	"unsafe precondition(s) violated: slice::from_raw_parts requires the pointer to be aligned and non-null, and the total size of the slice not to exceed `isize::MAX`\n\nThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety."

	.section	.gfids$y,"dr"
	.symidx	__CxxFrameHandler3
	.section	.giats$y,"dr"
	.section	.gljmp$y,"dr"
