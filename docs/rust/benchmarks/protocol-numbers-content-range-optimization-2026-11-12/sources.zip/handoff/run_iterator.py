from pathlib import Path
import os,subprocess,json,hashlib,ctypes
r=Path('D:/Rustium');w=r/'.scratch/net-wave1/promote/optimization';work=w/'numbers';full=Path('D:/RustiumBuild/src');env=os.environ.copy()
for item in (full/'out/Default/environment.x64').read_bytes().decode().split('\0'):
 k,s,v=item.partition('=')
 if s:env[k]=v
env.update({'RUSTC':str(full/'third_party/rust-toolchain/bin/rustc.exe'),'RUSTDOC':str(full/'third_party/rust-toolchain/bin/rustdoc.exe'),'CARGO_TARGET_DIR':str(work/'iterator-target'),'RUSTFLAGS':'-Cdebug-assertions=yes -Ccontrol-flow-guard=yes -Cinstrument-coverage -Dwarnings','CARGO_TARGET_X86_64_PC_WINDOWS_MSVC_LINKER':str(full/'third_party/llvm-build/Release+Asserts/bin/lld-link.exe'),'LLVM_PROFILE_FILE':str(work/'iterator-%p.profraw')})
command=['C:/Users/jackv/.cargo/bin/cargo.exe','test','--release','--offline','--test','iterator_contract','--','--nocapture'];source=r/'net/base/parse_number_parser.rs';test=r/'net/base/parse_number_native_core_unittest.rs';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();record={'command':command,'environment_overrides':{k:v for k,v in env.items() if k in ['RUSTC','RUSTDOC','CARGO_TARGET_DIR','RUSTFLAGS','CARGO_TARGET_X86_64_PC_WINDOWS_MSVC_LINKER','LLVM_PROFILE_FILE']},'source_sha256':{p.relative_to(r).as_posix():sha(p) for p in [source,test]},'cpu':13,'scope':'Safe core iterator contract tests; C++ public-API differential harness separately validates slice API. Test binary uses standard Rust test panic behavior (not production panic=abort).'}
with (work/'iterator.log').open('wb') as stream:
 p=subprocess.Popen(command,cwd=work,env=env,stdout=stream,stderr=subprocess.STDOUT)
 if not ctypes.windll.kernel32.SetProcessAffinityMask(ctypes.c_void_p(int(p._handle)),ctypes.c_size_t(1<<13)):p.kill();raise RuntimeError('affinity failed')
 code=p.wait()
record['exit_code']=code;record['source_unchanged']=all(sha(r/p)==h for p,h in record['source_sha256'].items());record['binary_sha256']={str(p):sha(p) for p in (work/'iterator-target/release/deps').glob('iterator_contract*.exe')};(work/'iterator-execution.json').write_text(json.dumps(record,indent=2)+'\n');print((work/'iterator.log').read_text()[-2500:]);raise SystemExit(code)
