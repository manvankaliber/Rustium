from pathlib import Path
import json,hashlib,subprocess,difflib
r=Path('D:/Rustium');w=r/'.scratch/net-wave1/promote/optimization';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
initial=json.loads((w/'before-manifest.json').read_text());changed=['net/base/parse_number_parser.rs','net/base/parse_number_native_unittest.cc'];created=['net/base/parse_number_native_core_unittest.rs']
for p,h in initial.items():
 if p not in changed:assert sha(r/p)==h,p
for module in ('numbers','range','candidate','hsts'):
 ex=json.loads((w/module/'unit-execution.json').read_text());assert ex['exit_code']==0 and ex['source_unchanged'];assert all(sha(r/p)==h for p,h in ex['source_sha256'].items())
for module in ('numbers','range'):
 for mode in ['fuzz','clippy']+(['core-clippy'] if module=='numbers' else []):
  ex=json.loads((w/module/(mode+'-execution.json')).read_text());assert ex['exit_code']==0 and ex['source_unchanged'];assert all(sha(r/p)==h for p,h in ex['source_sha256'].items());
 assert 'stat::number_of_executed_units: 1000000' in (w/module/'fuzz.log').read_text()
assert json.loads((w/'numbers/iterator-execution.json').read_text())['exit_code']==0
# All measured workloads and every frozen C++ reference remain byte-identical.
for p in ['net/base/parse_number_native_perftest.cc','net/http/http_range_promote_perftest.cc','net/base/parse_number_native_reference.cc','net/http/http_range_promote_reference.cc']:
 assert sha(r/p)==initial[p]
commands=[]
for cmd in [[str(r/'.scratch/clang-format/clang_format/data/bin/clang-format.exe'),'--dry-run','--Werror',str(r/changed[1])],['D:/RustiumBuild/src/third_party/rust-toolchain/bin/rustfmt.exe','--edition','2024','--check',str(r/changed[0]),str(r/created[0])]]:
 p=subprocess.run(cmd,capture_output=True,text=True);commands.append({'command':cmd,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr});p.check_returncode()
for module in ('protocol-numbers','http-range'):
 source=r/'.scratch/net-wave1/measurement-descriptors'/(module+'.json');(w/(module+'-descriptor.json')).write_bytes(source.read_bytes());d=json.loads(source.read_text());assert sum(len(g['cases']) for g in d['groups'])==35;assert all(len(g['cases'])<=5 for g in d['groups'])
for p in changed:
 patch=''.join(difflib.unified_diff((w/'before'/p).read_text().splitlines(True),(r/p).read_text().splitlines(True),fromfile='a/'+p,tofile='b/'+p));(w/(Path(p).name+'.patch')).write_text(patch)
# Verify integrated Range adapter identity read-only, with all three methods.
import importlib.util
spec=importlib.util.spec_from_file_location('benchmark_runner',r/'tools/run_rust_rewrite_benchmarks.py');runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner);methods=runner.check_range_adapter(r)
(w/'checks.json').write_text(json.dumps({'unchanged_files_from_before':{p:h for p,h in initial.items() if p not in changed},'changed_files_sha256':{p:sha(r/p) for p in changed+created},'range_adapter_methods_identical_to_production':methods,'all_70_cases_retained':True,'all_final_validation_source_hashes_match':True,'formatting':commands,'performance_measurements_collected':False},indent=2)+'\n');print('Final hashes, all unchanged references/workloads, adapter identity and formatting verified.')
