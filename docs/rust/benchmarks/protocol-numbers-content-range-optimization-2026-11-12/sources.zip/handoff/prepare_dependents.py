from pathlib import Path
import shutil
r=Path('D:/Rustium');w=r/'.scratch/net-wave1/promote/optimization'
for module,old in [('candidate','protocol-numbers'),('hsts','hsts-parser')]:
 work=w/module;work.mkdir(exist_ok=True);(work/'.cargo').mkdir(exist_ok=True);(work/'core').mkdir(exist_ok=True)
 shutil.copy2(w/'numbers/core/Cargo.toml',work/'core/Cargo.toml');shutil.copy2(r/'.scratch'/old/'.cargo/config.toml',work/'.cargo/config.toml')
 cargo=(r/'.scratch'/old/'Cargo.toml').read_text().replace('../../net/', '../../../../../net/').replace('../protocol-numbers/core','core');(work/'Cargo.toml').write_text(cargo)
 s=(r/'.scratch'/old/'build_native.py').read_text().replace("work=root/'.scratch/"+old+"'","work=root/'.scratch/net-wave1/promote/optimization/"+module+"'")
 if module=='hsts':
  a=s.index('    config=work/');b=s.index("    tool=full/",a);s=s[:a]+s[b:]
 # Keep measured/reference algorithms untouched; native builds compile the
 # unmodified test references locally, with their existing export defines.
 s=s.replace("if mode=='unit':command+=' /DNET_IMPLEMENTATION'", "if mode=='unit':command+=' /DNET_IMPLEMENTATION'\n    command+=' /DIS_PARSE_NUMBER_REFERENCE_IMPL /DIS_HSTS_REFERENCE_IMPL /DIS_HTTP_RANGE_REFERENCE_IMPL'")
 s=s.replace("result=subprocess.run(command,cwd=out,env=env,capture_output=True,text=True)","import json\n(work/(mode+'-link-command.json')).write_text(json.dumps(command,indent=2)+'\\n')\nresult=subprocess.run(command,cwd=out,env=env,capture_output=True,text=True)")
 (work/'build_native.py').write_text(s)
print('Prepared isolated read-only builds for historical candidate and HSTS API.')
