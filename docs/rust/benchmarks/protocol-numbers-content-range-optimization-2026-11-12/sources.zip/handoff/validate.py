from pathlib import Path
import os,sys,subprocess,json,hashlib,ctypes,time,shutil
root=Path('D:/Rustium');full=Path('D:/RustiumBuild/src');w=root/'.scratch/net-wave1/promote/optimization';module,mode=sys.argv[1:];work=w/module
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env=os.environ.copy()
for item in (full/'out/Default/environment.x64').read_bytes().decode().split('\0'):
 k,s,v=item.partition('=')
 if s:env[k]=v
env['PATH']=str(full/'out/Default')+os.pathsep+env.get('PATH','')
paths=[*sorted((root/'net/base').glob('parse_number_native_*')),root/'net/base/parse_number_parser.rs']
if module=='numbers':paths+=[root/'net/base/parse_number.cc',root/'net/base/parse_number_unittest.cc']
elif module=='candidate':paths += [root/'net/base/parse_number_candidate.cc',root/'net/base/parse_number_ffi.rs',root/'net/base/parse_number_parser_unittest.cc',root/'net/base/parse_number_unittest.cc',root/'net/base/parse_number_test_support.cc',root/'net/base/parse_number_test_support.h']
elif module=='hsts':paths += [*sorted((root/'net/http').glob('hsts*')),root/'net/http/http_security_headers.cc',root/'net/http/http_security_headers_unittest.cc',root/'net/base/parse_number_test_support.cc',root/'net/base/parse_number_test_support.h']
else:paths+=[*sorted((root/'net/http').glob('http_range_promote_*')),*sorted((root/'net/http').glob('http_range*.rs')),root/'net/http/http_range_ffi.h',root/'net/http/http_range_benchmark_adapter.cc',root/'net/http/http_byte_range.cc']
hashes={p.relative_to(root).as_posix():sha(p) for p in paths if p.is_file()};extra={}
if mode=='unit':
 env['LLVM_PROFILE_FILE']=str(work/'unit-%p.profraw');command=[str(work/'unit.exe'),'--gtest_output=json:'+str(work/'unit-results.json')]
elif mode=='fuzz':
 corpus=work/'corpus';corpus.mkdir(exist_ok=True);seed=root/('net/base/parse_number_fuzzer_corpus' if module=='numbers' else 'net/http/http_range_fuzzer_corpus')
 for p in seed.iterdir():shutil.copy2(p,corpus/p.name)
 command=[str(work/'fuzz.exe'),'-runs=1000000','-max_len=512','-seed=20261112','-print_final_stats=1',str(corpus)]
 extra={'seed_corpus':{p.name:sha(p) for p in seed.iterdir()},'instrumentation':'C++ libFuzzer inline counters and trace-cmp only. Rust is not sanitizer-instrumented.'}
elif mode in ('clippy','core-clippy'):
 env['CARGO_TARGET_DIR']=str(work/'clippy-target');command=['C:/Users/jackv/.cargo/bin/cargo.exe','clippy','--release','--offline']+(['--manifest-path',str(work/'core/Cargo.toml')] if mode=='core-clippy' else [])+['--','-D','warnings'];extra={'rustc':subprocess.check_output(['C:/Users/jackv/.cargo/bin/rustc.exe','--version'],text=True).strip(),'clippy':subprocess.check_output(['C:/Users/jackv/.cargo/bin/cargo.exe','clippy','--version'],text=True).strip()}
else:raise RuntimeError(mode)
record={'command':command,'source_sha256':hashes,'cpu':{'numbers':9,'range':10,'candidate':11,'hsts':12}[module],'scope':'Native focused harness using configured Chromium dependencies; canonical GN integration remains parent-owned.',**extra}
if mode not in ('clippy','core-clippy'):
 record['binary_sha256']=sha(Path(command[0]));record['link_command']=json.loads((work/(mode+'-link-command.json')).read_text());record['compile_responses']={p.name:p.read_text() for p in work.glob('*.rsp')}
(work/(mode+'-started.json')).write_text(json.dumps(record,indent=2)+'\n')
t=time.monotonic()
with (work/(mode+'.log')).open('wb') as stream:
 p=subprocess.Popen(command,cwd=work,env=env,stdout=stream,stderr=subprocess.STDOUT)
 if not ctypes.windll.kernel32.SetProcessAffinityMask(ctypes.c_void_p(int(p._handle)),ctypes.c_size_t(1<<record['cpu'])):p.kill();raise RuntimeError('affinity failed')
 code=p.wait()
record.update(exit_code=code,elapsed_seconds=time.monotonic()-t,source_unchanged=all(sha(root/p)==h for p,h in hashes.items()))
(work/(mode+'-execution.json')).write_text(json.dumps(record,indent=2)+'\n');print(module,mode,code,record['source_unchanged']);print((work/(mode+'.log')).read_text()[-1800:]);sys.exit(code)
