from pathlib import Path
import subprocess,json,hashlib
r=Path('D:/Rustium');w=r/'.scratch/net-wave1/promote/optimization';rustc=Path('D:/RustiumBuild/src/third_party/rust-toolchain/bin/rustc.exe');commands=[]
for tag,base in [('before',w/'before'),('after',r)]:
 dest=w/('codegen-'+tag);dest.mkdir(exist_ok=True)
 common=['--edition=2024','-Copt-level=3','-Cdebug-assertions=yes','-Ccontrol-flow-guard=yes','-Cpanic=abort','-Ccodegen-units=1']
 command=[str(rustc),str(base/'net/base/parse_number_parser.rs'),'--crate-name','parse_number_core','--crate-type','rlib',*common,'--out-dir',str(dest)];p=subprocess.run(command,capture_output=True,text=True);commands.append({'command':command,'exit_code':p.returncode,'stderr':p.stderr});p.check_returncode()
 command=[str(rustc),str(base/'net/base/parse_number_native_ffi.rs'),'--crate-name','numeric_ffi','--crate-type','lib',*common,'--extern','parse_number_core='+str(dest/'libparse_number_core.rlib'),'--emit=asm,llvm-ir','--out-dir',str(dest)];p=subprocess.run(command,capture_output=True,text=True);commands.append({'command':command,'exit_code':p.returncode,'stderr':p.stderr});p.check_returncode()
for tag,base in [('before',w/'before'),('after',r)]:
 dest=w/('codegen-'+tag)
 memchr=next((w/'range/chromium-target/release/deps').glob('libmemchr-*.rlib'))
 command=[str(rustc),str(base/'net/http/http_range_ffi.rs'),'--crate-name','range_ffi','--crate-type','lib',*common,'--extern','parse_number_core='+str(dest/'libparse_number_core.rlib'),'--extern','memchr='+str(memchr),'--emit=asm,llvm-ir','--out-dir',str(dest)];p=subprocess.run(command,capture_output=True,text=True);commands.append({'command':command,'exit_code':p.returncode,'stderr':p.stderr});p.check_returncode()
(w/'codegen-commands.json').write_text(json.dumps({'rustc_version':subprocess.check_output([str(rustc),'--version'],text=True).strip(),'commands':commands,'scope':'Static generated-code inspection only. Same native opt/debug/CFG/panic/codegen flags before/after; standard toolchain sysroot, not canonical GN compilation. No timing or performance metric.'},indent=2)+'\n')
print('Saved before/after assembly and LLVM IR with matching native flags.')
