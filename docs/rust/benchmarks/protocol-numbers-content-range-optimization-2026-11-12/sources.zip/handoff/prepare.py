from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path('D:/Rustium');w=r/'.scratch/net-wave1/promote/optimization';snap=w/'before';snap.mkdir(exist_ok=True)
if (w/'before-manifest.json').exists():
 raise SystemExit('Existing optimization evidence must not be overwritten. Use a new work directory.')
paths=['net/base/parse_number.cc','net/base/parse_number.h','net/base/parse_number_parser.rs','net/base/parse_number_native_ffi.rs','net/base/parse_number_ffi.rs','net/base/parse_number_candidate.cc','net/http/http_range_parser.rs','net/http/http_range_ffi.rs','net/http/http_range_ffi.h','net/http/http_range_benchmark_adapter.cc','net/http/http_util.cc']
paths += [p.relative_to(r).as_posix() for folder,pat in [('net/base','parse_number_native_*'),('net/http','http_range_promote_*')] for p in (r/folder).glob(pat)]
for p in dict.fromkeys(paths):
 dest=snap/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r/p,dest)
(w/'before-manifest.json').write_text(json.dumps({p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in dict.fromkeys(paths)},indent=2)+'\n')
for n in ('protocol-numbers','http-range'):
 p=r/'docs/rust/benchmarks'/(n+'-wave1-final-2026-11-12.json');shutil.copy2(p,snap/p.name)
for module in ('numbers','range'):
 work=w/module;(work/'core').mkdir(parents=True,exist_ok=True);(work/'.cargo').mkdir(exist_ok=True)
 for name in ['Cargo.toml','core/Cargo.toml','.cargo/config.toml','build_native.py']:
  p=r/'.scratch/net-wave1/promote'/module/name;text=p.read_text().replace(".scratch/net-wave1/promote/"+module,".scratch/net-wave1/promote/optimization/"+module)
  if name=='Cargo.toml':text=text.replace('../../../../net','../../../../../net')
  if name=='core/Cargo.toml':text=text.replace('../../../../../net','../../../../../../net')
  (work/name).write_text(text)
 # Hook clang assembly emission when requested separately; do not run perftests.
text=(r/'.scratch/net-wave1/promote/validate.py').read_text().replace("w=root/'.scratch/net-wave1/promote'","w=root/'.scratch/net-wave1/promote/optimization'")
(w/'validate.py').write_text(text)
text=(r/'.scratch/net-wave1/promote/coverage.py').read_text().replace("w=Path('D:/Rustium/.scratch/net-wave1/promote')","w=Path('D:/Rustium/.scratch/net-wave1/promote/optimization')")
(w/'coverage.py').write_text(text)
print((w/'numbers/Cargo.toml').read_text());print((w/'numbers/core/Cargo.toml').read_text())
