from pathlib import Path
import shutil
r=Path('D:/Rustium');w=r/'.scratch/net-wave1/promote/optimization';stage=w/'first-pass';stage.mkdir(exist_ok=True)
shutil.copy2(r/'net/base/parse_number_parser.rs',stage/'parse_number_parser.rs')
for m in ('numbers','range'):
 d=stage/m;d.mkdir(exist_ok=True)
 for p in (w/m).glob('*'):
  if p.is_file() and p.suffix in ('.json','.log','.profraw','.profdata'):shutil.copy2(p,d/p.name)
p=r/'net/base/parse_number_parser.rs';s=p.read_text().replace('let mut blocks = self.0.as_slice().chunks_exact(16);\n        for block in blocks.by_ref() {','let (blocks, remainder) = self.0.as_slice().as_chunks::<16>();\n        for block in blocks {').replace('blocks.remainder().iter().all(u8::is_ascii_digit)','remainder.iter().all(u8::is_ascii_digit)');p.write_text(s)
# Isolate final artifact paths, retaining first-pass failures/results separately.
for m in ('numbers','range'):
 p=w/m/'build_native.py';s=p.read_text().replace("work=root/'.scratch/net-wave1/promote/optimization/"+m+"'", "work=root/'.scratch/net-wave1/promote/optimization/"+m+"'");p.write_text(s)
 # Remove only stale runtime profiles from this task after preservation, so no
 # earlier algorithm's counters are merged into final runtime coverage.
 for p in (w/m).glob('unit-*.profraw'):p.unlink()
