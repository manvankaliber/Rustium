from pathlib import Path
p=Path('D:/Rustium/net/base/parse_number_parser.rs');s=p.read_text();at=s.index('#[inline]\nfn accumulate')
insert='''// Iterator inputs may be decoded (HSTS quoted strings), whereas public scalar
// APIs borrow contiguous bytes. Keep their overflow-classification strategies
// separate without changing the common magnitude/error rules.
trait NumberBytes: Iterator<Item = u8> + Sized {
    #[inline]
    fn remaining_digits(mut self) -> bool {
        self.all(|byte| byte.is_ascii_digit())
    }
}

struct DecodedBytes<I>(I);

impl<I: Iterator<Item = u8>> Iterator for DecodedBytes<I> {
    type Item = u8;

    #[inline]
    fn next(&mut self) -> Option<u8> {
        self.0.next()
    }
}

impl<I: Iterator<Item = u8>> NumberBytes for DecodedBytes<I> {}

struct SliceBytes<'a>(std::slice::Iter<'a, u8>);

impl Iterator for SliceBytes<'_> {
    type Item = u8;

    #[inline]
    fn next(&mut self) -> Option<u8> {
        self.0.next().copied()
    }
}

impl NumberBytes for SliceBytes<'_> {
    #[inline]
    fn remaining_digits(self) -> bool {
        // A short-circuiting per-byte scan prevents vector reduction. Reduce
        // invalid-byte flags within bounded blocks instead, then short-circuit
        // between blocks. Every byte, including NUL/non-ASCII, is still checked.
        let mut blocks = self.0.as_slice().chunks_exact(16);
        for block in blocks.by_ref() {
            let invalid = block.iter().fold(0u8, |flags, byte| {
                flags | u8::from(!byte.is_ascii_digit())
            });
            if invalid != 0 {
                return false;
            }
        }
        blocks.remainder().iter().all(u8::is_ascii_digit)
    }
}

'''
s=s[:at]+insert+s[at:];s=s.replace('mut bytes: impl Iterator<Item = u8>,','mut bytes: impl NumberBytes,')
s=s.replace('bytes.all(|byte| byte.is_ascii_digit())','bytes.remaining_digits()')
s=s.replace('parse_unsigned::<{ u32::MAX as u64 }>(bytes, strict, report_error)', 'parse_unsigned::<{ u32::MAX as u64 }>(DecodedBytes(bytes), strict, report_error)')
# Public iterator signatures must remain unchanged.
s=s.replace('pub fn parse_i64_iter(\n    bytes: impl Iterator<Item = u8>,','pub fn parse_i64_iter(\n    bytes: impl Iterator<Item = u8>,')
s=s.replace('parse::<{ i64::MAX as u64 }, { i64::MAX as u64 + 1 }>(bytes, format, report_error)', 'parse::<{ i64::MAX as u64 }, { i64::MAX as u64 + 1 }>(DecodedBytes(bytes), format, report_error)')
at=s.index('#[inline]\npub fn parse_i32')
s=s[:at]+'''// Positive slice fields need neither negative-limit accumulation nor sign
// restoration. This applies equally to strict, optional-sign and legacy unknown
// signed formats. Negative inputs retain the original format/underflow path.
#[inline]
fn parse_slice<const POSITIVE_LIMIT: u64, const NEGATIVE_LIMIT: u64>(
    input: &[u8],
    format: i32,
    report_error: bool,
) -> Result<(u64, bool), ParseError> {
    let bytes = SliceBytes(input.iter());
    if input.first() == Some(&b'-') {
        parse::<POSITIVE_LIMIT, NEGATIVE_LIMIT>(bytes, format, report_error)
    } else {
        parse_unsigned::<POSITIVE_LIMIT>(bytes, format == 2 || format == 3, report_error)
            .map(|value| (value, false))
    }
}

'''+s[at:]
s=s.replace('parse::<{ i32::MAX as u64 }, { i32::MAX as u64 + 1 }>(\n        input.iter().copied(),','parse_slice::<{ i32::MAX as u64 }, { i32::MAX as u64 + 1 }>(\n        input,')
s=s.replace('    parse_i64_iter(input.iter().copied(), format, report_error)','    parse_slice::<{ i64::MAX as u64 }, { i64::MAX as u64 + 1 }>(input, format, report_error).map(\n        |(value, negative)| if negative { (value as i64).wrapping_neg() } else { value as i64 },\n    )')
s=s.replace('    parse_u32_iter(input.iter().copied(), format == 2, report_error)','    parse_unsigned::<{ u32::MAX as u64 }>(SliceBytes(input.iter()), format == 2, report_error)\n        .map(|value| value as u32)')
s=s.replace('parse_unsigned::<{ u64::MAX }>(input.iter().copied(), format == 2, report_error)','parse_unsigned::<{ u64::MAX }>(SliceBytes(input.iter()), format == 2, report_error)')
p.write_text(s)
