from pathlib import Path
r=Path('D:/Rustium');p=r/'net/base/parse_number_parser.rs';s=p.read_text().replace("    if input.first() == Some(&b'-') {", "    if matches!(input.first(), Some(b'-' | b'0')) {")
s=s.replace('// restoration. This applies equally to strict, optional-sign and legacy unknown\n// signed formats. Negative inputs retain the original format/underflow path.', '// restoration. This applies equally to strict, optional-sign and legacy unknown\n// signed formats. Negative inputs retain the original format/underflow path;\n// zero-prefixed inputs retain the existing leading-zero skip.')
p.write_text(s)
p=r/'net/base/parse_number_native_unittest.cc';s=p.read_text();pos=s.rindex('}  // namespace\n');s=s[:pos]+'''TEST(ParseNumberNativeTest, OverflowTailBlocksPreserveMalformedPrecedence) {
  // Exercise each lane, every possible byte, the block/remainder boundaries,
  // and both overflow and underflow through the public APIs with/without errors.
  std::string digits(96, '9');
  for (size_t index = 20; index < digits.size(); ++index) {
    for (unsigned byte = 0; byte < 256; ++byte) {
      digits[index] = static_cast<char>(byte);
      Compare(digits);
      Compare("-" + digits);
    }
    digits[index] = '9';
  }
  for (size_t length : {31u, 32u, 33u, 47u, 48u, 49u, 63u, 64u, 65u, 4096u}) {
    const std::string valid(length, '9');
    Compare(valid);
    Compare("-" + valid);
    for (size_t index : {size_t{20}, length - 1}) {
      for (char byte : {'/', ':', '\\0', '\\x80', '\\xff'}) {
        std::string malformed = valid;
        malformed[index] = byte;
        Compare(malformed);
        Compare("-" + malformed);
      }
    }
  }
}

'''+s[pos:];p.write_text(s)
