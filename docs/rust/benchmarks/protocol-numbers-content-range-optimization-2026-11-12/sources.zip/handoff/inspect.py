from pathlib import Path
import subprocess,json
r=Path('D:/Rustium');w=r/'.scratch/net-wave1/promote/optimization';out=Path('D:/RustiumBuild/src/out/Default');tool=Path('C:/Users/jackv/.rustup/toolchains/stable-x86_64-pc-windows-msvc/lib/rustlib/x86_64-pc-windows-msvc/bin/llvm-objdump.exe')
for module in ('numbers','range'):
 p=w/module/'core/Cargo.toml';p.write_text(p.read_text().replace('../../../../../../../net','../../../../../../net'))
for name in ('parse_number_native_parser','http_range_parser'):
 lib=next((out/'obj/net').glob('lib'+name+'_*.rlib'));cmd=[str(tool),'-d','--demangle',str(lib)];p=subprocess.run(cmd,capture_output=True,text=True);(w/('before-'+name+'.asm')).write_text(p.stdout);p.check_returncode()
print('Configured assembly archived.')
