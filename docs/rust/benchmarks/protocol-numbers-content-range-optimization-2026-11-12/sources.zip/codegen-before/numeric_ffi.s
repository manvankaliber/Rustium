	.def	@feat.00;
	.scl	3;
	.type	0;
	.endef
	.globl	@feat.00
@feat.00 = 2048
	.att_syntax
	.file	"numeric_ffi.db33e3d5a3958eec-cgu.0"
	.def	rustium_parse_number_native_i32;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,rustium_parse_number_native_i32,unique,0
	.globl	rustium_parse_number_native_i32
	.p2align	4
rustium_parse_number_native_i32:
.seh_proc rustium_parse_number_native_i32
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	80(%rsp), %r10
	testq	%rdx, %rdx
	je	.LBB0_8
	testq	%rcx, %rcx
	setne	%al
	testq	%rdx, %rdx
	setns	%r11b
	testb	%r11b, %al
	je	.LBB0_47
	movzbl	(%rcx), %esi
	leal	-48(%rsi), %eax
	cmpb	$10, %al
	jae	.LBB0_9
	leaq	1(%rcx), %rax
	movl	%esi, %r11d
.LBB0_4:
	addq	%rdx, %rcx
	andl	$-2, %r8d
	cmpl	$2, %r8d
	sete	%dl
	cmpb	$48, %r11b
	sete	%r8b
	testb	%r8b, %dl
	je	.LBB0_13
	cmpb	$45, %sil
	sete	%r8b
	cmpq	%rcx, %rax
	setne	%al
	xorl	%edx, %edx
	orb	%r8b, %al
	movl	$2, %r11d
	jne	.LBB0_18
.LBB0_6:
	movl	%edx, (%r9)
	movb	$1, %al
.LBB0_7:
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
.LBB0_8:
	movl	$2, %r11d
	jmp	.LBB0_18
.LBB0_9:
	movl	$2, %r11d
	cmpb	$45, %sil
	jne	.LBB0_18
	testl	$-3, %r8d
	je	.LBB0_18
	cmpq	$1, %rdx
	je	.LBB0_18
	leaq	2(%rcx), %rax
	movzbl	1(%rcx), %r11d
	jmp	.LBB0_4
.LBB0_13:
	cmpb	$48, %r11b
	jne	.LBB0_17
	xorl	%edx, %edx
	.p2align	4
.LBB0_15:
	cmpq	%rcx, %rax
	je	.LBB0_6
	movzbl	(%rax), %r11d
	incq	%rax
	cmpb	$48, %r11b
	je	.LBB0_15
.LBB0_17:
	addb	$-48, %r11b
	movl	%r11d, %r8d
	movl	$2, %r11d
	cmpb	$9, %r8b
	jbe	.LBB0_21
.LBB0_18:
	testq	%r10, %r10
	je	.LBB0_20
	movl	%r11d, (%r10)
.LBB0_20:
	xorl	%eax, %eax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
.LBB0_21:
	movzbl	%r8b, %edx
	cmpb	$45, %sil
	jne	.LBB0_34
	cmpq	%rcx, %rax
	jne	.LBB0_25
.LBB0_23:
	negq	%rdx
	jmp	.LBB0_6
.LBB0_24:
	movzbl	%r8b, %eax
	leaq	(%rdx,%rdx,4), %rdx
	leaq	(%rax,%rdx,2), %rdx
	movq	%rsi, %rax
	cmpq	%rcx, %rsi
	je	.LBB0_23
.LBB0_25:
	movzbl	(%rax), %r8d
	addb	$-48, %r8b
	cmpb	$9, %r8b
	ja	.LBB0_18
	leaq	1(%rax), %rsi
	cmpq	$214748364, %rdx
	ja	.LBB0_29
	jne	.LBB0_24
	cmpb	$9, %r8b
	jne	.LBB0_24
.LBB0_29:
	testq	%r10, %r10
	je	.LBB0_20
	incq	%rax
	cmpq	%rcx, %rax
	je	.LBB0_45
.LBB0_31:
	movzbl	(%rax), %edx
	addb	$-58, %dl
	cmpb	$-10, %dl
	jb	.LBB0_18
	incq	%rax
	cmpq	%rcx, %rax
	jne	.LBB0_31
.LBB0_45:
	movl	$1, %r11d
	jmp	.LBB0_18
.LBB0_34:
	cmpq	%rcx, %rax
	jne	.LBB0_36
	jmp	.LBB0_6
.LBB0_35:
	movzbl	%r8b, %eax
	leaq	(%rdx,%rdx,4), %rdx
	leaq	(%rax,%rdx,2), %rdx
	movq	%rsi, %rax
	cmpq	%rcx, %rsi
	je	.LBB0_6
.LBB0_36:
	movzbl	(%rax), %r8d
	addb	$-48, %r8b
	cmpb	$9, %r8b
	ja	.LBB0_18
	leaq	1(%rax), %rsi
	cmpq	$214748364, %rdx
	ja	.LBB0_40
	jne	.LBB0_35
	cmpb	$7, %r8b
	jbe	.LBB0_35
.LBB0_40:
	movq	%rax, %rdx
	xorl	%eax, %eax
	testq	%r10, %r10
	je	.LBB0_7
	movq	%rdx, %rax
	incq	%rax
	cmpq	%rcx, %rax
	je	.LBB0_46
.LBB0_42:
	movzbl	(%rax), %edx
	addb	$-58, %dl
	cmpb	$-10, %dl
	jb	.LBB0_18
	incq	%rax
	cmpq	%rcx, %rax
	jne	.LBB0_42
.LBB0_46:
	xorl	%r11d, %r11d
	jmp	.LBB0_18
.LBB0_47:
	leaq	alloc_a28e8c8fd5088943a8b5d44af697ff83(%rip), %rcx
	leaq	alloc_f31ace42d833e4aa0828d2e955a5507b(%rip), %r9
	movl	$559, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
	.seh_endproc

	.def	rustium_parse_number_native_i64;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,rustium_parse_number_native_i64,unique,1
	.globl	rustium_parse_number_native_i64
	.p2align	4
rustium_parse_number_native_i64:
.seh_proc rustium_parse_number_native_i64
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	96(%rsp), %r10
	testq	%rdx, %rdx
	je	.LBB1_9
	testq	%rcx, %rcx
	setne	%al
	testq	%rdx, %rdx
	setns	%r11b
	testb	%r11b, %al
	je	.LBB1_50
	movzbl	(%rcx), %esi
	leal	-48(%rsi), %eax
	cmpb	$10, %al
	jae	.LBB1_10
	leaq	1(%rcx), %rax
	movl	%esi, %r11d
.LBB1_4:
	addq	%rdx, %rcx
	andl	$-2, %r8d
	cmpl	$2, %r8d
	sete	%dl
	cmpb	$48, %r11b
	sete	%r8b
	testb	%r8b, %dl
	je	.LBB1_14
	cmpb	$45, %sil
	sete	%dl
	cmpq	%rcx, %rax
	setne	%al
	orb	%dl, %al
	movl	$2, %r11d
	jne	.LBB1_19
	xorl	%edx, %edx
.LBB1_7:
	movq	%rdx, (%r9)
	movb	$1, %al
.LBB1_8:
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rsi
	.seh_endepilogue
	retq
.LBB1_9:
	movl	$2, %r11d
	jmp	.LBB1_19
.LBB1_10:
	movl	$2, %r11d
	cmpb	$45, %sil
	jne	.LBB1_19
	testl	$-3, %r8d
	je	.LBB1_19
	cmpq	$1, %rdx
	je	.LBB1_19
	leaq	2(%rcx), %rax
	movzbl	1(%rcx), %r11d
	jmp	.LBB1_4
.LBB1_14:
	cmpb	$48, %r11b
	jne	.LBB1_18
	xorl	%edx, %edx
	.p2align	4
.LBB1_16:
	cmpq	%rcx, %rax
	je	.LBB1_7
	movzbl	(%rax), %r11d
	incq	%rax
	cmpb	$48, %r11b
	je	.LBB1_16
.LBB1_18:
	addb	$-48, %r11b
	movl	%r11d, %r8d
	movl	$2, %r11d
	cmpb	$9, %r8b
	jbe	.LBB1_22
.LBB1_19:
	testq	%r10, %r10
	je	.LBB1_21
	movl	%r11d, (%r10)
.LBB1_21:
	xorl	%eax, %eax
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rsi
	.seh_endepilogue
	retq
.LBB1_22:
	movzbl	%r8b, %edx
	cmpb	$45, %sil
	jne	.LBB1_35
	cmpq	%rcx, %rax
	je	.LBB1_47
	movabsq	$922337203685477580, %r8
	jmp	.LBB1_26
.LBB1_25:
	movzbl	%bl, %eax
	leaq	(%rdx,%rdx,4), %rdx
	leaq	(%rax,%rdx,2), %rdx
	movq	%rsi, %rax
	cmpq	%rcx, %rsi
	je	.LBB1_47
.LBB1_26:
	movzbl	(%rax), %ebx
	addb	$-48, %bl
	cmpb	$9, %bl
	ja	.LBB1_19
	leaq	1(%rax), %rsi
	cmpq	%r8, %rdx
	ja	.LBB1_30
	jne	.LBB1_25
	cmpb	$9, %bl
	jne	.LBB1_25
.LBB1_30:
	testq	%r10, %r10
	je	.LBB1_21
	incq	%rax
	cmpq	%rcx, %rax
	je	.LBB1_48
.LBB1_32:
	movzbl	(%rax), %edx
	addb	$-58, %dl
	cmpb	$-10, %dl
	jb	.LBB1_19
	incq	%rax
	cmpq	%rcx, %rax
	jne	.LBB1_32
.LBB1_48:
	movl	$1, %r11d
	jmp	.LBB1_19
.LBB1_35:
	cmpq	%rcx, %rax
	je	.LBB1_7
	movabsq	$922337203685477580, %r8
	jmp	.LBB1_38
.LBB1_37:
	movzbl	%bl, %eax
	leaq	(%rdx,%rdx,4), %rdx
	leaq	(%rax,%rdx,2), %rdx
	movq	%rsi, %rax
	cmpq	%rcx, %rsi
	je	.LBB1_7
.LBB1_38:
	movzbl	(%rax), %ebx
	addb	$-48, %bl
	cmpb	$9, %bl
	ja	.LBB1_19
	leaq	1(%rax), %rsi
	cmpq	%r8, %rdx
	ja	.LBB1_42
	jne	.LBB1_37
	cmpb	$7, %bl
	jbe	.LBB1_37
.LBB1_42:
	movq	%rax, %rdx
	xorl	%eax, %eax
	testq	%r10, %r10
	je	.LBB1_8
	movq	%rdx, %rax
	incq	%rax
	cmpq	%rcx, %rax
	je	.LBB1_49
.LBB1_44:
	movzbl	(%rax), %edx
	addb	$-58, %dl
	cmpb	$-10, %dl
	jb	.LBB1_19
	incq	%rax
	cmpq	%rcx, %rax
	jne	.LBB1_44
.LBB1_49:
	xorl	%r11d, %r11d
	jmp	.LBB1_19
.LBB1_47:
	negq	%rdx
	jmp	.LBB1_7
.LBB1_50:
	leaq	alloc_a28e8c8fd5088943a8b5d44af697ff83(%rip), %rcx
	leaq	alloc_f31ace42d833e4aa0828d2e955a5507b(%rip), %r9
	movl	$559, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
	.seh_endproc

	.def	rustium_parse_number_native_u32;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,rustium_parse_number_native_u32,unique,2
	.globl	rustium_parse_number_native_u32
	.p2align	4
rustium_parse_number_native_u32:
.seh_proc rustium_parse_number_native_u32
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	96(%rsp), %r10
	testq	%rdx, %rdx
	je	.LBB2_5
	testq	%rcx, %rcx
	setne	%al
	testq	%rdx, %rdx
	setns	%r11b
	testb	%r11b, %al
	je	.LBB2_24
	movzbl	(%rcx), %eax
	addb	$-48, %al
	movl	$2, %r11d
	cmpb	$9, %al
	ja	.LBB2_6
	cmpl	$2, %r8d
	sete	%r8b
	testb	%al, %al
	sete	%bl
	testb	%bl, %r8b
	je	.LBB2_10
	xorl	%eax, %eax
	cmpq	$1, %rdx
	jne	.LBB2_6
	jmp	.LBB2_11
.LBB2_5:
	movl	$2, %r11d
.LBB2_6:
	testq	%r10, %r10
	je	.LBB2_8
	movl	%r11d, (%r10)
.LBB2_8:
	xorl	%eax, %eax
.LBB2_9:
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB2_10:
	movzbl	%al, %eax
	cmpq	$1, %rdx
	jne	.LBB2_12
.LBB2_11:
	movl	%eax, (%r9)
	movb	$1, %al
	jmp	.LBB2_9
.LBB2_12:
	movq	%rdx, %rsi
	negq	%rsi
	movl	$2, %r8d
	jmp	.LBB2_14
	.p2align	4
.LBB2_13:
	movzbl	%bl, %edi
	leaq	(%rax,%rax,4), %rax
	leaq	(%rdi,%rax,2), %rax
	leaq	(%rsi,%r8), %rdi
	incq	%rdi
	incq	%r8
	cmpq	$1, %rdi
	je	.LBB2_11
.LBB2_14:
	movzbl	-1(%rcx,%r8), %ebx
	addb	$-48, %bl
	cmpb	$9, %bl
	ja	.LBB2_6
	cmpq	$429496729, %rax
	ja	.LBB2_18
	jne	.LBB2_13
	cmpb	$5, %bl
	jbe	.LBB2_13
.LBB2_18:
	xorl	%eax, %eax
	testq	%r10, %r10
	je	.LBB2_9
	movq	%r8, %rax
	subq	%rdx, %rax
	je	.LBB2_23
	.p2align	4
.LBB2_20:
	movzbl	(%rcx,%r8), %eax
	addb	$-58, %al
	cmpb	$-10, %al
	jb	.LBB2_6
	incq	%r8
	cmpq	%r8, %rdx
	jne	.LBB2_20
.LBB2_23:
	xorl	%r11d, %r11d
	jmp	.LBB2_6
.LBB2_24:
	leaq	alloc_a28e8c8fd5088943a8b5d44af697ff83(%rip), %rcx
	leaq	alloc_f31ace42d833e4aa0828d2e955a5507b(%rip), %r9
	movl	$559, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
	.seh_endproc

	.def	rustium_parse_number_native_u64;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,rustium_parse_number_native_u64,unique,3
	.globl	rustium_parse_number_native_u64
	.p2align	4
rustium_parse_number_native_u64:
.seh_proc rustium_parse_number_native_u64
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	96(%rsp), %r10
	testq	%rdx, %rdx
	je	.LBB3_9
	testq	%rcx, %rcx
	setne	%al
	testq	%rdx, %rdx
	setns	%r11b
	testb	%r11b, %al
	je	.LBB3_27
	movzbl	(%rcx), %eax
	addb	$-48, %al
	cmpb	$9, %al
	jbe	.LBB3_6
.LBB3_3:
	xorl	%r8d, %r8d
.LBB3_4:
	xorl	%eax, %eax
	testq	%r10, %r10
	je	.LBB3_13
	testb	%r8b, %r8b
	je	.LBB3_10
	jmp	.LBB3_11
.LBB3_6:
	cmpl	$2, %r8d
	sete	%r8b
	testb	%al, %al
	sete	%r11b
	testb	%r11b, %r8b
	je	.LBB3_14
	cmpq	$1, %rdx
	jne	.LBB3_9
	xorl	%r8d, %r8d
	jmp	.LBB3_25
.LBB3_9:
	testq	%r10, %r10
	je	.LBB3_12
.LBB3_10:
	movl	$2, %eax
.LBB3_11:
	movl	%eax, (%r10)
.LBB3_12:
	xorl	%eax, %eax
.LBB3_13:
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB3_14:
	movzbl	%al, %r8d
	movq	%rdx, %r11
	decq	%r11
	je	.LBB3_25
	xorl	%eax, %eax
	movabsq	$1844674407370955161, %rsi
	jmp	.LBB3_17
	.p2align	4
.LBB3_16:
	movzbl	%bl, %edi
	leaq	(%r8,%r8,4), %r8
	leaq	(%rdi,%r8,2), %r8
	incq	%rax
	cmpq	%rax, %r11
	je	.LBB3_25
.LBB3_17:
	movzbl	1(%rcx,%rax), %ebx
	addb	$-48, %bl
	cmpb	$9, %bl
	ja	.LBB3_3
	cmpq	%rsi, %r8
	ja	.LBB3_21
	jne	.LBB3_16
	cmpb	$5, %bl
	jbe	.LBB3_16
.LBB3_21:
	testq	%r10, %r10
	je	.LBB3_12
	leaq	-2(%rdx), %r9
	movb	$1, %r8b
	cmpq	%rax, %r9
	je	.LBB3_4
	addq	$-3, %rdx
	.p2align	4
.LBB3_24:
	movzbl	2(%rcx,%rax), %r8d
	addb	$-48, %r8b
	cmpb	$10, %r8b
	setb	%r8b
	setae	%r9b
	cmpq	%rax, %rdx
	sete	%r11b
	orb	%r9b, %r11b
	incq	%rax
	testb	%r11b, %r11b
	je	.LBB3_24
	jmp	.LBB3_4
.LBB3_25:
	movq	%r8, (%r9)
	movb	$1, %al
	jmp	.LBB3_13
.LBB3_27:
	leaq	alloc_a28e8c8fd5088943a8b5d44af697ff83(%rip), %rcx
	leaq	alloc_f31ace42d833e4aa0828d2e955a5507b(%rip), %r9
	movl	$559, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
	.seh_endproc

	.section	.rdata,"dr",one_only,alloc_a58958037699a75cd119e9baa74d93b4,unique,4
alloc_a58958037699a75cd119e9baa74d93b4:
	.asciz	"D:\\Rustium\\.scratch\\net-wave1\\promote\\optimization\\before\\net\\base\\parse_number_native_ffi.rs"

	.section	.rdata,"dr",one_only,alloc_f31ace42d833e4aa0828d2e955a5507b,unique,5
	.p2align	3, 0x0
alloc_f31ace42d833e4aa0828d2e955a5507b:
	.quad	alloc_a58958037699a75cd119e9baa74d93b4
	.asciz	"]\000\000\000\000\000\000\000#\000\000\000\026\000\000"

	.section	.rdata,"dr",one_only,alloc_a28e8c8fd5088943a8b5d44af697ff83,unique,6
alloc_a28e8c8fd5088943a8b5d44af697ff83:
	.ascii	"unsafe precondition(s) violated: slice::from_raw_parts requires the pointer to be aligned and non-null, and the total size of the slice not to exceed `isize::MAX`\n\nThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety."

	.section	.gfids$y,"dr"
	.symidx	__CxxFrameHandler3
	.section	.giats$y,"dr"
	.section	.gljmp$y,"dr"
