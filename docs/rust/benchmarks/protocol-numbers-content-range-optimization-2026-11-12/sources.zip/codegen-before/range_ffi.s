	.def	@feat.00;
	.scl	3;
	.type	0;
	.endef
	.globl	@feat.00
@feat.00 = 2048
	.att_syntax
	.file	"range_ffi.c63e0d924bc54e24-cgu.0"
	.def	_RNvCsh1eR4S1pMdQ_9range_ffi5bytes;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvCsh1eR4S1pMdQ_9range_ffi5bytes,unique,0
	.globl	_RNvCsh1eR4S1pMdQ_9range_ffi5bytes
	.p2align	4
_RNvCsh1eR4S1pMdQ_9range_ffi5bytes:
.seh_proc _RNvCsh1eR4S1pMdQ_9range_ffi5bytes
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%rdx, %rdx
	je	.LBB0_3
	testq	%rcx, %rcx
	setne	%al
	testq	%rdx, %rdx
	setns	%r8b
	testb	%r8b, %al
	je	.LBB0_4
	movq	%rcx, %rax
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB0_3:
	movl	$1, %ecx
	movq	%rcx, %rax
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB0_4:
	leaq	alloc_a28e8c8fd5088943a8b5d44af697ff83(%rip), %rcx
	leaq	alloc_ff650c45cc045765b5fb342d7b104cb9(%rip), %r9
	movl	$559, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
	.seh_endproc

	.def	_RNvMs7_NtCs8tsiLsQ9XHg_5alloc7raw_vecINtB5_6RawVecNtCsh1eR4S1pMdQ_9range_ffi11ParsedRangeE8grow_oneBO_;
	.scl	2;
	.type	32;
	.endef
	.section	.text$unlikely,"xr",one_only,_RNvMs7_NtCs8tsiLsQ9XHg_5alloc7raw_vecINtB5_6RawVecNtCsh1eR4S1pMdQ_9range_ffi11ParsedRangeE8grow_oneBO_,unique,1
	.globl	_RNvMs7_NtCs8tsiLsQ9XHg_5alloc7raw_vecINtB5_6RawVecNtCsh1eR4S1pMdQ_9range_ffi11ParsedRangeE8grow_oneBO_
	.p2align	4
_RNvMs7_NtCs8tsiLsQ9XHg_5alloc7raw_vecINtB5_6RawVecNtCsh1eR4S1pMdQ_9range_ffi11ParsedRangeE8grow_oneBO_:
.seh_proc _RNvMs7_NtCs8tsiLsQ9XHg_5alloc7raw_vecINtB5_6RawVecNtCsh1eR4S1pMdQ_9range_ffi11ParsedRangeE8grow_oneBO_
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	(%rcx), %rdx
	callq	_RNvMs8_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14grow_amortizedCsh1eR4S1pMdQ_9range_ffi
	cmpq	$-1, %rax
	jne	.LBB1_1
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB1_1:
	movq	%rax, %rcx
	callq	_RNvNtCs8tsiLsQ9XHg_5alloc7raw_vec12handle_error
	ud2
	.seh_endproc

	.def	_RNvMs8_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsh1eR4S1pMdQ_9range_ffi;
	.scl	3;
	.type	32;
	.endef
	.section	.text$unlikely,"xr",one_only,_RNvMs8_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsh1eR4S1pMdQ_9range_ffi,unique,2
	.p2align	4
_RNvMs8_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsh1eR4S1pMdQ_9range_ffi:
.seh_proc _RNvMs8_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsh1eR4S1pMdQ_9range_ffi
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$56, %rsp
	.seh_stackalloc 56
	.seh_endprologue
	movq	%rcx, %rsi
	movabsq	$384307168202282325, %rax
	cmpq	%rax, %r9
	jbe	.LBB2_1
	movq	$0, 8(%rsi)
	movl	$1, %eax
	jmp	.LBB2_21
.LBB2_1:
	testq	%rdx, %rdx
	je	.LBB2_2
	movabsq	$768614336404564651, %rcx
	cmpq	%rcx, %rdx
	jae	.LBB2_4
	incq	%rax
	cmpq	%rax, %rdx
	jae	.LBB2_6
	shlq	$3, %rdx
	leaq	(%rdx,%rdx,2), %rax
	movq	$8, 40(%rsp)
	leaq	48(%rsp), %rcx
	jmp	.LBB2_8
.LBB2_2:
	leaq	40(%rsp), %rcx
	xorl	%eax, %eax
.LBB2_8:
	shlq	$3, %r9
	leaq	(%r9,%r9,2), %rdi
	movq	%rax, (%rcx)
	movq	40(%rsp), %rax
	testq	%rax, %rax
	je	.LBB2_17
	cmpq	$8, %rax
	jne	.LBB2_10
	movq	48(%rsp), %rdx
	testq	%rdx, %rdx
	je	.LBB2_17
	cmpq	%rdx, %rdi
	jb	.LBB2_15
	movq	%r8, %rcx
	movl	$8, %r8d
	movq	%rdi, %r9
	callq	_RNvCs6d6XRwTwhVh_7___rustc14___rust_realloc
	testq	%rax, %rax
	jne	.LBB2_20
.LBB2_19:
	movq	$8, 8(%rsi)
	movq	%rdi, 16(%rsi)
	movl	$1, %eax
	jmp	.LBB2_21
.LBB2_17:
	callq	_RNvCs6d6XRwTwhVh_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$8, %edx
	movq	%rdi, %rcx
	callq	_RNvCs6d6XRwTwhVh_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB2_19
.LBB2_20:
	movq	%rax, 8(%rsi)
	movq	%rdi, 16(%rsi)
	xorl	%eax, %eax
.LBB2_21:
	movq	%rax, (%rsi)
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB2_4:
	leaq	alloc_db07ae5a9ce650d9b7cc970d048e6f0c(%rip), %rcx
	leaq	alloc_ad088eaa3dc0ae68b11fd72bfcf5e34b(%rip), %r9
	movl	$373, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
.LBB2_6:
	leaq	alloc_1be5ea12ba708d9a11b6e93a7d387a75(%rip), %rcx
	leaq	alloc_dade1aed0d0fe800cb3ecdb07302e098(%rip), %r9
	movl	$563, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
.LBB2_10:
	leaq	alloc_64e308ef4babfeb8b6220184de794a17(%rip), %rcx
	leaq	alloc_5a885d3db7500f26d581e948d37c49fe(%rip), %r9
	movl	$443, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
.LBB2_15:
	leaq	alloc_64e308ef4babfeb8b6220184de794a17(%rip), %rcx
	leaq	alloc_1b98de0e82d923a9daff35d520cf360d(%rip), %r9
	movl	$443, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
	.seh_endproc

	.def	_RNvMs8_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14grow_amortizedCsh1eR4S1pMdQ_9range_ffi;
	.scl	3;
	.type	32;
	.endef
	.section	.text$unlikely,"xr",one_only,_RNvMs8_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14grow_amortizedCsh1eR4S1pMdQ_9range_ffi,unique,3
	.p2align	4
_RNvMs8_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14grow_amortizedCsh1eR4S1pMdQ_9range_ffi:
.seh_proc _RNvMs8_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14grow_amortizedCsh1eR4S1pMdQ_9range_ffi
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$56, %rsp
	.seh_stackalloc 56
	.seh_endprologue
	movq	%rcx, %rsi
	incq	%rdx
	movq	(%rcx), %rax
	leaq	(%rax,%rax), %rcx
	cmpq	%rdx, %rcx
	cmovaq	%rcx, %rdx
	cmpq	$5, %rdx
	movl	$4, %edi
	cmovaeq	%rdx, %rdi
	movq	8(%rsi), %r8
	leaq	32(%rsp), %rcx
	movq	%rax, %rdx
	movq	%rdi, %r9
	callq	_RNvMs8_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsh1eR4S1pMdQ_9range_ffi
	cmpb	$0, 32(%rsp)
	je	.LBB3_2
	movq	40(%rsp), %rax
	movq	48(%rsp), %rdx
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB3_2:
	movq	40(%rsp), %rax
	movq	%rax, 8(%rsi)
	movq	%rdi, (%rsi)
	movq	$-1, %rax
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc

	.def	_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser10legacy_i64;
	.scl	3;
	.type	32;
	.endef
	.globl	__xmm@30303030303030303030303030303030
	.section	.rdata,"dr",discard,__xmm@30303030303030303030303030303030
	.p2align	4, 0x0
__xmm@30303030303030303030303030303030:
	.zero	16,48
	.section	.text,"xr",one_only,_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser10legacy_i64,unique,4
	.p2align	4
_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser10legacy_i64:
	testq	%rdx, %rdx
	je	.LBB4_57
	cmpb	$43, (%rcx)
	jne	.LBB4_10
	movq	%rdx, %r8
	decq	%r8
	je	.LBB4_57
	leaq	1(%rcx), %r9
	movzbl	(%r9), %eax
	addb	$-48, %al
	cmpb	$9, %al
	ja	.LBB4_57
	cmpq	$18, %rdx
	jb	.LBB4_42
	xorl	%eax, %eax
	movdqa	__xmm@30303030303030303030303030303030(%rip), %xmm0
	.p2align	4
.LBB4_6:
	movdqu	1(%rcx,%rax), %xmm1
	pcmpeqb	%xmm0, %xmm1
	pmovmskb	%xmm1, %r9d
	cmpl	$65535, %r9d
	jne	.LBB4_41
	addq	$-16, %r8
	addq	$16, %rax
	cmpq	$16, %r8
	ja	.LBB4_6
	leaq	-1(%rdx), %r8
	cmpq	%rax, %r8
	je	.LBB4_57
	subq	%rax, %rdx
	addq	%rcx, %rdx
	addq	%rax, %rdx
	leaq	(%rcx,%rax), %r9
	incq	%r9
	movq	%rdx, %r8
	jmp	.LBB4_43
.LBB4_10:
	cmpq	$17, %rdx
	jb	.LBB4_15
	leaq	-17(%rdx), %rax
	andq	$-16, %rax
	movdqa	__xmm@30303030303030303030303030303030(%rip), %xmm0
	movq	%rcx, %r8
	.p2align	4
.LBB4_12:
	movdqu	(%r8), %xmm1
	pcmpeqb	%xmm0, %xmm1
	pmovmskb	%xmm1, %r9d
	cmpl	$65535, %r9d
	jne	.LBB4_17
	addq	$-16, %rdx
	addq	$16, %r8
	cmpq	$16, %rdx
	ja	.LBB4_12
	addq	%rcx, %rax
	leaq	(%rdx,%rax), %rcx
	addq	$16, %rcx
	movzbl	(%r8), %r9d
	leal	-48(%r9), %eax
	cmpb	$10, %al
	jb	.LBB4_16
	jmp	.LBB4_18
.LBB4_15:
	movq	%rcx, %r8
	addq	%rdx, %rcx
	movzbl	(%r8), %r9d
	leal	-48(%r9), %eax
	cmpb	$10, %al
	jae	.LBB4_18
.LBB4_16:
	incq	%r8
	movl	%r9d, %r10d
	cmpb	$48, %r10b
	je	.LBB4_20
	jmp	.LBB4_23
.LBB4_17:
	leaq	(%r8,%rdx), %rcx
	movzbl	(%r8), %r9d
	leal	-48(%r9), %eax
	cmpb	$10, %al
	jb	.LBB4_16
.LBB4_18:
	cmpb	$45, %r9b
	sete	%al
	cmpq	$1, %rdx
	setne	%dl
	andb	%al, %dl
	cmpb	$1, %dl
	jne	.LBB4_57
	movzbl	1(%r8), %r10d
	addq	$2, %r8
	cmpb	$48, %r10b
	jne	.LBB4_23
.LBB4_20:
	movl	$1, %eax
	xorl	%edx, %edx
	.p2align	4
.LBB4_21:
	cmpq	%rcx, %r8
	je	.LBB4_71
	movzbl	(%r8), %r10d
	incq	%r8
	cmpb	$48, %r10b
	je	.LBB4_21
.LBB4_23:
	addb	$-48, %r10b
	cmpb	$9, %r10b
	ja	.LBB4_57
	movzbl	%r10b, %edx
	cmpb	$45, %r9b
	jne	.LBB4_33
	cmpq	%rcx, %r8
	je	.LBB4_69
	xorl	%eax, %eax
	movabsq	$922337203685477580, %r9
	jmp	.LBB4_28
	.p2align	4
.LBB4_27:
	movzbl	%r10b, %r10d
	leaq	(%rdx,%rdx,4), %rdx
	leaq	(%r10,%rdx,2), %rdx
	cmpq	%rcx, %r8
	je	.LBB4_69
.LBB4_28:
	movzbl	(%r8), %r10d
	addb	$-48, %r10b
	cmpb	$9, %r10b
	ja	.LBB4_59
	incq	%r8
	cmpq	%r9, %rdx
	ja	.LBB4_71
	jne	.LBB4_27
	cmpb	$9, %r10b
	jne	.LBB4_27
	retq
.LBB4_33:
	cmpq	%rcx, %r8
	je	.LBB4_70
	xorl	%eax, %eax
	movabsq	$922337203685477580, %r9
	jmp	.LBB4_36
	.p2align	4
.LBB4_35:
	movzbl	%r10b, %r10d
	leaq	(%rdx,%rdx,4), %rdx
	leaq	(%r10,%rdx,2), %rdx
	cmpq	%rcx, %r8
	je	.LBB4_70
.LBB4_36:
	movzbl	(%r8), %r10d
	addb	$-48, %r10b
	cmpb	$9, %r10b
	ja	.LBB4_59
	incq	%r8
	cmpq	%r9, %rdx
	ja	.LBB4_71
	jne	.LBB4_35
	cmpb	$7, %r10b
	jbe	.LBB4_35
	retq
.LBB4_41:
	leaq	(%rcx,%rax), %r9
	incq	%r9
.LBB4_42:
	addq	%r9, %r8
.LBB4_43:
	movzbl	(%r9), %ecx
	leal	-48(%rcx), %eax
	cmpb	$9, %al
	ja	.LBB4_57
	incq	%r9
	cmpb	$48, %cl
	jne	.LBB4_48
	movl	$1, %eax
	xorl	%edx, %edx
	cmpq	%r8, %r9
	je	.LBB4_71
	.p2align	4
.LBB4_46:
	movzbl	(%r9), %r10d
	addb	$-48, %r10b
	jne	.LBB4_56
	incq	%r9
	cmpq	%r8, %r9
	jne	.LBB4_46
	jmp	.LBB4_71
.LBB4_48:
	movzbl	%al, %edx
	cmpq	%r8, %r9
	je	.LBB4_70
.LBB4_49:
	movabsq	$922337203685477580, %rcx
	jmp	.LBB4_51
.LBB4_50:
	movzbl	%r10b, %eax
	leaq	(%rdx,%rdx,4), %rdx
	leaq	(%rax,%rdx,2), %rdx
	movl	$1, %eax
	cmpq	%r8, %r9
	je	.LBB4_71
.LBB4_51:
	movzbl	(%r9), %r10d
	addb	$-48, %r10b
	cmpb	$9, %r10b
	ja	.LBB4_55
	incq	%r9
	movl	$0, %eax
	cmpq	%rcx, %rdx
	ja	.LBB4_71
	jne	.LBB4_50
	cmpb	$7, %r10b
	jbe	.LBB4_50
.LBB4_55:
	xorl	%eax, %eax
	retq
.LBB4_56:
	cmpb	$9, %r10b
	jbe	.LBB4_60
.LBB4_57:
	xorl	%eax, %eax
	retq
.LBB4_60:
	movzbl	%r10b, %edx
	incq	%r9
	cmpb	$45, %cl
	jne	.LBB4_72
	cmpq	%r8, %r9
	je	.LBB4_69
	xorl	%eax, %eax
	movabsq	$922337203685477580, %rcx
	jmp	.LBB4_64
.LBB4_63:
	movzbl	%r10b, %r10d
	leaq	(%rdx,%rdx,4), %rdx
	leaq	(%r10,%rdx,2), %rdx
	cmpq	%r8, %r9
	je	.LBB4_69
.LBB4_64:
	movzbl	(%r9), %r10d
	addb	$-48, %r10b
	cmpb	$9, %r10b
	ja	.LBB4_59
	incq	%r9
	cmpq	%rcx, %rdx
	ja	.LBB4_71
	jne	.LBB4_63
	cmpb	$9, %r10b
	jne	.LBB4_63
.LBB4_59:
	retq
.LBB4_69:
	negq	%rdx
.LBB4_70:
	movl	$1, %eax
.LBB4_71:
	retq
.LBB4_72:
	movl	$1, %eax
	cmpq	%r8, %r9
	jne	.LBB4_49
	jmp	.LBB4_71

	.def	_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13fetch_decimal;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13fetch_decimal,unique,5
	.p2align	4
_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13fetch_decimal:
.seh_proc _RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13fetch_decimal
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	%rcx, %r10
	movq	(%r8), %rcx
	cmpq	%rdx, %rcx
	jae	.LBB5_12
	movq	%rcx, %rax
	.p2align	4
.LBB5_2:
	movzbl	(%r10,%rax), %r9d
	addb	$-48, %r9b
	cmpb	$10, %r9b
	jae	.LBB5_11
	incq	%rax
	movq	%rax, (%r8)
	cmpq	%rax, %rdx
	jne	.LBB5_2
	movq	%rdx, %r11
	cmpq	%r11, %rcx
	je	.LBB5_12
.LBB5_5:
	setbe	%al
	cmpq	%rdx, %r11
	setbe	%r8b
	testb	%r8b, %al
	je	.LBB5_38
	movabsq	$9223372036854775807, %rdx
	movzbl	(%r10,%rcx), %r9d
	leal	-48(%r9), %r8d
	movl	$1, %eax
	cmpb	$9, %r8b
	ja	.LBB5_10
	cmpb	$48, %r9b
	jne	.LBB5_13
	leaq	1(%rcx), %r8
	cmpq	%r11, %r8
	je	.LBB5_9
	addq	$2, %rcx
	movq	%r11, %r8
	negq	%r8
	.p2align	4
.LBB5_16:
	movzbl	-1(%r10,%rcx), %ebx
	addb	$-48, %bl
	jne	.LBB5_26
	leaq	(%r8,%rcx), %rsi
	incq	%rsi
	incq	%rcx
	cmpq	$1, %rsi
	jne	.LBB5_16
.LBB5_9:
	xorl	%edx, %edx
.LBB5_10:
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rsi
	.seh_endepilogue
	retq
.LBB5_11:
	movq	%rax, %r11
	cmpq	%r11, %rcx
	jne	.LBB5_5
.LBB5_12:
	xorl	%eax, %eax
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rsi
	.seh_endepilogue
	retq
.LBB5_13:
	movzbl	%r8b, %r8d
	leaq	1(%rcx), %r9
	cmpq	%r11, %r9
	jne	.LBB5_19
.LBB5_14:
	movq	%r8, %rdx
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rsi
	.seh_endepilogue
	retq
.LBB5_19:
	addq	%r10, %rcx
	incq	%rcx
.LBB5_20:
	addq	%r11, %r10
	movabsq	$922337203685477580, %r9
	jmp	.LBB5_22
	.p2align	4
.LBB5_21:
	leaq	(%r8,%r8,4), %r8
	leaq	(%r11,%r8,2), %r8
	cmpq	%r10, %rcx
	je	.LBB5_14
.LBB5_22:
	movzbl	(%rcx), %r11d
	addb	$-48, %r11b
	cmpb	$9, %r11b
	ja	.LBB5_10
	incq	%rcx
	cmpq	%r9, %r8
	ja	.LBB5_10
	movzbl	%r11b, %r11d
	jne	.LBB5_21
	cmpb	$7, %r11b
	jbe	.LBB5_21
	jmp	.LBB5_10
.LBB5_26:
	cmpb	$9, %bl
	ja	.LBB5_10
	movzbl	%bl, %r8d
	cmpb	$45, %r9b
	jne	.LBB5_30
	cmpq	%rcx, %r11
	jne	.LBB5_32
.LBB5_29:
	negq	%r8
	jmp	.LBB5_14
.LBB5_30:
	cmpq	%rcx, %r11
	je	.LBB5_14
	addq	%r10, %rcx
	jmp	.LBB5_20
.LBB5_32:
	movabsq	$922337203685477580, %r9
	jmp	.LBB5_34
.LBB5_33:
	leaq	(%r8,%r8,4), %r8
	leaq	(%rsi,%r8,2), %r8
	incq	%rcx
	cmpq	%rcx, %r11
	je	.LBB5_29
.LBB5_34:
	movzbl	(%r10,%rcx), %ebx
	addb	$-48, %bl
	cmpb	$9, %bl
	ja	.LBB5_10
	cmpq	%r9, %r8
	ja	.LBB5_10
	movzbl	%bl, %esi
	jne	.LBB5_33
	cmpb	$9, %sil
	jne	.LBB5_33
	jmp	.LBB5_10
.LBB5_38:
	leaq	alloc_1b3f66c2f4ed52ecb24dab3a701c30a4(%rip), %r9
	movq	%rdx, %r8
	movq	%r11, %rdx
	callq	_RNvNtNtCs9l4wcBNbII5_4core5slice5index16slice_index_fail
	ud2
	.seh_endproc

	.def	_RNvNvNtCs9l4wcBNbII5_4core4hint21unreachable_unchecked18precondition_check;
	.scl	3;
	.type	32;
	.endef
	.section	.text$unlikely,"xr",one_only,_RNvNvNtCs9l4wcBNbII5_4core4hint21unreachable_unchecked18precondition_check,unique,6
	.p2align	4
_RNvNvNtCs9l4wcBNbII5_4core4hint21unreachable_unchecked18precondition_check:
.seh_proc _RNvNvNtCs9l4wcBNbII5_4core4hint21unreachable_unchecked18precondition_check
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	%rcx, %r9
	leaq	alloc_75fb06c2453febd814e73f5f2e72ae38(%rip), %rcx
	movl	$399, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
	.seh_endproc

	.def	rustium_http_range_content;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,rustium_http_range_content,unique,7
	.globl	rustium_http_range_content
	.p2align	4
rustium_http_range_content:
.seh_proc rustium_http_range_content
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$104, %rsp
	.seh_stackalloc 104
	.seh_endprologue
	movq	%rdx, %rdi
	movq	208(%rsp), %rax
	movq	$-1, (%rax)
	movq	$-1, (%r9)
	movq	$-1, (%r8)
	testq	%rdx, %rdx
	je	.LBB7_1
	testq	%rcx, %rcx
	setne	%al
	testq	%rdi, %rdi
	setns	%dl
	testb	%dl, %al
	je	.LBB7_3
	xorl	%esi, %esi
	jmp	.LBB7_6
	.p2align	4
.LBB7_8:
	incq	%rsi
	cmpq	%rsi, %rdi
	je	.LBB7_9
.LBB7_6:
	movzbl	(%rcx,%rsi), %eax
	cmpl	$32, %eax
	je	.LBB7_8
	cmpl	$9, %eax
	je	.LBB7_8
	cmpq	%rdi, %rsi
	jb	.LBB7_10
	jmp	.LBB7_16
.LBB7_9:
	movq	%rdi, %rsi
.LBB7_10:
	movq	%rdi, %rbx
	jmp	.LBB7_11
	.p2align	4
.LBB7_13:
	decq	%rbx
	je	.LBB7_14
.LBB7_11:
	movzbl	-1(%rcx,%rbx), %eax
	cmpl	$32, %eax
	je	.LBB7_13
	cmpl	$9, %eax
	je	.LBB7_13
	leaq	-1(%rbx), %rax
	movq	%rcx, %r13
	cmpq	%rdi, %rax
	jb	.LBB7_18
	jmp	.LBB7_16
.LBB7_14:
	movq	%rcx, %r13
	movq	%rsi, %rbx
	jmp	.LBB7_18
.LBB7_1:
	movl	$1, %r13d
	xorl	%esi, %esi
	xorl	%ebx, %ebx
.LBB7_18:
	movq	%rbx, %rbp
	subq	%rsi, %rbp
	setae	%al
	cmpq	%rdi, %rbx
	setbe	%dl
	testb	%dl, %al
	je	.LBB7_19
	leaq	(%rsi,%r13), %r11
	leaq	(%rbx,%r13), %r10
	cmpq	$17, %rbp
	jae	.LBB7_21
	cmpq	%rsi, %rbx
	je	.LBB7_117
	xorl	%edx, %edx
	.p2align	4
.LBB7_27:
	cmpb	$32, (%r11,%rdx)
	je	.LBB7_29
	incq	%rdx
	cmpq	%rdx, %rbp
	jne	.LBB7_27
	jmp	.LBB7_117
.LBB7_21:
	movq	%r13, 56(%rsp)
	movq	%rcx, 40(%rsp)
	movq	%r9, %r15
	movq	%r8, %r14
	movq	__imp__RNvNvNtNtNtCskuZNHgLkVkS_6memchr4arch6x86_646memchr10memchr_raw2FN(%rip), %rax
	movq	(%rax), %rax
	movb	$32, %cl
	movq	%r11, %rdx
	movq	%r10, %r12
	movq	%r10, %r8
	movq	%r11, %r13
	callq	*__guard_dispatch_icall_fptr(%rip)
	cmpq	$1, %rax
	jne	.LBB7_117
	subq	%r13, %rdx
	js	.LBB7_119
	movq	%r13, %r11
	cmpq	%rbp, %rdx
	movq	%r14, %r8
	movq	%r15, %r9
	movq	40(%rsp), %rcx
	movq	56(%rsp), %r13
	movq	%r12, %r10
	jb	.LBB7_30
.LBB7_24:
	leaq	alloc_a59d8fe4279b26f926811f91f116a398(%rip), %rcx
	callq	_RNvNvNtCs9l4wcBNbII5_4core4hint21unreachable_unchecked18precondition_check
	ud2
.LBB7_29:
	cmpq	%rbp, %rdx
	jae	.LBB7_16
.LBB7_30:
	leaq	(%rdx,%rsi), %rax
	cmpq	%rdi, %rax
	ja	.LBB7_31
	testq	%rdx, %rdx
	je	.LBB7_117
	movq	%r11, %r15
	movq	%r10, %r12
	leaq	(%rsi,%r13), %r14
	addq	$4, %r14
	xorl	%r10d, %r10d
	jmp	.LBB7_34
	.p2align	4
.LBB7_40:
	incq	%r10
	cmpq	%r10, %rdx
	je	.LBB7_117
.LBB7_34:
	movzbl	-4(%r14,%r10), %r11d
	cmpl	$9, %r11d
	je	.LBB7_40
	cmpl	$32, %r11d
	je	.LBB7_40
	movq	%r13, 56(%rsp)
	addq	%rax, %r13
	decq	%r13
	xorl	%ebp, %ebp
	jmp	.LBB7_37
	.p2align	4
.LBB7_39:
	leaq	(%rdx,%rbp), %r14
	decq	%r14
	decq	%rbp
	cmpq	%r10, %r14
	je	.LBB7_117
.LBB7_37:
	movzbl	(%r13,%rbp), %r14d
	cmpl	$32, %r14d
	je	.LBB7_39
	cmpl	$9, %r14d
	je	.LBB7_39
	leaq	(%rdx,%rbp), %r14
	addq	$-5, %r14
	cmpq	%r10, %r14
	jne	.LBB7_117
	leal	-65(%r11), %ebp
	cmpb	$26, %bpl
	setb	%bpl
	shlb	$5, %bpl
	orb	%r11b, %bpl
	cmpb	$98, %bpl
	jne	.LBB7_117
	movzbl	1(%r10,%r15), %r11d
	leal	-65(%r11), %ebp
	cmpb	$26, %bpl
	setb	%bpl
	shlb	$5, %bpl
	orb	%r11b, %bpl
	cmpb	$121, %bpl
	jne	.LBB7_117
	movzbl	2(%r10,%r15), %r11d
	leal	-65(%r11), %ebp
	cmpb	$26, %bpl
	setb	%bpl
	shlb	$5, %bpl
	orb	%r11b, %bpl
	cmpb	$116, %bpl
	jne	.LBB7_117
	movzbl	3(%r10,%r15), %r11d
	leal	-65(%r11), %ebp
	cmpb	$26, %bpl
	setb	%bpl
	shlb	$5, %bpl
	orb	%r11b, %bpl
	cmpb	$101, %bpl
	jne	.LBB7_117
	movzbl	4(%r10,%r15), %r10d
	leal	-65(%r10), %r11d
	cmpb	$26, %r11b
	setb	%r11b
	shlb	$5, %r11b
	orb	%r10b, %r11b
	cmpb	$115, %r11b
	jne	.LBB7_117
	leaq	1(%rax), %r10
	cmpq	%rax, %rbx
	jbe	.LBB7_120
	movq	%rbx, %rbp
	subq	%r10, %rbp
	movq	56(%rsp), %r11
	leaq	(%r11,%r10), %r13
	cmpq	$17, %rbp
	jae	.LBB7_49
	cmpq	%r10, %rbx
	je	.LBB7_117
	movq	%rax, %r14
	movq	%rdx, 88(%rsp)
	movq	%rcx, 40(%rsp)
	xorl	%edx, %edx
.LBB7_54:
	cmpb	$45, (%r13,%rdx)
	je	.LBB7_56
	incq	%rdx
	xorl	%eax, %eax
	cmpq	%rdx, %rbp
	jne	.LBB7_54
	jmp	.LBB7_118
.LBB7_19:
	leaq	alloc_c7b5750b1529aae3bc1899068a0d6d0a(%rip), %r9
	movq	%rsi, %rcx
	movq	%rbx, %rdx
	movq	%rdi, %r8
	callq	_RNvNtNtCs9l4wcBNbII5_4core5slice5index16slice_index_fail
	ud2
.LBB7_49:
	movq	%r10, %r15
	movq	%rax, %r14
	movq	%rdx, 88(%rsp)
	movq	%rcx, 40(%rsp)
	movq	%r9, 80(%rsp)
	movq	%r8, 64(%rsp)
	movq	__imp__RNvNvNtNtNtCskuZNHgLkVkS_6memchr4arch6x86_646memchr10memchr_raw2FN(%rip), %rax
	movq	(%rax), %rax
	movb	$45, %cl
	movq	%r13, %rdx
	movq	%r12, %r8
	callq	*__guard_dispatch_icall_fptr(%rip)
	cmpq	$1, %rax
	jne	.LBB7_117
	subq	%r13, %rdx
	js	.LBB7_119
	cmpq	%rbp, %rdx
	jb	.LBB7_57
	jmp	.LBB7_24
.LBB7_31:
	leaq	alloc_a2e76e97d647536f60d6b5ff43dbedf2(%rip), %r9
	movq	%rsi, %rcx
	movq	%rax, %rdx
	movq	%rdi, %r8
	callq	_RNvNtNtCs9l4wcBNbII5_4core5slice5index16slice_index_fail
	ud2
.LBB7_56:
	movq	%r9, 80(%rsp)
	movq	%r8, 64(%rsp)
	cmpq	%rbp, %rdx
	movq	%r10, %r15
	jae	.LBB7_16
.LBB7_57:
	addq	%rdx, %r15
	cmpq	%r14, %r15
	jbe	.LBB7_121
	leaq	1(%r15), %rcx
	cmpq	%r15, %rbx
	jbe	.LBB7_71
	movq	%r15, 96(%rsp)
	movq	%rdx, 72(%rsp)
	movq	%rbx, %rbp
	subq	%rcx, %rbp
	addq	%rcx, 56(%rsp)
	cmpq	$17, %rbp
	movq	%rcx, 48(%rsp)
	jae	.LBB7_60
	cmpq	%rcx, %rbx
	je	.LBB7_117
	xorl	%r15d, %r15d
.LBB7_68:
	movq	56(%rsp), %rax
	cmpb	$47, (%rax,%r15)
	je	.LBB7_70
	incq	%r15
	xorl	%eax, %eax
	cmpq	%r15, %rbp
	jne	.LBB7_68
	jmp	.LBB7_118
.LBB7_60:
	movq	__imp__RNvNvNtNtNtCskuZNHgLkVkS_6memchr4arch6x86_646memchr10memchr_raw2FN(%rip), %rax
	movq	(%rax), %rax
	movb	$47, %cl
	movq	56(%rsp), %rdx
	movq	%r12, %r8
	callq	*__guard_dispatch_icall_fptr(%rip)
	cmpq	$1, %rax
	jne	.LBB7_117
	movq	%rdx, %r15
	subq	56(%rsp), %r15
	js	.LBB7_119
	cmpq	%rbp, %r15
	jb	.LBB7_63
	jmp	.LBB7_24
.LBB7_119:
	leaq	alloc_6d855724149bc5132e1bc43bfd525250(%rip), %rcx
	callq	_RNvNvNtCs9l4wcBNbII5_4core4hint21unreachable_unchecked18precondition_check
	ud2
.LBB7_70:
	cmpq	%rbp, %r15
	jae	.LBB7_16
.LBB7_63:
	cmpq	$0, 40(%rsp)
	setne	%al
	testq	%rdi, %rdi
	setns	%cl
	testb	%cl, %al
	je	.LBB7_3
	movq	40(%rsp), %rax
	leaq	(%rax,%r14), %rcx
	incq	%rcx
	cmpq	$0, 72(%rsp)
	je	.LBB7_65
	movq	96(%rsp), %rax
	addq	40(%rsp), %rax
	movq	%rax, 96(%rsp)
	xorl	%edx, %edx
	xorl	%eax, %eax
	movq	72(%rsp), %r8
	jmp	.LBB7_75
.LBB7_3:
	leaq	alloc_a28e8c8fd5088943a8b5d44af697ff83(%rip), %rcx
	leaq	alloc_ff650c45cc045765b5fb342d7b104cb9(%rip), %r9
	movl	$559, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
.LBB7_81:
	incq	%rax
	cmpq	%rax, %r8
	je	.LBB7_82
.LBB7_75:
	movzbl	(%rcx,%rax), %r9d
	cmpl	$9, %r9d
	je	.LBB7_81
	cmpl	$32, %r9d
	je	.LBB7_81
	leaq	(%rsi,%r8), %r9
	movq	88(%rsp), %rdx
	movq	40(%rsp), %r10
	addq	%r10, %rdx
	addq	%rdx, %r9
	addq	%rax, %rcx
	xorl	%edx, %edx
	xorl	%r10d, %r10d
	jmp	.LBB7_78
.LBB7_16:
	leaq	alloc_64e308ef4babfeb8b6220184de794a17(%rip), %rcx
	leaq	alloc_1d1b1e35bb489427b2bdc9752de92226(%rip), %r9
	movl	$443, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
.LBB7_80:
	leaq	(%r10,%r8), %r11
	decq	%r11
	decq	%r10
	cmpq	%rax, %r11
	je	.LBB7_84
.LBB7_78:
	movzbl	(%r9,%r10), %r11d
	cmpl	$32, %r11d
	je	.LBB7_80
	cmpl	$9, %r11d
	je	.LBB7_80
	movq	%r8, %rdx
	subq	%rax, %rdx
	addq	%r10, %rdx
	jmp	.LBB7_84
.LBB7_82:
	movq	96(%rsp), %rcx
	jmp	.LBB7_84
.LBB7_65:
	xorl	%edx, %edx
.LBB7_84:
	callq	_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser10legacy_i64
	cmpq	$1, %rax
	jne	.LBB7_117
	movq	48(%rsp), %rax
	leaq	(%r15,%rax), %r14
	movq	64(%rsp), %rax
	movq	%rdx, (%rax)
	cmpq	%rdi, %r14
	ja	.LBB7_97
	movq	40(%rsp), %rax
	addq	%rax, 48(%rsp)
	testq	%r15, %r15
	je	.LBB7_87
	movq	40(%rsp), %rax
	leaq	(%rax,%r14), %r8
	xorl	%edx, %edx
	xorl	%eax, %eax
	movq	48(%rsp), %rcx
	jmp	.LBB7_89
.LBB7_95:
	incq	%rax
	cmpq	%rax, %r15
	je	.LBB7_96
.LBB7_89:
	movzbl	(%rcx,%rax), %r9d
	cmpl	$9, %r9d
	je	.LBB7_95
	cmpl	$32, %r9d
	je	.LBB7_95
	movq	88(%rsp), %rdx
	movq	72(%rsp), %r8
	leaq	(%r8,%rdx), %r8
	addq	%rsi, %r8
	addq	%r15, %r8
	movq	40(%rsp), %rdx
	addq	%rdx, %r8
	incq	%r8
	addq	%rax, %rcx
	movq	%rcx, 48(%rsp)
	xorl	%edx, %edx
	xorl	%ecx, %ecx
	jmp	.LBB7_92
.LBB7_94:
	leaq	(%rcx,%r15), %r9
	decq	%r9
	decq	%rcx
	cmpq	%rax, %r9
	je	.LBB7_99
.LBB7_92:
	movzbl	(%r8,%rcx), %r9d
	cmpl	$32, %r9d
	je	.LBB7_94
	cmpl	$9, %r9d
	je	.LBB7_94
	movq	%r15, %rdx
	subq	%rax, %rdx
	addq	%rcx, %rdx
	jmp	.LBB7_99
.LBB7_96:
	movq	%r8, 48(%rsp)
	jmp	.LBB7_99
.LBB7_87:
	xorl	%edx, %edx
.LBB7_99:
	movq	48(%rsp), %rcx
	callq	_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser10legacy_i64
	cmpq	$1, %rax
	movq	64(%rsp), %rcx
	movq	80(%rsp), %r8
	jne	.LBB7_116
	movq	%rdx, (%r8)
	cmpq	(%rcx), %rdx
	jl	.LBB7_116
	movq	%r8, 80(%rsp)
	movq	%rcx, 64(%rsp)
	leaq	1(%r14), %rcx
	cmpq	%r14, %rbx
	jbe	.LBB7_112
	cmpq	%rcx, %rbx
	je	.LBB7_103
	movq	40(%rsp), %rdx
	leaq	(%rdx,%rbx), %rcx
	addq	%r15, %rsi
	addq	72(%rsp), %rsi
	movq	%rdx, %r8
	movq	88(%rsp), %r11
	leaq	(%r11,%rdx), %r10
	addq	$3, %r10
	movq	%rbx, %rax
	movq	%r11, %r9
	subq	%r11, %rax
	leaq	-3(%rax), %r11
	xorl	%edx, %edx
	jmp	.LBB7_105
.LBB7_111:
	incq	%rsi
	cmpq	%rsi, %r11
	je	.LBB7_114
.LBB7_105:
	movzbl	(%r10,%rsi), %edi
	cmpl	$9, %edi
	je	.LBB7_111
	cmpl	$32, %edi
	je	.LBB7_111
	movq	%r8, %rcx
	addq	%rbx, %r8
	decq	%r8
	addq	%rcx, %r9
	leaq	(%rsi,%r9), %rcx
	addq	$3, %rcx
	xorl	%edx, %edx
	xorl	%r9d, %r9d
	jmp	.LBB7_108
.LBB7_110:
	leaq	(%rax,%r9), %r10
	addq	$-4, %r10
	decq	%r9
	cmpq	%rsi, %r10
	je	.LBB7_114
.LBB7_108:
	movzbl	(%r8,%r9), %r10d
	cmpl	$32, %r10d
	je	.LBB7_110
	cmpl	$9, %r10d
	je	.LBB7_110
	subq	%rsi, %rax
	leaq	(%rax,%r9), %rdx
	addq	$-3, %rdx
	jmp	.LBB7_114
.LBB7_103:
	movq	40(%rsp), %rax
	addq	%rcx, %rax
	xorl	%edx, %edx
	movq	%rax, %rcx
.LBB7_114:
	callq	_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser10legacy_i64
	cmpq	$1, %rax
	movq	64(%rsp), %rcx
	movq	80(%rsp), %r8
	jne	.LBB7_116
	movq	208(%rsp), %rax
	movq	%rdx, (%rax)
	movb	$1, %al
	cmpq	(%r8), %rdx
	jg	.LBB7_118
.LBB7_116:
	movq	208(%rsp), %rax
	movq	$-1, (%rax)
	movq	$-1, (%r8)
	movq	$-1, (%rcx)
.LBB7_117:
	xorl	%eax, %eax
.LBB7_118:
	.seh_startepilogue
	addq	$104, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB7_120:
	leaq	alloc_2129c8913edc2e7db116d57805312a74(%rip), %r9
	movq	%r10, %rcx
	movq	%rbx, %rdx
	movq	%rdi, %r8
	callq	_RNvNtNtCs9l4wcBNbII5_4core5slice5index16slice_index_fail
	ud2
.LBB7_71:
	leaq	alloc_2f4cdfd3b0122afbd665a6453ceef804(%rip), %r9
	movq	%rbx, %rdx
	movq	%rdi, %r8
	callq	_RNvNtNtCs9l4wcBNbII5_4core5slice5index16slice_index_fail
	ud2
.LBB7_97:
	leaq	alloc_1762a5e96faed5a081690a1a3c96ac12(%rip), %r9
	movq	48(%rsp), %rcx
	movq	%r14, %rdx
	movq	%rdi, %r8
	callq	_RNvNtNtCs9l4wcBNbII5_4core5slice5index16slice_index_fail
	ud2
.LBB7_112:
	leaq	alloc_1a3a8cea57c881098c85c9e448afd88d(%rip), %r9
	movq	%rbx, %rdx
	movq	%rdi, %r8
	callq	_RNvNtNtCs9l4wcBNbII5_4core5slice5index16slice_index_fail
	ud2
.LBB7_121:
	leaq	alloc_56ce2bf5c55f188118fc69a2dc8c77e4(%rip), %rcx
	callq	_RNvNtNtCs9l4wcBNbII5_4core9panicking11panic_const24panic_const_add_overflow
	ud2
	.seh_endproc

	.def	rustium_http_range_fetch;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,rustium_http_range_fetch,unique,8
	.globl	rustium_http_range_fetch
	.p2align	4
rustium_http_range_fetch:
.seh_proc rustium_http_range_fetch
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$80, %rsp
	.seh_stackalloc 80
	.seh_endprologue
	testq	%rdx, %rdx
	je	.LBB8_4
	testq	%rcx, %rcx
	setne	%al
	testq	%rdx, %rdx
	setns	%r10b
	testb	%r10b, %al
	je	.LBB8_38
	cmpq	$5, %rdx
	jb	.LBB8_4
	movl	$1702132066, %eax
	xorl	(%rcx), %eax
	movzbl	4(%rcx), %r10d
	xorl	$115, %r10d
	orl	%eax, %r10d
	je	.LBB8_8
.LBB8_4:
	xorl	%eax, %eax
	.seh_startepilogue
	addq	$80, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
.LBB8_8:
	cmpq	$5, %rdx
	sete	%r10b
	movl	%r8d, %r11d
	xorb	$1, %r11b
	movl	$5, %eax
	orb	%r10b, %r11b
	je	.LBB8_10
	jmp	.LBB8_12
	.p2align	4
.LBB8_9:
	incq	%rax
	cmpq	%rax, %rdx
	je	.LBB8_4
.LBB8_10:
	movzbl	(%rcx,%rax), %r10d
	cmpl	$9, %r10d
	je	.LBB8_9
	cmpl	$32, %r10d
	je	.LBB8_9
.LBB8_12:
	cmpq	%rdx, %rax
	jae	.LBB8_4
	cmpb	$61, (%rcx,%rax)
	jne	.LBB8_4
	incq	%rax
	movq	%rax, 40(%rsp)
	cmpq	%rdx, %rax
	setb	%r10b
	movb	%r8b, 39(%rsp)
	andb	%r8b, %r10b
	cmpb	$1, %r10b
	je	.LBB8_16
	jmp	.LBB8_20
	.p2align	4
.LBB8_15:
	incq	%rax
	cmpq	%rax, %rdx
	je	.LBB8_18
.LBB8_16:
	movzbl	(%rcx,%rax), %r8d
	cmpl	$32, %r8d
	je	.LBB8_15
	cmpl	$9, %r8d
	je	.LBB8_15
	jmp	.LBB8_19
.LBB8_18:
	movq	%rdx, %rax
.LBB8_19:
	movq	%rax, 40(%rsp)
.LBB8_20:
	movq	%r9, 72(%rsp)
	leaq	40(%rsp), %r8
	movq	%rcx, 48(%rsp)
	movq	%rdx, 56(%rsp)
	movq	56(%rsp), %rdx
	callq	_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13fetch_decimal
	movq	56(%rsp), %rsi
	movq	40(%rsp), %r8
	cmpq	%rsi, %r8
	setb	%cl
	movzbl	39(%rsp), %r9d
	andb	%r9b, %cl
	cmpb	$1, %cl
	jne	.LBB8_25
	movq	48(%rsp), %rcx
	jmp	.LBB8_23
	.p2align	4
.LBB8_22:
	incq	%r8
	cmpq	%r8, %rsi
	je	.LBB8_4
.LBB8_23:
	movzbl	(%rcx,%r8), %r10d
	cmpl	$9, %r10d
	je	.LBB8_22
	cmpl	$32, %r10d
	je	.LBB8_22
	jmp	.LBB8_26
.LBB8_25:
	movq	48(%rsp), %rcx
.LBB8_26:
	cmpq	%rsi, %r8
	jae	.LBB8_4
	cmpb	$45, (%rcx,%r8)
	jne	.LBB8_4
	movq	%rax, 48(%rsp)
	movq	%rdx, 64(%rsp)
	incq	%r8
	movq	%r8, 40(%rsp)
	cmpq	%rsi, %r8
	setb	%al
	andb	%al, %r9b
	cmpb	$1, %r9b
	je	.LBB8_30
	jmp	.LBB8_34
.LBB8_29:
	incq	%r8
	cmpq	%r8, %rsi
	je	.LBB8_32
.LBB8_30:
	movzbl	(%rcx,%r8), %eax
	cmpl	$32, %eax
	je	.LBB8_29
	cmpl	$9, %eax
	je	.LBB8_29
	jmp	.LBB8_33
.LBB8_32:
	movq	%rsi, %r8
.LBB8_33:
	movq	%r8, 40(%rsp)
.LBB8_34:
	leaq	40(%rsp), %r8
	movq	%rsi, %rdx
	callq	_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser13fetch_decimal
	cmpq	%rsi, 40(%rsp)
	movq	72(%rsp), %rcx
	movq	64(%rsp), %r8
	movq	48(%rsp), %r9
	jne	.LBB8_4
	cmpq	$1, %r9
	jne	.LBB8_39
	xorl	%r9d, %r9d
	andb	$1, %al
	cmpb	$1, %al
	sbbq	%r9, %r9
	orq	%rdx, %r9
	movq	$-1, %rdx
	jmp	.LBB8_41
.LBB8_38:
	leaq	alloc_a28e8c8fd5088943a8b5d44af697ff83(%rip), %rcx
	leaq	alloc_ff650c45cc045765b5fb342d7b104cb9(%rip), %r9
	movl	$559, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
.LBB8_39:
	testb	$1, %al
	je	.LBB8_4
	movq	$-1, %r8
	movq	$-1, %r9
.LBB8_41:
	movq	%r8, (%rcx)
	movq	%r9, 8(%rcx)
	movq	%rdx, 16(%rcx)
	movb	$1, %al
	.seh_startepilogue
	addq	$80, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc

	.def	rustium_http_range_list;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,rustium_http_range_list,unique,9
	.globl	rustium_http_range_list
	.p2align	4
rustium_http_range_list:
.seh_proc rustium_http_range_list
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$144, %rsp
	.seh_stackalloc 144
	.seh_endprologue
	movq	$0, 64(%rsp)
	movq	$8, 72(%rsp)
	movq	$0, 80(%rsp)
	testq	%rdx, %rdx
	je	.LBB9_5
	testq	%rcx, %rcx
	setne	%al
	testq	%rdx, %rdx
	setns	%r9b
	testb	%r9b, %al
	je	.LBB9_34
	xorl	%eax, %eax
	.p2align	4
.LBB9_3:
	cmpb	$61, (%rcx,%rax)
	je	.LBB9_6
	incq	%rax
	cmpq	%rax, %rdx
	jne	.LBB9_3
	jmp	.LBB9_24
.LBB9_5:
	leaq	56(%rsp), %rax
	xorl	%esi, %esi
	xorl	%edx, %edx
	movq	%rdx, (%rax)
	movq	56(%rsp), %r8
	testq	%r8, %r8
	jne	.LBB9_31
	jmp	.LBB9_33
.LBB9_6:
	cmpq	%rdx, %rax
	jae	.LBB9_102
	testq	%rax, %rax
	je	.LBB9_24
	movq	%rcx, %r9
	movq	%rax, %r10
	jmp	.LBB9_10
	.p2align	4
.LBB9_9:
	incq	%r9
	decq	%r10
	je	.LBB9_24
.LBB9_10:
	movzbl	(%r9), %r11d
	cmpl	$9, %r11d
	je	.LBB9_9
	cmpl	$32, %r11d
	je	.LBB9_9
	movq	$-1, %rsi
	jmp	.LBB9_14
	.p2align	4
.LBB9_13:
	leaq	(%r10,%rsi), %rdi
	decq	%rdi
	decq	%rsi
	cmpq	$-1, %rdi
	je	.LBB9_24
.LBB9_14:
	leaq	(%rcx,%rsi), %rdi
	movzbl	(%rax,%rdi), %edi
	cmpl	$32, %edi
	je	.LBB9_13
	cmpl	$9, %edi
	je	.LBB9_13
	addq	%rsi, %r10
	cmpq	$4, %r10
	jne	.LBB9_24
	leal	-65(%r11), %r10d
	cmpb	$26, %r10b
	setb	%r10b
	shlb	$5, %r10b
	orb	%r11b, %r10b
	cmpb	$98, %r10b
	jne	.LBB9_24
	movzbl	1(%r9), %r10d
	leal	-65(%r10), %r11d
	cmpb	$26, %r11b
	setb	%r11b
	shlb	$5, %r11b
	orb	%r10b, %r11b
	cmpb	$121, %r11b
	jne	.LBB9_24
	movzbl	2(%r9), %r10d
	leal	-65(%r10), %r11d
	cmpb	$26, %r11b
	setb	%r11b
	shlb	$5, %r11b
	orb	%r10b, %r11b
	cmpb	$116, %r11b
	jne	.LBB9_24
	movzbl	3(%r9), %r10d
	leal	-65(%r10), %r11d
	cmpb	$26, %r11b
	setb	%r11b
	shlb	$5, %r11b
	orb	%r10b, %r11b
	cmpb	$101, %r11b
	jne	.LBB9_24
	movzbl	4(%r9), %r9d
	leal	-65(%r9), %r10d
	cmpb	$26, %r10b
	setb	%r10b
	shlb	$5, %r10b
	orb	%r9b, %r10b
	cmpb	$115, %r10b
	jne	.LBB9_24
	incq	%rax
	movb	$1, %sil
	cmpq	%rdx, %rax
	jae	.LBB9_25
	leaq	-1(%rcx), %r14
	movl	$8, %ebx
	movq	$0, 48(%rsp)
	movq	%r14, 128(%rsp)
	jmp	.LBB9_37
.LBB9_24:
	xorl	%esi, %esi
.LBB9_25:
	movq	64(%rsp), %rax
	movq	72(%rsp), %rcx
.LBB9_26:
	testq	%rax, %rax
	je	.LBB9_30
	movabsq	$768614336404564651, %rdx
	cmpq	%rdx, %rax
	jae	.LBB9_100
	movabsq	$384307168202282326, %rdx
	cmpq	%rdx, %rax
	jae	.LBB9_101
	shlq	$3, %rax
	leaq	(%rax,%rax,2), %rdx
	movq	$8, 56(%rsp)
	leaq	136(%rsp), %rax
	movq	%rdx, (%rax)
	movq	56(%rsp), %r8
	testq	%r8, %r8
	jne	.LBB9_31
	jmp	.LBB9_33
.LBB9_30:
	leaq	56(%rsp), %rax
	xorl	%edx, %edx
	movq	%rdx, (%rax)
	movq	56(%rsp), %r8
	testq	%r8, %r8
	je	.LBB9_33
.LBB9_31:
	movq	136(%rsp), %rdx
	testq	%rdx, %rdx
	je	.LBB9_33
	callq	_RNvCs6d6XRwTwhVh_7___rustc14___rust_dealloc
.LBB9_33:
	movl	%esi, %eax
	.seh_startepilogue
	addq	$144, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB9_34:
	leaq	alloc_a28e8c8fd5088943a8b5d44af697ff83(%rip), %rcx
	leaq	alloc_ff650c45cc045765b5fb342d7b104cb9(%rip), %r9
	movl	$559, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
.LBB9_35:
	movq	%r15, %rbx
.LBB9_36:
	addq	%rdi, %r9
	movq	%r9, %rax
	cmpq	%rdx, %r9
	jae	.LBB9_104
.LBB9_37:
	leaq	1(%rax), %r9
	cmpq	%r9, %rdx
	cmovaq	%rdx, %r9
	xorl	%r11d, %r11d
	movq	%rax, %rdi
	xorl	%r10d, %r10d
	jmp	.LBB9_40
.LBB9_38:
	xorl	%r10d, %r10d
.LBB9_39:
	incq	%rdi
	cmpq	%rdi, %r9
	je	.LBB9_51
.LBB9_40:
	movzbl	(%rcx,%rdi), %ebp
	movzbl	%bpl, %esi
	testb	$1, %r11b
	je	.LBB9_45
	movb	$1, %r11b
	testb	$1, %r10b
	jne	.LBB9_38
	cmpb	$34, %bpl
	je	.LBB9_48
	cmpl	$92, %esi
	jne	.LBB9_38
	movb	$1, %r10b
	movb	$1, %r11b
	jmp	.LBB9_39
.LBB9_45:
	cmpl	$34, %esi
	je	.LBB9_47
	cmpl	$44, %esi
	jne	.LBB9_49
	jmp	.LBB9_52
.LBB9_47:
	movb	$1, %r11b
	jmp	.LBB9_39
.LBB9_48:
	xorl	%r10d, %r10d
.LBB9_49:
	xorl	%r11d, %r11d
	jmp	.LBB9_39
.LBB9_51:
	movq	%r9, %rdi
	xorl	%r9d, %r9d
	jmp	.LBB9_53
.LBB9_52:
	movl	$1, %r9d
.LBB9_53:
	movq	%rdi, %r11
	subq	%rax, %r11
	je	.LBB9_36
	leaq	(%rcx,%rax), %rsi
	leaq	(%r14,%rax), %r10
	notq	%rax
	addq	%rdi, %rax
	jmp	.LBB9_56
.LBB9_55:
	incq	%rsi
	decq	%rax
	incq	%r10
	decq	%r11
	je	.LBB9_36
.LBB9_56:
	movzbl	(%rsi), %ebp
	cmpl	$9, %ebp
	je	.LBB9_55
	cmpl	$32, %ebp
	je	.LBB9_55
	movq	%rbx, %r15
	leaq	(%rcx,%rdi), %rbx
	jmp	.LBB9_60
.LBB9_59:
	decq	%rbx
	decq	%r11
	addq	$-1, %rax
	jae	.LBB9_35
.LBB9_60:
	movzbl	-1(%rbx), %ebp
	cmpl	$32, %ebp
	je	.LBB9_59
	cmpl	$9, %ebp
	je	.LBB9_59
	leaq	1(%rax), %r12
	xorl	%r14d, %r14d
.LBB9_63:
	cmpb	$45, (%rsi,%r14)
	je	.LBB9_65
	incq	%r14
	incq	%r10
	decq	%r11
	jne	.LBB9_63
	jmp	.LBB9_103
.LBB9_65:
	movq	%r9, 120(%rsp)
	movq	%rdi, 112(%rsp)
	movq	%r15, 88(%rsp)
	movq	%rcx, 104(%rsp)
	movq	%rdx, 96(%rsp)
	movq	%r8, 40(%rsp)
	cmpq	%r12, %r14
	jae	.LBB9_102
	movq	%rax, %rdi
	movq	%r14, %rax
	movq	$-1, %r15
	testq	%r14, %r14
	je	.LBB9_78
	xorl	%r8d, %r8d
	movq	%rsi, %rcx
	jmp	.LBB9_69
.LBB9_68:
	incq	%r8
	cmpq	%r8, %rax
	je	.LBB9_78
.LBB9_69:
	movzbl	(%rcx,%r8), %edx
	cmpl	$9, %edx
	je	.LBB9_68
	cmpl	$32, %edx
	je	.LBB9_68
	addq	%r8, %rcx
	movq	%rax, %rdx
	subq	%r8, %rdx
	jmp	.LBB9_73
.LBB9_72:
	decq	%rdx
	decq	%r10
	testq	%rdx, %rdx
	je	.LBB9_77
.LBB9_73:
	movzbl	(%r10), %eax
	cmpl	$32, %eax
	je	.LBB9_72
	cmpl	$9, %eax
	je	.LBB9_72
	callq	_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser10legacy_i64
	testb	$1, %al
	je	.LBB9_107
	movq	%rdx, %r15
.LBB9_77:
	movq	%r14, %rax
.LBB9_78:
	movq	%rdi, %rdx
	subq	%rax, %rdx
	jne	.LBB9_84
.LBB9_79:
	movq	$-1, %rsi
	cmpq	$-1, %r15
	je	.LBB9_107
	movq	$-1, %rdi
	testq	%rsi, %rsi
	jg	.LBB9_82
.LBB9_81:
	testq	%r15, %r15
	js	.LBB9_107
.LBB9_82:
	movq	48(%rsp), %rax
	cmpq	64(%rsp), %rax
	je	.LBB9_97
.LBB9_83:
	leaq	(%rax,%rax,2), %rcx
	movq	88(%rsp), %rbx
	movq	%r15, (%rbx,%rcx,8)
	movq	%rdi, 8(%rbx,%rcx,8)
	movq	%rsi, 16(%rbx,%rcx,8)
	incq	%rax
	movq	%rax, 48(%rsp)
	movq	%rax, 80(%rsp)
	movq	40(%rsp), %r8
	movq	96(%rsp), %rdx
	movq	104(%rsp), %rcx
	movq	128(%rsp), %r14
	movq	112(%rsp), %rdi
	movq	120(%rsp), %r9
	jmp	.LBB9_36
.LBB9_84:
	leaq	(%rsi,%rax), %rcx
	incq	%rcx
	jmp	.LBB9_86
.LBB9_85:
	incq	%rcx
	decq	%rdx
	je	.LBB9_79
.LBB9_86:
	movzbl	(%rcx), %eax
	cmpl	$9, %eax
	je	.LBB9_85
	cmpl	$32, %eax
	je	.LBB9_85
	xorl	%eax, %eax
	jmp	.LBB9_90
.LBB9_89:
	decq	%rax
	movq	%rdx, %r8
	addq	%rax, %r8
	je	.LBB9_79
.LBB9_90:
	movzbl	-1(%rbx,%rax), %r8d
	cmpl	$32, %r8d
	je	.LBB9_89
	cmpl	$9, %r8d
	je	.LBB9_89
	addq	%rax, %rdx
	callq	_RNvNtCsh1eR4S1pMdQ_9range_ffi17http_range_parser10legacy_i64
	testb	$1, %al
	je	.LBB9_107
	movq	%rdx, %rdi
	cmpq	$-1, %r15
	je	.LBB9_98
	testq	%r15, %r15
	js	.LBB9_107
	movq	$-1, %rsi
	cmpq	$-1, %rdi
	je	.LBB9_99
	cmpq	%r15, %rdi
	jge	.LBB9_82
	jmp	.LBB9_107
.LBB9_97:
	leaq	64(%rsp), %rcx
	callq	_RNvMs7_NtCs8tsiLsQ9XHg_5alloc7raw_vecINtB5_6RawVecNtCsh1eR4S1pMdQ_9range_ffi11ParsedRangeE8grow_oneBO_
	movq	48(%rsp), %rax
	movq	72(%rsp), %rcx
	movq	%rcx, 88(%rsp)
	jmp	.LBB9_83
.LBB9_98:
	movq	%rdi, %rsi
	movq	$-1, %rdi
	testq	%rsi, %rsi
	jle	.LBB9_81
	jmp	.LBB9_82
.LBB9_99:
	movq	$-1, %rdi
	jmp	.LBB9_82
.LBB9_100:
	leaq	alloc_db07ae5a9ce650d9b7cc970d048e6f0c(%rip), %rcx
	leaq	alloc_ad088eaa3dc0ae68b11fd72bfcf5e34b(%rip), %r9
	movl	$373, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
.LBB9_101:
	leaq	alloc_1be5ea12ba708d9a11b6e93a7d387a75(%rip), %rcx
	leaq	alloc_dade1aed0d0fe800cb3ecdb07302e098(%rip), %r9
	movl	$563, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
.LBB9_102:
	leaq	alloc_64e308ef4babfeb8b6220184de794a17(%rip), %rcx
	leaq	alloc_1d1b1e35bb489427b2bdc9752de92226(%rip), %r9
	movl	$443, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
.LBB9_103:
	xorl	%esi, %esi
	jmp	.LBB9_105
.LBB9_104:
	movb	$1, %sil
.LBB9_105:
	movq	64(%rsp), %rax
	movq	72(%rsp), %rcx
	movq	48(%rsp), %rdx
	testq	%rdx, %rdx
	je	.LBB9_26
	movq	%rcx, (%r8)
	movq	%rdx, 8(%r8)
	movq	%rax, 16(%r8)
	orb	$2, %sil
	jmp	.LBB9_33
.LBB9_107:
	xorl	%esi, %esi
	movq	40(%rsp), %r8
	jmp	.LBB9_105
	.seh_endproc

	.def	rustium_http_range_list_drop;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,rustium_http_range_list_drop,unique,10
	.globl	rustium_http_range_list_drop
	.p2align	4
rustium_http_range_list_drop:
.seh_proc rustium_http_range_list_drop
	subq	$56, %rsp
	.seh_stackalloc 56
	.seh_endprologue
	movq	16(%rcx), %rax
	cmpq	%rax, 8(%rcx)
	ja	.LBB10_1
	movq	(%rcx), %rcx
	testq	%rcx, %rcx
	je	.LBB10_4
	testq	%rax, %rax
	je	.LBB10_6
	movabsq	$768614336404564651, %rdx
	cmpq	%rdx, %rax
	jae	.LBB10_8
	movabsq	$384307168202282326, %rdx
	cmpq	%rdx, %rax
	jae	.LBB10_10
	shlq	$3, %rax
	leaq	(%rax,%rax,2), %rax
	movq	$8, 40(%rsp)
	leaq	48(%rsp), %rdx
	movq	%rax, (%rdx)
	movq	40(%rsp), %r8
	testq	%r8, %r8
	jne	.LBB10_13
	jmp	.LBB10_14
.LBB10_6:
	leaq	40(%rsp), %rdx
	xorl	%eax, %eax
	movq	%rax, (%rdx)
	movq	40(%rsp), %r8
	testq	%r8, %r8
	je	.LBB10_14
.LBB10_13:
	movq	48(%rsp), %rdx
	testq	%rdx, %rdx
	je	.LBB10_14
	.seh_startepilogue
	addq	$56, %rsp
	.seh_endepilogue
	jmp	_RNvCs6d6XRwTwhVh_7___rustc14___rust_dealloc
.LBB10_14:
	.seh_startepilogue
	addq	$56, %rsp
	.seh_endepilogue
	retq
.LBB10_1:
	leaq	alloc_82a99021b1306c9239507412b95c0e74(%rip), %rcx
	leaq	alloc_5b8d19018527d26ed8c47fbaf3eafd4f(%rip), %r9
	movl	$411, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
.LBB10_4:
	leaq	alloc_560a59ed819b9d9a5841f6e731c4c8e5(%rip), %rcx
	leaq	alloc_91244a802f615a731e570cd82aa5f107(%rip), %r9
	movl	$421, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
.LBB10_8:
	leaq	alloc_db07ae5a9ce650d9b7cc970d048e6f0c(%rip), %rcx
	leaq	alloc_ad088eaa3dc0ae68b11fd72bfcf5e34b(%rip), %r9
	movl	$373, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
.LBB10_10:
	leaq	alloc_1be5ea12ba708d9a11b6e93a7d387a75(%rip), %rcx
	leaq	alloc_dade1aed0d0fe800cb3ecdb07302e098(%rip), %r9
	movl	$563, %edx
	xorl	%r8d, %r8d
	callq	_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt
	ud2
	.seh_endproc

	.section	.rdata,"dr",one_only,alloc_0de2ba7348580a97f43fcfb1c810f249,unique,11
alloc_0de2ba7348580a97f43fcfb1c810f249:
	.asciz	"D:\\Rustium\\.scratch\\net-wave1\\promote\\optimization\\before\\net\\http\\http_range_parser.rs"

	.section	.rdata,"dr",one_only,alloc_c712be591025e6a1f0f9ed6c6808275b,unique,12
alloc_c712be591025e6a1f0f9ed6c6808275b:
	.asciz	"D:\\Rustium\\third_party\\rust\\chromium_crates_io\\vendor\\memchr-v2\\src\\arch\\generic\\memchr.rs"

	.section	.rdata,"dr",one_only,alloc_a59d8fe4279b26f926811f91f116a398,unique,13
	.p2align	3, 0x0
alloc_a59d8fe4279b26f926811f91f116a398:
	.quad	alloc_c712be591025e6a1f0f9ed6c6808275b
	.asciz	"Z\000\000\000\000\000\000\000s\004\000\000\t\000\000"

	.section	.rdata,"dr",one_only,alloc_87e6578268e354c4f2747b30d32a9b4e,unique,14
alloc_87e6578268e354c4f2747b30d32a9b4e:
	.asciz	"library\\core\\src\\slice\\iter.rs"

	.section	.rdata,"dr",one_only,alloc_1d1b1e35bb489427b2bdc9752de92226,unique,15
	.p2align	3, 0x0
alloc_1d1b1e35bb489427b2bdc9752de92226:
	.quad	alloc_87e6578268e354c4f2747b30d32a9b4e
	.asciz	"\036\000\000\000\000\000\000\000\214\000\000\000\001\000\000"

	.section	.rdata,"dr",one_only,alloc_56ce2bf5c55f188118fc69a2dc8c77e4,unique,16
	.p2align	3, 0x0
alloc_56ce2bf5c55f188118fc69a2dc8c77e4:
	.quad	alloc_0de2ba7348580a97f43fcfb1c810f249
	.asciz	"W\000\000\000\000\000\000\000\335\000\000\000\025\000\000"

	.section	.rdata,"dr",one_only,alloc_2f4cdfd3b0122afbd665a6453ceef804,unique,17
	.p2align	3, 0x0
alloc_2f4cdfd3b0122afbd665a6453ceef804:
	.quad	alloc_0de2ba7348580a97f43fcfb1c810f249
	.asciz	"W\000\000\000\000\000\000\000\336\000\000\0002\000\000"

	.section	.rdata,"dr",one_only,alloc_2129c8913edc2e7db116d57805312a74,unique,18
	.p2align	3, 0x0
alloc_2129c8913edc2e7db116d57805312a74:
	.quad	alloc_0de2ba7348580a97f43fcfb1c810f249
	.asciz	"W\000\000\000\000\000\000\000\335\000\000\0002\000\000"

	.section	.rdata,"dr",one_only,alloc_a2e76e97d647536f60d6b5ff43dbedf2,unique,19
	.p2align	3, 0x0
alloc_a2e76e97d647536f60d6b5ff43dbedf2:
	.quad	alloc_0de2ba7348580a97f43fcfb1c810f249
	.asciz	"W\000\000\000\000\000\000\000\332\000\000\000\030\000\000"

	.section	.rdata,"dr",one_only,alloc_c7b5750b1529aae3bc1899068a0d6d0a,unique,20
	.p2align	3, 0x0
alloc_c7b5750b1529aae3bc1899068a0d6d0a:
	.quad	alloc_0de2ba7348580a97f43fcfb1c810f249
	.asciz	"W\000\000\000\000\000\000\000\331\000\000\000.\000\000"

	.section	.rdata,"dr",one_only,alloc_1762a5e96faed5a081690a1a3c96ac12,unique,21
	.p2align	3, 0x0
alloc_1762a5e96faed5a081690a1a3c96ac12:
	.quad	alloc_0de2ba7348580a97f43fcfb1c810f249
	.asciz	"W\000\000\000\000\000\000\000\350\000\000\000D\000\000"

	.section	.rdata,"dr",one_only,alloc_1a3a8cea57c881098c85c9e448afd88d,unique,22
	.p2align	3, 0x0
alloc_1a3a8cea57c881098c85c9e448afd88d:
	.quad	alloc_0de2ba7348580a97f43fcfb1c810f249
	.asciz	"W\000\000\000\000\000\000\000\356\000\000\000F\000\000"

	.section	.rdata,"dr",one_only,alloc_40fd0ccb23656c1e5964b7b09a293f91,unique,23
alloc_40fd0ccb23656c1e5964b7b09a293f91:
	.asciz	"D:\\Rustium\\.scratch\\net-wave1\\promote\\optimization\\before\\net\\http\\http_range_ffi.rs"

	.section	.rdata,"dr",one_only,alloc_ff650c45cc045765b5fb342d7b104cb9,unique,24
	.p2align	3, 0x0
alloc_ff650c45cc045765b5fb342d7b104cb9:
	.quad	alloc_40fd0ccb23656c1e5964b7b09a293f91
	.asciz	"T\000\000\000\000\000\000\0008\000\000\000\022\000\000"

	.section	.rdata,"dr",one_only,alloc_6b2d6f9c10483c97dd45df2e37fdbaf3,unique,25
alloc_6b2d6f9c10483c97dd45df2e37fdbaf3:
	.asciz	"library\\alloc\\src\\alloc.rs"

	.section	.rdata,"dr",one_only,alloc_1b98de0e82d923a9daff35d520cf360d,unique,26
	.p2align	3, 0x0
alloc_1b98de0e82d923a9daff35d520cf360d:
	.quad	alloc_6b2d6f9c10483c97dd45df2e37fdbaf3
	.asciz	"\032\000\000\000\000\000\000\000~\001\000\000\021\000\000"

	.section	.rdata,"dr",one_only,alloc_24f4768e38f126368567621cf7f11fcd,unique,27
alloc_24f4768e38f126368567621cf7f11fcd:
	.asciz	"library\\alloc\\src\\raw_vec\\mod.rs"

	.section	.rdata,"dr",one_only,alloc_ad088eaa3dc0ae68b11fd72bfcf5e34b,unique,28
	.p2align	3, 0x0
alloc_ad088eaa3dc0ae68b11fd72bfcf5e34b:
	.quad	alloc_24f4768e38f126368567621cf7f11fcd
	.asciz	" \000\000\000\000\000\000\000\230\002\000\0005\000\000"

	.section	.rdata,"dr",one_only,alloc_dade1aed0d0fe800cb3ecdb07302e098,unique,29
	.p2align	3, 0x0
alloc_dade1aed0d0fe800cb3ecdb07302e098:
	.quad	alloc_24f4768e38f126368567621cf7f11fcd
	.asciz	" \000\000\000\000\000\000\000\231\002\000\000\036\000\000"

	.section	.rdata,"dr",one_only,alloc_5a885d3db7500f26d581e948d37c49fe,unique,30
	.p2align	3, 0x0
alloc_5a885d3db7500f26d581e948d37c49fe:
	.quad	alloc_24f4768e38f126368567621cf7f11fcd
	.asciz	" \000\000\000\000\000\000\000C\002\000\000\021\000\000"

	.section	.rdata,"dr",one_only,alloc_1b3f66c2f4ed52ecb24dab3a701c30a4,unique,31
	.p2align	3, 0x0
alloc_1b3f66c2f4ed52ecb24dab3a701c30a4:
	.quad	alloc_0de2ba7348580a97f43fcfb1c810f249
	.asciz	"W\000\000\000\000\000\000\000\251\000\000\000\036\000\000"

	.section	.rdata,"dr",one_only,alloc_1be5ea12ba708d9a11b6e93a7d387a75,unique,32
alloc_1be5ea12ba708d9a11b6e93a7d387a75:
	.ascii	"unsafe precondition(s) violated: Layout::from_size_align_unchecked requires that align is a power of 2 and the rounded-up allocation size does not exceed isize::MAX\n\nThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety."

	.section	.rdata,"dr",one_only,alloc_560a59ed819b9d9a5841f6e731c4c8e5,unique,33
alloc_560a59ed819b9d9a5841f6e731c4c8e5:
	.ascii	"unsafe precondition(s) violated: NonNull::new_unchecked requires that the pointer is non-null\n\nThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety."

	.section	.rdata,"dr",one_only,alloc_db07ae5a9ce650d9b7cc970d048e6f0c,unique,34
alloc_db07ae5a9ce650d9b7cc970d048e6f0c:
	.ascii	"unsafe precondition(s) violated: usize::unchecked_mul cannot overflow\n\nThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety."

	.section	.rdata,"dr",one_only,alloc_82a99021b1306c9239507412b95c0e74,unique,35
alloc_82a99021b1306c9239507412b95c0e74:
	.ascii	"unsafe precondition(s) violated: Vec::from_raw_parts_in requires that length <= capacity\n\nThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety."

	.section	.rdata,"dr",one_only,alloc_64e308ef4babfeb8b6220184de794a17,unique,36
alloc_64e308ef4babfeb8b6220184de794a17:
	.ascii	"unsafe precondition(s) violated: hint::assert_unchecked must never be called when the condition is false\n\nThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety."

	.section	.rdata,"dr",one_only,alloc_75fb06c2453febd814e73f5f2e72ae38,unique,37
alloc_75fb06c2453febd814e73f5f2e72ae38:
	.ascii	"unsafe precondition(s) violated: hint::unreachable_unchecked must never be reached\n\nThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety."

	.section	.rdata,"dr",one_only,alloc_a28e8c8fd5088943a8b5d44af697ff83,unique,38
alloc_a28e8c8fd5088943a8b5d44af697ff83:
	.ascii	"unsafe precondition(s) violated: slice::from_raw_parts requires the pointer to be aligned and non-null, and the total size of the slice not to exceed `isize::MAX`\n\nThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety."

	.section	.rdata,"dr",one_only,alloc_03e70bdcab636393a4206dfdf6ac4e05,unique,39
alloc_03e70bdcab636393a4206dfdf6ac4e05:
	.asciz	"D:\\Rustium\\third_party\\rust\\chromium_crates_io\\vendor\\memchr-v2\\src\\ext.rs"

	.section	.rdata,"dr",one_only,alloc_6d855724149bc5132e1bc43bfd525250,unique,40
	.p2align	3, 0x0
alloc_6d855724149bc5132e1bc43bfd525250:
	.quad	alloc_03e70bdcab636393a4206dfdf6ac4e05
	.asciz	"J\000\000\000\000\000\000\000\027\000\000\0003\000\000"

	.section	.rdata,"dr",one_only,alloc_2728436149d2d0d1e5775c8099d441a1,unique,41
alloc_2728436149d2d0d1e5775c8099d441a1:
	.asciz	"library\\alloc\\src\\vec\\mod.rs"

	.section	.rdata,"dr",one_only,alloc_5b8d19018527d26ed8c47fbaf3eafd4f,unique,42
	.p2align	3, 0x0
alloc_5b8d19018527d26ed8c47fbaf3eafd4f:
	.quad	alloc_2728436149d2d0d1e5775c8099d441a1
	.asciz	"\034\000\000\000\000\000\000\000m\004\000\000\t\000\000"

	.section	.rdata,"dr",one_only,alloc_91244a802f615a731e570cd82aa5f107,unique,43
	.p2align	3, 0x0
alloc_91244a802f615a731e570cd82aa5f107:
	.quad	alloc_24f4768e38f126368567621cf7f11fcd
	.asciz	" \000\000\000\000\000\000\000k\002\000\000\036\000\000"

	.section	.gfids$y,"dr"
	.symidx	__CxxFrameHandler3
	.section	.giats$y,"dr"
	.section	.gljmp$y,"dr"
