; ModuleID = 'numeric_ffi.db33e3d5a3958eec-cgu.0'
source_filename = "numeric_ffi.db33e3d5a3958eec-cgu.0"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc"

@alloc_a58958037699a75cd119e9baa74d93b4 = private unnamed_addr constant [94 x i8] c"D:\\Rustium\\.scratch\\net-wave1\\promote\\optimization\\before\\net\\base\\parse_number_native_ffi.rs\00", align 1, !guid !0
@alloc_f31ace42d833e4aa0828d2e955a5507b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_a58958037699a75cd119e9baa74d93b4, [16 x i8] c"]\00\00\00\00\00\00\00#\00\00\00\16\00\00\00" }>, align 8, !guid !1
@alloc_a28e8c8fd5088943a8b5d44af697ff83 = private unnamed_addr constant [279 x i8] c"unsafe precondition(s) violated: slice::from_raw_parts requires the pointer to be aligned and non-null, and the total size of the slice not to exceed `isize::MAX`\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !2

; Function Attrs: nounwind uwtable
define noundef zeroext i1 @rustium_parse_number_native_i32(ptr nofree noundef readonly captures(address) %input, i64 noundef %len, i32 noundef %format, ptr nofree noundef writeonly captures(none) %output, ptr nofree noundef writeonly captures(address_is_null) %error) unnamed_addr #0 personality ptr @__CxxFrameHandler3 !guid !7 {
start:
  %0 = icmp eq i64 %len, 0
  br i1 %0, label %bb2.i.thread, label %bb14.i

bb2.i.thread:                                     ; preds = %start
  %_11.i5.not = icmp eq ptr %error, null
  br i1 %_11.i5.not, label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchlNvCs4A2AHSyUD2M_17parse_number_core9parse_i32EB2_.exit, label %bb11.i

bb14.i:                                           ; preds = %start
  %_12.not.i = icmp ne ptr %input, null
  %_7.i = icmp sgt i64 %len, -1
  %or.cond.i = and i1 %_12.not.i, %_7.i
  br i1 %or.cond.i, label %bb5.i.i.i, label %bb5.i1, !prof !8

bb5.i1:                                           ; preds = %bb14.i
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_a28e8c8fd5088943a8b5d44af697ff83, ptr noundef nonnull inttoptr (i64 559 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_f31ace42d833e4aa0828d2e955a5507b) #3
  unreachable

bb5.i.i.i:                                        ; preds = %bb14.i
  %_11.i.not = icmp eq ptr %error, null
  %_11.i.i = getelementptr inbounds nuw i8, ptr %input, i64 %len
  %_16.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %input, i64 1
  %v.i.i.i.i = load i8, ptr %input, align 1, !alias.scope !9, !noalias !14, !noundef !19
  %1 = and i32 %format, -2
  %strict.sroa.0.0.i.i.i = icmp eq i32 %1, 2
  %negative.i.i.i = icmp eq i8 %v.i.i.i.i, 45
  %2 = add i8 %v.i.i.i.i, -48
  %or.cond.i.i.i = icmp ult i8 %2, 10
  br i1 %or.cond.i.i.i, label %bb15.i.i.i, label %bb10.i.i.i

bb10.i.i.i:                                       ; preds = %bb5.i.i.i
  br i1 %negative.i.i.i, label %switch.early.test.i.i.i, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread

switch.early.test.i.i.i:                          ; preds = %bb10.i.i.i
  switch i32 %format, label %bb12.i.i.i [
    i32 2, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread
    i32 0, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread
  ]

bb12.i.i.i:                                       ; preds = %switch.early.test.i.i.i
  %_6.i.i23.not.i.i.i = icmp samesign eq i64 %len, 1
  br i1 %_6.i.i23.not.i.i.i, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread, label %bb52.i.i.i

bb52.i.i.i:                                       ; preds = %bb12.i.i.i
  %_16.i.i26.i.i.i = getelementptr inbounds nuw i8, ptr %input, i64 2
  %v.i27.i.i.i = load i8, ptr %_16.i.i.i.i.i, align 1, !alias.scope !9, !noalias !20, !noundef !19
  br label %bb15.i.i.i

bb15.i.i.i:                                       ; preds = %bb52.i.i.i, %bb5.i.i.i
  %bytes.sroa.0.0.i.i.i = phi ptr [ %_16.i.i.i.i.i, %bb5.i.i.i ], [ %_16.i.i26.i.i.i, %bb52.i.i.i ]
  %first.sroa.0.0.i.i.i = phi i8 [ %v.i.i.i.i, %bb5.i.i.i ], [ %v.i27.i.i.i, %bb52.i.i.i ]
  %3 = icmp eq i8 %first.sroa.0.0.i.i.i, 48
  %or.cond4.i.i.i = and i1 %strict.sroa.0.0.i.i.i, %3
  br i1 %or.cond4.i.i.i, label %bb17.i.i.i, label %bb25.i.i.i

bb25.i.i.i:                                       ; preds = %bb15.i.i.i
  br i1 %3, label %bb28.i.i.i.preheader, label %bb34.i.i.i

bb28.i.i.i.preheader:                             ; preds = %bb25.i.i.i
  %_6.i.i39.not.i.i.i61 = icmp eq ptr %bytes.sroa.0.0.i.i.i, %_11.i.i
  br i1 %_6.i.i39.not.i.i.i61, label %bb6.i, label %bb30.i.i.i

bb17.i.i.i:                                       ; preds = %bb15.i.i.i
  %_6.i.i31.not.i.i.i = icmp ne ptr %bytes.sroa.0.0.i.i.i, %_11.i.i
  %or.cond103.not.i.i.i = select i1 %negative.i.i.i, i1 true, i1 %_6.i.i31.not.i.i.i
  br i1 %or.cond103.not.i.i.i, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread, label %bb6.i

bb28.i.i.i:                                       ; preds = %bb30.i.i.i
  %_6.i.i39.not.i.i.i = icmp eq ptr %_16.i.i42.i.i.i, %_11.i.i
  br i1 %_6.i.i39.not.i.i.i, label %bb6.i, label %bb30.i.i.i

bb30.i.i.i:                                       ; preds = %bb28.i.i.i.preheader, %bb28.i.i.i
  %bytes.sroa.0.1.i.i.i62 = phi ptr [ %_16.i.i42.i.i.i, %bb28.i.i.i ], [ %bytes.sroa.0.0.i.i.i, %bb28.i.i.i.preheader ]
  %_16.i.i42.i.i.i = getelementptr inbounds nuw i8, ptr %bytes.sroa.0.1.i.i.i62, i64 1
  %v.i43.i.i.i = load i8, ptr %bytes.sroa.0.1.i.i.i62, align 1, !alias.scope !9, !noalias !23, !noundef !19
  %4 = icmp eq i8 %v.i43.i.i.i, 48
  br i1 %4, label %bb28.i.i.i, label %bb34.i.i.i

bb34.i.i.i:                                       ; preds = %bb30.i.i.i, %bb25.i.i.i
  %bytes.sroa.0.2.i.i.i = phi ptr [ %bytes.sroa.0.0.i.i.i, %bb25.i.i.i ], [ %_16.i.i42.i.i.i, %bb30.i.i.i ]
  %first.sroa.0.1.i.i.i = phi i8 [ %first.sroa.0.0.i.i.i, %bb25.i.i.i ], [ %v.i43.i.i.i, %bb30.i.i.i ]
  %_28.i.i.i = add i8 %first.sroa.0.1.i.i.i, -48
  %digit.i.i.i = zext i8 %_28.i.i.i to i64
  %_29.i.i.i = icmp ugt i8 %_28.i.i.i, 9
  br i1 %_29.i.i.i, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread, label %bb36.i.i.i

bb36.i.i.i:                                       ; preds = %bb34.i.i.i
  %_6.i.i.not12.i46.i.i.i = icmp eq ptr %bytes.sroa.0.2.i.i.i, %_11.i.i
  br i1 %negative.i.i.i, label %bb37.i.i.i, label %bb38.i.i.i

bb38.i.i.i:                                       ; preds = %bb36.i.i.i
  br i1 %_6.i.i.not12.i46.i.i.i, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit, label %bb4.i.i.i.i

bb4.i.i.i.i:                                      ; preds = %bb38.i.i.i, %bb21.i.i.i.i
  %value.sroa.0.014.i.i.i.i = phi i64 [ %5, %bb21.i.i.i.i ], [ %digit.i.i.i, %bb38.i.i.i ]
  %bytes.sroa.0.013.i.i.i.i = phi ptr [ %_16.i.i.i.i.i.i, %bb21.i.i.i.i ], [ %bytes.sroa.0.2.i.i.i, %bb38.i.i.i ]
  %_16.i.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %bytes.sroa.0.013.i.i.i.i, i64 1
  %v.i.i.i.i.i = load i8, ptr %bytes.sroa.0.013.i.i.i.i, align 1, !alias.scope !9, !noalias !26, !noundef !19
  %_10.i.i.i.i = add i8 %v.i.i.i.i.i, -48
  %digit.i.i.i.i = zext nneg i8 %_10.i.i.i.i to i64
  %_11.i.i.i.i = icmp ugt i8 %_10.i.i.i.i, 9
  br i1 %_11.i.i.i.i, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread, label %bb7.i.i.i.i

bb7.i.i.i.i:                                      ; preds = %bb4.i.i.i.i
  %_12.i.i.i.i = icmp ugt i64 %value.sroa.0.014.i.i.i.i, 214748364
  br i1 %_12.i.i.i.i, label %bb12.i.i.i.i, label %bb9.i.i.i.i

bb9.i.i.i.i:                                      ; preds = %bb7.i.i.i.i
  %_15.i.i.i.i = icmp eq i64 %value.sroa.0.014.i.i.i.i, 214748364
  %_17.i.i.i.i = icmp samesign ugt i8 %_10.i.i.i.i, 7
  %or.cond.i.i.i.i = and i1 %_15.i.i.i.i, %_17.i.i.i.i
  br i1 %or.cond.i.i.i.i, label %bb12.i.i.i.i, label %bb21.i.i.i.i

bb21.i.i.i.i:                                     ; preds = %bb9.i.i.i.i
  %_21.i.i.i.i = mul nuw nsw i64 %value.sroa.0.014.i.i.i.i, 10
  %5 = add nuw nsw i64 %_21.i.i.i.i, %digit.i.i.i.i
  %_6.i.i.not.i.i.i.i = icmp eq ptr %_16.i.i.i.i.i.i, %_11.i.i
  br i1 %_6.i.i.not.i.i.i.i, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit, label %bb4.i.i.i.i

bb12.i.i.i.i:                                     ; preds = %bb9.i.i.i.i, %bb7.i.i.i.i
  br i1 %_11.i.not, label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchlNvCs4A2AHSyUD2M_17parse_number_core9parse_i32EB2_.exit, label %bb1.i.i.i.i.i.i.i.preheader

bb1.i.i.i.i.i.i.i.preheader:                      ; preds = %bb12.i.i.i.i
  %_6.i.not.not.not.i.not.not.not.i.not.i.i.i.i.i63 = icmp eq ptr %_16.i.i.i.i.i.i, %_11.i.i
  br i1 %_6.i.not.not.not.i.not.not.not.i.not.i.i.i.i.i63, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread, label %bb3.i.i.i.i.i.i.i

bb1.i.i.i.i.i.i.i:                                ; preds = %bb3.i.i.i.i.i.i.i
  %_16.i.i.i.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %_16.i6.i.i.i.i.i.i.i64, i64 1
  %_6.i.not.not.not.i.not.not.not.i.not.i.i.i.i.i = icmp eq ptr %_16.i.i.i.i.i.i.i.i, %_11.i.i
  br i1 %_6.i.not.not.not.i.not.not.not.i.not.i.i.i.i.i, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread, label %bb3.i.i.i.i.i.i.i

bb3.i.i.i.i.i.i.i:                                ; preds = %bb1.i.i.i.i.i.i.i.preheader, %bb1.i.i.i.i.i.i.i
  %_16.i6.i.i.i.i.i.i.i64 = phi ptr [ %_16.i.i.i.i.i.i.i.i, %bb1.i.i.i.i.i.i.i ], [ %_16.i.i.i.i.i.i, %bb1.i.i.i.i.i.i.i.preheader ]
  %.val.i.i.i.i.i.i.i = load i8, ptr %_16.i6.i.i.i.i.i.i.i64, align 1, !alias.scope !9, !noalias !31, !noundef !19
  %6 = add i8 %.val.i.i.i.i.i.i.i, -58
  %_0.sroa.0.0.i.i.i.i.i.i.i.i.i.i = icmp ult i8 %6, -10
  br i1 %_0.sroa.0.0.i.i.i.i.i.i.i.i.i.i, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread, label %bb1.i.i.i.i.i.i.i

bb37.i.i.i:                                       ; preds = %bb36.i.i.i
  br i1 %_6.i.i.not12.i46.i.i.i, label %bb5.thread51.i.i, label %bb4.i47.i.i.i

bb4.i47.i.i.i:                                    ; preds = %bb37.i.i.i, %bb21.i61.i.i.i
  %value.sroa.0.014.i48.i.i.i = phi i64 [ %7, %bb21.i61.i.i.i ], [ %digit.i.i.i, %bb37.i.i.i ]
  %bytes.sroa.0.013.i49.i.i.i = phi ptr [ %_16.i.i.i50.i.i.i, %bb21.i61.i.i.i ], [ %bytes.sroa.0.2.i.i.i, %bb37.i.i.i ]
  %_16.i.i.i50.i.i.i = getelementptr inbounds nuw i8, ptr %bytes.sroa.0.013.i49.i.i.i, i64 1
  %v.i.i51.i.i.i = load i8, ptr %bytes.sroa.0.013.i49.i.i.i, align 1, !alias.scope !9, !noalias !38, !noundef !19
  %_10.i52.i.i.i = add i8 %v.i.i51.i.i.i, -48
  %digit.i53.i.i.i = zext nneg i8 %_10.i52.i.i.i to i64
  %_11.i54.i.i.i = icmp ugt i8 %_10.i52.i.i.i, 9
  br i1 %_11.i54.i.i.i, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread, label %bb7.i55.i.i.i

bb7.i55.i.i.i:                                    ; preds = %bb4.i47.i.i.i
  %_12.i56.i.i.i = icmp ugt i64 %value.sroa.0.014.i48.i.i.i, 214748364
  br i1 %_12.i56.i.i.i, label %bb12.i67.i.i.i, label %bb9.i57.i.i.i

bb9.i57.i.i.i:                                    ; preds = %bb7.i55.i.i.i
  %_15.i58.i.i.i = icmp eq i64 %value.sroa.0.014.i48.i.i.i, 214748364
  %_17.i59.i.i.i = icmp eq i8 %_10.i52.i.i.i, 9
  %or.cond.i60.i.i.i = and i1 %_15.i58.i.i.i, %_17.i59.i.i.i
  br i1 %or.cond.i60.i.i.i, label %bb12.i67.i.i.i, label %bb21.i61.i.i.i

bb21.i61.i.i.i:                                   ; preds = %bb9.i57.i.i.i
  %_21.i62.i.i.i = mul nuw nsw i64 %value.sroa.0.014.i48.i.i.i, 10
  %7 = add nuw nsw i64 %_21.i62.i.i.i, %digit.i53.i.i.i
  %_6.i.i.not.i63.i.i.i = icmp eq ptr %_16.i.i.i50.i.i.i, %_11.i.i
  br i1 %_6.i.i.not.i63.i.i.i, label %bb5.thread51.i.i, label %bb4.i47.i.i.i

bb12.i67.i.i.i:                                   ; preds = %bb9.i57.i.i.i, %bb7.i55.i.i.i
  br i1 %_11.i.not, label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchlNvCs4A2AHSyUD2M_17parse_number_core9parse_i32EB2_.exit, label %bb1.i.i.i.i69.i.i.i.preheader

bb1.i.i.i.i69.i.i.i.preheader:                    ; preds = %bb12.i67.i.i.i
  %_6.i.not.not.not.i.not.not.not.i.not.i.i71.i.i.i66 = icmp eq ptr %_16.i.i.i50.i.i.i, %_11.i.i
  br i1 %_6.i.not.not.not.i.not.not.not.i.not.i.i71.i.i.i66, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread, label %bb3.i.i.i.i72.i.i.i

bb1.i.i.i.i69.i.i.i:                              ; preds = %bb3.i.i.i.i72.i.i.i
  %_16.i.i.i.i.i73.i.i.i = getelementptr inbounds nuw i8, ptr %_16.i6.i.i.i.i70.i.i.i67, i64 1
  %_6.i.not.not.not.i.not.not.not.i.not.i.i71.i.i.i = icmp eq ptr %_16.i.i.i.i.i73.i.i.i, %_11.i.i
  br i1 %_6.i.not.not.not.i.not.not.not.i.not.i.i71.i.i.i, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread, label %bb3.i.i.i.i72.i.i.i

bb3.i.i.i.i72.i.i.i:                              ; preds = %bb1.i.i.i.i69.i.i.i.preheader, %bb1.i.i.i.i69.i.i.i
  %_16.i6.i.i.i.i70.i.i.i67 = phi ptr [ %_16.i.i.i.i.i73.i.i.i, %bb1.i.i.i.i69.i.i.i ], [ %_16.i.i.i50.i.i.i, %bb1.i.i.i.i69.i.i.i.preheader ]
  %.val.i.i.i.i74.i.i.i = load i8, ptr %_16.i6.i.i.i.i70.i.i.i67, align 1, !alias.scope !9, !noalias !43, !noundef !19
  %8 = add i8 %.val.i.i.i.i74.i.i.i, -58
  %_0.sroa.0.0.i.i.i.i.i.i.i75.i.i.i = icmp ult i8 %8, -10
  br i1 %_0.sroa.0.0.i.i.i.i.i.i.i75.i.i.i, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread, label %bb1.i.i.i.i69.i.i.i

bb5.thread51.i.i:                                 ; preds = %bb21.i61.i.i.i, %bb37.i.i.i
  %_4.sroa.0.0.ph50.i.i = phi i64 [ %digit.i.i.i, %bb37.i.i.i ], [ %7, %bb21.i61.i.i.i ]
  %9 = sub nsw i64 0, %_4.sroa.0.0.ph50.i.i
  br label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit

_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread: ; preds = %bb4.i.i.i.i, %bb3.i.i.i.i.i.i.i, %bb1.i.i.i.i.i.i.i, %bb4.i47.i.i.i, %bb1.i.i.i.i69.i.i.i, %bb3.i.i.i.i72.i.i.i, %bb1.i.i.i.i.i.i.i.preheader, %bb1.i.i.i.i69.i.i.i.preheader, %switch.early.test.i.i.i, %switch.early.test.i.i.i, %bb10.i.i.i, %bb34.i.i.i, %bb17.i.i.i, %bb12.i.i.i
  %_0.sroa.3.0.insert.insert.i.i.ph = phi i32 [ 0, %bb1.i.i.i.i.i.i.i.preheader ], [ 0, %bb1.i.i.i.i.i.i.i ], [ 2, %bb34.i.i.i ], [ 2, %bb10.i.i.i ], [ 2, %bb3.i.i.i.i72.i.i.i ], [ 2, %switch.early.test.i.i.i ], [ 2, %switch.early.test.i.i.i ], [ 2, %bb12.i.i.i ], [ 2, %bb17.i.i.i ], [ 2, %bb4.i47.i.i.i ], [ 1, %bb1.i.i.i.i69.i.i.i.preheader ], [ 1, %bb1.i.i.i.i69.i.i.i ], [ 2, %bb3.i.i.i.i.i.i.i ], [ 2, %bb4.i.i.i.i ]
  br i1 %_11.i.not, label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchlNvCs4A2AHSyUD2M_17parse_number_core9parse_i32EB2_.exit, label %bb11.i

_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit: ; preds = %bb21.i.i.i.i, %bb38.i.i.i, %bb5.thread51.i.i
  %10 = phi i64 [ %9, %bb5.thread51.i.i ], [ %digit.i.i.i, %bb38.i.i.i ], [ %5, %bb21.i.i.i.i ]
  %11 = trunc i64 %10 to i32
  br label %bb6.i

bb6.i:                                            ; preds = %bb28.i.i.i, %bb28.i.i.i.preheader, %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit, %bb17.i.i.i
  %.sroa.6.0.extract.trunc.i = phi i32 [ %11, %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit ], [ 0, %bb17.i.i.i ], [ 0, %bb28.i.i.i.preheader ], [ 0, %bb28.i.i.i ]
  store i32 %.sroa.6.0.extract.trunc.i, ptr %output, align 4
  br label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchlNvCs4A2AHSyUD2M_17parse_number_core9parse_i32EB2_.exit

bb11.i:                                           ; preds = %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread, %bb2.i.thread
  %value.sroa.0.0.i = phi i32 [ 2, %bb2.i.thread ], [ %_0.sroa.3.0.insert.insert.i.i.ph, %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread ]
  store i32 %value.sroa.0.0.i, ptr %error, align 4
  br label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchlNvCs4A2AHSyUD2M_17parse_number_core9parse_i32EB2_.exit

_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchlNvCs4A2AHSyUD2M_17parse_number_core9parse_i32EB2_.exit: ; preds = %bb12.i67.i.i.i, %bb12.i.i.i.i, %bb2.i.thread, %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread, %bb6.i, %bb11.i
  %_0.sroa.0.0.i = phi i1 [ false, %bb2.i.thread ], [ true, %bb6.i ], [ false, %bb11.i ], [ false, %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread ], [ false, %bb12.i.i.i.i ], [ false, %bb12.i67.i.i.i ]
  ret i1 %_0.sroa.0.0.i
}

; Function Attrs: nounwind uwtable
define noundef zeroext i1 @rustium_parse_number_native_i64(ptr nofree noundef readonly captures(address) %input, i64 noundef %len, i32 noundef %format, ptr nofree noundef writeonly captures(none) %output, ptr nofree noundef writeonly captures(address_is_null) %error) unnamed_addr #0 personality ptr @__CxxFrameHandler3 !guid !50 {
start:
  %0 = icmp eq i64 %len, 0
  br i1 %0, label %bb2.i.thread, label %bb14.i

bb2.i.thread:                                     ; preds = %start
  %_11.i6.not = icmp eq ptr %error, null
  br i1 %_11.i6.not, label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchxNvCs4A2AHSyUD2M_17parse_number_core9parse_i64EB2_.exit, label %bb11.i

bb14.i:                                           ; preds = %start
  %_12.not.i = icmp ne ptr %input, null
  %_7.i = icmp sgt i64 %len, -1
  %or.cond.i = and i1 %_12.not.i, %_7.i
  br i1 %or.cond.i, label %bb5.i.i.i, label %bb5.i1, !prof !8

bb5.i1:                                           ; preds = %bb14.i
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_a28e8c8fd5088943a8b5d44af697ff83, ptr noundef nonnull inttoptr (i64 559 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_f31ace42d833e4aa0828d2e955a5507b) #3
  unreachable

bb5.i.i.i:                                        ; preds = %bb14.i
  %_11.i.not = icmp eq ptr %error, null
  %_10.i.i = getelementptr inbounds nuw i8, ptr %input, i64 %len
  %_16.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %input, i64 1
  %v.i.i.i.i = load i8, ptr %input, align 1, !alias.scope !51, !noalias !56, !noundef !19
  %1 = and i32 %format, -2
  %strict.sroa.0.0.i.i.i = icmp eq i32 %1, 2
  %negative.i.i.i = icmp eq i8 %v.i.i.i.i, 45
  %2 = add i8 %v.i.i.i.i, -48
  %or.cond.i.i.i = icmp ult i8 %2, 10
  br i1 %or.cond.i.i.i, label %bb15.i.i.i, label %bb10.i.i.i

bb10.i.i.i:                                       ; preds = %bb5.i.i.i
  br i1 %negative.i.i.i, label %switch.early.test.i.i.i, label %bb5.i

switch.early.test.i.i.i:                          ; preds = %bb10.i.i.i
  switch i32 %format, label %bb12.i.i.i [
    i32 2, label %bb5.i
    i32 0, label %bb5.i
  ]

bb12.i.i.i:                                       ; preds = %switch.early.test.i.i.i
  %_6.i.i23.not.i.i.i = icmp samesign eq i64 %len, 1
  br i1 %_6.i.i23.not.i.i.i, label %bb5.i, label %bb52.i.i.i

bb52.i.i.i:                                       ; preds = %bb12.i.i.i
  %_16.i.i26.i.i.i = getelementptr inbounds nuw i8, ptr %input, i64 2
  %v.i27.i.i.i = load i8, ptr %_16.i.i.i.i.i, align 1, !alias.scope !51, !noalias !61, !noundef !19
  br label %bb15.i.i.i

bb15.i.i.i:                                       ; preds = %bb52.i.i.i, %bb5.i.i.i
  %bytes.sroa.0.0.i.i.i = phi ptr [ %_16.i.i.i.i.i, %bb5.i.i.i ], [ %_16.i.i26.i.i.i, %bb52.i.i.i ]
  %first.sroa.0.0.i.i.i = phi i8 [ %v.i.i.i.i, %bb5.i.i.i ], [ %v.i27.i.i.i, %bb52.i.i.i ]
  %3 = icmp eq i8 %first.sroa.0.0.i.i.i, 48
  %or.cond4.i.i.i = and i1 %strict.sroa.0.0.i.i.i, %3
  br i1 %or.cond4.i.i.i, label %bb17.i.i.i, label %bb25.i.i.i

bb25.i.i.i:                                       ; preds = %bb15.i.i.i
  br i1 %3, label %bb28.i.i.i.preheader, label %bb34.i.i.i

bb28.i.i.i.preheader:                             ; preds = %bb25.i.i.i
  %_6.i.i39.not.i.i.i61 = icmp eq ptr %bytes.sroa.0.0.i.i.i, %_10.i.i
  br i1 %_6.i.i39.not.i.i.i61, label %bb6.i, label %bb30.i.i.i

bb17.i.i.i:                                       ; preds = %bb15.i.i.i
  %_6.i.i31.not.i.i.i = icmp ne ptr %bytes.sroa.0.0.i.i.i, %_10.i.i
  %or.cond103.not.i.i.i = select i1 %negative.i.i.i, i1 true, i1 %_6.i.i31.not.i.i.i
  br i1 %or.cond103.not.i.i.i, label %bb5.i, label %bb6.i

bb28.i.i.i:                                       ; preds = %bb30.i.i.i
  %_6.i.i39.not.i.i.i = icmp eq ptr %_16.i.i42.i.i.i, %_10.i.i
  br i1 %_6.i.i39.not.i.i.i, label %bb6.i, label %bb30.i.i.i

bb30.i.i.i:                                       ; preds = %bb28.i.i.i.preheader, %bb28.i.i.i
  %bytes.sroa.0.1.i.i.i62 = phi ptr [ %_16.i.i42.i.i.i, %bb28.i.i.i ], [ %bytes.sroa.0.0.i.i.i, %bb28.i.i.i.preheader ]
  %_16.i.i42.i.i.i = getelementptr inbounds nuw i8, ptr %bytes.sroa.0.1.i.i.i62, i64 1
  %v.i43.i.i.i = load i8, ptr %bytes.sroa.0.1.i.i.i62, align 1, !alias.scope !51, !noalias !64, !noundef !19
  %4 = icmp eq i8 %v.i43.i.i.i, 48
  br i1 %4, label %bb28.i.i.i, label %bb34.i.i.i

bb34.i.i.i:                                       ; preds = %bb30.i.i.i, %bb25.i.i.i
  %bytes.sroa.0.2.i.i.i = phi ptr [ %bytes.sroa.0.0.i.i.i, %bb25.i.i.i ], [ %_16.i.i42.i.i.i, %bb30.i.i.i ]
  %first.sroa.0.1.i.i.i = phi i8 [ %first.sroa.0.0.i.i.i, %bb25.i.i.i ], [ %v.i43.i.i.i, %bb30.i.i.i ]
  %_28.i.i.i = add i8 %first.sroa.0.1.i.i.i, -48
  %digit.i.i.i = zext i8 %_28.i.i.i to i64
  %_29.i.i.i = icmp ugt i8 %_28.i.i.i, 9
  br i1 %_29.i.i.i, label %bb5.i, label %bb36.i.i.i

bb36.i.i.i:                                       ; preds = %bb34.i.i.i
  %_6.i.i.not12.i46.i.i.i = icmp eq ptr %bytes.sroa.0.2.i.i.i, %_10.i.i
  br i1 %negative.i.i.i, label %bb37.i.i.i, label %bb38.i.i.i

bb38.i.i.i:                                       ; preds = %bb36.i.i.i
  br i1 %_6.i.i.not12.i46.i.i.i, label %bb6.i, label %bb4.i.i.i.i

bb4.i.i.i.i:                                      ; preds = %bb38.i.i.i, %bb21.i.i.i.i
  %value.sroa.0.014.i.i.i.i = phi i64 [ %5, %bb21.i.i.i.i ], [ %digit.i.i.i, %bb38.i.i.i ]
  %bytes.sroa.0.013.i.i.i.i = phi ptr [ %_16.i.i.i.i.i.i, %bb21.i.i.i.i ], [ %bytes.sroa.0.2.i.i.i, %bb38.i.i.i ]
  %_16.i.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %bytes.sroa.0.013.i.i.i.i, i64 1
  %v.i.i.i.i.i = load i8, ptr %bytes.sroa.0.013.i.i.i.i, align 1, !alias.scope !51, !noalias !67, !noundef !19
  %_10.i.i.i.i = add i8 %v.i.i.i.i.i, -48
  %digit.i.i.i.i = zext nneg i8 %_10.i.i.i.i to i64
  %_11.i.i.i.i = icmp ugt i8 %_10.i.i.i.i, 9
  br i1 %_11.i.i.i.i, label %bb5.i, label %bb7.i.i.i.i

bb7.i.i.i.i:                                      ; preds = %bb4.i.i.i.i
  %_12.i.i.i.i = icmp ugt i64 %value.sroa.0.014.i.i.i.i, 922337203685477580
  br i1 %_12.i.i.i.i, label %bb12.i.i.i.i, label %bb9.i.i.i.i

bb9.i.i.i.i:                                      ; preds = %bb7.i.i.i.i
  %_15.i.i.i.i = icmp eq i64 %value.sroa.0.014.i.i.i.i, 922337203685477580
  %_17.i.i.i.i = icmp samesign ugt i8 %_10.i.i.i.i, 7
  %or.cond.i.i.i.i = and i1 %_15.i.i.i.i, %_17.i.i.i.i
  br i1 %or.cond.i.i.i.i, label %bb12.i.i.i.i, label %bb21.i.i.i.i

bb21.i.i.i.i:                                     ; preds = %bb9.i.i.i.i
  %_21.i.i.i.i = mul nuw nsw i64 %value.sroa.0.014.i.i.i.i, 10
  %5 = add nuw i64 %_21.i.i.i.i, %digit.i.i.i.i
  %_6.i.i.not.i.i.i.i = icmp eq ptr %_16.i.i.i.i.i.i, %_10.i.i
  br i1 %_6.i.i.not.i.i.i.i, label %bb6.i, label %bb4.i.i.i.i

bb12.i.i.i.i:                                     ; preds = %bb9.i.i.i.i, %bb7.i.i.i.i
  br i1 %_11.i.not, label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchxNvCs4A2AHSyUD2M_17parse_number_core9parse_i64EB2_.exit, label %bb1.i.i.i.i.i.i.i.preheader

bb1.i.i.i.i.i.i.i.preheader:                      ; preds = %bb12.i.i.i.i
  %_6.i.not.not.not.i.not.not.not.i.not.i.i.i.i.i63 = icmp eq ptr %_16.i.i.i.i.i.i, %_10.i.i
  br i1 %_6.i.not.not.not.i.not.not.not.i.not.i.i.i.i.i63, label %bb5.i, label %bb3.i.i.i.i.i.i.i

bb1.i.i.i.i.i.i.i:                                ; preds = %bb3.i.i.i.i.i.i.i
  %_16.i.i.i.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %_16.i6.i.i.i.i.i.i.i64, i64 1
  %_6.i.not.not.not.i.not.not.not.i.not.i.i.i.i.i = icmp eq ptr %_16.i.i.i.i.i.i.i.i, %_10.i.i
  br i1 %_6.i.not.not.not.i.not.not.not.i.not.i.i.i.i.i, label %bb5.i, label %bb3.i.i.i.i.i.i.i

bb3.i.i.i.i.i.i.i:                                ; preds = %bb1.i.i.i.i.i.i.i.preheader, %bb1.i.i.i.i.i.i.i
  %_16.i6.i.i.i.i.i.i.i64 = phi ptr [ %_16.i.i.i.i.i.i.i.i, %bb1.i.i.i.i.i.i.i ], [ %_16.i.i.i.i.i.i, %bb1.i.i.i.i.i.i.i.preheader ]
  %.val.i.i.i.i.i.i.i = load i8, ptr %_16.i6.i.i.i.i.i.i.i64, align 1, !alias.scope !51, !noalias !72, !noundef !19
  %6 = add i8 %.val.i.i.i.i.i.i.i, -58
  %_0.sroa.0.0.i.i.i.i.i.i.i.i.i.i = icmp ult i8 %6, -10
  br i1 %_0.sroa.0.0.i.i.i.i.i.i.i.i.i.i, label %bb5.i, label %bb1.i.i.i.i.i.i.i

bb37.i.i.i:                                       ; preds = %bb36.i.i.i
  br i1 %_6.i.i.not12.i46.i.i.i, label %bb5.thread51.i.i, label %bb4.i47.i.i.i

bb4.i47.i.i.i:                                    ; preds = %bb37.i.i.i, %bb21.i61.i.i.i
  %value.sroa.0.014.i48.i.i.i = phi i64 [ %7, %bb21.i61.i.i.i ], [ %digit.i.i.i, %bb37.i.i.i ]
  %bytes.sroa.0.013.i49.i.i.i = phi ptr [ %_16.i.i.i50.i.i.i, %bb21.i61.i.i.i ], [ %bytes.sroa.0.2.i.i.i, %bb37.i.i.i ]
  %_16.i.i.i50.i.i.i = getelementptr inbounds nuw i8, ptr %bytes.sroa.0.013.i49.i.i.i, i64 1
  %v.i.i51.i.i.i = load i8, ptr %bytes.sroa.0.013.i49.i.i.i, align 1, !alias.scope !51, !noalias !79, !noundef !19
  %_10.i52.i.i.i = add i8 %v.i.i51.i.i.i, -48
  %digit.i53.i.i.i = zext nneg i8 %_10.i52.i.i.i to i64
  %_11.i54.i.i.i = icmp ugt i8 %_10.i52.i.i.i, 9
  br i1 %_11.i54.i.i.i, label %bb5.i, label %bb7.i55.i.i.i

bb7.i55.i.i.i:                                    ; preds = %bb4.i47.i.i.i
  %_12.i56.i.i.i = icmp ugt i64 %value.sroa.0.014.i48.i.i.i, 922337203685477580
  br i1 %_12.i56.i.i.i, label %bb12.i67.i.i.i, label %bb9.i57.i.i.i

bb9.i57.i.i.i:                                    ; preds = %bb7.i55.i.i.i
  %_15.i58.i.i.i = icmp eq i64 %value.sroa.0.014.i48.i.i.i, 922337203685477580
  %_17.i59.i.i.i = icmp eq i8 %_10.i52.i.i.i, 9
  %or.cond.i60.i.i.i = and i1 %_15.i58.i.i.i, %_17.i59.i.i.i
  br i1 %or.cond.i60.i.i.i, label %bb12.i67.i.i.i, label %bb21.i61.i.i.i

bb21.i61.i.i.i:                                   ; preds = %bb9.i57.i.i.i
  %_21.i62.i.i.i = mul nuw nsw i64 %value.sroa.0.014.i48.i.i.i, 10
  %7 = add nuw i64 %_21.i62.i.i.i, %digit.i53.i.i.i
  %_6.i.i.not.i63.i.i.i = icmp eq ptr %_16.i.i.i50.i.i.i, %_10.i.i
  br i1 %_6.i.i.not.i63.i.i.i, label %bb5.thread51.i.i, label %bb4.i47.i.i.i

bb12.i67.i.i.i:                                   ; preds = %bb9.i57.i.i.i, %bb7.i55.i.i.i
  br i1 %_11.i.not, label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchxNvCs4A2AHSyUD2M_17parse_number_core9parse_i64EB2_.exit, label %bb1.i.i.i.i69.i.i.i.preheader

bb1.i.i.i.i69.i.i.i.preheader:                    ; preds = %bb12.i67.i.i.i
  %_6.i.not.not.not.i.not.not.not.i.not.i.i71.i.i.i66 = icmp eq ptr %_16.i.i.i50.i.i.i, %_10.i.i
  br i1 %_6.i.not.not.not.i.not.not.not.i.not.i.i71.i.i.i66, label %bb5.i, label %bb3.i.i.i.i72.i.i.i

bb1.i.i.i.i69.i.i.i:                              ; preds = %bb3.i.i.i.i72.i.i.i
  %_16.i.i.i.i.i73.i.i.i = getelementptr inbounds nuw i8, ptr %_16.i6.i.i.i.i70.i.i.i67, i64 1
  %_6.i.not.not.not.i.not.not.not.i.not.i.i71.i.i.i = icmp eq ptr %_16.i.i.i.i.i73.i.i.i, %_10.i.i
  br i1 %_6.i.not.not.not.i.not.not.not.i.not.i.i71.i.i.i, label %bb5.i, label %bb3.i.i.i.i72.i.i.i

bb3.i.i.i.i72.i.i.i:                              ; preds = %bb1.i.i.i.i69.i.i.i.preheader, %bb1.i.i.i.i69.i.i.i
  %_16.i6.i.i.i.i70.i.i.i67 = phi ptr [ %_16.i.i.i.i.i73.i.i.i, %bb1.i.i.i.i69.i.i.i ], [ %_16.i.i.i50.i.i.i, %bb1.i.i.i.i69.i.i.i.preheader ]
  %.val.i.i.i.i74.i.i.i = load i8, ptr %_16.i6.i.i.i.i70.i.i.i67, align 1, !alias.scope !51, !noalias !84, !noundef !19
  %8 = add i8 %.val.i.i.i.i74.i.i.i, -58
  %_0.sroa.0.0.i.i.i.i.i.i.i75.i.i.i = icmp ult i8 %8, -10
  br i1 %_0.sroa.0.0.i.i.i.i.i.i.i75.i.i.i, label %bb5.i, label %bb1.i.i.i.i69.i.i.i

bb5.thread51.i.i:                                 ; preds = %bb21.i61.i.i.i, %bb37.i.i.i
  %_15.sroa.0.0.ph50.i.i = phi i64 [ %digit.i.i.i, %bb37.i.i.i ], [ %7, %bb21.i61.i.i.i ]
  %9 = sub i64 0, %_15.sroa.0.0.ph50.i.i
  br label %bb6.i

bb5.i:                                            ; preds = %bb4.i.i.i.i, %bb1.i.i.i.i.i.i.i, %bb3.i.i.i.i.i.i.i, %bb4.i47.i.i.i, %bb1.i.i.i.i69.i.i.i, %bb3.i.i.i.i72.i.i.i, %bb1.i.i.i.i.i.i.i.preheader, %bb1.i.i.i.i69.i.i.i.preheader, %bb10.i.i.i, %bb34.i.i.i, %bb17.i.i.i, %bb12.i.i.i, %switch.early.test.i.i.i, %switch.early.test.i.i.i
  %result.i.sroa.4.0.ph = phi i32 [ 2, %bb34.i.i.i ], [ 2, %switch.early.test.i.i.i ], [ 2, %bb10.i.i.i ], [ 2, %bb3.i.i.i.i.i.i.i ], [ 2, %switch.early.test.i.i.i ], [ 0, %bb1.i.i.i.i.i.i.i.preheader ], [ 2, %bb12.i.i.i ], [ 2, %bb17.i.i.i ], [ 2, %bb3.i.i.i.i72.i.i.i ], [ 2, %bb4.i47.i.i.i ], [ 1, %bb1.i.i.i.i69.i.i.i.preheader ], [ 1, %bb1.i.i.i.i69.i.i.i ], [ 0, %bb1.i.i.i.i.i.i.i ], [ 2, %bb4.i.i.i.i ]
  br i1 %_11.i.not, label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchxNvCs4A2AHSyUD2M_17parse_number_core9parse_i64EB2_.exit, label %bb11.i

bb6.i:                                            ; preds = %bb28.i.i.i, %bb21.i.i.i.i, %bb28.i.i.i.preheader, %bb17.i.i.i, %bb5.thread51.i.i, %bb38.i.i.i
  %result.i.sroa.63.0 = phi i64 [ 0, %bb17.i.i.i ], [ %digit.i.i.i, %bb38.i.i.i ], [ %9, %bb5.thread51.i.i ], [ 0, %bb28.i.i.i.preheader ], [ %5, %bb21.i.i.i.i ], [ 0, %bb28.i.i.i ]
  store i64 %result.i.sroa.63.0, ptr %output, align 8
  br label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchxNvCs4A2AHSyUD2M_17parse_number_core9parse_i64EB2_.exit

bb11.i:                                           ; preds = %bb5.i, %bb2.i.thread
  %value.sroa.0.0.i = phi i32 [ 2, %bb2.i.thread ], [ %result.i.sroa.4.0.ph, %bb5.i ]
  store i32 %value.sroa.0.0.i, ptr %error, align 4
  br label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchxNvCs4A2AHSyUD2M_17parse_number_core9parse_i64EB2_.exit

_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchxNvCs4A2AHSyUD2M_17parse_number_core9parse_i64EB2_.exit: ; preds = %bb12.i67.i.i.i, %bb12.i.i.i.i, %bb2.i.thread, %bb5.i, %bb6.i, %bb11.i
  %_0.sroa.0.0.i = phi i1 [ false, %bb5.i ], [ true, %bb6.i ], [ false, %bb11.i ], [ false, %bb2.i.thread ], [ false, %bb12.i.i.i.i ], [ false, %bb12.i67.i.i.i ]
  ret i1 %_0.sroa.0.0.i
}

; Function Attrs: nounwind uwtable
define noundef zeroext i1 @rustium_parse_number_native_u32(ptr nofree noundef readonly captures(address) %input, i64 noundef %len, i32 noundef %format, ptr nofree noundef writeonly captures(none) %output, ptr nofree noundef writeonly captures(address_is_null) %error) unnamed_addr #0 personality ptr @__CxxFrameHandler3 !guid !91 {
start:
  %0 = icmp eq i64 %len, 0
  br i1 %0, label %bb2.i.thread, label %bb14.i

bb2.i.thread:                                     ; preds = %start
  %_11.i5.not = icmp eq ptr %error, null
  br i1 %_11.i5.not, label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchmNvCs4A2AHSyUD2M_17parse_number_core9parse_u32EB2_.exit, label %bb11.i

bb14.i:                                           ; preds = %start
  %_12.not.i = icmp ne ptr %input, null
  %_7.i = icmp sgt i64 %len, -1
  %or.cond.i = and i1 %_12.not.i, %_7.i
  br i1 %or.cond.i, label %bb17.i.i.i, label %bb5.i1, !prof !8

bb5.i1:                                           ; preds = %bb14.i
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_a28e8c8fd5088943a8b5d44af697ff83, ptr noundef nonnull inttoptr (i64 559 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_f31ace42d833e4aa0828d2e955a5507b) #3
  unreachable

bb17.i.i.i:                                       ; preds = %bb14.i
  %_11.i.not = icmp eq ptr %error, null
  %_11.i.i = getelementptr inbounds nuw i8, ptr %input, i64 %len
  %_16.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %input, i64 1
  %v.i.i.i.i = load i8, ptr %input, align 1, !alias.scope !92, !noalias !97, !noundef !19
  %digit.i.i.i = add i8 %v.i.i.i.i, -48
  %_11.i.i.i = icmp ugt i8 %digit.i.i.i, 9
  br i1 %_11.i.i.i, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread, label %bb4.i.i.i

bb4.i.i.i:                                        ; preds = %bb17.i.i.i
  %_6.i.i = icmp eq i32 %format, 2
  %1 = icmp eq i8 %digit.i.i.i, 0
  %or.cond.i.i.i = and i1 %_6.i.i, %1
  br i1 %or.cond.i.i.i, label %bb6.i.i.i, label %bb11.i.i.i

bb11.i.i.i:                                       ; preds = %bb4.i.i.i
  %_15.i.i.i = zext nneg i8 %digit.i.i.i to i64
  %_6.i.i.not12.i.i.i.i = icmp samesign eq i64 %len, 1
  br i1 %_6.i.i.not12.i.i.i.i, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit, label %bb4.i.i.i.i

bb4.i.i.i.i:                                      ; preds = %bb11.i.i.i, %bb21.i.i.i.i
  %value.sroa.0.014.i.i.i.i = phi i64 [ %2, %bb21.i.i.i.i ], [ %_15.i.i.i, %bb11.i.i.i ]
  %bytes.sroa.0.013.i.i.i.i = phi ptr [ %_16.i.i.i.i.i.i, %bb21.i.i.i.i ], [ %_16.i.i.i.i.i, %bb11.i.i.i ]
  %_16.i.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %bytes.sroa.0.013.i.i.i.i, i64 1
  %v.i.i.i.i.i = load i8, ptr %bytes.sroa.0.013.i.i.i.i, align 1, !alias.scope !92, !noalias !102, !noundef !19
  %_10.i.i.i.i = add i8 %v.i.i.i.i.i, -48
  %digit.i.i.i.i = zext nneg i8 %_10.i.i.i.i to i64
  %_11.i.i.i.i = icmp ugt i8 %_10.i.i.i.i, 9
  br i1 %_11.i.i.i.i, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread, label %bb7.i.i.i.i

bb7.i.i.i.i:                                      ; preds = %bb4.i.i.i.i
  %_12.i.i.i.i = icmp ugt i64 %value.sroa.0.014.i.i.i.i, 429496729
  br i1 %_12.i.i.i.i, label %bb12.i.i.i.i, label %bb9.i.i.i.i

bb9.i.i.i.i:                                      ; preds = %bb7.i.i.i.i
  %_15.i.i.i.i = icmp eq i64 %value.sroa.0.014.i.i.i.i, 429496729
  %_17.i.i.i.i = icmp samesign ugt i8 %_10.i.i.i.i, 5
  %or.cond.i.i.i.i = and i1 %_15.i.i.i.i, %_17.i.i.i.i
  br i1 %or.cond.i.i.i.i, label %bb12.i.i.i.i, label %bb21.i.i.i.i

bb21.i.i.i.i:                                     ; preds = %bb9.i.i.i.i
  %_21.i.i.i.i = mul nuw nsw i64 %value.sroa.0.014.i.i.i.i, 10
  %2 = add nuw nsw i64 %_21.i.i.i.i, %digit.i.i.i.i
  %_6.i.i.not.i.i.i.i = icmp eq ptr %_16.i.i.i.i.i.i, %_11.i.i
  br i1 %_6.i.i.not.i.i.i.i, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit, label %bb4.i.i.i.i

bb12.i.i.i.i:                                     ; preds = %bb9.i.i.i.i, %bb7.i.i.i.i
  br i1 %_11.i.not, label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchmNvCs4A2AHSyUD2M_17parse_number_core9parse_u32EB2_.exit, label %bb1.i.i.i.i.i.i.i.preheader

bb1.i.i.i.i.i.i.i.preheader:                      ; preds = %bb12.i.i.i.i
  %_6.i.not.not.not.i.not.not.not.i.not.i.i.i.i.i38 = icmp eq ptr %_16.i.i.i.i.i.i, %_11.i.i
  br i1 %_6.i.not.not.not.i.not.not.not.i.not.i.i.i.i.i38, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread, label %bb3.i.i.i.i.i.i.i

bb1.i.i.i.i.i.i.i:                                ; preds = %bb3.i.i.i.i.i.i.i
  %_16.i.i.i.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %_16.i6.i.i.i.i.i.i.i39, i64 1
  %_6.i.not.not.not.i.not.not.not.i.not.i.i.i.i.i = icmp eq ptr %_16.i.i.i.i.i.i.i.i, %_11.i.i
  br i1 %_6.i.not.not.not.i.not.not.not.i.not.i.i.i.i.i, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread, label %bb3.i.i.i.i.i.i.i

bb3.i.i.i.i.i.i.i:                                ; preds = %bb1.i.i.i.i.i.i.i.preheader, %bb1.i.i.i.i.i.i.i
  %_16.i6.i.i.i.i.i.i.i39 = phi ptr [ %_16.i.i.i.i.i.i.i.i, %bb1.i.i.i.i.i.i.i ], [ %_16.i.i.i.i.i.i, %bb1.i.i.i.i.i.i.i.preheader ]
  %.val.i.i.i.i.i.i.i = load i8, ptr %_16.i6.i.i.i.i.i.i.i39, align 1, !alias.scope !92, !noalias !107, !noundef !19
  %3 = add i8 %.val.i.i.i.i.i.i.i, -58
  %_0.sroa.0.0.i.i.i.i.i.i.i.i.i.i = icmp ult i8 %3, -10
  br i1 %_0.sroa.0.0.i.i.i.i.i.i.i.i.i.i, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread, label %bb1.i.i.i.i.i.i.i

bb6.i.i.i:                                        ; preds = %bb4.i.i.i
  %_6.i.i7.not.i.i.i = icmp samesign eq i64 %len, 1
  br i1 %_6.i.i7.not.i.i.i, label %bb6.i, label %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread

_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread: ; preds = %bb4.i.i.i.i, %bb3.i.i.i.i.i.i.i, %bb1.i.i.i.i.i.i.i, %bb1.i.i.i.i.i.i.i.preheader, %bb17.i.i.i, %bb6.i.i.i
  %spec.select = phi i32 [ 0, %bb1.i.i.i.i.i.i.i.preheader ], [ 2, %bb17.i.i.i ], [ 2, %bb6.i.i.i ], [ 0, %bb1.i.i.i.i.i.i.i ], [ 2, %bb3.i.i.i.i.i.i.i ], [ 2, %bb4.i.i.i.i ]
  br i1 %_11.i.not, label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchmNvCs4A2AHSyUD2M_17parse_number_core9parse_u32EB2_.exit, label %bb11.i

_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit: ; preds = %bb21.i.i.i.i, %bb11.i.i.i
  %_16.sroa.112.0.i.i = phi i64 [ %_15.i.i.i, %bb11.i.i.i ], [ %2, %bb21.i.i.i.i ]
  %4 = trunc i64 %_16.sroa.112.0.i.i to i32
  br label %bb6.i

bb6.i:                                            ; preds = %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit, %bb6.i.i.i
  %.sroa.6.0.extract.trunc.i = phi i32 [ %4, %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit ], [ 0, %bb6.i.i.i ]
  store i32 %.sroa.6.0.extract.trunc.i, ptr %output, align 4
  br label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchmNvCs4A2AHSyUD2M_17parse_number_core9parse_u32EB2_.exit

bb11.i:                                           ; preds = %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread, %bb2.i.thread
  %value.sroa.0.0.i = phi i32 [ 2, %bb2.i.thread ], [ %spec.select, %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread ]
  store i32 %value.sroa.0.0.i, ptr %error, align 4
  br label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchmNvCs4A2AHSyUD2M_17parse_number_core9parse_u32EB2_.exit

_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchmNvCs4A2AHSyUD2M_17parse_number_core9parse_u32EB2_.exit: ; preds = %bb12.i.i.i.i, %bb2.i.thread, %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread, %bb6.i, %bb11.i
  %_0.sroa.0.0.i = phi i1 [ false, %bb12.i.i.i.i ], [ true, %bb6.i ], [ false, %bb11.i ], [ false, %_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi.exit.thread ], [ false, %bb2.i.thread ]
  ret i1 %_0.sroa.0.0.i
}

; Function Attrs: nounwind uwtable
define noundef zeroext i1 @rustium_parse_number_native_u64(ptr nofree noundef readonly captures(address) %input, i64 noundef %len, i32 noundef %format, ptr nofree noundef writeonly captures(none) %output, ptr nofree noundef writeonly captures(address_is_null) %error) unnamed_addr #0 personality ptr @__CxxFrameHandler3 !guid !114 {
start:
  %0 = icmp eq i64 %len, 0
  br i1 %0, label %bb16.i.i.i, label %bb14.i

bb14.i:                                           ; preds = %start
  %_12.not.i = icmp ne ptr %input, null
  %_7.i = icmp sgt i64 %len, -1
  %or.cond.i = and i1 %_12.not.i, %_7.i
  br i1 %or.cond.i, label %bb17.i.i.i, label %bb5.i1, !prof !8

bb5.i1:                                           ; preds = %bb14.i
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_a28e8c8fd5088943a8b5d44af697ff83, ptr noundef nonnull inttoptr (i64 559 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_f31ace42d833e4aa0828d2e955a5507b) #3
  unreachable

bb17.i.i.i:                                       ; preds = %bb14.i
  %_11.i.not = icmp eq ptr %error, null
  %_11.i.i = getelementptr inbounds nuw i8, ptr %input, i64 %len
  %_16.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %input, i64 1
  %v.i.i.i.i = load i8, ptr %input, align 1, !alias.scope !115, !noalias !120, !noundef !19
  %digit.i.i.i = add i8 %v.i.i.i.i, -48
  %_11.i.i.i = icmp ugt i8 %digit.i.i.i, 9
  br i1 %_11.i.i.i, label %bb5.i, label %bb4.i.i.i

bb16.i.i.i:                                       ; preds = %start
  %_11.i6.not = icmp eq ptr %error, null
  br i1 %_11.i6.not, label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchyNvCs4A2AHSyUD2M_17parse_number_core9parse_u64EB2_.exit, label %bb8.i

bb4.i.i.i:                                        ; preds = %bb17.i.i.i
  %_6.i.i = icmp eq i32 %format, 2
  %1 = icmp eq i8 %digit.i.i.i, 0
  %or.cond.i.i.i = and i1 %_6.i.i, %1
  br i1 %or.cond.i.i.i, label %bb6.i.i.i, label %bb11.i.i.i

bb11.i.i.i:                                       ; preds = %bb4.i.i.i
  %_15.i.i.i = zext nneg i8 %digit.i.i.i to i64
  %_6.i.i.not12.i.i.i.i = icmp samesign eq i64 %len, 1
  br i1 %_6.i.i.not12.i.i.i.i, label %bb6.i, label %bb4.i.i.i.i

bb4.i.i.i.i:                                      ; preds = %bb11.i.i.i, %bb21.i.i.i.i
  %value.sroa.0.014.i.i.i.i = phi i64 [ %2, %bb21.i.i.i.i ], [ %_15.i.i.i, %bb11.i.i.i ]
  %bytes.sroa.0.013.i.i.i.i = phi ptr [ %_16.i.i.i.i.i.i, %bb21.i.i.i.i ], [ %_16.i.i.i.i.i, %bb11.i.i.i ]
  %_16.i.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %bytes.sroa.0.013.i.i.i.i, i64 1
  %v.i.i.i.i.i = load i8, ptr %bytes.sroa.0.013.i.i.i.i, align 1, !alias.scope !115, !noalias !125, !noundef !19
  %_10.i.i.i.i = add i8 %v.i.i.i.i.i, -48
  %digit.i.i.i.i = zext nneg i8 %_10.i.i.i.i to i64
  %_11.i.i.i.i = icmp ugt i8 %_10.i.i.i.i, 9
  br i1 %_11.i.i.i.i, label %bb5.i, label %bb7.i.i.i.i

bb7.i.i.i.i:                                      ; preds = %bb4.i.i.i.i
  %_12.i.i.i.i = icmp ugt i64 %value.sroa.0.014.i.i.i.i, 1844674407370955161
  br i1 %_12.i.i.i.i, label %bb12.i.i.i.i, label %bb9.i.i.i.i

bb9.i.i.i.i:                                      ; preds = %bb7.i.i.i.i
  %_15.i.i.i.i = icmp eq i64 %value.sroa.0.014.i.i.i.i, 1844674407370955161
  %_17.i.i.i.i = icmp samesign ugt i8 %_10.i.i.i.i, 5
  %or.cond.i.i.i.i = and i1 %_15.i.i.i.i, %_17.i.i.i.i
  br i1 %or.cond.i.i.i.i, label %bb12.i.i.i.i, label %bb21.i.i.i.i

bb21.i.i.i.i:                                     ; preds = %bb9.i.i.i.i
  %_21.i.i.i.i = mul nuw i64 %value.sroa.0.014.i.i.i.i, 10
  %2 = add i64 %_21.i.i.i.i, %digit.i.i.i.i
  %_6.i.i.not.i.i.i.i = icmp eq ptr %_16.i.i.i.i.i.i, %_11.i.i
  br i1 %_6.i.i.not.i.i.i.i, label %bb6.i, label %bb4.i.i.i.i

bb12.i.i.i.i:                                     ; preds = %bb9.i.i.i.i, %bb7.i.i.i.i
  br i1 %_11.i.not, label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchyNvCs4A2AHSyUD2M_17parse_number_core9parse_u64EB2_.exit, label %bb1.i.i.i.i.i.i.i.preheader

bb1.i.i.i.i.i.i.i.preheader:                      ; preds = %bb12.i.i.i.i
  %_6.i.not.not.not.i.not.not.not.i.not.i.i.i.i.i34 = icmp eq ptr %_16.i.i.i.i.i.i, %_11.i.i
  br i1 %_6.i.not.not.not.i.not.not.not.i.not.i.i.i.i.i34, label %bb5.i, label %bb3.i.i.i.i.i.i.i

bb3.i.i.i.i.i.i.i:                                ; preds = %bb3.i.i.i.i.i.i.i, %bb1.i.i.i.i.i.i.i.preheader
  %_16.i6.i.i.i.i.i.i.i35 = phi ptr [ %_16.i.i.i.i.i.i.i.i, %bb3.i.i.i.i.i.i.i ], [ %_16.i.i.i.i.i.i, %bb1.i.i.i.i.i.i.i.preheader ]
  %.val.i.i.i.i.i.i.i = load i8, ptr %_16.i6.i.i.i.i.i.i.i35, align 1, !alias.scope !115, !noalias !130, !noundef !19
  %3 = add i8 %.val.i.i.i.i.i.i.i, -48
  %_0.sroa.0.0.i.i.i.i.i.i.i.i.i.i = icmp ult i8 %3, 10
  %_0.sroa.0.0.i.i.i.i.i.i.i.i.i.i.not = xor i1 %_0.sroa.0.0.i.i.i.i.i.i.i.i.i.i, true
  %_16.i.i.i.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %_16.i6.i.i.i.i.i.i.i35, i64 1
  %_6.i.not.not.not.i.not.not.not.i.not.i.i.i.i.i = icmp eq ptr %_16.i.i.i.i.i.i.i.i, %_11.i.i
  %or.cond = select i1 %_0.sroa.0.0.i.i.i.i.i.i.i.i.i.i.not, i1 true, i1 %_6.i.not.not.not.i.not.not.not.i.not.i.i.i.i.i
  br i1 %or.cond, label %bb5.i, label %bb3.i.i.i.i.i.i.i

bb6.i.i.i:                                        ; preds = %bb4.i.i.i
  %_6.i.i7.not.i.i.i = icmp samesign eq i64 %len, 1
  br i1 %_6.i.i7.not.i.i.i, label %bb6.i, label %bb8.i.i.i

bb8.i.i.i:                                        ; preds = %bb6.i.i.i
  br i1 %_11.i.not, label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchyNvCs4A2AHSyUD2M_17parse_number_core9parse_u64EB2_.exit, label %bb8.i

bb5.i:                                            ; preds = %bb4.i.i.i.i, %bb3.i.i.i.i.i.i.i, %bb1.i.i.i.i.i.i.i.preheader, %bb17.i.i.i
  %4 = phi i1 [ false, %bb17.i.i.i ], [ %_0.sroa.0.0.i.i.i.i.i.i.i.i.i.i, %bb3.i.i.i.i.i.i.i ], [ true, %bb1.i.i.i.i.i.i.i.preheader ], [ false, %bb4.i.i.i.i ]
  br i1 %_11.i.not, label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchyNvCs4A2AHSyUD2M_17parse_number_core9parse_u64EB2_.exit, label %bb7.i

bb6.i:                                            ; preds = %bb21.i.i.i.i, %bb11.i.i.i, %bb6.i.i.i
  %result.i.sroa.113.0 = phi i64 [ 0, %bb6.i.i.i ], [ %_15.i.i.i, %bb11.i.i.i ], [ %2, %bb21.i.i.i.i ]
  store i64 %result.i.sroa.113.0, ptr %output, align 8
  br label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchyNvCs4A2AHSyUD2M_17parse_number_core9parse_u64EB2_.exit

bb7.i:                                            ; preds = %bb5.i
  br i1 %4, label %bb11.i, label %bb8.i

bb8.i:                                            ; preds = %bb7.i, %bb16.i.i.i, %bb8.i.i.i
  br label %bb11.i

bb11.i:                                           ; preds = %bb7.i, %bb8.i
  %value.sroa.0.0.i = phi i32 [ 2, %bb8.i ], [ 0, %bb7.i ]
  store i32 %value.sroa.0.0.i, ptr %error, align 4
  br label %_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchyNvCs4A2AHSyUD2M_17parse_number_core9parse_u64EB2_.exit

_RINvCsiOOgJ5cnKHw_11numeric_ffi8dispatchyNvCs4A2AHSyUD2M_17parse_number_core9parse_u64EB2_.exit: ; preds = %bb12.i.i.i.i, %bb16.i.i.i, %bb8.i.i.i, %bb5.i, %bb6.i, %bb11.i
  %_0.sroa.0.0.i = phi i1 [ false, %bb5.i ], [ true, %bb6.i ], [ false, %bb11.i ], [ false, %bb16.i.i.i ], [ false, %bb8.i.i.i ], [ false, %bb12.i.i.i.i ]
  ret i1 %_0.sroa.0.0.i
}

declare i32 @__CxxFrameHandler3(...) unnamed_addr #1

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind uwtable
declare void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull, ptr noundef nonnull, i1 noundef zeroext, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #2

attributes #0 = { nounwind uwtable "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #1 = { "target-cpu"="x86-64" }
attributes #2 = { cold noinline noreturn nounwind uwtable "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #3 = { noreturn nounwind }

!llvm.module.flags = !{!3, !4, !5}
!llvm.ident = !{!6}

!0 = !{i64 8749209283468254370}
!1 = !{i64 -770623746013266748}
!2 = !{i64 2826628553247914406}
!3 = !{i32 8, !"PIC Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{i32 2, !"cfguard", i32 2}
!6 = !{!"rustc version 1.101.0-nightly (41b321963 2026-10-29) (96a18bf5ffa2b24f9cf3d1c731a9eb121c1acad9-4-llvmorg-24-init-17044-gc3223914 chromium)"}
!7 = !{i64 8319556262770079865}
!8 = !{!"branch_weights", i32 -294967296, i32 6003000}
!9 = !{!10, !12}
!10 = distinct !{!10, !11, !"_RNvCs4A2AHSyUD2M_17parse_number_core9parse_i32: %input.0"}
!11 = distinct !{!11, i1 true, !"_RNvCs4A2AHSyUD2M_17parse_number_core9parse_i32"}
!12 = distinct !{!12, !13, !"_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi: argument 0"}
!13 = distinct !{!13, i1 true, !"_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi"}
!14 = !{!15, !17}
!15 = distinct !{!15, !16, !"_RNvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB4_6CopiedINtNtNtBa_5slice4iter4IterhEENtNtNtB8_6traits8iterator8Iterator4nextCsiOOgJ5cnKHw_11numeric_ffi: %self"}
!16 = distinct !{!16, i1 true, !"_RNvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB4_6CopiedINtNtNtBa_5slice4iter4IterhEENtNtNtB8_6traits8iterator8Iterator4nextCsiOOgJ5cnKHw_11numeric_ffi"}
!17 = distinct !{!17, !18, !"_RINvCs4A2AHSyUD2M_17parse_number_core5parseKy7fffffff_Ky80000000_INtNtNtNtCs9l4wcBNbII5_4core4iter8adapters6copied6CopiedINtNtNtB1a_5slice4iter4IterhEEECsiOOgJ5cnKHw_11numeric_ffi: %_0"}
!18 = distinct !{!18, i1 true, !"_RINvCs4A2AHSyUD2M_17parse_number_core5parseKy7fffffff_Ky80000000_INtNtNtNtCs9l4wcBNbII5_4core4iter8adapters6copied6CopiedINtNtNtB1a_5slice4iter4IterhEEECsiOOgJ5cnKHw_11numeric_ffi"}
!19 = !{}
!20 = !{!21, !17}
!21 = distinct !{!21, !22, !"_RNvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB4_6CopiedINtNtNtBa_5slice4iter4IterhEENtNtNtB8_6traits8iterator8Iterator4nextCsiOOgJ5cnKHw_11numeric_ffi: %self"}
!22 = distinct !{!22, i1 true, !"_RNvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB4_6CopiedINtNtNtBa_5slice4iter4IterhEENtNtNtB8_6traits8iterator8Iterator4nextCsiOOgJ5cnKHw_11numeric_ffi"}
!23 = !{!24, !17}
!24 = distinct !{!24, !25, !"_RNvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB4_6CopiedINtNtNtBa_5slice4iter4IterhEENtNtNtB8_6traits8iterator8Iterator4nextCsiOOgJ5cnKHw_11numeric_ffi: %self"}
!25 = distinct !{!25, i1 true, !"_RNvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB4_6CopiedINtNtNtBa_5slice4iter4IterhEENtNtNtB8_6traits8iterator8Iterator4nextCsiOOgJ5cnKHw_11numeric_ffi"}
!26 = !{!27, !29, !17}
!27 = distinct !{!27, !28, !"_RNvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB4_6CopiedINtNtNtBa_5slice4iter4IterhEENtNtNtB8_6traits8iterator8Iterator4nextCsiOOgJ5cnKHw_11numeric_ffi: %self"}
!28 = distinct !{!28, i1 true, !"_RNvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB4_6CopiedINtNtNtBa_5slice4iter4IterhEENtNtNtB8_6traits8iterator8Iterator4nextCsiOOgJ5cnKHw_11numeric_ffi"}
!29 = distinct !{!29, !30, !"_RINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy7fffffff_INtNtNtNtCs9l4wcBNbII5_4core4iter8adapters6copied6CopiedINtNtNtB15_5slice4iter4IterhEEECsiOOgJ5cnKHw_11numeric_ffi: %_0"}
!30 = distinct !{!30, i1 true, !"_RINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy7fffffff_INtNtNtNtCs9l4wcBNbII5_4core4iter8adapters6copied6CopiedINtNtNtB15_5slice4iter4IterhEEECsiOOgJ5cnKHw_11numeric_ffi"}
!31 = !{!32, !34, !36, !29, !17}
!32 = distinct !{!32, !33, !"_RINvYINtNtNtCs9l4wcBNbII5_4core5slice4iter4IterhENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNtNtBR_8adapters6copied13copy_try_foldhuINtNtNtBa_3ops12control_flow11ControlFlowuENCINvNvBL_3all5checkhNCINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy7fffffff_INtB1F_6CopiedB3_EE0E0E0B2j_ECsiOOgJ5cnKHw_11numeric_ffi: %self"}
!33 = distinct !{!33, i1 true, !"_RINvYINtNtNtCs9l4wcBNbII5_4core5slice4iter4IterhENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNtNtBR_8adapters6copied13copy_try_foldhuINtNtNtBa_3ops12control_flow11ControlFlowuENCINvNvBL_3all5checkhNCINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy7fffffff_INtB1F_6CopiedB3_EE0E0E0B2j_ECsiOOgJ5cnKHw_11numeric_ffi"}
!34 = distinct !{!34, !35, !"_RINvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB5_6CopiedINtNtNtBb_5slice4iter4IterhEENtNtNtB9_6traits8iterator8Iterator8try_folduNCINvNvB1v_3all5checkhNCINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy7fffffff_BP_E0E0INtNtNtBb_3ops12control_flow11ControlFlowuEECsiOOgJ5cnKHw_11numeric_ffi: %self"}
!35 = distinct !{!35, i1 true, !"_RINvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB5_6CopiedINtNtNtBb_5slice4iter4IterhEENtNtNtB9_6traits8iterator8Iterator8try_folduNCINvNvB1v_3all5checkhNCINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy7fffffff_BP_E0E0INtNtNtBb_3ops12control_flow11ControlFlowuEECsiOOgJ5cnKHw_11numeric_ffi"}
!36 = distinct !{!36, !37, !"_RINvYINtNtNtNtCs9l4wcBNbII5_4core4iter8adapters6copied6CopiedINtNtNtBc_5slice4iter4IterhEENtNtNtBa_6traits8iterator8Iterator3allNCINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy7fffffff_B3_E0ECsiOOgJ5cnKHw_11numeric_ffi: %self"}
!37 = distinct !{!37, i1 true, !"_RINvYINtNtNtNtCs9l4wcBNbII5_4core4iter8adapters6copied6CopiedINtNtNtBc_5slice4iter4IterhEENtNtNtBa_6traits8iterator8Iterator3allNCINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy7fffffff_B3_E0ECsiOOgJ5cnKHw_11numeric_ffi"}
!38 = !{!39, !41, !17}
!39 = distinct !{!39, !40, !"_RNvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB4_6CopiedINtNtNtBa_5slice4iter4IterhEENtNtNtB8_6traits8iterator8Iterator4nextCsiOOgJ5cnKHw_11numeric_ffi: %self"}
!40 = distinct !{!40, i1 true, !"_RNvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB4_6CopiedINtNtNtBa_5slice4iter4IterhEENtNtNtB8_6traits8iterator8Iterator4nextCsiOOgJ5cnKHw_11numeric_ffi"}
!41 = distinct !{!41, !42, !"_RINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy80000000_INtNtNtNtCs9l4wcBNbII5_4core4iter8adapters6copied6CopiedINtNtNtB15_5slice4iter4IterhEEECsiOOgJ5cnKHw_11numeric_ffi: %_0"}
!42 = distinct !{!42, i1 true, !"_RINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy80000000_INtNtNtNtCs9l4wcBNbII5_4core4iter8adapters6copied6CopiedINtNtNtB15_5slice4iter4IterhEEECsiOOgJ5cnKHw_11numeric_ffi"}
!43 = !{!44, !46, !48, !41, !17}
!44 = distinct !{!44, !45, !"_RINvYINtNtNtCs9l4wcBNbII5_4core5slice4iter4IterhENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNtNtBR_8adapters6copied13copy_try_foldhuINtNtNtBa_3ops12control_flow11ControlFlowuENCINvNvBL_3all5checkhNCINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy80000000_INtB1F_6CopiedB3_EE0E0E0B2j_ECsiOOgJ5cnKHw_11numeric_ffi: %self"}
!45 = distinct !{!45, i1 true, !"_RINvYINtNtNtCs9l4wcBNbII5_4core5slice4iter4IterhENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNtNtBR_8adapters6copied13copy_try_foldhuINtNtNtBa_3ops12control_flow11ControlFlowuENCINvNvBL_3all5checkhNCINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy80000000_INtB1F_6CopiedB3_EE0E0E0B2j_ECsiOOgJ5cnKHw_11numeric_ffi"}
!46 = distinct !{!46, !47, !"_RINvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB5_6CopiedINtNtNtBb_5slice4iter4IterhEENtNtNtB9_6traits8iterator8Iterator8try_folduNCINvNvB1v_3all5checkhNCINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy80000000_BP_E0E0INtNtNtBb_3ops12control_flow11ControlFlowuEECsiOOgJ5cnKHw_11numeric_ffi: %self"}
!47 = distinct !{!47, i1 true, !"_RINvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB5_6CopiedINtNtNtBb_5slice4iter4IterhEENtNtNtB9_6traits8iterator8Iterator8try_folduNCINvNvB1v_3all5checkhNCINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy80000000_BP_E0E0INtNtNtBb_3ops12control_flow11ControlFlowuEECsiOOgJ5cnKHw_11numeric_ffi"}
!48 = distinct !{!48, !49, !"_RINvYINtNtNtNtCs9l4wcBNbII5_4core4iter8adapters6copied6CopiedINtNtNtBc_5slice4iter4IterhEENtNtNtBa_6traits8iterator8Iterator3allNCINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy80000000_B3_E0ECsiOOgJ5cnKHw_11numeric_ffi: %self"}
!49 = distinct !{!49, i1 true, !"_RINvYINtNtNtNtCs9l4wcBNbII5_4core4iter8adapters6copied6CopiedINtNtNtBc_5slice4iter4IterhEENtNtNtBa_6traits8iterator8Iterator3allNCINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy80000000_B3_E0ECsiOOgJ5cnKHw_11numeric_ffi"}
!50 = !{i64 6076576142214827742}
!51 = !{!52, !54}
!52 = distinct !{!52, !53, !"_RNvCs4A2AHSyUD2M_17parse_number_core9parse_i64: %input.0"}
!53 = distinct !{!53, i1 true, !"_RNvCs4A2AHSyUD2M_17parse_number_core9parse_i64"}
!54 = distinct !{!54, !55, !"_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i64INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi: argument 1"}
!55 = distinct !{!55, i1 true, !"_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_i64INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi"}
!56 = !{!57, !59}
!57 = distinct !{!57, !58, !"_RNvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB4_6CopiedINtNtNtBa_5slice4iter4IterhEENtNtNtB8_6traits8iterator8Iterator4nextCsiOOgJ5cnKHw_11numeric_ffi: %self"}
!58 = distinct !{!58, i1 true, !"_RNvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB4_6CopiedINtNtNtBa_5slice4iter4IterhEENtNtNtB8_6traits8iterator8Iterator4nextCsiOOgJ5cnKHw_11numeric_ffi"}
!59 = distinct !{!59, !60, !"_RINvCs4A2AHSyUD2M_17parse_number_core5parseKy7fffffffffffffff_Ky8000000000000000_INtNtNtNtCs9l4wcBNbII5_4core4iter8adapters6copied6CopiedINtNtNtB1q_5slice4iter4IterhEEECsiOOgJ5cnKHw_11numeric_ffi: %_0"}
!60 = distinct !{!60, i1 true, !"_RINvCs4A2AHSyUD2M_17parse_number_core5parseKy7fffffffffffffff_Ky8000000000000000_INtNtNtNtCs9l4wcBNbII5_4core4iter8adapters6copied6CopiedINtNtNtB1q_5slice4iter4IterhEEECsiOOgJ5cnKHw_11numeric_ffi"}
!61 = !{!62, !59}
!62 = distinct !{!62, !63, !"_RNvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB4_6CopiedINtNtNtBa_5slice4iter4IterhEENtNtNtB8_6traits8iterator8Iterator4nextCsiOOgJ5cnKHw_11numeric_ffi: %self"}
!63 = distinct !{!63, i1 true, !"_RNvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB4_6CopiedINtNtNtBa_5slice4iter4IterhEENtNtNtB8_6traits8iterator8Iterator4nextCsiOOgJ5cnKHw_11numeric_ffi"}
!64 = !{!65, !59}
!65 = distinct !{!65, !66, !"_RNvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB4_6CopiedINtNtNtBa_5slice4iter4IterhEENtNtNtB8_6traits8iterator8Iterator4nextCsiOOgJ5cnKHw_11numeric_ffi: %self"}
!66 = distinct !{!66, i1 true, !"_RNvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB4_6CopiedINtNtNtBa_5slice4iter4IterhEENtNtNtB8_6traits8iterator8Iterator4nextCsiOOgJ5cnKHw_11numeric_ffi"}
!67 = !{!68, !70, !59}
!68 = distinct !{!68, !69, !"_RNvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB4_6CopiedINtNtNtBa_5slice4iter4IterhEENtNtNtB8_6traits8iterator8Iterator4nextCsiOOgJ5cnKHw_11numeric_ffi: %self"}
!69 = distinct !{!69, i1 true, !"_RNvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB4_6CopiedINtNtNtBa_5slice4iter4IterhEENtNtNtB8_6traits8iterator8Iterator4nextCsiOOgJ5cnKHw_11numeric_ffi"}
!70 = distinct !{!70, !71, !"_RINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy7fffffffffffffff_INtNtNtNtCs9l4wcBNbII5_4core4iter8adapters6copied6CopiedINtNtNtB1d_5slice4iter4IterhEEECsiOOgJ5cnKHw_11numeric_ffi: %_0"}
!71 = distinct !{!71, i1 true, !"_RINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy7fffffffffffffff_INtNtNtNtCs9l4wcBNbII5_4core4iter8adapters6copied6CopiedINtNtNtB1d_5slice4iter4IterhEEECsiOOgJ5cnKHw_11numeric_ffi"}
!72 = !{!73, !75, !77, !70, !59}
!73 = distinct !{!73, !74, !"_RINvYINtNtNtCs9l4wcBNbII5_4core5slice4iter4IterhENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNtNtBR_8adapters6copied13copy_try_foldhuINtNtNtBa_3ops12control_flow11ControlFlowuENCINvNvBL_3all5checkhNCINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy7fffffffffffffff_INtB1F_6CopiedB3_EE0E0E0B2j_ECsiOOgJ5cnKHw_11numeric_ffi: %self"}
!74 = distinct !{!74, i1 true, !"_RINvYINtNtNtCs9l4wcBNbII5_4core5slice4iter4IterhENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNtNtBR_8adapters6copied13copy_try_foldhuINtNtNtBa_3ops12control_flow11ControlFlowuENCINvNvBL_3all5checkhNCINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy7fffffffffffffff_INtB1F_6CopiedB3_EE0E0E0B2j_ECsiOOgJ5cnKHw_11numeric_ffi"}
!75 = distinct !{!75, !76, !"_RINvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB5_6CopiedINtNtNtBb_5slice4iter4IterhEENtNtNtB9_6traits8iterator8Iterator8try_folduNCINvNvB1v_3all5checkhNCINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy7fffffffffffffff_BP_E0E0INtNtNtBb_3ops12control_flow11ControlFlowuEECsiOOgJ5cnKHw_11numeric_ffi: %self"}
!76 = distinct !{!76, i1 true, !"_RINvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB5_6CopiedINtNtNtBb_5slice4iter4IterhEENtNtNtB9_6traits8iterator8Iterator8try_folduNCINvNvB1v_3all5checkhNCINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy7fffffffffffffff_BP_E0E0INtNtNtBb_3ops12control_flow11ControlFlowuEECsiOOgJ5cnKHw_11numeric_ffi"}
!77 = distinct !{!77, !78, !"_RINvYINtNtNtNtCs9l4wcBNbII5_4core4iter8adapters6copied6CopiedINtNtNtBc_5slice4iter4IterhEENtNtNtBa_6traits8iterator8Iterator3allNCINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy7fffffffffffffff_B3_E0ECsiOOgJ5cnKHw_11numeric_ffi: %self"}
!78 = distinct !{!78, i1 true, !"_RINvYINtNtNtNtCs9l4wcBNbII5_4core4iter8adapters6copied6CopiedINtNtNtBc_5slice4iter4IterhEENtNtNtBa_6traits8iterator8Iterator3allNCINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy7fffffffffffffff_B3_E0ECsiOOgJ5cnKHw_11numeric_ffi"}
!79 = !{!80, !82, !59}
!80 = distinct !{!80, !81, !"_RNvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB4_6CopiedINtNtNtBa_5slice4iter4IterhEENtNtNtB8_6traits8iterator8Iterator4nextCsiOOgJ5cnKHw_11numeric_ffi: %self"}
!81 = distinct !{!81, i1 true, !"_RNvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB4_6CopiedINtNtNtBa_5slice4iter4IterhEENtNtNtB8_6traits8iterator8Iterator4nextCsiOOgJ5cnKHw_11numeric_ffi"}
!82 = distinct !{!82, !83, !"_RINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy8000000000000000_INtNtNtNtCs9l4wcBNbII5_4core4iter8adapters6copied6CopiedINtNtNtB1d_5slice4iter4IterhEEECsiOOgJ5cnKHw_11numeric_ffi: %_0"}
!83 = distinct !{!83, i1 true, !"_RINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy8000000000000000_INtNtNtNtCs9l4wcBNbII5_4core4iter8adapters6copied6CopiedINtNtNtB1d_5slice4iter4IterhEEECsiOOgJ5cnKHw_11numeric_ffi"}
!84 = !{!85, !87, !89, !82, !59}
!85 = distinct !{!85, !86, !"_RINvYINtNtNtCs9l4wcBNbII5_4core5slice4iter4IterhENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNtNtBR_8adapters6copied13copy_try_foldhuINtNtNtBa_3ops12control_flow11ControlFlowuENCINvNvBL_3all5checkhNCINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy8000000000000000_INtB1F_6CopiedB3_EE0E0E0B2j_ECsiOOgJ5cnKHw_11numeric_ffi: %self"}
!86 = distinct !{!86, i1 true, !"_RINvYINtNtNtCs9l4wcBNbII5_4core5slice4iter4IterhENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNtNtBR_8adapters6copied13copy_try_foldhuINtNtNtBa_3ops12control_flow11ControlFlowuENCINvNvBL_3all5checkhNCINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy8000000000000000_INtB1F_6CopiedB3_EE0E0E0B2j_ECsiOOgJ5cnKHw_11numeric_ffi"}
!87 = distinct !{!87, !88, !"_RINvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB5_6CopiedINtNtNtBb_5slice4iter4IterhEENtNtNtB9_6traits8iterator8Iterator8try_folduNCINvNvB1v_3all5checkhNCINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy8000000000000000_BP_E0E0INtNtNtBb_3ops12control_flow11ControlFlowuEECsiOOgJ5cnKHw_11numeric_ffi: %self"}
!88 = distinct !{!88, i1 true, !"_RINvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB5_6CopiedINtNtNtBb_5slice4iter4IterhEENtNtNtB9_6traits8iterator8Iterator8try_folduNCINvNvB1v_3all5checkhNCINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy8000000000000000_BP_E0E0INtNtNtBb_3ops12control_flow11ControlFlowuEECsiOOgJ5cnKHw_11numeric_ffi"}
!89 = distinct !{!89, !90, !"_RINvYINtNtNtNtCs9l4wcBNbII5_4core4iter8adapters6copied6CopiedINtNtNtBc_5slice4iter4IterhEENtNtNtBa_6traits8iterator8Iterator3allNCINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy8000000000000000_B3_E0ECsiOOgJ5cnKHw_11numeric_ffi: %self"}
!90 = distinct !{!90, i1 true, !"_RINvYINtNtNtNtCs9l4wcBNbII5_4core4iter8adapters6copied6CopiedINtNtNtBc_5slice4iter4IterhEENtNtNtBa_6traits8iterator8Iterator3allNCINvCs4A2AHSyUD2M_17parse_number_core10accumulateKy8000000000000000_B3_E0ECsiOOgJ5cnKHw_11numeric_ffi"}
!91 = !{i64 -5003817264122049413}
!92 = !{!93, !95}
!93 = distinct !{!93, !94, !"_RNvCs4A2AHSyUD2M_17parse_number_core9parse_u32: %input.0"}
!94 = distinct !{!94, i1 true, !"_RNvCs4A2AHSyUD2M_17parse_number_core9parse_u32"}
!95 = distinct !{!95, !96, !"_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi: argument 0"}
!96 = distinct !{!96, i1 true, !"_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u32INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi"}
!97 = !{!98, !100}
!98 = distinct !{!98, !99, !"_RNvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB4_6CopiedINtNtNtBa_5slice4iter4IterhEENtNtNtB8_6traits8iterator8Iterator4nextCsiOOgJ5cnKHw_11numeric_ffi: %self"}
!99 = distinct !{!99, i1 true, !"_RNvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB4_6CopiedINtNtNtBa_5slice4iter4IterhEENtNtNtB8_6traits8iterator8Iterator4nextCsiOOgJ5cnKHw_11numeric_ffi"}
!100 = distinct !{!100, !101, !"_RINvCs4A2AHSyUD2M_17parse_number_core14parse_unsignedKyffffffff_INtNtNtNtCs9l4wcBNbII5_4core4iter8adapters6copied6CopiedINtNtNtB19_5slice4iter4IterhEEECsiOOgJ5cnKHw_11numeric_ffi: %_0"}
!101 = distinct !{!101, i1 true, !"_RINvCs4A2AHSyUD2M_17parse_number_core14parse_unsignedKyffffffff_INtNtNtNtCs9l4wcBNbII5_4core4iter8adapters6copied6CopiedINtNtNtB19_5slice4iter4IterhEEECsiOOgJ5cnKHw_11numeric_ffi"}
!102 = !{!103, !105, !100}
!103 = distinct !{!103, !104, !"_RNvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB4_6CopiedINtNtNtBa_5slice4iter4IterhEENtNtNtB8_6traits8iterator8Iterator4nextCsiOOgJ5cnKHw_11numeric_ffi: %self"}
!104 = distinct !{!104, i1 true, !"_RNvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB4_6CopiedINtNtNtBa_5slice4iter4IterhEENtNtNtB8_6traits8iterator8Iterator4nextCsiOOgJ5cnKHw_11numeric_ffi"}
!105 = distinct !{!105, !106, !"_RINvCs4A2AHSyUD2M_17parse_number_core10accumulateKyffffffff_INtNtNtNtCs9l4wcBNbII5_4core4iter8adapters6copied6CopiedINtNtNtB15_5slice4iter4IterhEEECsiOOgJ5cnKHw_11numeric_ffi: %_0"}
!106 = distinct !{!106, i1 true, !"_RINvCs4A2AHSyUD2M_17parse_number_core10accumulateKyffffffff_INtNtNtNtCs9l4wcBNbII5_4core4iter8adapters6copied6CopiedINtNtNtB15_5slice4iter4IterhEEECsiOOgJ5cnKHw_11numeric_ffi"}
!107 = !{!108, !110, !112, !105, !100}
!108 = distinct !{!108, !109, !"_RINvYINtNtNtCs9l4wcBNbII5_4core5slice4iter4IterhENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNtNtBR_8adapters6copied13copy_try_foldhuINtNtNtBa_3ops12control_flow11ControlFlowuENCINvNvBL_3all5checkhNCINvCs4A2AHSyUD2M_17parse_number_core10accumulateKyffffffff_INtB1F_6CopiedB3_EE0E0E0B2j_ECsiOOgJ5cnKHw_11numeric_ffi: %self"}
!109 = distinct !{!109, i1 true, !"_RINvYINtNtNtCs9l4wcBNbII5_4core5slice4iter4IterhENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNtNtBR_8adapters6copied13copy_try_foldhuINtNtNtBa_3ops12control_flow11ControlFlowuENCINvNvBL_3all5checkhNCINvCs4A2AHSyUD2M_17parse_number_core10accumulateKyffffffff_INtB1F_6CopiedB3_EE0E0E0B2j_ECsiOOgJ5cnKHw_11numeric_ffi"}
!110 = distinct !{!110, !111, !"_RINvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB5_6CopiedINtNtNtBb_5slice4iter4IterhEENtNtNtB9_6traits8iterator8Iterator8try_folduNCINvNvB1v_3all5checkhNCINvCs4A2AHSyUD2M_17parse_number_core10accumulateKyffffffff_BP_E0E0INtNtNtBb_3ops12control_flow11ControlFlowuEECsiOOgJ5cnKHw_11numeric_ffi: %self"}
!111 = distinct !{!111, i1 true, !"_RINvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB5_6CopiedINtNtNtBb_5slice4iter4IterhEENtNtNtB9_6traits8iterator8Iterator8try_folduNCINvNvB1v_3all5checkhNCINvCs4A2AHSyUD2M_17parse_number_core10accumulateKyffffffff_BP_E0E0INtNtNtBb_3ops12control_flow11ControlFlowuEECsiOOgJ5cnKHw_11numeric_ffi"}
!112 = distinct !{!112, !113, !"_RINvYINtNtNtNtCs9l4wcBNbII5_4core4iter8adapters6copied6CopiedINtNtNtBc_5slice4iter4IterhEENtNtNtBa_6traits8iterator8Iterator3allNCINvCs4A2AHSyUD2M_17parse_number_core10accumulateKyffffffff_B3_E0ECsiOOgJ5cnKHw_11numeric_ffi: %self"}
!113 = distinct !{!113, i1 true, !"_RINvYINtNtNtNtCs9l4wcBNbII5_4core4iter8adapters6copied6CopiedINtNtNtBc_5slice4iter4IterhEENtNtNtBa_6traits8iterator8Iterator3allNCINvCs4A2AHSyUD2M_17parse_number_core10accumulateKyffffffff_B3_E0ECsiOOgJ5cnKHw_11numeric_ffi"}
!114 = !{i64 7517475993067217578}
!115 = !{!116, !118}
!116 = distinct !{!116, !117, !"_RNvCs4A2AHSyUD2M_17parse_number_core9parse_u64: %input.0"}
!117 = distinct !{!117, i1 true, !"_RNvCs4A2AHSyUD2M_17parse_number_core9parse_u64"}
!118 = distinct !{!118, !119, !"_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u64INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi: argument 1"}
!119 = distinct !{!119, i1 true, !"_RNvYNvCs4A2AHSyUD2M_17parse_number_core9parse_u64INtNtNtCs9l4wcBNbII5_4core3ops8function6FnOnceTRShlbEE9call_onceCsiOOgJ5cnKHw_11numeric_ffi"}
!120 = !{!121, !123}
!121 = distinct !{!121, !122, !"_RNvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB4_6CopiedINtNtNtBa_5slice4iter4IterhEENtNtNtB8_6traits8iterator8Iterator4nextCsiOOgJ5cnKHw_11numeric_ffi: %self"}
!122 = distinct !{!122, i1 true, !"_RNvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB4_6CopiedINtNtNtBa_5slice4iter4IterhEENtNtNtB8_6traits8iterator8Iterator4nextCsiOOgJ5cnKHw_11numeric_ffi"}
!123 = distinct !{!123, !124, !"_RINvCs4A2AHSyUD2M_17parse_number_core14parse_unsignedKyffffffffffffffff_INtNtNtNtCs9l4wcBNbII5_4core4iter8adapters6copied6CopiedINtNtNtB1h_5slice4iter4IterhEEECsiOOgJ5cnKHw_11numeric_ffi: %_0"}
!124 = distinct !{!124, i1 true, !"_RINvCs4A2AHSyUD2M_17parse_number_core14parse_unsignedKyffffffffffffffff_INtNtNtNtCs9l4wcBNbII5_4core4iter8adapters6copied6CopiedINtNtNtB1h_5slice4iter4IterhEEECsiOOgJ5cnKHw_11numeric_ffi"}
!125 = !{!126, !128, !123}
!126 = distinct !{!126, !127, !"_RNvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB4_6CopiedINtNtNtBa_5slice4iter4IterhEENtNtNtB8_6traits8iterator8Iterator4nextCsiOOgJ5cnKHw_11numeric_ffi: %self"}
!127 = distinct !{!127, i1 true, !"_RNvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB4_6CopiedINtNtNtBa_5slice4iter4IterhEENtNtNtB8_6traits8iterator8Iterator4nextCsiOOgJ5cnKHw_11numeric_ffi"}
!128 = distinct !{!128, !129, !"_RINvCs4A2AHSyUD2M_17parse_number_core10accumulateKyffffffffffffffff_INtNtNtNtCs9l4wcBNbII5_4core4iter8adapters6copied6CopiedINtNtNtB1d_5slice4iter4IterhEEECsiOOgJ5cnKHw_11numeric_ffi: %_0"}
!129 = distinct !{!129, i1 true, !"_RINvCs4A2AHSyUD2M_17parse_number_core10accumulateKyffffffffffffffff_INtNtNtNtCs9l4wcBNbII5_4core4iter8adapters6copied6CopiedINtNtNtB1d_5slice4iter4IterhEEECsiOOgJ5cnKHw_11numeric_ffi"}
!130 = !{!131, !133, !135, !128, !123}
!131 = distinct !{!131, !132, !"_RINvYINtNtNtCs9l4wcBNbII5_4core5slice4iter4IterhENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNtNtBR_8adapters6copied13copy_try_foldhuINtNtNtBa_3ops12control_flow11ControlFlowuENCINvNvBL_3all5checkhNCINvCs4A2AHSyUD2M_17parse_number_core10accumulateKyffffffffffffffff_INtB1F_6CopiedB3_EE0E0E0B2j_ECsiOOgJ5cnKHw_11numeric_ffi: %self"}
!132 = distinct !{!132, i1 true, !"_RINvYINtNtNtCs9l4wcBNbII5_4core5slice4iter4IterhENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNtNtBR_8adapters6copied13copy_try_foldhuINtNtNtBa_3ops12control_flow11ControlFlowuENCINvNvBL_3all5checkhNCINvCs4A2AHSyUD2M_17parse_number_core10accumulateKyffffffffffffffff_INtB1F_6CopiedB3_EE0E0E0B2j_ECsiOOgJ5cnKHw_11numeric_ffi"}
!133 = distinct !{!133, !134, !"_RINvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB5_6CopiedINtNtNtBb_5slice4iter4IterhEENtNtNtB9_6traits8iterator8Iterator8try_folduNCINvNvB1v_3all5checkhNCINvCs4A2AHSyUD2M_17parse_number_core10accumulateKyffffffffffffffff_BP_E0E0INtNtNtBb_3ops12control_flow11ControlFlowuEECsiOOgJ5cnKHw_11numeric_ffi: %self"}
!134 = distinct !{!134, i1 true, !"_RINvXs_NtNtNtCs9l4wcBNbII5_4core4iter8adapters6copiedINtB5_6CopiedINtNtNtBb_5slice4iter4IterhEENtNtNtB9_6traits8iterator8Iterator8try_folduNCINvNvB1v_3all5checkhNCINvCs4A2AHSyUD2M_17parse_number_core10accumulateKyffffffffffffffff_BP_E0E0INtNtNtBb_3ops12control_flow11ControlFlowuEECsiOOgJ5cnKHw_11numeric_ffi"}
!135 = distinct !{!135, !136, !"_RINvYINtNtNtNtCs9l4wcBNbII5_4core4iter8adapters6copied6CopiedINtNtNtBc_5slice4iter4IterhEENtNtNtBa_6traits8iterator8Iterator3allNCINvCs4A2AHSyUD2M_17parse_number_core10accumulateKyffffffffffffffff_B3_E0ECsiOOgJ5cnKHw_11numeric_ffi: %self"}
!136 = distinct !{!136, i1 true, !"_RINvYINtNtNtNtCs9l4wcBNbII5_4core4iter8adapters6copied6CopiedINtNtNtBc_5slice4iter4IterhEENtNtNtBa_6traits8iterator8Iterator3allNCINvCs4A2AHSyUD2M_17parse_number_core10accumulateKyffffffffffffffff_B3_E0ECsiOOgJ5cnKHw_11numeric_ffi"}
