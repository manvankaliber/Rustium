// Copyright 2026 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef NET_BASE_MIME_TYPE_RUST_REFERENCE_H_
#define NET_BASE_MIME_TYPE_RUST_REFERENCE_H_
#include "net/base/mime_util.h"
namespace net::mime_type_test {
bool LegacyParseMimeType(std::string_view, std::string*, base::StringPairs*);
bool LegacyWithoutParameter(std::string_view, std::string*, std::string*);
void LegacyContentType(std::string_view,
                       std::string*,
                       std::string*,
                       bool*,
                       std::string*);
}  // namespace net::mime_type_test
#endif
