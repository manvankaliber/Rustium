from pathlib import Path
import os, subprocess, ctypes, json, hashlib, sys, time
root=Path('D:/Rustium');full=Path('D:/RustiumBuild/src');out=full/'out/Default';work=root/'.scratch/net-wave1/content-type'
mode=sys.argv[1];env=os.environ.copy();env['PATH']=str(out)+';'+env.get('PATH','')
env['LLVM_PROFILE_FILE']=str(work/'mime-type-unit-%p.profraw')
args=[str(work/(mode+'.exe'))]
if mode=='unit':args+=['--gtest_output=json:'+str(work/'unit-results.json')]
if mode=='fuzz':
    corpus=work/'corpus';corpus.mkdir(exist_ok=True)
    for i,s in enumerate([b'a/b', b'a/b;charset=UTF-8;boundary=foo',b'a/b;x="abc\\";boundary=foo',b'\x00\xff/\x80;p=\x00',b'a/b; charset=""; charset=ignored;boundary=" z "',b'a/b; x; ;=v; x=; x="a\\',b'*/*',b'\vText/Plain\r']):
        (corpus/str(i)).write_bytes(s)
    args += [str(corpus), '-runs=1000000','-max_len=512','-seed=20261112','-print_final_stats=1','-artifact_prefix='+str(work/'crash-')]
start=time.time()
with (work/(mode+'-run.log')).open('w') as log:
    process=subprocess.Popen(args,env=env,cwd=work,stdout=log,stderr=subprocess.STDOUT)
    ctypes.windll.kernel32.SetProcessAffinityMask(ctypes.c_void_p(int(process._handle)),ctypes.c_size_t(64))
    code=process.wait()
(work/(mode+'-execution.json')).write_text(json.dumps({'command':args,'exit_code':code,'elapsed_seconds':time.time()-start,'affinity_mask':64,'sha256':hashlib.sha256((work/(mode+'.exe')).read_bytes()).hexdigest(),'benchmark':False},indent=2)+'\n')
print((work/(mode+'-run.log')).read_text()[-5000:]);sys.exit(code)
