from pathlib import Path
import json, re, ast
work=Path('D:/Rustium/.scratch/net-wave1/content-type')
groups=[('mime-type-parameters','Parse MIME parameters',[
('parse_simple','Simple MIME'),('parse_quoted','Quoted escapes'),('parse_malformed_quote','Unterminated quote'),('parse_many','32 parameters'),('parse_bytes','Non-ASCII and NUL')]),
('mime-type-tokens','Validate parameter-free MIME',[
('strict_simple','Simple tokens'),('strict_whitespace','Outer ASCII whitespace'),('strict_invalid','Internal whitespace'),('strict_nonascii','Non-ASCII token'),('strict_multislash','Multiple slashes')]),
('mime-type-content','Parse Content-Type parameters',[
('content_simple','Type only'),('content_charset','Charset'),('content_boundary','Quoted boundary'),('content_duplicate','First duplicate wins'),('content_empty_charset','Empty quoted charset')]),
('mime-type-state','Preserve Content-Type state',[
('content_exact_wildcard','Exact wildcard ignored'),('content_malformed','Invalid type'),('content_same_type','Same MIME keeps charset'),('content_changed_type','Changed MIME resets charset'),('content_alias_boundary','Boundary aliases MIME')])]
metadata={
'module':'mime-type', 'source':'mime-type','label':'Content-Type and MIME parsing',
'baseline':'Frozen original C++ ParseMimeType, parameter-free parser, Content-Type selection and HTTP whitespace/token helpers; no migrated public helper calls.',
'measurement':'Public C++ API, CXX bridge and Rust grammar; preloaded warm bytes; caller string/pair construction, allocation, output consumption and destruction included. 20 paired repetitions with deterministic randomized order. Single isolated operation; not Chromium end-to-end performance.',
'chart_scope':'Public C++ API + Rust bridge / warm input',
'chart_baseline':'Baseline: original C++ MIME and Content-Type parsers.',
'scope_excludes':['network I/O','browser startup','disk I/O','input construction','environment setup'],
'build_path':'Parent must capture canonical configured GN flags, executable/source hashes and successful execution; native harness is validation only.',
'groups':[{'id':key,'title':title,'operation':title,'cases':[{'key':c,'label':label} for c,label in cases]} for key,title,cases in groups]
}
source=(Path('D:/Rustium/net/base/mime_type_rust_perftest.cc')).read_text()
pattern=r'\{"([^"]+)",\s*(std::string\("((?:\\.|[^"])*)",\s*(\d+)\)|"((?:\\.|[^"])*)"|(many)),\s*(\d+),\s*(\d+)\}'
workloads={}
for match in re.finditer(pattern,source):
    key,expression,explicit,length,literal,many,api,iterations=match.groups()
    if many:
        data=b'a/b'+32*b'; p="a;b\\c"'
    else:
        data=ast.literal_eval('b"'+(explicit if explicit is not None else literal)+'"')
        if length:
            data=(data+b'\0')[:int(length)]
    workloads[key]={'input_hex':data.hex(),'input_bytes':len(data),'iterations_per_pair_side':int(iterations),'api':['ParseMimeType','ParseMimeTypeWithoutParameter','HttpUtil::ParseContentType','HttpUtil::ParseContentType with boundary==mime'][int(api)],'initial_mime':'Text/Html','initial_charset':'OLD','initial_had_charset':True,'initial_boundary':'keep'}
assert len(workloads)==20,workloads.keys()
for group in metadata['groups']:
    for case in group['cases']:
        case.update(workloads[case['key']])
(work/'benchmark-descriptor.json').write_text(json.dumps(metadata,indent=2)+'\n')
