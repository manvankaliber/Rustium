from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,platform,subprocess,shutil,zipfile,os,re
root=Path('D:/Rustium');work=root/'.scratch/net-wave1/content-type';full=Path('D:/RustiumBuild/src');out=full/'out/Default'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(name):return json.loads((work/name).read_text())
assert read('unit-execution.json')['exit_code']==0
assert read('fuzz-execution.json')['exit_code']==0
assert 'stat::number_of_executed_units: 1000000' in (work/'fuzz-run.log').read_text()
checks=read('checks.json');assert all(checks[k]['exit_code']==0 for k in ['clippy','rustfmt','clang-format'])
owned=[root/'net/base/mime_util.cc',*sorted((root/'net/base').glob('mime_type_*'))]
assert all(p.is_file() for p in owned)
stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
archive=root/'docs/rust/benchmarks'/('mime-type-wave1-'+stamp)
archive.mkdir(parents=True,exist_ok=False)
source_manifest={str(p.relative_to(root)).replace('\\','/'):sha(p) for p in owned}
source_manifest['.scratch/net-wave1/content-type/http-util-wrapper.cc.txt']=sha(work/'http-util-wrapper.cc.txt')
(work/'source-hashes.json').write_text(json.dumps(source_manifest,indent=2)+'\n')
# Include helper leaves that are still unchanged base C++ dependencies, without
# altering the original pre-edit manifest. Record their later capture explicitly.
helper_files=['base/strings/trim_string_internal.h','base/strings/whitespace_constants.h','base/strings/whitespace_constants.cc','base/strings/string_util_internal.h']
helper_hashes={}
for f in helper_files:
    p=root/f
    if p.exists():
        dst=work/'additional-helper-snapshot'/f;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst)
        helper_hashes[f]=sha(p)
(work/'additional-helper-manifest.json').write_text(json.dumps({'capture':'At handoff; after owned parser edits. These base helper files were not edited by this component.','sha256':helper_hashes},indent=2)+'\n')
tools={}
for name,args in {
    'rustc':[str(full/'third_party/rust-toolchain/bin/rustc.exe'),'--version','--verbose'],
    'clang-cl':[str(full/'third_party/llvm-build/Release+Asserts/bin/clang-cl.exe'),'--version'],
    'clang-format':[str(root/'.scratch/clang-format/clang_format/data/bin/clang-format.exe'),'--version'],
    'llvm-profdata':[str(root/'.scratch/gzip-header/llvm-tools/bin/llvm-profdata.exe'),'--version'],
}.items():
    tools[name]=subprocess.check_output(args,text=True).strip()
(work/'toolchain.json').write_text(json.dumps(tools,indent=2)+'\n')
dependencies=['base.dll','libc++.dll','base.dll.lib','libc++.dll.lib','obj/net/gzip_header_perftests.ninja','obj/net/gzip_header_unittests.ninja','toolchain.ninja']
dependency_hashes={f:sha(out/f) for f in dependencies}
(work/'native-dependency-hashes.json').write_text(json.dumps(dependency_hashes,indent=2)+'\n')
sources=archive/'source-snapshot.zip'
with zipfile.ZipFile(sources,'w',zipfile.ZIP_DEFLATED) as z:
    for p in owned:z.write(p,'final/'+str(p.relative_to(root)).replace('\\','/'))
    for directory in ['original','additional-helper-snapshot']:
        for p in (work/directory).rglob('*'):
            if p.is_file():z.write(p,str(p.relative_to(work)).replace('\\','/'))
    for p in work.glob('*.py'):z.write(p,'validation/'+p.name)
    for name in ['http-util-wrapper.cc.txt','gn-fragments.gn.txt','benchmark-descriptor.json','Cargo.toml','Cargo.lock']:
        z.write(work/name,'validation/'+name)
    z.write(work/'.cargo/config.toml','validation/.cargo/config.toml')
    z.write(work/'mime_type_rust_native_adapter.cc','validation/mime_type_rust_native_adapter.cc')
with zipfile.ZipFile(archive/'final-fuzz-corpus.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in (work/'corpus').iterdir():
        if p.is_file():z.write(p,p.name)
files=['original-manifest.json','additional-helper-manifest.json','source-hashes.json','adapter-method-hashes.json','unit-results.json','unit-execution.json','fuzz-execution.json','initial-fuzz-execution.json','second-fuzz-execution.json','unit-binary.json','fuzz-binary.json','bench-binary.json','unit-run.log','fuzz-run.log','initial-fuzz-run.log','second-fuzz-run.log','coverage-raw.json','coverage-summary.json','checks.json','clippy.log','rustfmt.log','clang-format.log','benchmark-descriptor.json','http-util-wrapper.cc.txt','gn-fragments.gn.txt','toolchain.json','native-dependency-hashes.json','unit.profdata']
files += [str(p.relative_to(work)).replace('\\','/') for mode in ['unit','fuzz','bench'] for p in (work/(mode+'-flags')).glob('*.rsp')]
for name in files:
    dst=archive/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(work/name,dst)
for p in [Path(s) for s in read('coverage-summary.json')['profiles']]:
    shutil.copyfile(p,archive/p.name)
coverage=read('coverage-summary.json')
runtime=[v for v in coverage.values() if isinstance(v,dict) and 'lines' in v]
report={
 'component':'Content-Type and MIME-type parameter parsing',
 'status':'Implementation and focused validation complete; candidate pending parent canonical integration and measurement',
 'created_utc':datetime.now(timezone.utc).isoformat(),
 'owned_files':source_manifest,
 'unmodified_owned_api_header':'net/base/mime_util.h',
 'exact_source_snapshot':str(sources).replace('\\','/'),
 'exact_source_snapshot_sha256':sha(sources),
 'durable_evidence_directory':str(archive).replace('\\','/'),
 'original_reference':{'manifest':str(work/'original-manifest.json').replace('\\','/'),'baseline_mime_util_sha256':read('original-manifest.json')['net/base/mime_util.cc'],'baseline_http_util_sha256':read('original-manifest.json')['net/http/http_util.cc'],'parser_source':'net/base/mime_type_rust_reference.cc','frozen_dependencies':'LegacyContentType calls LegacyParseMimeType, never migrated public ParseMimeType. IsToken/IsTokenChar/IsLWS/TrimLWS are private frozen C++ helpers. Unchanged base string split/trim/ASCII helpers remain shared C++ dependencies; source snapshots and native base DLL hash are preserved.'},
 'migration':{'safe_core':'net/base/mime_type_parser.rs: #![forbid(unsafe_code)]','ffi':'net/base/mime_type_ffi.rs; generated CXX glue is the only Rust unsafe code','algorithms_in_rust':['lenient MIME grammar','quoted-string escaping and malformed permissiveness','parameter iteration and incomplete-value skipping','parameter-free ASCII HTTP-token validation','ASCII normalization','first charset and boundary selection','multi-header charset retention/reset','output alias-aware equality and write planning','lazy had_charset state resolution'],'cpp_adaptation':'std::string/string_view and StringPairs ownership, CXX byte spans, pointer identity and ordered output commits. No fallback to the C++ reference.'},
 'compatibility':{'preserved':['original public APIs and original tests','first duplicate charset/boundary including empty quoted values','parameter name trailing whitespace','unterminated quotes/backslash at EOF/post-quote junk','non-ASCII bytes and embedded NULs','null-empty views, nullable optional outputs, unchanged outputs on failure','case-preserving equal MIME state across headers','boundary-before-MIME-before-charset output alias write order','no read of output pointers for invalid Content-Type, no read of had_charset for equal MIME'],'safe_snapshot_extension':'When the old ParseMimeType or parameter-free parser could invalidate an input view by writing an aliased output, new adapters finish the owned Rust parse first. Such previously unsafe input-output combinations use explicit snapshot expectations, not an invalid C++ differential oracle.'},
 'parent_changes':{'http_util_wrapper':str(work/'http-util-wrapper.cc.txt').replace('\\','/'),'gn_fragments':str(work/'gn-fragments.gn.txt').replace('\\','/'),'configured_tree_changed_by_agent':False,'gn_or_ninja_run_by_agent':False},
 'validation':{'native_unit_tests':read('unit-execution.json'),'unit_test_count':10,'original_test_bodies':4,'fuzz':read('fuzz-execution.json'),'fuzz_executions':1000000,'fuzz_max_input_bytes':512,'fuzz_affinity_cpu':6,'fuzz_note':'libFuzzer guides instrumented C++ adapters/reference; each input compares full owned Rust-backed outputs, null-output combinations, all output alias partitions and repeated-header state. Rust authored source coverage is measured separately.','coverage':{'runtime_lines':sum(v['lines']['covered'] for v in runtime),'runtime_lines_total':sum(v['lines']['count'] for v in runtime),'runtime_regions':sum(v['regions']['covered'] for v in runtime),'runtime_regions_total':sum(v['regions']['count'] for v in runtime),'qualified_runtime_exclusions':[],'excluded_from_authored_runtime_scope':['CXX macro-generated glue','vendored crates','standard library'],'branch_coverage_collected':False,'raw':'coverage-raw.json','summary':'coverage-summary.json'},'checks':checks,'production_compile':'Complete owned net/base/mime_util.cc compiled successfully with configured Chromium Clang flags; not linked as a full Chromium target. Native executable uses exact extracted production method bodies and supplied HttpUtil wrapper, verified by SHA-256.','commands':['python .scratch/net-wave1/content-type/build_native.py coverage','python .scratch/net-wave1/content-type/build_native.py unit','python .scratch/net-wave1/content-type/run_native.py unit','python .scratch/net-wave1/content-type/coverage.py','python .scratch/net-wave1/content-type/build_native.py rust','python .scratch/net-wave1/content-type/build_native.py fuzz','python .scratch/net-wave1/content-type/run_native.py fuzz','python .scratch/net-wave1/content-type/checks.py','python .scratch/net-wave1/content-type/build_native.py bench']},
 'native_binaries':{mode:read(mode+'-binary.json') for mode in ['unit','fuzz','bench']},
 'rust_flags':{'release':'-Cdebug-assertions=yes -Ccontrol-flow-guard=yes -Cpanic=abort; Cargo release opt-level=3, codegen-units=1','coverage_addition':'-Cinstrument-coverage','vendored_cxx':'1.0.205; offline; Cargo.lock in source snapshot'},
 'environment':{'platform':platform.platform(),'processor':platform.processor(),'logical_cpus':os.cpu_count(),'toolchain':tools,'configured_build_root':'D:/RustiumBuild/src/out/Default'},
 'benchmark':{'timings_run':False,'reason':'Timing is parent-only in a quiet coordinated window. No performance claims or gallery data were added.','descriptor':str(work/'benchmark-descriptor.json').replace('\\','/'),'cases':20,'groups':4,'cases_per_group':5,'executable_built':True,'repetitions':20,'ordering_seed':20261112,'warm_buffers':True,'timing_includes':['caller output construction','public C++ parser API','CXX bridge and Rust ownership','output consumption','output destruction'],'timing_excludes':['input construction','network I/O','disk I/O','browser startup'],'equivalence_bound':'Not selected; no parity claim.'},
 'canonical_targets_needed':['mime_type_unittests','mime_type_parser_fuzzer','net_unittests (MimeUtilTest.*, HttpUtilTest.ParseContentType, HttpUtilTest.ParseContentResetCharset, content-type HttpResponseHeaders consumers)','mime_type_perftests (parent-only paired benchmark)'],
 'remaining_cpp_seams':['std::string, StringPairs, caller output ownership and CXX byte adaptation','MimeUtil singleton and public forwarding entrypoint','extension-to-MIME and MIME-to-extension lookup tables, platform registry/filesystem lookups','MatchesMimeType and MatchesMimeTypeParameters (including its independent matching-specific parameter splitter)','IsValidTopLevelMimeType and standard MIME tables/enumeration','multipart boundary generation and upload formatting','ExtractMimeTypeFromMediaType delimiter/normalization wrapper (its parameter-free token validator now dispatches to Rust)','HttpUtil methods other than the provided ParseContentType replacement remain outside this component; GURL adaptation is not used by these parsers'],
 'known_gaps':['Parent must apply shared HttpUtil wrapper/GN fragments, sync owned sources after independent-change checks, and run configured Chromium build/tests.','Native differential fuzzer is not a sanitizer proof; no Rust branch coverage or end-to-end browser tests were collected.','No benchmark data yet; all actual improvements/regressions must be archived and charted by parent after canonical execution.'],
 'optimization_debt':[{'status':'Unmeasured opportunity; not a verified regression','affected_workload':'MIME parameters and Content-Type state cases in the 20-case descriptor','seam':'Rust owned Vec results, CXX transfer and C++ output copies; Content-Type uses staged state resolution to preserve lazy reads','suspected_cause':'Extra allocation/copy or bridge-call overhead is plausible but unmeasured. Algorithmic behavior must also be measured.','verified_cause':'None; no benchmark run','follow_up':'Parent measures all cases with paired provenance; if regressions exist, record exact evidence in gallery/backlog, then investigate borrowed ranges or fewer allocations/calls without weakening alias/lazy-output safety. Bridge retirement does not guarantee removal of regressions.'}]
}
(work/'report.json').write_text(json.dumps(report,indent=2)+'\n')
shutil.copyfile(work/'report.json',archive/'report.json')
manifest={str(p.relative_to(archive)).replace('\\','/'):sha(p) for p in archive.rglob('*') if p.is_file()}
(archive/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'report':str(work/'report.json'),'archive':str(archive),'snapshot_sha256':sha(sources)},indent=2))
