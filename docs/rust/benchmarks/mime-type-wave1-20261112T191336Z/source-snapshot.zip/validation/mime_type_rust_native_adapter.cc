#include "net/base/mime_util.h"
#include "net/base/mime_type_rust_adapter.h"
#include "net/http/http_util.h"
namespace net {
class MimeUtil { public:
 static MimeUtil& Get() { static MimeUtil instance; return instance; }
 bool ParseMimeTypeWithoutParameter(std::string_view, std::string*, std::string*) const;
};

bool ParseMimeType(std::string_view type_str,
                   std::string* mime_type,
                   base::StringPairs* params) {
  auto parsed = mime_type_internal::parse_mime(
      mime_type_internal::Bytes(type_str), params != nullptr);
  if (!parsed.valid) {
    return false;
  }
  if (mime_type) {
    *mime_type = mime_type_internal::String(parsed.mime);
  }
  if (params) {
    params->clear();
    for (const auto& parameter : parsed.parameters) {
      params->emplace_back(mime_type_internal::String(parameter.name),
                           mime_type_internal::String(parameter.value));
    }
  }
  return true;
}

bool MimeUtil::ParseMimeTypeWithoutParameter(std::string_view type_string,
                                             std::string* top_level_type,
                                             std::string* subtype) const {
  const auto parsed = mime_type_internal::parse_without_parameters(
      mime_type_internal::Bytes(type_string));
  if (!parsed.valid) {
    return false;
  }
  if (top_level_type) {
    *top_level_type = mime_type_internal::String(parsed.top);
  }
  if (subtype) {
    *subtype = mime_type_internal::String(parsed.sub);
  }
  return true;
}

bool ParseMimeTypeWithoutParameter(std::string_view type_string,
                                   std::string* top_level_type,
                                   std::string* subtype) {
  return MimeUtil::Get().ParseMimeTypeWithoutParameter(type_string,
                                                       top_level_type, subtype);
}
void HttpUtil::ParseContentType(std::string_view content_type_str,
                                std::string* mime_type,
                                std::string* charset,
                                bool* had_charset,
                                std::string* boundary) {
  auto selection = mime_type_internal::select_content_type(
      mime_type_internal::Bytes(content_type_str), boundary != nullptr);
  if (!selection.valid) {
    return;
  }
  auto update = mime_type_internal::plan_content_type(
      std::move(selection), mime_type_internal::Bytes(*mime_type),
      boundary == mime_type);
  if (update.needs_had_charset) {
    mime_type_internal::resolve_charset(update, *had_charset);
  }
  // Preserve the legacy mutation order even when string outputs alias. All
  // input borrows have ended and the Rust update owns its bytes before writes.
  if (update.write_boundary) {
    *boundary = mime_type_internal::String(update.boundary);
  }
  if (update.write_mime) {
    *mime_type = mime_type_internal::String(update.mime);
  }
  if (update.write_charset) {
    *had_charset = true;
    *charset = mime_type_internal::String(update.charset);
  }
}
}
