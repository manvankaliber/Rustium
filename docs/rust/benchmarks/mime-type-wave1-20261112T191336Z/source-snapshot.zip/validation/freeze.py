from pathlib import Path
import hashlib, json, shutil
root = Path('D:/Rustium')
work = root/'.scratch/net-wave1/content-type'
files = ['net/base/mime_util.cc', 'net/base/mime_util.h',
         'net/http/http_util.cc', 'net/http/http_util.h',
         'net/base/mime_util_unittest.cc', 'net/http/http_util_unittest.cc',
         'base/strings/string_util.cc', 'base/strings/string_util.h',
         'base/strings/string_util_impl_helpers.h',
         'base/strings/string_split.cc', 'base/strings/string_split.h',
         'base/strings/string_split_internal.h']
manifest = {}
for f in files:
    src = root/f
    if not src.exists():
        manifest[f] = {'missing': True}
        continue
    dest = work/'original'/f
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        raise SystemExit('Refusing to overwrite frozen reference: '+str(dest))
    shutil.copyfile(src,dest)
    manifest[f] = hashlib.sha256(src.read_bytes()).hexdigest()
(work/'original-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
