from pathlib import Path
root=Path('D:/Rustium'); work=root/'.scratch/net-wave1/content-type'
def function(text, signature):
    start=text.index(signature); body=text.index('{',start); depth=0
    # Known function boundary uses a column-zero closing brace.
    return text[start:text.index('\n}',body)+2]
mime=(work/'original/net/base/mime_util.cc').read_text()
http=(work/'original/net/http/http_util.cc').read_text()
parse=function(mime,'bool ParseMimeType(')
strict=function(mime,'bool MimeUtil::ParseMimeTypeWithoutParameter(')
content=function(http,'void HttpUtil::ParseContentType(')
newparse='''bool ParseMimeType(std::string_view type_str,
                   std::string* mime_type,
                   base::StringPairs* params) {
  auto parsed = mime_type_internal::parse_mime(
      mime_type_internal::Bytes(type_str), params != nullptr);
  if (!parsed.valid)
    return false;
  if (mime_type)
    *mime_type = mime_type_internal::String(parsed.mime);
  if (params) {
    params->clear();
    for (const auto& parameter : parsed.parameters) {
      params->emplace_back(mime_type_internal::String(parameter.name),
                           mime_type_internal::String(parameter.value));
    }
  }
  return true;
}'''
newstrict='''bool MimeUtil::ParseMimeTypeWithoutParameter(std::string_view type_string,
                                             std::string* top_level_type,
                                             std::string* subtype) const {
  const auto parsed = mime_type_internal::parse_without_parameters(
      mime_type_internal::Bytes(type_string));
  if (!parsed.valid)
    return false;
  if (top_level_type)
    *top_level_type = mime_type_internal::String(parsed.top);
  if (subtype)
    *subtype = mime_type_internal::String(parsed.sub);
  return true;
}'''
(root/'net/base/mime_util.cc').write_text(mime.replace('#include "net/base/platform_mime_util.h"','#include "net/base/platform_mime_util.h"\n#include "net/base/mime_type_rust_adapter.h"').replace(parse,newparse).replace(strict,newstrict))
wrapper='''void HttpUtil::ParseContentType(std::string_view content_type_str,
                                std::string* mime_type,
                                std::string* charset,
                                bool* had_charset,
                                std::string* boundary) {
  const auto update = mime_type_internal::parse_content_type(
      mime_type_internal::Bytes(content_type_str),
      mime_type_internal::Bytes(*mime_type), *had_charset, boundary != nullptr,
      boundary == mime_type);
  // Preserve the legacy mutation order even when string outputs alias. All
  // input borrows have ended and the Rust update owns its bytes before writes.
  if (update.write_boundary)
    *boundary = mime_type_internal::String(update.boundary);
  if (update.write_mime)
    *mime_type = mime_type_internal::String(update.mime);
  if (update.write_charset) {
    *had_charset = true;
    *charset = mime_type_internal::String(update.charset);
  }
}'''
(work/'http-util-wrapper.cc.txt').write_text('// Add #include "net/base/mime_type_rust_adapter.h" to net/http/http_util.cc\n\n'+wrapper+'\n')
prefix='''// Copyright 2026 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.
'''
(root/'net/base/mime_type_rust_reference.h').write_text(prefix+'''
#ifndef NET_BASE_MIME_TYPE_RUST_REFERENCE_H_
#define NET_BASE_MIME_TYPE_RUST_REFERENCE_H_
#include "net/base/mime_util.h"
namespace net::mime_type_test {
bool LegacyParseMimeType(std::string_view, std::string*, base::StringPairs*);
bool LegacyWithoutParameter(std::string_view, std::string*, std::string*);
void LegacyContentType(std::string_view, std::string*, std::string*, bool*, std::string*);
}
#endif
''')
helper='''namespace {
class FrozenHttpUtil {
 public:
  static bool IsLWS(char c) { return c == ' ' || c == '\\t'; }
  static std::string_view TrimLWS(std::string_view s) {
    size_t begin = 0, end = s.size();
    while (begin < end && IsLWS(s[begin])) ++begin;
    while (begin < end && IsLWS(s[end - 1])) --end;
    return s.substr(begin, end - begin);
  }
  static bool IsTokenChar(char c);
  static bool IsToken(std::string_view string);
};
'''+function(http,'bool HttpUtil::IsTokenChar(').replace('HttpUtil::','FrozenHttpUtil::')+'\n'+function(http,'bool HttpUtil::IsToken(').replace('HttpUtil::','FrozenHttpUtil::')+'\n}  // namespace\n'
reference=prefix+'''// Frozen before Rust migration. No dependency on public migrated parsers.
#include "net/base/mime_type_rust_reference.h"
#include <algorithm>
#include <array>
#include "base/check_op.h"
#include "base/strings/string_split.h"
#include "base/strings/string_util.h"
#define HTTP_LWS " \\t"
namespace net::mime_type_test {
'''+helper+'\n'+parse.replace('bool ParseMimeType(', 'bool LegacyParseMimeType(').replace('HttpUtil::','FrozenHttpUtil::')+'\n'+strict.replace('bool MimeUtil::ParseMimeTypeWithoutParameter(', 'bool LegacyWithoutParameter(').replace(') const {',') {').replace('HttpUtil::','FrozenHttpUtil::')+'\n'+content.replace('void HttpUtil::ParseContentType(','void LegacyContentType(').replace('ParseMimeType(content_type_str','LegacyParseMimeType(content_type_str').replace('HttpUtil::','FrozenHttpUtil::')+'\n}  // namespace net::mime_type_test\n'
(root/'net/base/mime_type_rust_reference.cc').write_text(reference)
# Extract existing tests verbatim; do not modify their original source files.
oldmime=(work/'original/net/base/mime_util_unittest.cc').read_text()
oldhttp=(work/'original/net/http/http_util_unittest.cc').read_text()
tests=prefix+'''// Original parser tests copied verbatim for focused native validation.
#include "net/base/mime_util.h"
#include "net/http/http_util.h"
#include "base/strings/utf_string_conversions.h"
#include "testing/gtest/include/gtest/gtest.h"
namespace net {
'''
for src, sig in [(oldmime,'TEST(MimeUtilTest, TestParseMimeType)'),(oldmime,'TEST(MimeUtilTest, TestParseMimeTypeWithoutParameter)'),(oldhttp,'TEST(HttpUtilTest, ParseContentType)'),(oldhttp,'TEST(HttpUtilTest, ParseContentResetCharset)')]:
    tests+=function(src,sig)+'\n'
(root/'net/base/mime_type_rust_original_unittest.cc').write_text(tests+'}  // namespace net\n')
