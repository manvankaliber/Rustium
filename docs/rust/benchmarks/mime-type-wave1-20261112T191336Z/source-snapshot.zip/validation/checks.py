from pathlib import Path
import subprocess,json,hashlib,re
root=Path('D:/Rustium');work=root/'.scratch/net-wave1/content-type'
results={}
def run(name,args,cwd=root):
    p=subprocess.run(args,cwd=cwd,capture_output=True,text=True)
    (work/(name+'.log')).write_text(p.stdout+p.stderr)
    results[name]={'command':args,'exit_code':p.returncode}
    p.check_returncode()
run('clippy',['python',str(work/'build_native.py'),'lint'])
run('rustfmt',['D:/RustiumBuild/src/third_party/rust-toolchain/bin/rustfmt.exe','--edition','2024','--check',str(root/'net/base/mime_type_parser.rs'),str(root/'net/base/mime_type_ffi.rs')])
files=list((root/'net/base').glob('mime_type_rust_*.cc'))+list((root/'net/base').glob('mime_type_rust_*.h'))
run('clang-format',[str(root/'.scratch/clang-format/clang_format/data/bin/clang-format.exe'),'--dry-run','--Werror',*map(str,files)])
def extract(text,sig):
    start=text.index(sig);return text[start:text.index('\n}',text.index('{',start))+2]
before=(work/'original/net/base/mime_util.cc').read_text()
after=(root/'net/base/mime_util.cc').read_text()
for sig in ('\nbool ParseMimeType(', '\nbool MimeUtil::ParseMimeTypeWithoutParameter('):
    before=before.replace(extract(before,sig),'')
    after=after.replace(extract(after,sig),'')
after=after.replace('#include "net/base/mime_type_rust_adapter.h"\n','')
assert before==after,'Unrelated mime_util.cc changes'
results['scope']={'only_assigned_functions_and_adapter_include_changed':True,'mime_util_header_unchanged':hashlib.sha256((root/'net/base/mime_util.h').read_bytes()).hexdigest()==json.loads((work/'original-manifest.json').read_text())['net/base/mime_util.h']}
assert results['scope']['mime_util_header_unchanged']
for f in ['net/base/mime_util_unittest.cc','net/http/http_util_unittest.cc']:
    assert hashlib.sha256((root/f).read_bytes()).hexdigest()==json.loads((work/'original-manifest.json').read_text())[f]
results['original_tests_unchanged']=True
actual=json.loads((work/'adapter-method-hashes.json').read_text())
for sig,digest in actual.items():
    text=(work/'http-util-wrapper.cc.txt').read_text() if 'HttpUtil::' in sig else (root/'net/base/mime_util.cc').read_text()
    assert hashlib.sha256(extract(text,sig).encode()).hexdigest()==digest
results['native_adapter_method_bodies_match_production_and_parent_wrapper']=True
metadata=json.loads((work/'benchmark-descriptor.json').read_text())
keys=[case['key'] for group in metadata['groups'] for case in group['cases']]
assert len(keys)==len(set(keys))==20
assert all(1<=len(g['cases'])<=5 for g in metadata['groups'])
source=(root/'net/base/mime_type_rust_perftest.cc').read_text()
assert set(re.findall(r'\{"([a-z_]+)",',source))==set(keys)
results['benchmark_descriptor']={'cases':20,'groups':4,'max_cases_per_group':5,'timing_executed':False}
(work/'checks.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
