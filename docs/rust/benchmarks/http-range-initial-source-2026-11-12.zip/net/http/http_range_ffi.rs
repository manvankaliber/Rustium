// Copyright 2026 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

mod http_range_parser;

#[cxx::bridge(namespace = "net::http_range_internal")]
mod ffi {
    struct Range {
        first: i64,
        last: i64,
        suffix: i64,
    }
    struct RangesResult {
        success: bool,
        ranges: Vec<Range>,
    }
    struct FetchResult {
        success: bool,
        range: Range,
    }
    struct ContentAliases {
        first_offset: i64,
        last_offset: i64,
        length_offset: i64,
        mask: u8,
    }
    struct ContentResult {
        success: bool,
        first: i64,
        last: i64,
        length: i64,
    }
    extern "Rust" {
        fn parse_ranges(input: &[u8], had_ranges: bool) -> RangesResult;
        fn parse_fetch(input: &[u8], allow_whitespace: bool) -> FetchResult;
        fn parse_content(input: &[u8], aliases: &ContentAliases) -> ContentResult;
    }
}

fn wire(range: http_range_parser::Range) -> ffi::Range {
    ffi::Range { first: range.first, last: range.last, suffix: range.suffix }
}

fn parse_ranges(input: &[u8], had_ranges: bool) -> ffi::RangesResult {
    let mut ranges = Vec::new();
    let success =
        http_range_parser::parse_ranges(input, had_ranges, |range| ranges.push(wire(range)));
    ffi::RangesResult { success, ranges }
}

fn parse_fetch(input: &[u8], allow_whitespace: bool) -> ffi::FetchResult {
    let range = http_range_parser::parse_fetch(input, allow_whitespace);
    ffi::FetchResult { success: range.is_some(), range: wire(range.unwrap_or_default()) }
}

fn parse_content(input: &[u8], aliases: &ffi::ContentAliases) -> ffi::ContentResult {
    let values = http_range_parser::parse_content(
        input,
        http_range_parser::ContentAliases {
            offsets: [aliases.first_offset, aliases.last_offset, aliases.length_offset],
            mask: aliases.mask,
        },
    );
    let [first, last, length] = values.unwrap_or([-1; 3]);
    ffi::ContentResult { success: values.is_some(), first, last, length }
}
