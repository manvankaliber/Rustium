// Copyright 2026 The Chromium Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Exact production function bodies for direct out-of-line API measurements.
// The runner verifies these against http_util.cc before every measurement.
#include <limits>

#include "base/strings/string_view_rust.h"
#include "net/http/http_range_ffi.rs.h"
#include "net/http/http_util.h"
namespace net {
bool HttpUtil::ParseRangeHeader(std::string_view ranges_specifier,
                                std::vector<HttpByteRange>* ranges) {
  auto result = http_range_internal::parse_ranges(
      base::StringViewToRustSlice(ranges_specifier), !ranges->empty());
  // Preserve successfully parsed prefixes even if a later range is invalid.
  for (const auto& parsed : result.ranges) {
    HttpByteRange range;
    range.set_first_byte_position(parsed.first);
    range.set_last_byte_position(parsed.last);
    range.set_suffix_length(parsed.suffix);
    ranges->push_back(range);
  }
  return result.success;
}

std::optional<HttpByteRange> HttpUtil::ParseFetchSingleRange(
    std::string_view range_header_value,
    bool allow_whitespace) {
  const auto result = http_range_internal::parse_fetch(
      base::StringViewToRustSlice(range_header_value), allow_whitespace);
  if (!result.success) {
    return std::nullopt;
  }
  HttpByteRange range;
  range.set_first_byte_position(result.range.first);
  range.set_last_byte_position(result.range.last);
  range.set_suffix_length(result.range.suffix);
  return range;
}

bool HttpUtil::ParseContentRangeHeaderFor206(
    std::string_view content_range_spec,
    int64_t* first_byte_position,
    int64_t* last_byte_position,
    int64_t* instance_length) {
  // Initialization precedes reading the header, including when input bytes
  // overlap output storage. Rust retains no borrow after the synchronous call.
  *first_byte_position = *last_byte_position = *instance_length = -1;
  const auto offset = [&](const int64_t* output) -> int64_t {
    const uintptr_t input =
        reinterpret_cast<uintptr_t>(content_range_spec.data());
    const uintptr_t address = reinterpret_cast<uintptr_t>(output);
    if (address >= input) {
      const uintptr_t distance = address - input;
      if (distance < content_range_spec.size()) {
        return static_cast<int64_t>(distance);
      }
    } else if (input - address < sizeof(int64_t)) {
      return -static_cast<int64_t>(input - address);
    }
    return std::numeric_limits<int64_t>::min();
  };
  const uint8_t mask = (first_byte_position == last_byte_position ? 1 : 0) |
                       (first_byte_position == instance_length ? 2 : 0) |
                       (last_byte_position == instance_length ? 4 : 0);
  const http_range_internal::ContentAliases aliases{
      offset(first_byte_position), offset(last_byte_position),
      offset(instance_length), mask};
  const auto result = http_range_internal::parse_content(
      base::StringViewToRustSlice(content_range_spec), aliases);
  *first_byte_position = result.first;
  *last_byte_position = result.last;
  *instance_length = result.length;
  return result.success;
}
}  // namespace net
