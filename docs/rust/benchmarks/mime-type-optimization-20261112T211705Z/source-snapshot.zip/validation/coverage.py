from pathlib import Path
import json,subprocess
root=Path('D:/Rustium');work=root/'.scratch/net-wave1/content-type/optimization';tool=root/'.scratch/gzip-header/llvm-tools/bin'
profiles=[max(work.glob('mime-type-unit-*.profraw'),key=lambda p:p.stat().st_mtime_ns)]
subprocess.run([str(tool/'llvm-profdata.exe'),'merge','-sparse',*map(str,profiles),'-o',str(work/'unit.profdata')],check=True)
args=[str(tool/'llvm-cov.exe'),'export',str(work/'unit.exe'),'-instr-profile='+str(work/'unit.profdata')]
data=json.loads(subprocess.check_output(args))
(work/'coverage-raw.json').write_text(json.dumps(data)+'\n')
files=[f for d in data['data'] for f in d['files'] if f['filename'].endswith(('mime_type_parser.rs','mime_type_ffi.rs'))]
summary={f['filename']:f['summary'] for f in files}
summary['method']='LLVM source instrumentation; native unit tests; authored runtime Rust only, generated CXX/standard library excluded. No branch coverage collected.'
summary['qualified_exclusions']=[]
summary['profiles']=[str(p) for p in profiles]
(work/'coverage-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
