#include "net/base/mime_util.h"
#include "net/base/mime_type_rust_adapter.h"
#include "net/http/http_util.h"
namespace net {
class MimeUtil { public:
 static MimeUtil& Get() { static MimeUtil instance; return instance; }
 bool ParseMimeTypeWithoutParameter(std::string_view, std::string*, std::string*) const;
};

bool ParseMimeType(std::string_view type_str,
                   std::string* mime_type,
                   base::StringPairs* params) {
  auto parsed = mime_type_internal::parse_mime(
      mime_type_internal::Bytes(type_str), params != nullptr);
  if (!parsed.valid) {
    return false;
  }
  // Materialize from input offsets before writes can invalidate an input view.
  std::string mime_value;
  if (mime_type) {
    mime_value =
        mime_type_internal::View(type_str, parsed.scratch, parsed.mime);
  }
  base::StringPairs parameters;
  if (params) {
    parameters.reserve(parsed.parameters.size());
    for (const auto& parameter : parsed.parameters) {
      parameters.emplace_back(
          mime_type_internal::View(type_str, parsed.scratch, parameter.name),
          mime_type_internal::View(type_str, parsed.scratch, parameter.value));
    }
  }
  if (mime_type) {
    *mime_type = std::move(mime_value);
  }
  if (params) {
    *params = std::move(parameters);
  }
  return true;
}

bool MimeUtil::ParseMimeTypeWithoutParameter(std::string_view type_string,
                                             std::string* top_level_type,
                                             std::string* subtype) const {
  const auto parsed = mime_type_internal::parse_without_parameters(
      mime_type_internal::Bytes(type_string));
  if (!parsed.valid) {
    return false;
  }
  std::string top_value;
  std::string sub_value;
  if (top_level_type) {
    top_value =
        type_string.substr(parsed.top.start, parsed.top.end - parsed.top.start);
  }
  if (subtype) {
    sub_value =
        type_string.substr(parsed.sub.start, parsed.sub.end - parsed.sub.start);
  }
  if (top_level_type) {
    *top_level_type = std::move(top_value);
  }
  if (subtype) {
    *subtype = std::move(sub_value);
  }
  return true;
}

bool ParseMimeTypeWithoutParameter(std::string_view type_string,
                                   std::string* top_level_type,
                                   std::string* subtype) {
  return MimeUtil::Get().ParseMimeTypeWithoutParameter(type_string,
                                                       top_level_type, subtype);
}
void HttpUtil::ParseContentType(std::string_view content_type_str,
                                std::string* mime_type,
                                std::string* charset,
                                bool* had_charset,
                                std::string* boundary) {
  const mime_type_internal::ContentTypeState state(mime_type, had_charset);
  const auto plan = mime_type_internal::parse_content_type(
      mime_type_internal::Bytes(content_type_str), state, boundary != nullptr,
      boundary == mime_type);
  // Rust decides grammar, normalization, state reads and which writes occur.
  // Stage every selected value before any caller mutation can invalidate input.
  std::string mime_value;
  std::string charset_value;
  std::string boundary_value;
  if (plan.write_mime) {
    mime_value =
        mime_type_internal::View(content_type_str, plan.scratch, plan.mime);
  }
  if (plan.write_charset) {
    charset_value =
        mime_type_internal::View(content_type_str, plan.scratch, plan.charset);
  }
  if (plan.write_boundary) {
    boundary_value =
        mime_type_internal::View(content_type_str, plan.scratch, plan.boundary);
  }
  // Preserve boundary-before-MIME-before-charset order for output aliases.
  if (plan.write_boundary) {
    *boundary = std::move(boundary_value);
  }
  if (plan.write_mime) {
    *mime_type = std::move(mime_value);
  }
  if (plan.write_charset) {
    *had_charset = true;
    *charset = std::move(charset_value);
  }
}
}
