from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,platform,os,shutil,zipfile
root=Path('D:/Rustium');work=root/'.scratch/net-wave1/content-type/optimization';full=Path('D:/RustiumBuild/src');out=full/'out/Default'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(name):return json.loads((work/name).read_text())
checks=read('checks.json')
assert all(checks[k]['exit_code']==0 for k in ['clippy','rustfmt','clang-format','unit','fuzz'])
assert read('unit-results.json')['tests']==13
assert 'stat::number_of_executed_units: 1000000' in (work/'fuzz-run.log').read_text()
stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
archive=root/'docs/rust/benchmarks'/('mime-type-optimization-'+stamp)
archive.mkdir(parents=True,exist_ok=False)
owned=[root/'net/base/mime_util.cc',*sorted((root/'net/base').glob('mime_type_*'))]
source_manifest={str(p.relative_to(root)).replace('\\','/'):sha(p) for p in owned if p.is_file()}
source_manifest['.scratch/net-wave1/content-type/optimization/http-util-wrapper.cc.txt']=sha(work/'http-util-wrapper.cc.txt')
(work/'source-hashes.json').write_text(json.dumps(source_manifest,indent=2)+'\n')
before=read('before-manifest.json')
modified={f:h for f,h in source_manifest.items() if before.get(f)!=h}
toolchain={}
for name,args in {
 'rustc':[str(full/'third_party/rust-toolchain/bin/rustc.exe'),'--version','--verbose'],
 'clang-cl':[str(full/'third_party/llvm-build/Release+Asserts/bin/clang-cl.exe'),'--version'],
 'cxxbridge':[str(out/'win_clang_x64_for_rust_host_build_tools/cxxbridge.exe'),'--version'],
 'clang-format':[str(root/'.scratch/clang-format/clang_format/data/bin/clang-format.exe'),'--version'],
}.items():toolchain[name]=subprocess.check_output(args,text=True).strip()
(work/'toolchain.json').write_text(json.dumps(toolchain,indent=2)+'\n')
dependencies=['base.dll','libc++.dll','base.dll.lib','libc++.dll.lib','obj/net/gzip_header_perftests.ninja','obj/net/gzip_header_unittests.ninja','toolchain.ninja']
(work/'native-dependency-hashes.json').write_text(json.dumps({f:sha(out/f) for f in dependencies},indent=2)+'\n')
ir=list((work/'chromium-target/release/deps').glob('mime_type_validation-*.ll'))
assert len(ir)==1
shutil.copyfile(ir[0],work/'optimized-rust.ll')
with zipfile.ZipFile(archive/'source-snapshot.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in owned:
  if p.is_file():z.write(p,'final/'+str(p.relative_to(root)).replace('\\','/'))
 for p in (work/'before').rglob('*'):
  if p.is_file():z.write(p,str(p.relative_to(work)).replace('\\','/'))
 for p in work.glob('*.py'):z.write(p,'validation/'+p.name)
 for name in ['Cargo.toml','Cargo.lock','http-util-wrapper.cc.txt','gn-fragments.gn.txt','static-review.txt','mime_type_rust_native_adapter.cc','bridge.cc','optimized-rust.ll']:
  z.write(work/name,'validation/'+name)
 z.write(work/'.cargo/config.toml','validation/.cargo/config.toml')
 z.write(work/'include/net/base/mime_type_ffi.rs.h','validation/include/net/base/mime_type_ffi.rs.h')
with zipfile.ZipFile(archive/'fuzz-final-corpus.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in (work/'corpus').iterdir():
  if p.is_file():z.write(p,p.name)
selected=['before-manifest.json','source-hashes.json','checks.json','toolchain.json','native-dependency-hashes.json','adapter-method-hashes.json','unit-results.json','unit-execution.json','unit-binary.json','fuzz-execution.json','fuzz-binary.json','validation-commands.json','unit-run.log','fuzz-run.log','coverage-raw.json','coverage-summary.json','unit.profdata','clippy.log','rustfmt.log','clang-format.log','http-util-wrapper.cc.txt','gn-fragments.gn.txt','static-review.txt','fuzz-start-corpus.zip']
selected += [str(p.relative_to(work)).replace('\\','/') for pattern in ['*-compile.log','*-link.log','*-pipeline.log','unit-flags/*.rsp','fuzz-flags/*.rsp'] for p in work.glob(pattern)]
selected += [Path(p).name for p in read('coverage-summary.json')['profiles']]
for name in selected:
 dst=archive/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(work/name,dst)
coverage=read('coverage-summary.json');runtime=[v for v in coverage.values() if isinstance(v,dict) and 'lines' in v]
report={
 'component':'Content-Type and MIME parameter parsing',
 'status':'Concrete optimization and native validation complete; parent must apply coordinated wrapper/GN changes, build configured production, and remeasure',
 'created_utc':datetime.now(timezone.utc).isoformat(),
 'prior_accepted_revision_remains_accepted':True,
 'historical_evidence_untouched':True,
 'new_performance_measurements':False,
 'modified_or_new_files':modified,
 'source_sha256':source_manifest,
 'before_manifest':str(work/'before-manifest.json').replace('\\','/'),
 'source_snapshot':str(archive/'source-snapshot.zip').replace('\\','/'),
 'source_snapshot_sha256':sha(archive/'source-snapshot.zip'),
 'durable_evidence_directory':str(archive).replace('\\','/'),
 'canonical_regression_evidence':{'path':'docs/rust/benchmarks/mime-type-wave1-final-2026-11-12.json','sha256':before['docs/rust/benchmarks/mime-type-wave1-final-2026-11-12.json'],'cause_attribution':'No measured attribution collected; static redundant allocation/copy/call paths identified and changed.'},
 'implemented_optimizations':['Borrowed scalar offsets for MIME and parameter-free tokens, replacing owned Rust token byte vectors','One final MIME parameter descriptor vector built directly by FFI; names/unchanged values borrow input by offset','Shared transformed-byte scratch only for required unescaping or actual ASCII lowercase output','Content-Type selects first requested parameters directly from the byte iterator without a full parameter vector','Skip decoding/retaining unused or later duplicate Content-Type parameters','Single Content-Type plan call with synchronous Rust-controlled lazy state getters; unchanged MIME does not materialize a normalized output','C++ materializes final selected values once before any aliased output writes and commits in original mutation order'],
 'policy_location':'All grammar, token validation, unescaping, ASCII normalization, first-parameter selection, alias-aware MIME equality, lazy state reads and charset retention/reset remain in safe Rust (mime_type_parser.rs forbids unsafe_code).',
 'ffi_safety':{'authored_unsafe':'Only unsafe extern C++ declarations for immutable, synchronous state getters; documented validity/lifetime contract. No handwritten Rust pointer arithmetic/dereference or uninitialized mutable outputs.','state_getters':'C++ returns borrowed bytes or bool; no CxxString ABI crosses Cargo support library. No input/state borrow survives the FFI call.','layouts':'Shared structs and opaque C++ state are generated by CXX; explicit field conversion between core and FFI avoids handwritten layout casts.','alias_ownership':'C++ stages all selected strings/pairs before output writes; offsets remain valid across scratch-vector reallocations; commit order remains MIME then parameter vector, top then subtype, and boundary then MIME then charset.'},
 'static_review':{'notes':str(work/'static-review.txt').replace('\\','/'),'generated_bridge_sha256':sha(work/'bridge.cc'),'optimized_llvm_sha256':sha(work/'optimized-rust.ll'),'kind':'Source/generated-code inspection only; no timing or allocator instrumentation. No speedup or parity claimed.'},
 'unchanged_frozen_baseline_and_workloads':checks['unchanged_reference_workloads_and_evidence'],
 'validation':{'unit_tests':13,'original_test_bodies':4,'new_optimization_tests':3,'new_cases':['scratch growth with escaped/empty values and embedded NUL/non-ASCII bytes','incoming Content-Type aliases every mutable string output across all output alias partitions','heap-backed strict parser input/output alias snapshots and MIME output inside existing parameter storage'],'unit_execution':read('unit-execution.json'),'fuzz_execution':read('fuzz-execution.json'),'differential_fuzz_executions':1000000,'fuzz_affinity_cpu':6,'fuzz_max_input_bytes':512,'fuzz_corpus':'Fresh authored seeds; exact starting corpus zipped before execution; final corpus archived. libFuzzer instruments C++ adapters/oracle; each invocation checks full candidate public API results.','coverage':{'authored_runtime_lines_covered':sum(v['lines']['covered'] for v in runtime),'authored_runtime_lines_total':sum(v['lines']['count'] for v in runtime),'authored_runtime_regions_covered':sum(v['regions']['covered'] for v in runtime),'authored_runtime_regions_total':sum(v['regions']['count'] for v in runtime),'branch_coverage_collected':False,'qualified_runtime_exclusions':[],'outside_authored_runtime_scope':['generated CXX glue','vendored crates','standard library'],'raw':'coverage-raw.json'},'lint_and_format':checks,'production_compile':'Owned mime_util.cc compiled in full with configured Chromium Clang flags; native program links exact extracted owned method bodies and proposed HttpUtil wrapper, verified by SHA-256. Full configured GN link is parent-owned.','native_reference_define':'IS_MIME_TYPE_TEST_REFERENCE_IMPL for local focused reference compilation; reference source/header algorithms unchanged.'},
 'native_binaries':{'unit':read('unit-binary.json'),'fuzz':read('fuzz-binary.json')},
 'rust_flags':{'release':'-Cdebug-assertions=yes -Ccontrol-flow-guard=yes -Cpanic=abort; Cargo release opt-level=3 codegen-units=1','coverage_addition':'-Cinstrument-coverage','ir_addition':'--emit=llvm-ir','dependencies':'Offline cxx 1.0.205 and existing vendored/cache dependencies; Cargo.lock in snapshot'},
 'environment':{'platform':platform.platform(),'processor':platform.processor(),'logical_cpus':os.cpu_count(),'toolchain':toolchain,'configured_root':'D:/RustiumBuild/src/out/Default'},
 'commands':['python .scratch/net-wave1/content-type/optimization/build_native.py coverage','python .scratch/net-wave1/content-type/optimization/build_native.py unit','python .scratch/net-wave1/content-type/optimization/run_native.py unit','python .scratch/net-wave1/content-type/optimization/coverage.py','python .scratch/net-wave1/content-type/optimization/build_native.py rust','python .scratch/net-wave1/content-type/optimization/build_native.py fuzz','python .scratch/net-wave1/content-type/optimization/run_native.py fuzz','python .scratch/net-wave1/content-type/optimization/build_native.py ir','python .scratch/net-wave1/content-type/optimization/checks.py'],
 'parent_integration':{'http_util_replacement':str(work/'http-util-wrapper.cc.txt').replace('\\','/'),'gn_fragment':str(work/'gn-fragments.gn.txt').replace('\\','/'),'abi_coordination':'Apply wrapper and new FFI together; old shared wrapper calls removed intermediate owned-value functions. New header-only state target/public dependency enables generated CXX includes without a net dependency cycle.','configured_tests':['net production link','mime_type_unittests including new optimization source','mime_type_parser_fuzzer','applicable net_unittests MIME/Content-Type/response-header consumers'],'benchmarks':'All unchanged 20 mime_type_perftests cases through real net.dll and frozen reference component DLL. No native timing was run. Use unique accepted run slug; archive/import all results, update gallery/backlog, sync dashboard per AGENTS.','configured_tree_sync_or_gn_ninja_performed_by_agent':False},
 'remaining_cpp_seams':['caller std::string/StringPairs ownership and final staging/ordered commits','synchronous read-only string/boolean state getter adaptation','MimeUtil singleton/public forwarding','extension/MIME tables and platform lookups','MIME matching and its independent matching-specific parameter parser','top-level MIME tables/validation, enumeration, multipart generation/formatting and media-type extraction wrapper','all unrelated HttpUtil and GURL/platform algorithms outside this component'],
 'limitations':['No speedup or allocation-count measurement; prior slowdown attribution remains unverified.','Final canonical build, native component DLL interoperability and all-case performance measurement require parent integration.','Runtime coverage is line/region coverage, not branch coverage or proof of memory safety; C++ oracle instrumentation guides the fuzzer.','MIME descriptor/scratch vector growth, final C++ storage, alias staging and bridge/getter/destructor calls remain. These changes do not guarantee parity.'],
 'optimization_followup':{'verified':'The listed redundant owning-token paths and unused Content-Type materialization are removed from source/generated code.','unverified':'Performance effect, relative bridge contribution and residual algorithmic regression.','next':'Parent remeasures every unchanged case. Keep integrated slower cases accepted and in aggregate; archive all differences and exact residual regressions before further targeted optimization.'}
}
for p in [work/'report.json',archive/'report.json']:p.write_text(json.dumps(report,indent=2)+'\n')
manifest={str(p.relative_to(archive)).replace('\\','/'):sha(p) for p in archive.rglob('*') if p.is_file()}
(archive/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for f,h in manifest.items():assert sha(archive/f)==h
print(json.dumps({'report':str(work/'report.json'),'archive':str(archive),'evidence_files':len(manifest),'source_snapshot_sha256':sha(archive/'source-snapshot.zip')},indent=2))
