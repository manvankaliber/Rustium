from pathlib import Path
import subprocess
root=Path('D:/Rustium');work=root/'.scratch/net-wave1/content-type/optimization'
clang=root/'.scratch/clang-format/clang_format/data/bin/clang-format.exe'
files=[p for p in (root/'net/base').glob('mime_type_rust_*') if p.suffix in ('.cc','.h') and 'reference' not in p.name and 'perftest' not in p.name and 'original_unittest' not in p.name]
subprocess.run([str(clang),'-i',*map(str,files)],check=True)
# Format only owned function definitions/include order in mime_util.cc.
path=root/'net/base/mime_util.cc';text=path.read_text()
for signature in ('\nbool ParseMimeType(', '\nbool MimeUtil::ParseMimeTypeWithoutParameter('):
    start=text.index(signature)+1;end=text.index('\n}',text.index('{',start))+2
    body=text[start:end]
    formatted=subprocess.check_output([str(clang),'--assume-filename=net/base/mime_util.cc'],input=body.encode()).decode().rstrip()
    text=text[:start]+formatted+text[end:]
text=text.replace('#include "net/base/platform_mime_util.h"\n#include "net/base/mime_type_rust_adapter.h"','#include "net/base/mime_type_rust_adapter.h"\n#include "net/base/platform_mime_util.h"')
path.write_text(text)
path=work/'http-util-wrapper.cc.txt';text=path.read_text();start=text.index('void HttpUtil::')
path.write_text(text[:start]+subprocess.check_output([str(clang),'--assume-filename=net/http/http_util.cc'],input=text[start:].encode()).decode())
subprocess.run(['D:/RustiumBuild/src/third_party/rust-toolchain/bin/rustfmt.exe','--edition','2024',str(root/'net/base/mime_type_parser.rs'),str(root/'net/base/mime_type_ffi.rs')],check=True)
