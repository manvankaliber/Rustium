from pathlib import Path
import hashlib,json,subprocess,re
root=Path('D:/Rustium');work=root/'.scratch/net-wave1/content-type/optimization'
results={}
def run(name,args):
    p=subprocess.run(args,cwd=root,capture_output=True,text=True)
    (work/(name+'.log')).write_text(p.stdout+p.stderr)
    results[name]={'command':args,'exit_code':p.returncode};p.check_returncode()
run('clippy',['python',str(work/'build_native.py'),'lint'])
run('rustfmt',['D:/RustiumBuild/src/third_party/rust-toolchain/bin/rustfmt.exe','--edition','2024','--check',str(root/'net/base/mime_type_parser.rs'),str(root/'net/base/mime_type_ffi.rs')])
files=[p for p in (root/'net/base').glob('mime_type_rust_*') if p.suffix in ('.cc','.h') and 'reference' not in p.name and 'perftest' not in p.name and 'original_unittest' not in p.name]
run('clang-format',[str(root/'.scratch/clang-format/clang_format/data/bin/clang-format.exe'),'--dry-run','--Werror',*map(str,files)])
def extract(text,sig):
    start=text.index(sig);return text[start:text.index('\n}',text.index('{',start))+2]
before=(work/'before/net/base/mime_util.cc').read_text();after=(root/'net/base/mime_util.cc').read_text()
for sig in ('\nbool ParseMimeType(', '\nbool MimeUtil::ParseMimeTypeWithoutParameter('):
    before=before.replace(extract(before,sig),'');after=after.replace(extract(after,sig),'')
assert before==after,'Unrelated mime_util.cc edits'
results['scope']={'only_owned_mime_util_methods_changed':True}
manifest=json.loads((work/'before-manifest.json').read_text())
protected=[f for f in manifest if any(x in f for x in ('reference','perftest','original_unittest','test_support')) or f.endswith('mime_util.h') or f.startswith('docs/')]
for f in protected:
    assert hashlib.sha256((root/f).read_bytes()).hexdigest()==manifest[f],f
results['unchanged_reference_workloads_and_evidence']={f:manifest[f] for f in protected}
bodies=json.loads((work/'adapter-method-hashes.json').read_text())
for sig,digest in bodies.items():
    text=(work/'http-util-wrapper.cc.txt').read_text() if 'HttpUtil::' in sig else (root/'net/base/mime_util.cc').read_text()
    assert hashlib.sha256(extract(text,sig).encode()).hexdigest()==digest
results['native_method_bodies_match_final_production_or_parent_patch']=True
for mode in ['unit','fuzz']:
    executable=work/(mode+'.exe')
    digest=hashlib.sha256(executable.read_bytes()).hexdigest()
    execution=json.loads((work/(mode+'-execution.json')).read_text())
    build=json.loads((work/(mode+'-binary.json')).read_text())
    assert execution['exit_code']==0 and execution['sha256']==build['sha256']==digest
    results[mode]={'exit_code':execution['exit_code'],'binary_sha256':digest}
assert 'stat::number_of_executed_units: 1000000' in (work/'fuzz-run.log').read_text()
results['benchmark_timing_executed']=False
(work/'checks.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
