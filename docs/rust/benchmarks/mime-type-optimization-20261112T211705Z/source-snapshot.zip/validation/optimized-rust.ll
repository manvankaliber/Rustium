; ModuleID = 'mime_type_validation.8ef6bb76fb8441e5-cgu.0'
source_filename = "mime_type_validation.8ef6bb76fb8441e5-cgu.0"
target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-windows-msvc"

@alloc_2728436149d2d0d1e5775c8099d441a1 = private unnamed_addr constant [29 x i8] c"library\\alloc\\src\\vec\\mod.rs\00", align 1, !guid !0
@alloc_87e6578268e354c4f2747b30d32a9b4e = private unnamed_addr constant [31 x i8] c"library\\core\\src\\slice\\iter.rs\00", align 1, !guid !1
@alloc_1d1b1e35bb489427b2bdc9752de92226 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_87e6578268e354c4f2747b30d32a9b4e, [16 x i8] c"\1E\00\00\00\00\00\00\00\8C\00\00\00\01\00\00\00" }>, align 8, !guid !2
@alloc_d82b0e089738a8d65da181c674b5c170 = private unnamed_addr constant [17 x i8] c"()<>@,;:\\\22/[]?={}", align 1, !guid !3
@alloc_cee65835bcd8c782e6edbe2348e7d9b9 = private unnamed_addr constant [38 x i8] c"..\\..\\..\\..\\net\\base\\mime_type_ffi.rs\00", align 1, !guid !4
@alloc_8301db87b19c4fd1b041a9b35ebbea76 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_cee65835bcd8c782e6edbe2348e7d9b9, [16 x i8] c"%\00\00\00\00\00\00\00\15\00\00\00\22\00\00\00" }>, align 8, !guid !5
@alloc_bf8205ff82636365a7d0f6ecb946395f = private unnamed_addr constant [79 x i8] c"D:\\Rustium\\third_party\\rust\\chromium_crates_io\\vendor\\cxx-v1\\src\\rust_slice.rs\00", align 1, !guid !6
@alloc_7d52e238cba565908982a5cea838db34 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_bf8205ff82636365a7d0f6ecb946395f, [16 x i8] c"N\00\00\00\00\00\00\00\1D\00\00\00\12\00\00\00" }>, align 8, !guid !7
@alloc_645021e4993a13a209ed58b918c7a57a = private unnamed_addr constant [41 x i8] c"..\\..\\..\\..\\net\\base\\mime_type_parser.rs\00", align 1, !guid !8
@alloc_ad438f04501d3850fe5717f2a4e651e9 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_645021e4993a13a209ed58b918c7a57a, [16 x i8] c"(\00\00\00\00\00\00\00\13\00\00\00\10\00\00\00" }>, align 8, !guid !9
@alloc_6f59dc4b9b1e504715d6feec04f7efaa = private unnamed_addr constant [77 x i8] c"D:\\Rustium\\third_party\\rust\\chromium_crates_io\\vendor\\cxx-v1\\src\\rust_vec.rs\00", align 1, !guid !10
@alloc_761524272c43a324f2cd5804a1432b63 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_6f59dc4b9b1e504715d6feec04f7efaa, [16 x i8] c"L\00\00\00\00\00\00\00A\00\00\00\1E\00\00\00" }>, align 8, !guid !11
@alloc_5c16a04db8e7c261b2a076cf2ba35ad3 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_2728436149d2d0d1e5775c8099d441a1, [16 x i8] c"\1C\00\00\00\00\00\00\00W\08\00\00\09\00\00\00" }>, align 8, !guid !12
@alloc_6b2d6f9c10483c97dd45df2e37fdbaf3 = private unnamed_addr constant [27 x i8] c"library\\alloc\\src\\alloc.rs\00", align 1, !guid !13
@alloc_1b98de0e82d923a9daff35d520cf360d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_6b2d6f9c10483c97dd45df2e37fdbaf3, [16 x i8] c"\1A\00\00\00\00\00\00\00~\01\00\00\11\00\00\00" }>, align 8, !guid !14
@alloc_24f4768e38f126368567621cf7f11fcd = private unnamed_addr constant [33 x i8] c"library\\alloc\\src\\raw_vec\\mod.rs\00", align 1, !guid !15
@alloc_ad088eaa3dc0ae68b11fd72bfcf5e34b = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_24f4768e38f126368567621cf7f11fcd, [16 x i8] c" \00\00\00\00\00\00\00\98\02\00\005\00\00\00" }>, align 8, !guid !16
@alloc_dade1aed0d0fe800cb3ecdb07302e098 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_24f4768e38f126368567621cf7f11fcd, [16 x i8] c" \00\00\00\00\00\00\00\99\02\00\00\1E\00\00\00" }>, align 8, !guid !17
@alloc_5a885d3db7500f26d581e948d37c49fe = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_24f4768e38f126368567621cf7f11fcd, [16 x i8] c" \00\00\00\00\00\00\00C\02\00\00\11\00\00\00" }>, align 8, !guid !18
@alloc_e09840ce091b9d84c9136134ef6d6d3f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_645021e4993a13a209ed58b918c7a57a, [16 x i8] c"(\00\00\00\00\00\00\00\94\00\00\00\17\00\00\00" }>, align 8, !guid !19
@alloc_4827d7bcd2d5f9ba5354abce3f721069 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_645021e4993a13a209ed58b918c7a57a, [16 x i8] c"(\00\00\00\00\00\00\00\81\00\00\00\19\00\00\00" }>, align 8, !guid !20
@alloc_6778510a3f564171a901a93fb66df6da = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_645021e4993a13a209ed58b918c7a57a, [16 x i8] c"(\00\00\00\00\00\00\00\84\00\00\00\10\00\00\00" }>, align 8, !guid !21
@alloc_9f210cfd795faf6e85189269a278b85f = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_645021e4993a13a209ed58b918c7a57a, [16 x i8] c"(\00\00\00\00\00\00\00\87\00\00\00\18\00\00\00" }>, align 8, !guid !22
@alloc_bf5509759b66626e8f66aa42686e3529 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_645021e4993a13a209ed58b918c7a57a, [16 x i8] c"(\00\00\00\00\00\00\00\C5\00\00\003\00\00\00" }>, align 8, !guid !23
@alloc_5ae9d5ffcd4a9e402f4daeafec83ac84 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_645021e4993a13a209ed58b918c7a57a, [16 x i8] c"(\00\00\00\00\00\00\00\1C\00\00\00(\00\00\00" }>, align 8, !guid !24
@alloc_b65862ba02ce59bf102bd5cffbc3e71e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_645021e4993a13a209ed58b918c7a57a, [16 x i8] c"(\00\00\00\00\00\00\00\1F\00\00\00(\00\00\00" }>, align 8, !guid !25
@alloc_7ceb3fc2a9bd779a2ce04010a0c8ae4a = private unnamed_addr constant [33 x i8] c"library\\core\\src\\slice\\memchr.rs\00", align 1, !guid !26
@alloc_9447f9e979cd1531f5a09d1c25b3ec18 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_7ceb3fc2a9bd779a2ce04010a0c8ae4a, [16 x i8] c" \00\00\00\00\00\00\00\1F\00\00\00\12\00\00\00" }>, align 8, !guid !27
@alloc_1be5ea12ba708d9a11b6e93a7d387a75 = private unnamed_addr constant [281 x i8] c"unsafe precondition(s) violated: Layout::from_size_align_unchecked requires that align is a power of 2 and the rounded-up allocation size does not exceed isize::MAX\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !28
@alloc_db07ae5a9ce650d9b7cc970d048e6f0c = private unnamed_addr constant [186 x i8] c"unsafe precondition(s) violated: usize::unchecked_mul cannot overflow\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !29
@alloc_57d70e9d94c65ecfc15225d29a5ed72b = private unnamed_addr constant [198 x i8] c"unsafe precondition(s) violated: Vec::set_len requires that new_len <= capacity()\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !30
@alloc_64e308ef4babfeb8b6220184de794a17 = private unnamed_addr constant [221 x i8] c"unsafe precondition(s) violated: hint::assert_unchecked must never be called when the condition is false\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !31
@alloc_a28e8c8fd5088943a8b5d44af697ff83 = private unnamed_addr constant [279 x i8] c"unsafe precondition(s) violated: slice::from_raw_parts requires the pointer to be aligned and non-null, and the total size of the slice not to exceed `isize::MAX`\0A\0AThis indicates a bug in the program. This Undefined Behavior check is optional, and cannot be relied on for safety.", align 1, !guid !32
@alloc_bbf6a06aca8a736ba5f657d76cbabc56 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_645021e4993a13a209ed58b918c7a57a, [16 x i8] c"(\00\00\00\00\00\00\00D\00\00\00\0D\00\00\00" }>, align 8, !guid !33
@alloc_3703da2b1b4bb9e1c22edb34338572b1 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_645021e4993a13a209ed58b918c7a57a, [16 x i8] c"(\00\00\00\00\00\00\00L\00\00\00.\00\00\00" }>, align 8, !guid !34
@alloc_68ddaa981c2b4f25b2f4f08e18cc6057 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_645021e4993a13a209ed58b918c7a57a, [16 x i8] c"(\00\00\00\00\00\00\00l\00\00\004\00\00\00" }>, align 8, !guid !35
@alloc_18751c864f47f78987d76e83a84d153d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_645021e4993a13a209ed58b918c7a57a, [16 x i8] c"(\00\00\00\00\00\00\00C\00\00\00*\00\00\00" }>, align 8, !guid !36

@"cxxbridge1$rust_vec$net$mime_type_internal$Parameter$data_mut" = unnamed_addr alias ptr (ptr), ptr @"cxxbridge1$rust_vec$net$mime_type_internal$Parameter$data_const"

; <[u8]>::eq_ignore_ascii_case_chunks::<16>
; Function Attrs: inlinehint nofree norecurse nosync nounwind memory(argmem: read, inaccessiblemem: readwrite) uwtable
define internal fastcc noundef zeroext i1 @_RINvMNtNtCs9l4wcBNbII5_4core5slice5asciiSh27eq_ignore_ascii_case_chunksKj10_ECscgZyRT41Cnx_20mime_type_validation(ptr noalias nofree noundef nonnull readonly captures(none) %self.0, i64 noundef range(i64 16, -9223372036854775808) %self.1, ptr noalias nofree noundef nonnull readonly captures(none) %other.0, i64 noundef range(i64 0, -9223372036854775808) %other.1) unnamed_addr #0 personality ptr @__CxxFrameHandler3 !guid !41 {
start:
  %len.i.i = and i64 %self.1, 15
  %new_len2.i = lshr i64 %self.1, 4
  %new_len2.i26 = lshr i64 %other.1, 4
  %invariant.umin = tail call i64 @llvm.umin.i64(i64 %new_len2.i, i64 %new_len2.i26)
  %or.cond39.not = icmp eq i64 %invariant.umin, 0
  br i1 %or.cond39.not, label %bb13, label %bb7

bb3:                                              ; preds = %bb7
  %0 = add nuw nsw i64 %i.sroa.0.040, 1
  %exitcond.not = icmp eq i64 %0, %invariant.umin
  br i1 %exitcond.not, label %bb13, label %bb7

bb13:                                             ; preds = %bb3, %start
  %_22 = icmp eq i64 %len.i.i, 0
  %_45 = icmp samesign ult i64 %other.1, 16
  %or.cond = select i1 %_22, i1 true, i1 %_45
  br i1 %or.cond, label %bb21, label %_RNvMNtCs9l4wcBNbII5_4core5sliceSh8split_atCscgZyRT41Cnx_20mime_type_validation.exit36

_RNvMNtCs9l4wcBNbII5_4core5sliceSh8split_atCscgZyRT41Cnx_20mime_type_validation.exit36: ; preds = %bb13
  %1 = getelementptr i8, ptr %self.0, i64 %self.1
  %data.i.i27 = getelementptr i8, ptr %1, i64 -16
  %2 = getelementptr i8, ptr %other.0, i64 %other.1
  %data.i.i30 = getelementptr i8, ptr %2, i64 -16
  tail call void @llvm.experimental.noalias.scope.decl(metadata !42)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !45)
  %3 = load <16 x i8>, ptr %data.i.i27, align 1, !alias.scope !42
  %4 = add <16 x i8> %3, splat (i8 -65)
  %5 = icmp ult <16 x i8> %4, splat (i8 26)
  %6 = select <16 x i1> %5, <16 x i8> splat (i8 32), <16 x i8> zeroinitializer
  %7 = or <16 x i8> %6, %3
  %8 = load <16 x i8>, ptr %data.i.i30, align 1, !alias.scope !45
  %9 = add <16 x i8> %8, splat (i8 -65)
  %10 = icmp ult <16 x i8> %9, splat (i8 26)
  %11 = select <16 x i1> %10, <16 x i8> splat (i8 32), <16 x i8> zeroinitializer
  %12 = or <16 x i8> %11, %8
  %13 = icmp ne <16 x i8> %7, %12
  %14 = bitcast <16 x i1> %13 to i16
  %15 = icmp eq i16 %14, 0
  br i1 %15, label %bb21, label %bb20

bb20:                                             ; preds = %bb7, %_RNvMNtCs9l4wcBNbII5_4core5sliceSh8split_atCscgZyRT41Cnx_20mime_type_validation.exit36
  br label %bb21

bb21:                                             ; preds = %bb13, %_RNvMNtCs9l4wcBNbII5_4core5sliceSh8split_atCscgZyRT41Cnx_20mime_type_validation.exit36, %bb20
  %_0.sroa.0.1 = phi i1 [ false, %bb20 ], [ true, %bb13 ], [ true, %_RNvMNtCs9l4wcBNbII5_4core5sliceSh8split_atCscgZyRT41Cnx_20mime_type_validation.exit36 ]
  ret i1 %_0.sroa.0.1

bb7:                                              ; preds = %start, %bb3
  %i.sroa.0.040 = phi i64 [ %0, %bb3 ], [ 0, %start ]
  %_16 = getelementptr inbounds nuw [16 x i8], ptr %self.0, i64 %i.sroa.0.040
  %_19 = getelementptr inbounds nuw [16 x i8], ptr %other.0, i64 %i.sroa.0.040
  tail call void @llvm.experimental.noalias.scope.decl(metadata !47)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !50)
  %16 = load <16 x i8>, ptr %_16, align 1, !alias.scope !47
  %17 = add <16 x i8> %16, splat (i8 -65)
  %18 = icmp ult <16 x i8> %17, splat (i8 26)
  %19 = select <16 x i1> %18, <16 x i8> splat (i8 32), <16 x i8> zeroinitializer
  %20 = or <16 x i8> %19, %16
  %21 = load <16 x i8>, ptr %_19, align 1, !alias.scope !50
  %22 = add <16 x i8> %21, splat (i8 -65)
  %23 = icmp ult <16 x i8> %22, splat (i8 26)
  %24 = select <16 x i1> %23, <16 x i8> splat (i8 32), <16 x i8> zeroinitializer
  %25 = or <16 x i8> %24, %21
  %26 = icmp ne <16 x i8> %20, %25
  %27 = bitcast <16 x i1> %26 to i16
  %28 = icmp eq i16 %27, 0
  br i1 %28, label %bb3, label %bb20
}

; <alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>
; Function Attrs: cold nounwind uwtable
define internal fastcc void @_RINvNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECscgZyRT41Cnx_20mime_type_validation(ptr noalias nofree noundef nonnull align 8 captures(none) dereferenceable(16) %slf, i64 noundef %len, i64 noundef %additional, i64 noundef range(i64 1, 9) %elem_layout.0, i64 noundef range(i64 1, 49) %elem_layout.1) unnamed_addr #1 !guid !52 {
start:
  %self3.i = alloca [24 x i8], align 8
  tail call void @llvm.experimental.noalias.scope.decl(metadata !53)
  %_25.0.i = add i64 %additional, %len
  %_25.1.i = icmp ult i64 %_25.0.i, %len
  br i1 %_25.1.i, label %bb2, label %bb9.i

bb9.i:                                            ; preds = %start
  %self5.i = load i64, ptr %slf, align 8, !range !56, !alias.scope !53, !noundef !57
  %v16.i = shl nuw i64 %self5.i, 1
  %cap.i = tail call i64 @llvm.umax.i64(i64 %v16.i, i64 %_25.0.i)
  %0 = icmp eq i64 %elem_layout.1, 1
  %v1.sroa.0.0.i = select i1 %0, i64 8, i64 4
  %cap7.i = tail call i64 @llvm.umax.i64(i64 %v1.sroa.0.0.i, i64 %cap.i)
  call void @llvm.lifetime.start.p0(ptr nonnull %self3.i), !noalias !53
  %1 = getelementptr inbounds nuw i8, ptr %slf, i64 8
  %self.val15.i = load ptr, ptr %1, align 8, !alias.scope !53
; call <alloc::raw_vec::RawVecInner>::finish_grow
  call fastcc void @_RNvMs8_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner11finish_growCscgZyRT41Cnx_20mime_type_validation(ptr noalias nofree noundef align 8 captures(none) dereferenceable(24) %self3.i, i64 %self5.i, ptr %self.val15.i, i64 noundef %cap7.i, i64 noundef range(i64 1, 9) %elem_layout.0, i64 noundef range(i64 1, 49) %elem_layout.1) #19, !noalias !53
  %_37.i = load i64, ptr %self3.i, align 8, !range !58, !noalias !53, !noundef !57
  %2 = trunc nuw i64 %_37.i to i1
  %3 = getelementptr inbounds nuw i8, ptr %self3.i, i64 8
  br i1 %2, label %bb18.i, label %bb3

bb18.i:                                           ; preds = %bb9.i
  %e.0.i = load i64, ptr %3, align 8, !range !59, !noalias !53, !noundef !57
  %4 = getelementptr inbounds nuw i8, ptr %self3.i, i64 16
  %e.1.i = load i64, ptr %4, align 8, !noalias !53
  call void @llvm.lifetime.end.p0(ptr nonnull %self3.i), !noalias !53
  br label %bb2

bb2:                                              ; preds = %bb18.i, %start
  %_0.sroa.5.0.i.ph = phi i64 [ undef, %start ], [ %e.1.i, %bb18.i ]
  %_0.sroa.0.0.i.ph = phi i64 [ 0, %start ], [ %e.0.i, %bb18.i ]
; call alloc::raw_vec::handle_error
  tail call void @_RNvNtCs8tsiLsQ9XHg_5alloc7raw_vec12handle_error(i64 noundef %_0.sroa.0.0.i.ph, i64 %_0.sroa.5.0.i.ph) #20
  unreachable

bb3:                                              ; preds = %bb9.i
  %v.0.i = load ptr, ptr %3, align 8, !noalias !53, !nonnull !57, !noundef !57
  call void @llvm.lifetime.end.p0(ptr nonnull %self3.i), !noalias !53
  store ptr %v.0.i, ptr %1, align 8, !alias.scope !53
  %5 = icmp sgt i64 %cap7.i, -1
  tail call void @llvm.assume(i1 %5)
  store i64 %cap7.i, ptr %slf, align 8, !alias.scope !53
  ret void
}

; <alloc::raw_vec::RawVec<mime_type_validation::ffi::Parameter>>::grow_one
; Function Attrs: cold noinline nounwind uwtable
define internal fastcc void @_RNvMs7_NtCs8tsiLsQ9XHg_5alloc7raw_vecINtB5_6RawVecNtNtCscgZyRT41Cnx_20mime_type_validation3ffi9ParameterE8grow_oneBQ_(ptr noalias nofree noundef nonnull align 8 captures(none) dereferenceable(16) %self) unnamed_addr #2 !guid !60 {
start:
  %self3.i = alloca [24 x i8], align 8
  %self1 = load i64, ptr %self, align 8, !range !56, !noundef !57
  tail call void @llvm.experimental.noalias.scope.decl(metadata !61)
  %v16.i = shl nuw i64 %self1, 1
  %0 = tail call i64 @llvm.umax.i64(i64 %v16.i, i64 4)
  call void @llvm.lifetime.start.p0(ptr nonnull %self3.i), !noalias !61
  %1 = getelementptr inbounds nuw i8, ptr %self, i64 8
  %self.val15.i = load ptr, ptr %1, align 8, !alias.scope !61
; call <alloc::raw_vec::RawVecInner>::finish_grow
  call fastcc void @_RNvMs8_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner11finish_growCscgZyRT41Cnx_20mime_type_validation(ptr noalias nofree noundef align 8 captures(none) dereferenceable(24) %self3.i, i64 %self1, ptr %self.val15.i, i64 noundef %0, i64 noundef 8, i64 noundef 48) #19, !noalias !61
  %_37.i = load i64, ptr %self3.i, align 8, !range !58, !noalias !61, !noundef !57
  %2 = trunc nuw i64 %_37.i to i1
  %3 = getelementptr inbounds nuw i8, ptr %self3.i, i64 8
  br i1 %2, label %bb18.i, label %bb3

bb18.i:                                           ; preds = %start
  %e.0.i = load i64, ptr %3, align 8, !range !59, !noalias !61, !noundef !57
  %4 = getelementptr inbounds nuw i8, ptr %self3.i, i64 16
  %e.1.i = load i64, ptr %4, align 8, !noalias !61
  call void @llvm.lifetime.end.p0(ptr nonnull %self3.i), !noalias !61
; call alloc::raw_vec::handle_error
  tail call void @_RNvNtCs8tsiLsQ9XHg_5alloc7raw_vec12handle_error(i64 noundef %e.0.i, i64 %e.1.i) #20
  unreachable

bb3:                                              ; preds = %start
  %v.0.i = load ptr, ptr %3, align 8, !noalias !61, !nonnull !57, !noundef !57
  call void @llvm.lifetime.end.p0(ptr nonnull %self3.i), !noalias !61
  store ptr %v.0.i, ptr %1, align 8, !alias.scope !61
  %5 = icmp sgt i64 %0, -1
  tail call void @llvm.assume(i1 %5)
  store i64 %0, ptr %self, align 8, !alias.scope !61
  ret void
}

; <alloc::raw_vec::RawVecInner>::finish_grow
; Function Attrs: cold nounwind uwtable
define internal fastcc void @_RNvMs8_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner11finish_growCscgZyRT41Cnx_20mime_type_validation(ptr dead_on_unwind noalias nofree noundef nonnull writable writeonly align 8 captures(none) dereferenceable(24) %_0, i64 %self.0.val, ptr %self.8.val, i64 noundef range(i64 4, 0) %cap, i64 noundef range(i64 1, 9) %elem_layout.0, i64 noundef range(i64 1, 49) %elem_layout.1) unnamed_addr #1 personality ptr @__CxxFrameHandler3 !guid !64 {
start:
  %_10.sroa.5 = alloca i64, align 8
  %_10.sroa.8 = alloca i64, align 8
  %0 = tail call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %elem_layout.1, i64 %cap)
  %_32.0 = extractvalue { i64, i1 } %0, 0
  %_32.1 = extractvalue { i64, i1 } %0, 1
  %_39 = sub nuw i64 -9223372036854775808, %elem_layout.0
  %_37.not = icmp ugt i64 %_32.0, %_39
  %or.cond = select i1 %_32.1, i1 true, i1 %_37.not, !prof !65
  br i1 %or.cond, label %bb8, label %bb12, !prof !65

bb12:                                             ; preds = %start
  call void @llvm.lifetime.start.p0(ptr nonnull %_10.sroa.5)
  call void @llvm.lifetime.start.p0(ptr nonnull %_10.sroa.8)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !66)
  %1 = icmp eq i64 %self.0.val, 0
  br i1 %1, label %_RNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCscgZyRT41Cnx_20mime_type_validation.exit, label %bb4.i

bb4.i:                                            ; preds = %bb12
  %2 = tail call { i64, i1 } @llvm.umul.with.overflow.i64(i64 range(i64 1, 49) %elem_layout.1, i64 range(i64 1, -9223372036854775808) %self.0.val)
  %_7.1.i.i = extractvalue { i64, i1 } %2, 1
  br i1 %_7.1.i.i, label %bb1.i.i, label %_RNvNvMs9_NtCs9l4wcBNbII5_4core3numj13unchecked_mul18precondition_check.exit.i, !prof !69

bb1.i.i:                                          ; preds = %bb4.i
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_db07ae5a9ce650d9b7cc970d048e6f0c, ptr noundef nonnull inttoptr (i64 373 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_ad088eaa3dc0ae68b11fd72bfcf5e34b) #20, !noalias !66
  unreachable

_RNvNvMs9_NtCs9l4wcBNbII5_4core3numj13unchecked_mul18precondition_check.exit.i: ; preds = %bb4.i
  %alloc_size.i = mul nuw i64 %elem_layout.1, %self.0.val
  %3 = tail call range(i64 1, 5) i64 @llvm.ctpop.i64(i64 range(i64 1, 9) %elem_layout.0)
  %_7.i.i = icmp ne i64 %3, 1
  %_3.not.i.i = icmp ugt i64 %alloc_size.i, %_39
  %or.cond.i.i = select i1 %_7.i.i, i1 true, i1 %_3.not.i.i, !prof !70
  br i1 %or.cond.i.i, label %bb2.i.i, label %_RNvNvMNtNtCs9l4wcBNbII5_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_check.exit.i, !prof !70

bb2.i.i:                                          ; preds = %_RNvNvMs9_NtCs9l4wcBNbII5_4core3numj13unchecked_mul18precondition_check.exit.i
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_1be5ea12ba708d9a11b6e93a7d387a75, ptr noundef nonnull inttoptr (i64 563 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_dade1aed0d0fe800cb3ecdb07302e098) #20, !noalias !66
  unreachable

_RNvNvMNtNtCs9l4wcBNbII5_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_check.exit.i: ; preds = %_RNvNvMs9_NtCs9l4wcBNbII5_4core3numj13unchecked_mul18precondition_check.exit.i
  call void @llvm.assume(i1 true) [ "nonnull"(ptr %self.8.val) ]
  store i64 %elem_layout.0, ptr %_10.sroa.5, align 8, !alias.scope !66
  br label %_RNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCscgZyRT41Cnx_20mime_type_validation.exit

_RNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCscgZyRT41Cnx_20mime_type_validation.exit: ; preds = %bb12, %_RNvNvMNtNtCs9l4wcBNbII5_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_check.exit.i
  %_10.sroa.0.0 = phi ptr [ undef, %bb12 ], [ %self.8.val, %_RNvNvMNtNtCs9l4wcBNbII5_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_check.exit.i ]
  %.sink.i.sroa.phi = phi ptr [ %_10.sroa.5, %bb12 ], [ %_10.sroa.8, %_RNvNvMNtNtCs9l4wcBNbII5_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_check.exit.i ]
  %alloc_size.sink.i = phi i64 [ 0, %bb12 ], [ %alloc_size.i, %_RNvNvMNtNtCs9l4wcBNbII5_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_check.exit.i ]
  store i64 %alloc_size.sink.i, ptr %.sink.i.sroa.phi, align 8, !alias.scope !66
  %_10.sroa.5.0._10.sroa.5.0._10.sroa.5.0._10.sroa.5.8. = load i64, ptr %_10.sroa.5, align 8, !range !59, !noundef !57
  %.not = icmp eq i64 %_10.sroa.5.0._10.sroa.5.0._10.sroa.5.0._10.sroa.5.8., 0
  br i1 %.not, label %bb5, label %bb3

bb3:                                              ; preds = %_RNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCscgZyRT41Cnx_20mime_type_validation.exit
  call void @llvm.assume(i1 true) [ "nonnull"(ptr %_10.sroa.0.0) ]
  %_10.sroa.8.0._10.sroa.8.0._10.sroa.8.0._10.sroa.8.16.old_layout.1 = load i64, ptr %_10.sroa.8, align 8, !noundef !57
  %cond = icmp eq i64 %_10.sroa.5.0._10.sroa.5.0._10.sroa.5.0._10.sroa.5.8., %elem_layout.0
  br i1 %cond, label %_RNvNvNtCs9l4wcBNbII5_4core4hint16assert_unchecked18precondition_check.exit, label %bb1.i, !prof !71

bb1.i:                                            ; preds = %bb3
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_64e308ef4babfeb8b6220184de794a17, ptr noundef nonnull inttoptr (i64 443 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_5a885d3db7500f26d581e948d37c49fe) #20
  unreachable

_RNvNvNtCs9l4wcBNbII5_4core4hint16assert_unchecked18precondition_check.exit: ; preds = %bb3
  %4 = icmp eq i64 %_10.sroa.8.0._10.sroa.8.0._10.sroa.8.0._10.sroa.8.16.old_layout.1, 0
  br i1 %4, label %bb2.i.i14, label %bb3.i.i

bb2.i.i14:                                        ; preds = %_RNvNvNtCs9l4wcBNbII5_4core4hint16assert_unchecked18precondition_check.exit
  %5 = icmp eq i64 %_32.0, 0
  br i1 %5, label %bb2.i.i.i, label %bb4.i.i.i

bb2.i.i.i:                                        ; preds = %bb2.i.i14
  %self3.i.i.i = inttoptr i64 %elem_layout.0 to ptr
  br label %_RNvXs1_NtCs8tsiLsQ9XHg_5alloc5allocNtB5_6GlobalNtNtCs9l4wcBNbII5_4core5alloc9Allocator4grow.exit

bb4.i.i.i:                                        ; preds = %bb2.i.i14
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  tail call void @_RNvCs6d6XRwTwhVh_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #19
; call __rustc::__rust_alloc
  %6 = tail call noundef ptr @_RNvCs6d6XRwTwhVh_7___rustc12___rust_alloc(i64 noundef range(i64 0, -9223372036854775808) %_32.0, i64 noundef range(i64 1, 9) %elem_layout.0) #19
  br label %_RNvXs1_NtCs8tsiLsQ9XHg_5alloc5allocNtB5_6GlobalNtNtCs9l4wcBNbII5_4core5alloc9Allocator4grow.exit

bb3.i.i:                                          ; preds = %_RNvNvNtCs9l4wcBNbII5_4core4hint16assert_unchecked18precondition_check.exit
  %cond.not.i.i = icmp ult i64 %_32.0, %_10.sroa.8.0._10.sroa.8.0._10.sroa.8.0._10.sroa.8.16.old_layout.1
  br i1 %cond.not.i.i, label %bb1.i.i.i, label %_RNvNvNtCs9l4wcBNbII5_4core4hint16assert_unchecked18precondition_check.exit.i.i, !prof !69

bb1.i.i.i:                                        ; preds = %bb3.i.i
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_64e308ef4babfeb8b6220184de794a17, ptr noundef nonnull inttoptr (i64 443 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_1b98de0e82d923a9daff35d520cf360d) #20
  unreachable

_RNvNvNtCs9l4wcBNbII5_4core4hint16assert_unchecked18precondition_check.exit.i.i: ; preds = %bb3.i.i
; call __rustc::__rust_realloc
  %raw_ptr.i.i = tail call noundef ptr @_RNvCs6d6XRwTwhVh_7___rustc14___rust_realloc(ptr noundef nonnull %_10.sroa.0.0, i64 noundef %_10.sroa.8.0._10.sroa.8.0._10.sroa.8.0._10.sroa.8.16.old_layout.1, i64 noundef range(i64 1, 9) %elem_layout.0, i64 noundef range(i64 0, -9223372036854775808) %_32.0) #19
  br label %_RNvXs1_NtCs8tsiLsQ9XHg_5alloc5allocNtB5_6GlobalNtNtCs9l4wcBNbII5_4core5alloc9Allocator4grow.exit

_RNvXs1_NtCs8tsiLsQ9XHg_5alloc5allocNtB5_6GlobalNtNtCs9l4wcBNbII5_4core5alloc9Allocator4grow.exit: ; preds = %bb2.i.i.i, %bb4.i.i.i, %_RNvNvNtCs9l4wcBNbII5_4core4hint16assert_unchecked18precondition_check.exit.i.i
  %_0.sroa.0.0.i.i = phi ptr [ %raw_ptr.i.i, %_RNvNvNtCs9l4wcBNbII5_4core4hint16assert_unchecked18precondition_check.exit.i.i ], [ %self3.i.i.i, %bb2.i.i.i ], [ %6, %bb4.i.i.i ]
  call void @llvm.lifetime.end.p0(ptr nonnull %_10.sroa.5)
  call void @llvm.lifetime.end.p0(ptr nonnull %_10.sroa.8)
  br label %bb7

bb5:                                              ; preds = %_RNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCscgZyRT41Cnx_20mime_type_validation.exit
  call void @llvm.lifetime.end.p0(ptr nonnull %_10.sroa.5)
  call void @llvm.lifetime.end.p0(ptr nonnull %_10.sroa.8)
  %7 = icmp eq i64 %_32.0, 0
  br i1 %7, label %bb7.thread, label %bb4.i.i15

bb7.thread:                                       ; preds = %bb5
  %self3.i.i = inttoptr i64 %elem_layout.0 to ptr
  br label %bb19

bb4.i.i15:                                        ; preds = %bb5
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  tail call void @_RNvCs6d6XRwTwhVh_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #19
; call __rustc::__rust_alloc
  %8 = tail call noundef ptr @_RNvCs6d6XRwTwhVh_7___rustc12___rust_alloc(i64 noundef range(i64 0, -9223372036854775808) %_32.0, i64 noundef range(i64 1, 9) %elem_layout.0) #19
  br label %bb7

bb7:                                              ; preds = %bb4.i.i15, %_RNvXs1_NtCs8tsiLsQ9XHg_5alloc5allocNtB5_6GlobalNtNtCs9l4wcBNbII5_4core5alloc9Allocator4grow.exit
  %_0.sroa.0.0.i.i.pn = phi ptr [ %_0.sroa.0.0.i.i, %_RNvXs1_NtCs8tsiLsQ9XHg_5alloc5allocNtB5_6GlobalNtNtCs9l4wcBNbII5_4core5alloc9Allocator4grow.exit ], [ %8, %bb4.i.i15 ]
  %9 = icmp eq ptr %_0.sroa.0.0.i.i.pn, null
  br i1 %9, label %bb18, label %bb19

bb18:                                             ; preds = %bb7
  %10 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 %elem_layout.0, ptr %10, align 8
  br label %bb8

bb19:                                             ; preds = %bb7.thread, %bb7
  %_0.sroa.0.0.i.i.pn5 = phi ptr [ %self3.i.i, %bb7.thread ], [ %_0.sroa.0.0.i.i.pn, %bb7 ]
  %11 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store ptr %_0.sroa.0.0.i.i.pn5, ptr %11, align 8
  br label %bb8

bb8:                                              ; preds = %start, %bb19, %bb18
  %.sink7 = phi i64 [ 16, %bb19 ], [ 16, %bb18 ], [ 8, %start ]
  %_32.0.sink = phi i64 [ %_32.0, %bb19 ], [ %_32.0, %bb18 ], [ 0, %start ]
  %.sink = phi i64 [ 0, %bb19 ], [ 1, %bb18 ], [ 1, %start ]
  %12 = getelementptr inbounds nuw i8, ptr %_0, i64 %.sink7
  store i64 %_32.0.sink, ptr %12, align 8
  store i64 %.sink, ptr %_0, align 8
  ret void
}

; mime_type_validation::mime_type_parser::output_value
; Function Attrs: nounwind uwtable
define internal fastcc void @_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser12output_value(ptr dead_on_unwind noalias nofree noundef nonnull writable align 8 captures(none) dereferenceable(24) initializes((0, 24)) %span, ptr noalias nofree noundef nonnull readonly captures(address) %input.0, i64 noundef range(i64 0, -9223372036854775808) %input.1, ptr noalias nofree noundef nonnull readonly align 8 captures(none) dead_on_return dereferenceable(32) %value, ptr noalias nofree noundef nonnull align 8 dereferenceable(24) %scratch, i1 noundef zeroext %trim_lws, i1 noundef zeroext %lower) unnamed_addr #3 personality ptr @__CxxFrameHandler3 !guid !72 {
start:
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %span, ptr noundef nonnull align 8 dereferenceable(24) %value, i64 24, i1 false)
  %0 = getelementptr inbounds nuw i8, ptr %value, i64 24
  %1 = load i8, ptr %0, align 8, !range !73, !noundef !57
  %_6 = trunc nuw i8 %1 to i1
  br i1 %_6, label %bb1, label %bb23

bb23:                                             ; preds = %start
  br i1 %trim_lws, label %bb24, label %bb26

bb1:                                              ; preds = %start
  %2 = getelementptr inbounds nuw i8, ptr %scratch, i64 16
  %start2 = load i64, ptr %2, align 8, !noundef !57
  %_46 = icmp sgt i64 %start2, -1
  tail call void @llvm.assume(i1 %_46)
  %3 = getelementptr inbounds nuw i8, ptr %span, i64 8
  %_10 = load i64, ptr %3, align 8, !noundef !57
  %_11 = load i64, ptr %span, align 8, !noundef !57
  %_12.1 = icmp ult i64 %_10, %_11
  br i1 %_12.1, label %panic, label %bb2

bb26:                                             ; preds = %bb6.i, %_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser4trim.exit.loopexit, %_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser4trim.exit.loopexit49, %bb23
  %_36 = load i64, ptr %span, align 8, !noundef !57
  %4 = getelementptr inbounds nuw i8, ptr %span, i64 8
  %_37 = load i64, ptr %4, align 8, !noundef !57
  %_63 = icmp ult i64 %_37, %_36
  %_57.not = icmp ugt i64 %_37, %input.1
  %or.cond = or i1 %_63, %_57.not
  br i1 %or.cond, label %bb39, label %bb37, !prof !70

bb24:                                             ; preds = %bb23
  tail call void @llvm.experimental.noalias.scope.decl(metadata !74)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !77)
  %5 = getelementptr inbounds nuw i8, ptr %span, i64 8
  %_5.i = load i64, ptr %5, align 8, !alias.scope !74, !noundef !57
  %span.promoted.i = load i64, ptr %span, align 8, !alias.scope !74
  %_38.i = icmp ult i64 %span.promoted.i, %_5.i
  br i1 %_38.i, label %bb2.preheader.i, label %bb6.i

bb2.preheader.i:                                  ; preds = %bb24
  %umax.i = tail call i64 @llvm.umax.i64(i64 %span.promoted.i, i64 range(i64 0, -9223372036854775808) %input.1)
  br label %bb2.i

bb2.i:                                            ; preds = %bb4.i, %bb2.preheader.i
  %_10.0.i58 = phi i64 [ %_10.0.i, %bb4.i ], [ %span.promoted.i, %bb2.preheader.i ]
  %exitcond.not.i = icmp eq i64 %_10.0.i58, %umax.i
  br i1 %exitcond.not.i, label %panic.i, label %bb3.i

bb6.i.loopexit:                                   ; preds = %bb3.i
  store i64 %_10.0.i58, ptr %span, align 8
  br label %bb6.i

bb6.i:                                            ; preds = %bb6.i.loopexit, %bb24
  %_4.lcssa.i = phi i64 [ %span.promoted.i, %bb24 ], [ %_10.0.i58, %bb6.i.loopexit ]
  %_1112.i = icmp ugt i64 %_5.i, %_4.lcssa.i
  br i1 %_1112.i, label %bb8.i, label %bb26

bb3.i:                                            ; preds = %bb2.i
  %6 = getelementptr inbounds nuw i8, ptr %input.0, i64 %_10.0.i58
  %_6.i = load i8, ptr %6, align 1, !alias.scope !77, !noundef !57
  switch i8 %_6.i, label %bb6.i.loopexit [
    i8 32, label %bb4.i
    i8 9, label %bb4.i
  ]

panic.i:                                          ; preds = %bb2.i
  store i64 %umax.i, ptr %span, align 8
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_bounds_check(i64 noundef %umax.i, i64 noundef range(i64 0, -9223372036854775808) %input.1, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_5ae9d5ffcd4a9e402f4daeafec83ac84) #20, !noalias !79
  unreachable

bb4.i:                                            ; preds = %bb3.i, %bb3.i
  %_10.0.i = add i64 %_10.0.i58, 1
  %exitcond16.not.i = icmp eq i64 %_10.0.i, %_5.i
  br i1 %exitcond16.not.i, label %_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser4trim.exit.loopexit49, label %bb2.i

bb8.i:                                            ; preds = %bb6.i, %bb11.i
  %_17.0.i60 = phi i64 [ %_17.0.i, %bb11.i ], [ %_5.i, %bb6.i ]
  %_17.0.i = add i64 %_17.0.i60, -1
  %_19.i = icmp ult i64 %_17.0.i, %input.1
  br i1 %_19.i, label %bb10.i, label %panic3.i

bb10.i:                                           ; preds = %bb8.i
  %7 = getelementptr inbounds nuw i8, ptr %input.0, i64 %_17.0.i
  %_14.i = load i8, ptr %7, align 1, !alias.scope !77, !noundef !57
  switch i8 %_14.i, label %_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser4trim.exit.loopexit [
    i8 32, label %bb11.i
    i8 9, label %bb11.i
  ]

panic3.i:                                         ; preds = %bb8.i
  store i64 %_17.0.i60, ptr %5, align 8
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_bounds_check(i64 noundef %_17.0.i, i64 noundef range(i64 0, -9223372036854775808) %input.1, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_b65862ba02ce59bf102bd5cffbc3e71e) #20, !noalias !79
  unreachable

bb11.i:                                           ; preds = %bb10.i, %bb10.i
  %_11.i = icmp ugt i64 %_17.0.i, %_4.lcssa.i
  br i1 %_11.i, label %bb8.i, label %_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser4trim.exit.loopexit

_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser4trim.exit.loopexit: ; preds = %bb11.i, %bb10.i
  %_17.0.i61 = phi i64 [ %_4.lcssa.i, %bb11.i ], [ %_17.0.i60, %bb10.i ]
  store i64 %_17.0.i61, ptr %5, align 8
  br label %bb26

_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser4trim.exit.loopexit49: ; preds = %bb4.i
  store i64 %_5.i, ptr %span, align 8
  br label %bb26

bb37:                                             ; preds = %bb26
  %_66 = getelementptr inbounds nuw i8, ptr %input.0, i64 %_36
  br i1 %lower, label %bb27, label %bb32

bb39:                                             ; preds = %bb26
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCs9l4wcBNbII5_4core5slice5index16slice_index_fail(i64 noundef %_36, i64 noundef %_37, i64 noundef %input.1, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_e09840ce091b9d84c9136134ef6d6d3f) #20
  unreachable

bb27:                                             ; preds = %bb37
  %_70 = getelementptr inbounds nuw i8, ptr %input.0, i64 %_37
  %_12.not.not.not.i.not106 = icmp samesign eq i64 %_36, %_37
  br i1 %_12.not.not.not.i.not106, label %bb32, label %bb13.i

bb1.i:                                            ; preds = %bb13.i
  %_22.i = getelementptr inbounds nuw i8, ptr %_221.i107, i64 1
  %_12.not.not.not.i.not = icmp eq ptr %_22.i, %_70
  br i1 %_12.not.not.not.i.not, label %bb32, label %bb13.i

bb13.i:                                           ; preds = %bb27, %bb1.i
  %_221.i107 = phi ptr [ %_22.i, %bb1.i ], [ %_66, %bb27 ]
  %ptr.val.i = load i8, ptr %_221.i107, align 1, !noalias !81, !noundef !57
  %8 = add i8 %ptr.val.i, -65
  %_0.sroa.0.0.i.i.i = icmp ult i8 %8, 26
  br i1 %_0.sroa.0.0.i.i.i, label %bb29, label %bb1.i

bb29:                                             ; preds = %bb13.i
  %9 = getelementptr inbounds nuw i8, ptr %scratch, i64 16
  %start1 = load i64, ptr %9, align 8, !noundef !57
  %_75 = icmp sgt i64 %start1, -1
  tail call void @llvm.assume(i1 %_75)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !84)
  %gepdiff = sub nuw nsw i64 %_37, %_36
  %self2.i.i = load i64, ptr %scratch, align 8, !range !56, !alias.scope !87, !noundef !57
  %_9.i.i = sub nsw i64 %self2.i.i, %start1
  %_7.i.i = icmp ugt i64 %gepdiff, %_9.i.i
  br i1 %_7.i.i, label %bb1.i.i, label %iter.check, !prof !69

bb1.i.i:                                          ; preds = %bb29
; call <alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>
  tail call fastcc void @_RINvNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECscgZyRT41Cnx_20mime_type_validation(ptr noalias nofree noundef nonnull align 8 dereferenceable(24) %scratch, i64 noundef %start1, i64 noundef %gepdiff, i64 noundef 1, i64 noundef 1) #19
  %_27.pre.i = load i64, ptr %9, align 8, !alias.scope !84
  br label %iter.check

iter.check:                                       ; preds = %bb1.i.i, %bb29
  %_27.i = phi i64 [ %start1, %bb29 ], [ %_27.pre.i, %bb1.i.i ]
  %10 = getelementptr inbounds nuw i8, ptr %scratch, i64 8
  %_26.i = load ptr, ptr %10, align 8, !alias.scope !84, !nonnull !57, !noundef !57
  %min.iters.check = icmp ult i64 %gepdiff, 8
  br i1 %min.iters.check, label %_RNvNvMs9_NtCs9l4wcBNbII5_4core3numj13unchecked_add18precondition_check.exit.i.i.i.i.preheader, label %vector.main.loop.iter.check

vector.main.loop.iter.check:                      ; preds = %iter.check
  %min.iters.check108 = icmp ult i64 %gepdiff, 32
  br i1 %min.iters.check108, label %vec.epilog.ph, label %vector.ph

vector.ph:                                        ; preds = %vector.main.loop.iter.check
  %11 = and i64 %gepdiff, 24
  %n.vec = and i64 %gepdiff, -32
  %12 = add i64 %_27.i, %n.vec
  %13 = getelementptr i8, ptr %_26.i, i64 %_27.i
  br label %vector.body

vector.body:                                      ; preds = %vector.ph, %vector.body
  %index = phi i64 [ 0, %vector.ph ], [ %index.next, %vector.body ]
  %14 = getelementptr inbounds nuw i8, ptr %_66, i64 %index
  %15 = getelementptr inbounds nuw i8, ptr %14, i64 16
  %wide.load = load <16 x i8>, ptr %14, align 1, !noalias !90
  %wide.load109 = load <16 x i8>, ptr %15, align 1, !noalias !90
  %16 = add <16 x i8> %wide.load, splat (i8 -65)
  %17 = add <16 x i8> %wide.load109, splat (i8 -65)
  %18 = icmp ult <16 x i8> %16, splat (i8 26)
  %19 = icmp ult <16 x i8> %17, splat (i8 26)
  %20 = select <16 x i1> %18, <16 x i8> splat (i8 32), <16 x i8> zeroinitializer
  %21 = select <16 x i1> %19, <16 x i8> splat (i8 32), <16 x i8> zeroinitializer
  %22 = or <16 x i8> %20, %wide.load
  %23 = or <16 x i8> %21, %wide.load109
  %24 = getelementptr i8, ptr %13, i64 %index
  %25 = getelementptr inbounds nuw i8, ptr %24, i64 16
  store <16 x i8> %22, ptr %24, align 1, !noalias !97
  store <16 x i8> %23, ptr %25, align 1, !noalias !97
  %index.next = add nuw i64 %index, 32
  %26 = icmp eq i64 %index.next, %n.vec
  br i1 %26, label %middle.block, label %vector.body, !llvm.loop !104

middle.block:                                     ; preds = %vector.body
  %cmp.n = icmp eq i64 %gepdiff, %n.vec
  br i1 %cmp.n, label %_RINvMsk_NtCs8tsiLsQ9XHg_5alloc3vecINtB6_3VechE14extend_trustedINtNtNtNtCs9l4wcBNbII5_4core4iter8adapters3map3MapINtNtNtB17_5slice4iter4IterhENvMs4_NtB17_3numh18to_ascii_lowercaseEECscgZyRT41Cnx_20mime_type_validation.exit, label %vec.epilog.iter.check

vec.epilog.iter.check:                            ; preds = %middle.block
  %min.epilog.iters.check = icmp eq i64 %11, 0
  br i1 %min.epilog.iters.check, label %_RNvNvMs9_NtCs9l4wcBNbII5_4core3numj13unchecked_add18precondition_check.exit.i.i.i.i.preheader, label %vec.epilog.ph, !prof !107

vec.epilog.ph:                                    ; preds = %vector.main.loop.iter.check, %vec.epilog.iter.check
  %vec.epilog.resume.val = phi i64 [ %n.vec, %vec.epilog.iter.check ], [ 0, %vector.main.loop.iter.check ]
  %n.vec110 = and i64 %gepdiff, -8
  %27 = add i64 %_27.i, %n.vec110
  %28 = getelementptr i8, ptr %_26.i, i64 %_27.i
  br label %vec.epilog.vector.body

vec.epilog.vector.body:                           ; preds = %vec.epilog.vector.body, %vec.epilog.ph
  %index111 = phi i64 [ %vec.epilog.resume.val, %vec.epilog.ph ], [ %index.next113, %vec.epilog.vector.body ]
  %29 = getelementptr inbounds nuw i8, ptr %_66, i64 %index111
  %wide.load112 = load <8 x i8>, ptr %29, align 1, !noalias !90
  %30 = add <8 x i8> %wide.load112, splat (i8 -65)
  %31 = icmp ult <8 x i8> %30, splat (i8 26)
  %32 = select <8 x i1> %31, <8 x i8> splat (i8 32), <8 x i8> zeroinitializer
  %33 = or <8 x i8> %32, %wide.load112
  %34 = getelementptr i8, ptr %28, i64 %index111
  store <8 x i8> %33, ptr %34, align 1, !noalias !97
  %index.next113 = add nuw i64 %index111, 8
  %35 = icmp eq i64 %index.next113, %n.vec110
  br i1 %35, label %vec.epilog.middle.block, label %vec.epilog.vector.body, !llvm.loop !108

vec.epilog.middle.block:                          ; preds = %vec.epilog.vector.body
  %cmp.n114 = icmp eq i64 %gepdiff, %n.vec110
  br i1 %cmp.n114, label %_RINvMsk_NtCs8tsiLsQ9XHg_5alloc3vecINtB6_3VechE14extend_trustedINtNtNtNtCs9l4wcBNbII5_4core4iter8adapters3map3MapINtNtNtB17_5slice4iter4IterhENvMs4_NtB17_3numh18to_ascii_lowercaseEECscgZyRT41Cnx_20mime_type_validation.exit, label %_RNvNvMs9_NtCs9l4wcBNbII5_4core3numj13unchecked_add18precondition_check.exit.i.i.i.i.preheader

_RNvNvMs9_NtCs9l4wcBNbII5_4core3numj13unchecked_add18precondition_check.exit.i.i.i.i.preheader: ; preds = %iter.check, %vec.epilog.iter.check, %vec.epilog.middle.block
  %.ph = phi i64 [ %_27.i, %iter.check ], [ %12, %vec.epilog.iter.check ], [ %27, %vec.epilog.middle.block ]
  %i.sroa.0.0.i.i.i.i.ph = phi i64 [ 0, %iter.check ], [ %n.vec, %vec.epilog.iter.check ], [ %n.vec110, %vec.epilog.middle.block ]
  br label %_RNvNvMs9_NtCs9l4wcBNbII5_4core3numj13unchecked_add18precondition_check.exit.i.i.i.i

_RNvNvMs9_NtCs9l4wcBNbII5_4core3numj13unchecked_add18precondition_check.exit.i.i.i.i: ; preds = %_RNvNvMs9_NtCs9l4wcBNbII5_4core3numj13unchecked_add18precondition_check.exit.i.i.i.i.preheader, %_RNvNvMs9_NtCs9l4wcBNbII5_4core3numj13unchecked_add18precondition_check.exit.i.i.i.i
  %36 = phi i64 [ %40, %_RNvNvMs9_NtCs9l4wcBNbII5_4core3numj13unchecked_add18precondition_check.exit.i.i.i.i ], [ %.ph, %_RNvNvMs9_NtCs9l4wcBNbII5_4core3numj13unchecked_add18precondition_check.exit.i.i.i.i.preheader ]
  %i.sroa.0.0.i.i.i.i = phi i64 [ %_27.i.i.i.i, %_RNvNvMs9_NtCs9l4wcBNbII5_4core3numj13unchecked_add18precondition_check.exit.i.i.i.i ], [ %i.sroa.0.0.i.i.i.i.ph, %_RNvNvMs9_NtCs9l4wcBNbII5_4core3numj13unchecked_add18precondition_check.exit.i.i.i.i.preheader ]
  %_45.i.i.i.i = getelementptr inbounds nuw i8, ptr %_66, i64 %i.sroa.0.0.i.i.i.i
  %_45.val.i.i.i.i = load i8, ptr %_45.i.i.i.i, align 1, !noalias !90, !noundef !57
  %37 = add i8 %_45.val.i.i.i.i, -65
  %38 = icmp ult i8 %37, 26
  %39 = select i1 %38, i8 32, i8 0
  %_6.sroa.0.0.i.i.i.i.i.i.i = or i8 %39, %_45.val.i.i.i.i
  %_3.i.i.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %_26.i, i64 %36
  store i8 %_6.sroa.0.0.i.i.i.i.i.i.i, ptr %_3.i.i.i.i.i.i.i, align 1, !noalias !97
  %40 = add i64 %36, 1
  %_27.i.i.i.i = add nuw i64 %i.sroa.0.0.i.i.i.i, 1
  %_28.i.i.i.i = icmp eq i64 %_27.i.i.i.i, %gepdiff
  br i1 %_28.i.i.i.i, label %_RINvMsk_NtCs8tsiLsQ9XHg_5alloc3vecINtB6_3VechE14extend_trustedINtNtNtNtCs9l4wcBNbII5_4core4iter8adapters3map3MapINtNtNtB17_5slice4iter4IterhENvMs4_NtB17_3numh18to_ascii_lowercaseEECscgZyRT41Cnx_20mime_type_validation.exit, label %_RNvNvMs9_NtCs9l4wcBNbII5_4core3numj13unchecked_add18precondition_check.exit.i.i.i.i, !llvm.loop !109

_RINvMsk_NtCs8tsiLsQ9XHg_5alloc3vecINtB6_3VechE14extend_trustedINtNtNtNtCs9l4wcBNbII5_4core4iter8adapters3map3MapINtNtNtB17_5slice4iter4IterhENvMs4_NtB17_3numh18to_ascii_lowercaseEECscgZyRT41Cnx_20mime_type_validation.exit: ; preds = %_RNvNvMs9_NtCs9l4wcBNbII5_4core3numj13unchecked_add18precondition_check.exit.i.i.i.i, %vec.epilog.middle.block, %middle.block
  %.lcssa101 = phi i64 [ %27, %vec.epilog.middle.block ], [ %12, %middle.block ], [ %40, %_RNvNvMs9_NtCs9l4wcBNbII5_4core3numj13unchecked_add18precondition_check.exit.i.i.i.i ]
  store i64 %.lcssa101, ptr %9, align 8, !alias.scope !84, !noalias !110
  %_84 = icmp sgt i64 %.lcssa101, -1
  tail call void @llvm.assume(i1 %_84)
  store i64 %start1, ptr %span, align 8
  store i64 %.lcssa101, ptr %4, align 8
  %41 = getelementptr inbounds nuw i8, ptr %span, i64 16
  store i8 1, ptr %41, align 8
  br label %bb32

bb32:                                             ; preds = %bb1.i, %bb6.i19, %_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser4trim.exit43.loopexit, %_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser4trim.exit43.loopexit48, %bb27, %bb19, %bb37, %_RINvMsk_NtCs8tsiLsQ9XHg_5alloc3vecINtB6_3VechE14extend_trustedINtNtNtNtCs9l4wcBNbII5_4core4iter8adapters3map3MapINtNtNtB17_5slice4iter4IterhENvMs4_NtB17_3numh18to_ascii_lowercaseEECscgZyRT41Cnx_20mime_type_validation.exit
  ret void

bb2:                                              ; preds = %bb1
  %_12.0 = sub nuw i64 %_10, %_11
  %self2.i = load i64, ptr %scratch, align 8, !range !56, !alias.scope !111, !noundef !57
  %_9.i = sub nsw i64 %self2.i, %start2
  %_7.i = icmp ugt i64 %_12.0, %_9.i
  br i1 %_7.i, label %bb1.i15, label %_RNvMs_NtCs8tsiLsQ9XHg_5alloc3vecINtB4_3VechE7reserveCscgZyRT41Cnx_20mime_type_validation.exit, !prof !69

bb1.i15:                                          ; preds = %bb2
; call <alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>
  tail call fastcc void @_RINvNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECscgZyRT41Cnx_20mime_type_validation(ptr noalias nofree noundef nonnull align 8 dereferenceable(24) %scratch, i64 noundef %start2, i64 noundef %_12.0, i64 noundef 1, i64 noundef 1) #19
  br label %_RNvMs_NtCs8tsiLsQ9XHg_5alloc3vecINtB4_3VechE7reserveCscgZyRT41Cnx_20mime_type_validation.exit

_RNvMs_NtCs8tsiLsQ9XHg_5alloc3vecINtB4_3VechE7reserveCscgZyRT41Cnx_20mime_type_validation.exit: ; preds = %bb2, %bb1.i15
  %_1462 = icmp ult i64 %_11, %_10
  br i1 %_1462, label %bb5.lr.ph, label %_RNvMs_NtCs8tsiLsQ9XHg_5alloc3vecINtB4_3VechE7reserveCscgZyRT41Cnx_20mime_type_validation.exit.bb19_crit_edge

_RNvMs_NtCs8tsiLsQ9XHg_5alloc3vecINtB4_3VechE7reserveCscgZyRT41Cnx_20mime_type_validation.exit.bb19_crit_edge: ; preds = %_RNvMs_NtCs8tsiLsQ9XHg_5alloc3vecINtB4_3VechE7reserveCscgZyRT41Cnx_20mime_type_validation.exit
  %_32.pre = load i64, ptr %2, align 8
  br label %bb19

bb5.lr.ph:                                        ; preds = %_RNvMs_NtCs8tsiLsQ9XHg_5alloc3vecINtB4_3VechE7reserveCscgZyRT41Cnx_20mime_type_validation.exit
  %42 = getelementptr inbounds nuw i8, ptr %scratch, i64 8
  br label %bb5

panic:                                            ; preds = %bb1
; call core::panicking::panic_const::panic_const_sub_overflow
  tail call void @_RNvNtNtCs9l4wcBNbII5_4core9panicking11panic_const24panic_const_sub_overflow(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_4827d7bcd2d5f9ba5354abce3f721069) #20
  unreachable

bb19:                                             ; preds = %_RNvMsG_NtCs8tsiLsQ9XHg_5alloc3vecINtB5_3VechE8push_mutCscgZyRT41Cnx_20mime_type_validation.exit, %_RNvMs_NtCs8tsiLsQ9XHg_5alloc3vecINtB4_3VechE7reserveCscgZyRT41Cnx_20mime_type_validation.exit.bb19_crit_edge
  %.promoted66 = phi i64 [ %_32.pre, %_RNvMs_NtCs8tsiLsQ9XHg_5alloc3vecINtB4_3VechE7reserveCscgZyRT41Cnx_20mime_type_validation.exit.bb19_crit_edge ], [ %54, %_RNvMsG_NtCs8tsiLsQ9XHg_5alloc3vecINtB5_3VechE8push_mutCscgZyRT41Cnx_20mime_type_validation.exit ]
  %_52 = icmp sgt i64 %.promoted66, -1
  tail call void @llvm.assume(i1 %_52)
  store i64 %start2, ptr %span, align 8
  store i64 %.promoted66, ptr %3, align 8
  %43 = getelementptr inbounds nuw i8, ptr %span, i64 16
  store i8 1, ptr %43, align 8
  br i1 %trim_lws, label %bb20, label %bb32

bb5:                                              ; preds = %bb5.lr.ph, %_RNvMsG_NtCs8tsiLsQ9XHg_5alloc3vecINtB5_3VechE8push_mutCscgZyRT41Cnx_20mime_type_validation.exit
  %offset.sroa.0.063 = phi i64 [ %_11, %bb5.lr.ph ], [ %_31.0, %_RNvMsG_NtCs8tsiLsQ9XHg_5alloc3vecINtB5_3VechE8push_mutCscgZyRT41Cnx_20mime_type_validation.exit ]
  %_20 = icmp ult i64 %offset.sroa.0.063, %input.1
  br i1 %_20, label %bb6, label %panic3

bb20:                                             ; preds = %bb19
  %44 = getelementptr inbounds nuw i8, ptr %scratch, i64 8
  %_56 = load ptr, ptr %44, align 8, !nonnull !57, !noundef !57
  tail call void @llvm.experimental.noalias.scope.decl(metadata !114)
  %_38.i18 = icmp samesign ult i64 %start2, %.promoted66
  br i1 %_38.i18, label %bb2.i34, label %bb6.i19

bb2.i34:                                          ; preds = %bb20, %bb4.i39
  %_10.0.i4065 = phi i64 [ %_10.0.i40, %bb4.i39 ], [ %start2, %bb20 ]
  %45 = getelementptr inbounds nuw i8, ptr %_56, i64 %_10.0.i4065
  %_6.i38 = load i8, ptr %45, align 1, !alias.scope !114, !noundef !57
  switch i8 %_6.i38, label %bb6.i19.loopexit [
    i8 32, label %bb4.i39
    i8 9, label %bb4.i39
  ]

bb6.i19.loopexit:                                 ; preds = %bb2.i34
  store i64 %_10.0.i4065, ptr %span, align 8
  br label %bb6.i19

bb6.i19:                                          ; preds = %bb6.i19.loopexit, %bb20
  %_4.lcssa.i20 = phi i64 [ %start2, %bb20 ], [ %_10.0.i4065, %bb6.i19.loopexit ]
  %_1112.i21 = icmp ugt i64 %.promoted66, %_4.lcssa.i20
  br i1 %_1112.i21, label %bb8.i23, label %bb32

bb4.i39:                                          ; preds = %bb2.i34, %bb2.i34
  %_10.0.i40 = add i64 %_10.0.i4065, 1
  %exitcond16.not.i41 = icmp eq i64 %_10.0.i40, %.promoted66
  br i1 %exitcond16.not.i41, label %_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser4trim.exit43.loopexit48, label %bb2.i34

bb8.i23:                                          ; preds = %bb6.i19, %bb11.i30
  %_17.0.i2567 = phi i64 [ %_17.0.i25, %bb11.i30 ], [ %.promoted66, %bb6.i19 ]
  %_17.0.i25 = add nsw i64 %_17.0.i2567, -1
  %_19.i26 = icmp ult i64 %_17.0.i25, %.promoted66
  br i1 %_19.i26, label %bb10.i28, label %panic3.i27

bb10.i28:                                         ; preds = %bb8.i23
  %46 = getelementptr inbounds nuw i8, ptr %_56, i64 %_17.0.i25
  %_14.i29 = load i8, ptr %46, align 1, !alias.scope !114, !noundef !57
  switch i8 %_14.i29, label %_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser4trim.exit43.loopexit [
    i8 32, label %bb11.i30
    i8 9, label %bb11.i30
  ]

panic3.i27:                                       ; preds = %bb8.i23
  store i64 %_17.0.i2567, ptr %3, align 8
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_bounds_check(i64 noundef %_17.0.i25, i64 noundef range(i64 0, -9223372036854775808) %.promoted66, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_b65862ba02ce59bf102bd5cffbc3e71e) #20, !noalias !117
  unreachable

bb11.i30:                                         ; preds = %bb10.i28, %bb10.i28
  %_11.i31 = icmp samesign ugt i64 %_17.0.i25, %_4.lcssa.i20
  br i1 %_11.i31, label %bb8.i23, label %_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser4trim.exit43.loopexit

_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser4trim.exit43.loopexit: ; preds = %bb11.i30, %bb10.i28
  %_17.0.i2568 = phi i64 [ %_4.lcssa.i20, %bb11.i30 ], [ %_17.0.i2567, %bb10.i28 ]
  store i64 %_17.0.i2568, ptr %3, align 8
  br label %bb32

_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser4trim.exit43.loopexit48: ; preds = %bb4.i39
  store i64 %.promoted66, ptr %span, align 8
  br label %bb32

bb6:                                              ; preds = %bb5
  %47 = getelementptr inbounds nuw i8, ptr %input.0, i64 %offset.sroa.0.063
  %_17 = load i8, ptr %47, align 1, !noundef !57
  %48 = icmp eq i8 %_17, 92
  %_24.0 = add nuw nsw i64 %offset.sroa.0.063, 1
  %_21 = icmp ult i64 %_24.0, %_10
  %49 = select i1 %48, i1 %_21, i1 false
  %offset.sroa.0.1 = select i1 %49, i64 %_24.0, i64 %offset.sroa.0.063
  %_29 = icmp ult i64 %offset.sroa.0.1, %input.1
  br i1 %_29, label %bb14, label %panic6

panic3:                                           ; preds = %bb5
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_bounds_check(i64 noundef %offset.sroa.0.063, i64 noundef %input.1, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_6778510a3f564171a901a93fb66df6da) #20
  unreachable

bb14:                                             ; preds = %bb6
  %50 = getelementptr inbounds nuw i8, ptr %input.0, i64 %offset.sroa.0.1
  %byte = load i8, ptr %50, align 1, !noundef !57
  %51 = add i8 %byte, -65
  %52 = icmp ult i8 %51, 26
  %53 = and i1 %lower, %52
  %_50.sroa.0.0 = select i1 %53, i8 32, i8 0
  %_30.sroa.0.0 = or i8 %byte, %_50.sroa.0.0
  %len.i44 = load i64, ptr %2, align 8, !alias.scope !120, !noundef !57
  %self1.i = load i64, ptr %scratch, align 8, !range !56, !alias.scope !120, !noundef !57
  %_4.i = icmp eq i64 %len.i44, %self1.i
  br i1 %_4.i, label %bb1.i47, label %_RNvMsG_NtCs8tsiLsQ9XHg_5alloc3vecINtB5_3VechE8push_mutCscgZyRT41Cnx_20mime_type_validation.exit

panic6:                                           ; preds = %bb6
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_bounds_check(i64 noundef %offset.sroa.0.1, i64 noundef %input.1, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_9f210cfd795faf6e85189269a278b85f) #20
  unreachable

bb1.i47:                                          ; preds = %bb14
; call <alloc::raw_vec::RawVec<u8>>::grow_one
  tail call void @_RNvMs7_NtCs8tsiLsQ9XHg_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_(ptr noalias nofree noundef nonnull align 8 dereferenceable(24) %scratch) #19
  br label %_RNvMsG_NtCs8tsiLsQ9XHg_5alloc3vecINtB5_3VechE8push_mutCscgZyRT41Cnx_20mime_type_validation.exit

_RNvMsG_NtCs8tsiLsQ9XHg_5alloc3vecINtB5_3VechE8push_mutCscgZyRT41Cnx_20mime_type_validation.exit: ; preds = %bb14, %bb1.i47
  %_14.i46 = load ptr, ptr %42, align 8, !alias.scope !120, !nonnull !57, !noundef !57
  %end.i = getelementptr inbounds nuw i8, ptr %_14.i46, i64 %len.i44
  store i8 %_30.sroa.0.0, ptr %end.i, align 1
  %54 = add i64 %len.i44, 1
  store i64 %54, ptr %2, align 8, !alias.scope !120
  %_31.0 = add nuw nsw i64 %offset.sroa.0.1, 1
  %_14 = icmp ult i64 %_31.0, %_10
  br i1 %_14, label %bb5, label %bb19
}

; <mime_type_validation::mime_type_parser::Parameters as core::iter::traits::iterator::Iterator>::next
; Function Attrs: nounwind uwtable
define internal fastcc void @_RNvXs_NtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB4_10ParametersNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next(ptr dead_on_unwind noalias nofree noundef nonnull writable writeonly align 8 captures(none) dereferenceable(56) %_0, ptr noalias nofree noundef nonnull align 8 captures(none) dereferenceable(24) %self) unnamed_addr #3 personality ptr @__CxxFrameHandler3 !guid !123 {
start:
  %input.0 = load ptr, ptr %self, align 8, !nonnull !57, !noundef !57
  %0 = getelementptr inbounds nuw i8, ptr %self, i64 8
  %input.1 = load i64, ptr %0, align 8, !noundef !57
  %1 = getelementptr inbounds nuw i8, ptr %self, i64 16
  %.promoted77 = load i64, ptr %1, align 8
  %_8382 = icmp ugt i64 %.promoted77, %input.1
  br i1 %_8382, label %bb78, label %bb79.lr.ph, !prof !124

bb79.lr.ph:                                       ; preds = %start
  %_94 = getelementptr inbounds nuw i8, ptr %input.0, i64 %input.1
  br label %bb79

bb79:                                             ; preds = %bb79.lr.ph, %bb76
  %storemerge25.lcssa707883 = phi i64 [ %.promoted77, %bb79.lr.ph ], [ %storemerge25.lcssa7079, %bb76 ]
  %gepdiff = sub nuw nsw i64 %input.1, %storemerge25.lcssa707883
  %_296.i = icmp samesign eq i64 %storemerge25.lcssa707883, %input.1
  br i1 %_296.i, label %bb77, label %bb23.i.preheader

bb23.i.preheader:                                 ; preds = %bb79
  %_90 = getelementptr inbounds nuw i8, ptr %input.0, i64 %storemerge25.lcssa707883
  br label %bb23.i

bb23.i:                                           ; preds = %bb23.i.preheader, %bb7.i
  %i.sroa.0.08.i = phi i64 [ %2, %bb7.i ], [ 0, %bb23.i.preheader ]
  %_3957.i = phi ptr [ %_39.i, %bb7.i ], [ %_90, %bb23.i.preheader ]
  %ptr.val.i = load i8, ptr %_3957.i, align 1, !noalias !125, !noundef !57
  %_0.i.i = icmp eq i8 %ptr.val.i, 59
  br i1 %_0.i.i, label %bb6.i, label %bb7.i

bb7.i:                                            ; preds = %bb23.i
  %_39.i = getelementptr inbounds nuw i8, ptr %_3957.i, i64 1
  %2 = add nuw i64 %i.sroa.0.08.i, 1
  %_29.i = icmp eq ptr %_39.i, %_94
  br i1 %_29.i, label %bb77, label %bb23.i

bb6.i:                                            ; preds = %bb23.i
  %cond.i = icmp ult i64 %i.sroa.0.08.i, %gepdiff
  br i1 %cond.i, label %bb4, label %bb1.i.i, !prof !71

bb1.i.i:                                          ; preds = %bb6.i
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_64e308ef4babfeb8b6220184de794a17, ptr noundef nonnull inttoptr (i64 443 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_1d1b1e35bb489427b2bdc9752de92226) #20, !noalias !125
  unreachable

bb78:                                             ; preds = %bb76, %start
  %_6.lcssa = phi i64 [ %.promoted77, %start ], [ %storemerge25.lcssa7079, %bb76 ]
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCs9l4wcBNbII5_4core5slice5index16slice_index_fail(i64 noundef %_6.lcssa, i64 noundef %input.1, i64 noundef %input.1, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_18751c864f47f78987d76e83a84d153d) #20
  unreachable

bb4:                                              ; preds = %bb6.i
  %_10.0 = add i64 %storemerge25.lcssa707883, 1
  %_11.0 = add i64 %_10.0, %i.sroa.0.08.i
  %_11.1 = icmp ult i64 %_11.0, %storemerge25.lcssa707883
  br i1 %_11.1, label %panic2, label %bb6.preheader

bb6.preheader:                                    ; preds = %bb4
  %_1260 = icmp ult i64 %_11.0, %input.1
  br i1 %_1260, label %bb8, label %bb11

panic2:                                           ; preds = %bb4
; call core::panicking::panic_const::panic_const_add_overflow
  tail call void @_RNvNtNtCs9l4wcBNbII5_4core9panicking11panic_const24panic_const_add_overflow(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_bbf6a06aca8a736ba5f657d76cbabc56) #20
  unreachable

bb11:                                             ; preds = %bb8, %bb6.preheader
  %storemerge.lcssa59 = phi i64 [ %_11.0, %bb6.preheader ], [ %storemerge61, %bb8 ]
  store i64 %storemerge.lcssa59, ptr %1, align 8
  %_1966 = icmp ult i64 %storemerge.lcssa59, %input.1
  br i1 %_1966, label %bb14, label %bb19.thread

bb8:                                              ; preds = %bb6.preheader, %bb9
  %storemerge61 = phi i64 [ %_17.0, %bb9 ], [ %_11.0, %bb6.preheader ]
  %3 = getelementptr inbounds nuw i8, ptr %input.0, i64 %storemerge61
  %_14 = load i8, ptr %3, align 1, !noundef !57
  switch i8 %_14, label %bb11 [
    i8 32, label %bb9
    i8 9, label %bb9
  ]

bb9:                                              ; preds = %bb8, %bb8
  %_17.0 = add i64 %storemerge61, 1
  %exitcond.not = icmp eq i64 %_17.0, %input.1
  br i1 %exitcond.not, label %bb76.sink.split, label %bb8

bb19.thread:                                      ; preds = %bb11
  %_2429 = icmp eq i64 %storemerge.lcssa59, %input.1
  br i1 %_2429, label %bb76, label %panic6

bb14:                                             ; preds = %bb11, %bb17
  %_23.06567 = phi i64 [ %_23.0, %bb17 ], [ %storemerge.lcssa59, %bb11 ]
  %4 = getelementptr inbounds nuw i8, ptr %input.0, i64 %_23.06567
  %5 = load i8, ptr %4, align 1, !noundef !57
  switch i8 %5, label %bb17 [
    i8 59, label %bb76
    i8 61, label %bb26.preheader
  ]

bb26.preheader:                                   ; preds = %bb14
  %storemerge2571 = add nuw i64 %_23.06567, 1
  %_3272 = icmp ult i64 %storemerge2571, %input.1
  br i1 %_3272, label %bb28, label %bb76.sink.split

panic6:                                           ; preds = %bb19.thread
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_bounds_check(i64 noundef %storemerge.lcssa59, i64 noundef %input.1, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_3703da2b1b4bb9e1c22edb34338572b1) #20
  unreachable

bb31:                                             ; preds = %bb28
  store i64 %.lcssa58.promoted, ptr %1, align 8
  %6 = icmp eq i8 %_34, 59
  br i1 %6, label %bb76, label %bb37

bb28:                                             ; preds = %bb26.preheader, %bb83
  %.lcssa58.promoted = phi i64 [ %storemerge25, %bb83 ], [ %storemerge2571, %bb26.preheader ]
  %storemerge25.in73 = phi i64 [ %.lcssa58.promoted, %bb83 ], [ %_23.06567, %bb26.preheader ]
  %7 = getelementptr inbounds nuw i8, ptr %input.0, i64 %.lcssa58.promoted
  %_34 = load i8, ptr %7, align 1, !noundef !57
  switch i8 %_34, label %bb31 [
    i8 32, label %bb83
    i8 9, label %bb83
  ]

bb83:                                             ; preds = %bb28, %bb28
  %storemerge25 = add i64 %.lcssa58.promoted, 1
  %exitcond112.not = icmp eq i64 %storemerge25, %input.1
  br i1 %exitcond112.not, label %bb76.sink.split, label %bb28

bb37:                                             ; preds = %bb31
  %quoted = icmp ne i8 %_34, 34
  br i1 %quoted, label %bb56.preheader, label %bb38

bb56.preheader:                                   ; preds = %bb37
  %_6486 = icmp ult i64 %.lcssa58.promoted, %input.1
  br i1 %_6486, label %bb58, label %bb72

bb38:                                             ; preds = %bb37
  %_47.0 = add nuw i64 %storemerge25.in73, 2
  %_5090 = icmp ult i64 %_47.0, %input.1
  br i1 %_5090, label %bb42, label %bb64.loopexit

bb58:                                             ; preds = %bb56.preheader, %bb60
  %_658587 = phi i64 [ %_69.0, %bb60 ], [ %.lcssa58.promoted, %bb56.preheader ]
  %8 = getelementptr inbounds nuw i8, ptr %input.0, i64 %_658587
  %_66 = load i8, ptr %8, align 1, !noundef !57
  %9 = icmp eq i8 %_66, 59
  br i1 %9, label %bb64, label %bb60

bb64.loopexit:                                    ; preds = %bb42, %bb52, %bb38
  %storemerge26.lcssa = phi i64 [ %_47.0, %bb38 ], [ %_63.0, %bb52 ], [ %storemerge2691, %bb42 ]
  %escaped.sroa.0.1.lcssa = phi i8 [ 0, %bb38 ], [ %escaped.sroa.0.233, %bb52 ], [ %escaped.sroa.0.192, %bb42 ]
  store i64 %storemerge26.lcssa, ptr %1, align 8
  br label %bb64

bb64:                                             ; preds = %bb60, %bb58, %bb64.loopexit
  %_71 = phi i64 [ %storemerge26.lcssa, %bb64.loopexit ], [ %_658587, %bb58 ], [ %input.1, %bb60 ]
  %escaped.sroa.0.0 = phi i8 [ %escaped.sroa.0.1.lcssa, %bb64.loopexit ], [ 0, %bb58 ], [ 0, %bb60 ]
  %start1.sroa.0.0 = phi i64 [ %_47.0, %bb64.loopexit ], [ %.lcssa58.promoted, %bb58 ], [ %.lcssa58.promoted, %bb60 ]
  %_7297 = icmp ugt i64 %_71, %start1.sroa.0.0
  %or.cond = and i1 %quoted, %_7297
  br i1 %or.cond, label %bb66, label %bb72

bb60:                                             ; preds = %bb58
  %_69.0 = add i64 %_658587, 1
  store i64 %_69.0, ptr %1, align 8
  %exitcond113.not = icmp eq i64 %_69.0, %input.1
  br i1 %exitcond113.not, label %bb64, label %bb58

bb42:                                             ; preds = %bb38, %bb52
  %escaped.sroa.0.192 = phi i8 [ %escaped.sroa.0.233, %bb52 ], [ 0, %bb38 ]
  %storemerge2691 = phi i64 [ %_63.0, %bb52 ], [ %_47.0, %bb38 ]
  %10 = getelementptr inbounds nuw i8, ptr %input.0, i64 %storemerge2691
  %_52 = load i8, ptr %10, align 1, !noundef !57
  switch i8 %_52, label %bb52 [
    i8 34, label %bb64.loopexit
    i8 92, label %bb46
  ]

bb72:                                             ; preds = %bb69, %bb68, %bb56.preheader, %bb64
  %start1.sroa.0.0126 = phi i64 [ %start1.sroa.0.0, %bb64 ], [ %.lcssa58.promoted, %bb56.preheader ], [ %start1.sroa.0.0, %bb68 ], [ %start1.sroa.0.0, %bb69 ]
  %escaped.sroa.0.0125 = phi i8 [ %escaped.sroa.0.0, %bb64 ], [ 0, %bb56.preheader ], [ %escaped.sroa.0.0, %bb68 ], [ %escaped.sroa.0.0, %bb69 ]
  %span.sroa.3.1 = phi i64 [ %_71, %bb64 ], [ %.lcssa58.promoted, %bb56.preheader ], [ %start1.sroa.0.0, %bb69 ], [ %span.sroa.3.098, %bb68 ]
  store i64 %storemerge.lcssa59, ptr %_0, align 8
  %_81.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 %_23.06567, ptr %_81.sroa.4.0._0.sroa_idx, align 8
  %_81.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i8 0, ptr %_81.sroa.5.0._0.sroa_idx, align 8
  %_81.sroa.7.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 24
  store i64 %start1.sroa.0.0126, ptr %_81.sroa.7.0._0.sroa_idx, align 8
  %_81.sroa.7.sroa.4.0._81.sroa.7.0._0.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 32
  store i64 %span.sroa.3.1, ptr %_81.sroa.7.sroa.4.0._81.sroa.7.0._0.sroa_idx.sroa_idx, align 8
  %_81.sroa.7.sroa.5.0._81.sroa.7.0._0.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 40
  store i8 0, ptr %_81.sroa.7.sroa.5.0._81.sroa.7.0._0.sroa_idx.sroa_idx, align 8
  br label %bb77

bb66:                                             ; preds = %bb64, %bb69
  %span.sroa.3.098 = phi i64 [ %_78.0, %bb69 ], [ %_71, %bb64 ]
  %_78.0 = add i64 %span.sroa.3.098, -1
  %_79 = icmp ult i64 %_78.0, %input.1
  br i1 %_79, label %bb68, label %panic17

bb68:                                             ; preds = %bb66
  %11 = getelementptr inbounds nuw i8, ptr %input.0, i64 %_78.0
  %_75 = load i8, ptr %11, align 1, !noundef !57
  switch i8 %_75, label %bb72 [
    i8 32, label %bb69
    i8 9, label %bb69
  ]

panic17:                                          ; preds = %bb66
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_bounds_check(i64 noundef %_78.0, i64 noundef %input.1, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_68ddaa981c2b4f25b2f4f08e18cc6057) #20
  unreachable

bb69:                                             ; preds = %bb68, %bb68
  %_72 = icmp ugt i64 %_78.0, %start1.sroa.0.0
  br i1 %_72, label %bb66, label %bb72

bb77:                                             ; preds = %bb79, %bb7.i, %bb72
  %.sink139 = phi i64 [ 48, %bb72 ], [ 16, %bb7.i ], [ 16, %bb79 ]
  %.sink = phi i8 [ %escaped.sroa.0.0125, %bb72 ], [ 2, %bb7.i ], [ 2, %bb79 ]
  %12 = getelementptr inbounds nuw i8, ptr %_0, i64 %.sink139
  store i8 %.sink, ptr %12, align 8
  ret void

bb46:                                             ; preds = %bb42
  %_61.0 = add nuw i64 %storemerge2691, 1
  %_58 = icmp ult i64 %_61.0, %input.1
  %spec.select = select i1 %_58, i8 1, i8 %escaped.sroa.0.192
  %spec.select140 = select i1 %_58, i64 %_61.0, i64 %storemerge2691
  br label %bb52

bb52:                                             ; preds = %bb46, %bb42
  %escaped.sroa.0.233 = phi i8 [ %spec.select, %bb46 ], [ %escaped.sroa.0.192, %bb42 ]
  %13 = phi i64 [ %spec.select140, %bb46 ], [ %storemerge2691, %bb42 ]
  %_63.0 = add nuw i64 %13, 1
  %_50 = icmp ult i64 %_63.0, %input.1
  br i1 %_50, label %bb42, label %bb64.loopexit

bb76.sink.split:                                  ; preds = %bb9, %bb83, %bb26.preheader
  %input.1.sink = phi i64 [ %input.1, %bb83 ], [ %storemerge2571, %bb26.preheader ], [ %input.1, %bb9 ]
  store i64 %input.1.sink, ptr %1, align 8
  br label %bb76

bb76:                                             ; preds = %bb17, %bb14, %bb76.sink.split, %bb19.thread, %bb31
  %storemerge25.lcssa7079 = phi i64 [ %input.1.sink, %bb76.sink.split ], [ %input.1, %bb19.thread ], [ %.lcssa58.promoted, %bb31 ], [ %input.1, %bb17 ], [ %_23.06567, %bb14 ]
  %_83 = icmp ugt i64 %storemerge25.lcssa7079, %input.1
  br i1 %_83, label %bb78, label %bb79, !prof !128

bb17:                                             ; preds = %bb14
  %_23.0 = add i64 %_23.06567, 1
  store i64 %_23.0, ptr %1, align 8
  %exitcond111.not = icmp eq i64 %_23.0, %input.1
  br i1 %exitcond111.not, label %bb76, label %bb14
}

; Function Attrs: nounwind uwtable
define noundef range(i64 0, -9223372036854775808) i64 @"cxxbridge1$rust_vec$net$mime_type_internal$Parameter$capacity"(ptr noundef %this) unnamed_addr #3 !guid !129 {
start:
  %_2 = ptrtoint ptr %this to i64
  %_3 = and i64 %_2, 7
  %_4 = icmp eq i64 %_3, 0
  br i1 %_4, label %bb1, label %panic

bb1:                                              ; preds = %start
  %_5.not = icmp eq ptr %this, null
  br i1 %_5.not, label %panic1, label %bb4

panic:                                            ; preds = %start
; call core::panicking::panic_misaligned_pointer_dereference
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking36panic_misaligned_pointer_dereference(i64 noundef 8, i64 noundef %_2, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_8301db87b19c4fd1b041a9b35ebbea76) #20
  unreachable

panic1:                                           ; preds = %bb1
; call core::panicking::panic_null_reference_constructed
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking32panic_null_reference_constructed(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_8301db87b19c4fd1b041a9b35ebbea76) #20
  unreachable

bb4:                                              ; preds = %bb1
  %_14 = load i64, ptr %this, align 8, !range !56, !noundef !57
  ret i64 %_14
}

; Function Attrs: nounwind uwtable
define noundef nonnull ptr @"cxxbridge1$rust_vec$net$mime_type_internal$Parameter$data_const"(ptr noundef %this) unnamed_addr #3 !guid !130 {
start:
  %_2 = ptrtoint ptr %this to i64
  %_3 = and i64 %_2, 7
  %_4 = icmp eq i64 %_3, 0
  br i1 %_4, label %bb1, label %panic

bb1:                                              ; preds = %start
  %_5.not = icmp eq ptr %this, null
  br i1 %_5.not, label %panic1, label %bb4

panic:                                            ; preds = %start
; call core::panicking::panic_misaligned_pointer_dereference
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking36panic_misaligned_pointer_dereference(i64 noundef 8, i64 noundef %_2, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_8301db87b19c4fd1b041a9b35ebbea76) #20
  unreachable

panic1:                                           ; preds = %bb1
; call core::panicking::panic_null_reference_constructed
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking32panic_null_reference_constructed(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_8301db87b19c4fd1b041a9b35ebbea76) #20
  unreachable

bb4:                                              ; preds = %bb1
  %0 = getelementptr inbounds nuw i8, ptr %this, i64 8
  %_14 = load ptr, ptr %0, align 8, !nonnull !57, !noundef !57
  ret ptr %_14
}

; Function Attrs: nounwind uwtable
define void @"cxxbridge1$rust_vec$net$mime_type_internal$Parameter$drop"(ptr nofree noundef readonly captures(none) %this) unnamed_addr #3 !guid !131 {
start:
  %_3.sroa.5.i.i.i.i = alloca i64, align 8
  %_3.sroa.8.i.i.i.i = alloca i64, align 8
  %this.val = load i64, ptr %this, align 8, !range !56, !noundef !57
  %0 = getelementptr i8, ptr %this, i64 8
  %this.val1 = load ptr, ptr %0, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %_3.sroa.5.i.i.i.i)
  call void @llvm.lifetime.start.p0(ptr nonnull %_3.sroa.8.i.i.i.i)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !132)
  %1 = icmp eq i64 %this.val, 0
  br i1 %1, label %_RNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCscgZyRT41Cnx_20mime_type_validation.exit.i.i.i.i, label %bb4.i.i.i.i.i

bb4.i.i.i.i.i:                                    ; preds = %start
  %_7.1.i.i.i.i.i.i = icmp samesign ugt i64 %this.val, 384307168202282325
  br i1 %_7.1.i.i.i.i.i.i, label %bb1.i.i.i.i.i.i, label %_RNvNvMs9_NtCs9l4wcBNbII5_4core3numj13unchecked_mul18precondition_check.exit.i.i.i.i.i, !prof !69

bb1.i.i.i.i.i.i:                                  ; preds = %bb4.i.i.i.i.i
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_db07ae5a9ce650d9b7cc970d048e6f0c, ptr noundef nonnull inttoptr (i64 373 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_ad088eaa3dc0ae68b11fd72bfcf5e34b) #20, !noalias !132
  unreachable

_RNvNvMs9_NtCs9l4wcBNbII5_4core3numj13unchecked_mul18precondition_check.exit.i.i.i.i.i: ; preds = %bb4.i.i.i.i.i
  %_3.not.i.i.i.i.i.i = icmp samesign ugt i64 %this.val, 192153584101141162
  br i1 %_3.not.i.i.i.i.i.i, label %bb2.i.i.i.i.i.i, label %_RNvNvMNtNtCs9l4wcBNbII5_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_check.exit.i.i.i.i.i, !prof !70

bb2.i.i.i.i.i.i:                                  ; preds = %_RNvNvMs9_NtCs9l4wcBNbII5_4core3numj13unchecked_mul18precondition_check.exit.i.i.i.i.i
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_1be5ea12ba708d9a11b6e93a7d387a75, ptr noundef nonnull inttoptr (i64 563 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_dade1aed0d0fe800cb3ecdb07302e098) #20, !noalias !132
  unreachable

_RNvNvMNtNtCs9l4wcBNbII5_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_check.exit.i.i.i.i.i: ; preds = %_RNvNvMs9_NtCs9l4wcBNbII5_4core3numj13unchecked_mul18precondition_check.exit.i.i.i.i.i
  %alloc_size.i.i.i.i.i = mul nuw nsw i64 %this.val, 48
  call void @llvm.assume(i1 true) [ "nonnull"(ptr %this.val1) ]
  store i64 8, ptr %_3.sroa.5.i.i.i.i, align 8, !alias.scope !132
  br label %_RNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCscgZyRT41Cnx_20mime_type_validation.exit.i.i.i.i

_RNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCscgZyRT41Cnx_20mime_type_validation.exit.i.i.i.i: ; preds = %_RNvNvMNtNtCs9l4wcBNbII5_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_check.exit.i.i.i.i.i, %start
  %_3.sroa.0.0.i.i.i.i = phi ptr [ undef, %start ], [ %this.val1, %_RNvNvMNtNtCs9l4wcBNbII5_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_check.exit.i.i.i.i.i ]
  %.sink.i.sroa.phi.i.i.i.i = phi ptr [ %_3.sroa.5.i.i.i.i, %start ], [ %_3.sroa.8.i.i.i.i, %_RNvNvMNtNtCs9l4wcBNbII5_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_check.exit.i.i.i.i.i ]
  %alloc_size.sink.i.i.i.i.i = phi i64 [ 0, %start ], [ %alloc_size.i.i.i.i.i, %_RNvNvMNtNtCs9l4wcBNbII5_4core5alloc6layoutNtB4_6Layout25from_size_align_unchecked18precondition_check.exit.i.i.i.i.i ]
  store i64 %alloc_size.sink.i.i.i.i.i, ptr %.sink.i.sroa.phi.i.i.i.i, align 8, !alias.scope !132
  %_3.sroa.5.i.i.i.i.0._3.sroa.5.i.i.i.i.0._3.sroa.5.i.i.i.i.0._3.sroa.5.i.i.i.0._3.sroa.5.i.i.i.0._3.sroa.5.i.i.0._3.sroa.5.i.i.0._3.sroa.5.i.0._3.sroa.5.i.0._3.sroa.5.0._3.sroa.5.0._3.sroa.5.8..i.i.i.i = load i64, ptr %_3.sroa.5.i.i.i.i, align 8, !range !59, !noundef !57
  %.not.i.i.i.i = icmp eq i64 %_3.sroa.5.i.i.i.i.0._3.sroa.5.i.i.i.i.0._3.sroa.5.i.i.i.i.0._3.sroa.5.i.i.i.0._3.sroa.5.i.i.i.0._3.sroa.5.i.i.0._3.sroa.5.i.i.0._3.sroa.5.i.0._3.sroa.5.i.0._3.sroa.5.0._3.sroa.5.0._3.sroa.5.8..i.i.i.i, 0
  br i1 %.not.i.i.i.i, label %_RNvXs_NtCsdVJFY9KZ4lg_3cxx8rust_vecINtB4_7RustVecNtNtCscgZyRT41Cnx_20mime_type_validation3ffi9ParameterENtNtNtCs9l4wcBNbII5_4core3ops4drop4Drop4dropBP_.exit, label %bb2.i.i.i.i

bb2.i.i.i.i:                                      ; preds = %_RNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCscgZyRT41Cnx_20mime_type_validation.exit.i.i.i.i
  call void @llvm.assume(i1 true) [ "nonnull"(ptr %_3.sroa.0.0.i.i.i.i) ]
  %_3.sroa.8.i.i.i.i.0._3.sroa.8.i.i.i.i.0._3.sroa.8.i.i.i.i.0._3.sroa.8.i.i.i.0._3.sroa.8.i.i.i.0._3.sroa.8.i.i.0._3.sroa.8.i.i.0._3.sroa.8.i.0._3.sroa.8.i.0._3.sroa.8.0._3.sroa.8.0._3.sroa.8.16.layout.1.i.i.i.i = load i64, ptr %_3.sroa.8.i.i.i.i, align 8, !noundef !57
  %2 = icmp eq i64 %_3.sroa.8.i.i.i.i.0._3.sroa.8.i.i.i.i.0._3.sroa.8.i.i.i.i.0._3.sroa.8.i.i.i.0._3.sroa.8.i.i.i.0._3.sroa.8.i.i.0._3.sroa.8.i.i.0._3.sroa.8.i.0._3.sroa.8.i.0._3.sroa.8.0._3.sroa.8.0._3.sroa.8.16.layout.1.i.i.i.i, 0
  br i1 %2, label %_RNvXs_NtCsdVJFY9KZ4lg_3cxx8rust_vecINtB4_7RustVecNtNtCscgZyRT41Cnx_20mime_type_validation3ffi9ParameterENtNtNtCs9l4wcBNbII5_4core3ops4drop4Drop4dropBP_.exit, label %bb1.i.i.i.i.i

bb1.i.i.i.i.i:                                    ; preds = %bb2.i.i.i.i
; call __rustc::__rust_dealloc
  tail call void @_RNvCs6d6XRwTwhVh_7___rustc14___rust_dealloc(ptr noundef nonnull %_3.sroa.0.0.i.i.i.i, i64 noundef %_3.sroa.8.i.i.i.i.0._3.sroa.8.i.i.i.i.0._3.sroa.8.i.i.i.i.0._3.sroa.8.i.i.i.0._3.sroa.8.i.i.i.0._3.sroa.8.i.i.0._3.sroa.8.i.i.0._3.sroa.8.i.0._3.sroa.8.i.0._3.sroa.8.0._3.sroa.8.0._3.sroa.8.16.layout.1.i.i.i.i, i64 noundef range(i64 1, -9223372036854775807) %_3.sroa.5.i.i.i.i.0._3.sroa.5.i.i.i.i.0._3.sroa.5.i.i.i.i.0._3.sroa.5.i.i.i.0._3.sroa.5.i.i.i.0._3.sroa.5.i.i.0._3.sroa.5.i.i.0._3.sroa.5.i.0._3.sroa.5.i.0._3.sroa.5.0._3.sroa.5.0._3.sroa.5.8..i.i.i.i) #19
  br label %_RNvXs_NtCsdVJFY9KZ4lg_3cxx8rust_vecINtB4_7RustVecNtNtCscgZyRT41Cnx_20mime_type_validation3ffi9ParameterENtNtNtCs9l4wcBNbII5_4core3ops4drop4Drop4dropBP_.exit

_RNvXs_NtCsdVJFY9KZ4lg_3cxx8rust_vecINtB4_7RustVecNtNtCscgZyRT41Cnx_20mime_type_validation3ffi9ParameterENtNtNtCs9l4wcBNbII5_4core3ops4drop4Drop4dropBP_.exit: ; preds = %_RNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCscgZyRT41Cnx_20mime_type_validation.exit.i.i.i.i, %bb2.i.i.i.i, %bb1.i.i.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_3.sroa.5.i.i.i.i)
  call void @llvm.lifetime.end.p0(ptr nonnull %_3.sroa.8.i.i.i.i)
  ret void
}

; Function Attrs: nounwind uwtable
define noundef range(i64 0, 192153584101141163) i64 @"cxxbridge1$rust_vec$net$mime_type_internal$Parameter$len"(ptr noundef %this) unnamed_addr #3 !guid !135 {
start:
  %_2 = ptrtoint ptr %this to i64
  %_3 = and i64 %_2, 7
  %_4 = icmp eq i64 %_3, 0
  br i1 %_4, label %bb1, label %panic

bb1:                                              ; preds = %start
  %_5.not = icmp eq ptr %this, null
  br i1 %_5.not, label %panic1, label %bb4

panic:                                            ; preds = %start
; call core::panicking::panic_misaligned_pointer_dereference
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking36panic_misaligned_pointer_dereference(i64 noundef 8, i64 noundef %_2, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_8301db87b19c4fd1b041a9b35ebbea76) #20
  unreachable

panic1:                                           ; preds = %bb1
; call core::panicking::panic_null_reference_constructed
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking32panic_null_reference_constructed(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_8301db87b19c4fd1b041a9b35ebbea76) #20
  unreachable

bb4:                                              ; preds = %bb1
  %0 = getelementptr inbounds nuw i8, ptr %this, i64 16
  %_0 = load i64, ptr %0, align 8, !noundef !57
  %_14 = icmp ult i64 %_0, 192153584101141163
  tail call void @llvm.assume(i1 %_14)
  ret i64 %_0
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define void @"cxxbridge1$rust_vec$net$mime_type_internal$Parameter$new"(ptr nofree noundef writeonly captures(none) initializes((0, 24)) %this) unnamed_addr #4 !guid !136 {
start:
  store i64 0, ptr %this, align 8
  %_2.sroa.4.0.this.sroa_idx = getelementptr inbounds nuw i8, ptr %this, i64 8
  store ptr inttoptr (i64 8 to ptr), ptr %_2.sroa.4.0.this.sroa_idx, align 8
  %_2.sroa.5.0.this.sroa_idx = getelementptr inbounds nuw i8, ptr %this, i64 16
  store i64 0, ptr %_2.sroa.5.0.this.sroa_idx, align 8
  ret void
}

; Function Attrs: nounwind uwtable
define void @"cxxbridge1$rust_vec$net$mime_type_internal$Parameter$reserve_total"(ptr noundef %this, i64 noundef %new_cap) unnamed_addr #3 !guid !137 {
start:
  %_5 = ptrtoint ptr %this to i64
  %_6 = and i64 %_5, 7
  %_7 = icmp eq i64 %_6, 0
  br i1 %_7, label %bb2, label %panic

bb2:                                              ; preds = %start
  %_8.not = icmp eq ptr %this, null
  br i1 %_8.not, label %panic1, label %bb3

panic:                                            ; preds = %start
; call core::panicking::panic_misaligned_pointer_dereference
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking36panic_misaligned_pointer_dereference(i64 noundef 8, i64 noundef %_5, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_8301db87b19c4fd1b041a9b35ebbea76) #20
  unreachable

bb3:                                              ; preds = %bb2
  tail call void @llvm.experimental.noalias.scope.decl(metadata !138)
  %_17.i = load i64, ptr %this, align 8, !range !56, !alias.scope !138, !noundef !57
  %_4.i = icmp ugt i64 %new_cap, %_17.i
  br i1 %_4.i, label %bb1.i, label %_RNvMNtCsdVJFY9KZ4lg_3cxx8rust_vecINtB2_7RustVecNtNtCscgZyRT41Cnx_20mime_type_validation3ffi9ParameterE13reserve_totalBN_.exit

bb1.i:                                            ; preds = %bb3
  %0 = getelementptr inbounds nuw i8, ptr %this, i64 16
  %_7.i = load i64, ptr %0, align 8, !alias.scope !138, !noundef !57
  %_18.i = icmp ult i64 %_7.i, 192153584101141163
  tail call void @llvm.assume(i1 %_18.i)
  %_8.1.i = icmp ult i64 %new_cap, %_7.i
  br i1 %_8.1.i, label %panic2.i, label %bb2.i

bb2.i:                                            ; preds = %bb1.i
  %_8.0.i = sub nuw i64 %new_cap, %_7.i
  %_9.i.i = sub nsw i64 %_17.i, %_7.i
  %_7.i.i = icmp ugt i64 %_8.0.i, %_9.i.i
  br i1 %_7.i.i, label %bb1.i.i, label %_RNvMNtCsdVJFY9KZ4lg_3cxx8rust_vecINtB2_7RustVecNtNtCscgZyRT41Cnx_20mime_type_validation3ffi9ParameterE13reserve_totalBN_.exit, !prof !69

bb1.i.i:                                          ; preds = %bb2.i
; call <alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>
  tail call fastcc void @_RINvNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECscgZyRT41Cnx_20mime_type_validation(ptr noalias nofree noundef nonnull align 8 dereferenceable(24) %this, i64 noundef %_7.i, i64 noundef %_8.0.i, i64 noundef 8, i64 noundef 48) #19
  br label %_RNvMNtCsdVJFY9KZ4lg_3cxx8rust_vecINtB2_7RustVecNtNtCscgZyRT41Cnx_20mime_type_validation3ffi9ParameterE13reserve_totalBN_.exit

panic2.i:                                         ; preds = %bb1.i
; call core::panicking::panic_const::panic_const_sub_overflow
  tail call void @_RNvNtNtCs9l4wcBNbII5_4core9panicking11panic_const24panic_const_sub_overflow(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_761524272c43a324f2cd5804a1432b63) #20, !noalias !138
  unreachable

_RNvMNtCsdVJFY9KZ4lg_3cxx8rust_vecINtB2_7RustVecNtNtCscgZyRT41Cnx_20mime_type_validation3ffi9ParameterE13reserve_totalBN_.exit: ; preds = %bb3, %bb2.i, %bb1.i.i
  ret void

panic1:                                           ; preds = %bb2
; call core::panicking::panic_null_reference_constructed
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking32panic_null_reference_constructed(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_8301db87b19c4fd1b041a9b35ebbea76) #20
  unreachable
}

; Function Attrs: nounwind uwtable
define void @"cxxbridge1$rust_vec$net$mime_type_internal$Parameter$set_len"(ptr noundef %this, i64 noundef %len) unnamed_addr #3 !guid !141 {
start:
  %_5 = ptrtoint ptr %this to i64
  %_6 = and i64 %_5, 7
  %_7 = icmp eq i64 %_6, 0
  br i1 %_7, label %bb2, label %panic

bb2:                                              ; preds = %start
  %_8.not = icmp eq ptr %this, null
  br i1 %_8.not, label %panic1, label %bb3

panic:                                            ; preds = %start
; call core::panicking::panic_misaligned_pointer_dereference
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking36panic_misaligned_pointer_dereference(i64 noundef 8, i64 noundef %_5, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_8301db87b19c4fd1b041a9b35ebbea76) #20
  unreachable

bb3:                                              ; preds = %bb2
  tail call void @llvm.experimental.noalias.scope.decl(metadata !142)
  %_12.i = load i64, ptr %this, align 8, !range !56, !alias.scope !142, !noundef !57
  %_3.not.i.i = icmp ugt i64 %len, %_12.i
  br i1 %_3.not.i.i, label %bb2.i.i, label %_RNvMNtCsdVJFY9KZ4lg_3cxx8rust_vecINtB2_7RustVecNtNtCscgZyRT41Cnx_20mime_type_validation3ffi9ParameterE7set_lenBN_.exit, !prof !69

bb2.i.i:                                          ; preds = %bb3
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_57d70e9d94c65ecfc15225d29a5ed72b, ptr noundef nonnull inttoptr (i64 397 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_5c16a04db8e7c261b2a076cf2ba35ad3) #20, !noalias !142
  unreachable

_RNvMNtCsdVJFY9KZ4lg_3cxx8rust_vecINtB2_7RustVecNtNtCscgZyRT41Cnx_20mime_type_validation3ffi9ParameterE7set_lenBN_.exit: ; preds = %bb3
  %0 = getelementptr inbounds nuw i8, ptr %this, i64 16
  store i64 %len, ptr %0, align 8, !alias.scope !142
  ret void

panic1:                                           ; preds = %bb2
; call core::panicking::panic_null_reference_constructed
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking32panic_null_reference_constructed(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_8301db87b19c4fd1b041a9b35ebbea76) #20
  unreachable
}

; Function Attrs: nounwind uwtable
define void @"cxxbridge1$rust_vec$net$mime_type_internal$Parameter$truncate"(ptr noundef %0, i64 noundef %1) unnamed_addr #3 !guid !145 {
start:
  %_7.i = ptrtoint ptr %0 to i64
  %_8.i = and i64 %_7.i, 7
  %_9.i = icmp eq i64 %_8.i, 0
  br i1 %_9.i, label %bb2.i, label %panic.i

bb2.i:                                            ; preds = %start
  %_10.not.i = icmp eq ptr %0, null
  br i1 %_10.not.i, label %panic1.i, label %bb3.i

panic.i:                                          ; preds = %start
; call core::panicking::panic_misaligned_pointer_dereference
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking36panic_misaligned_pointer_dereference(i64 noundef 8, i64 noundef %_7.i, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_8301db87b19c4fd1b041a9b35ebbea76) #20
  unreachable

bb3.i:                                            ; preds = %bb2.i
  %2 = getelementptr inbounds nuw i8, ptr %0, i64 16
  %_4.i.i.i = load i64, ptr %2, align 8, !alias.scope !146, !noundef !57
  %_3.not.i.i.i = icmp ult i64 %1, %_4.i.i.i
  br i1 %_3.not.i.i.i, label %bb2.i.i.i, label %_RNCNvNvNtCscgZyRT41Cnx_20mime_type_validation3ffi1__10___truncate0B7_.exit

bb2.i.i.i:                                        ; preds = %bb3.i
  store i64 %1, ptr %2, align 8, !alias.scope !146
  br label %_RNCNvNvNtCscgZyRT41Cnx_20mime_type_validation3ffi1__10___truncate0B7_.exit

panic1.i:                                         ; preds = %bb2.i
; call core::panicking::panic_null_reference_constructed
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking32panic_null_reference_constructed(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_8301db87b19c4fd1b041a9b35ebbea76) #20
  unreachable

_RNCNvNvNtCscgZyRT41Cnx_20mime_type_validation3ffi1__10___truncate0B7_.exit: ; preds = %bb3.i, %bb2.i.i.i
  ret void
}

; Function Attrs: nounwind uwtable
define void @"net$mime_type_internal$cxxbridge1$205$parse_content_type"(ptr noalias nofree noundef readonly align 8 captures(none) dead_on_return dereferenceable(16) %input, ptr noundef nonnull %state, i1 noundef zeroext %want_boundary, i1 noundef zeroext %boundary_is_mime, ptr nofree noundef writeonly captures(none) %__return) unnamed_addr #3 personality ptr @__CxxFrameHandler3 !guid !151 {
start:
  %__return.i.i.i.i.i.i = alloca [16 x i8], align 8
  %_54.i.i.i.i = alloca [24 x i8], align 8
  %value2.i.i.i.i = alloca [32 x i8], align 8
  %_50.i.i.i.i = alloca [32 x i8], align 8
  %_49.i.i.i.i = alloca [24 x i8], align 8
  %_33.i.i.i.i = alloca [24 x i8], align 8
  %value1.i.i.i.i = alloca [32 x i8], align 8
  %result.i.i.i.i = alloca [104 x i8], align 8
  %boundary.sroa.0.i.i.i.i = alloca [24 x i8], align 8
  %boundary.sroa.7.i.i.i.i = alloca [7 x i8], align 1
  %charset.sroa.0.i.i.i.i = alloca [24 x i8], align 8
  %charset.sroa.8.i.i.i.i = alloca [7 x i8], align 1
  %_13.i.i.i.i = alloca [56 x i8], align 8
  %iter.i.i.i.i = alloca [24 x i8], align 8
  %_6.sroa.0.0.copyload = load ptr, ptr %input, align 8, !nonnull !57, !noundef !57
  %_6.sroa.4.0.input.sroa_idx = getelementptr inbounds nuw i8, ptr %input, i64 8
  %_6.sroa.4.0.copyload = load i64, ptr %_6.sroa.4.0.input.sroa_idx, align 8
  %_7.not.i.i = icmp slt i64 %_6.sroa.4.0.copyload, 0
  br i1 %_7.not.i.i, label %bb5.i.i, label %_RNvNvNtNtCs9l4wcBNbII5_4core5slice3raw14from_raw_parts18precondition_check.exit.i, !prof !69

bb5.i.i:                                          ; preds = %start
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_a28e8c8fd5088943a8b5d44af697ff83, ptr noundef nonnull inttoptr (i64 559 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_7d52e238cba565908982a5cea838db34) #20, !noalias !152
  unreachable

_RNvNvNtNtCs9l4wcBNbII5_4core5slice3raw14from_raw_parts18precondition_check.exit.i: ; preds = %start
  tail call void @llvm.experimental.noalias.scope.decl(metadata !155)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !158)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !161)
  call void @llvm.lifetime.start.p0(ptr nonnull %boundary.sroa.0.i.i.i.i)
  call void @llvm.lifetime.start.p0(ptr nonnull %boundary.sroa.7.i.i.i.i)
  call void @llvm.lifetime.start.p0(ptr nonnull %charset.sroa.0.i.i.i.i)
  call void @llvm.lifetime.start.p0(ptr nonnull %charset.sroa.8.i.i.i.i)
  call void @llvm.lifetime.start.p0(ptr nonnull %_13.i.i.i.i), !noalias !164
  %_317.not.i.i.i.i.i = icmp eq i64 %_6.sroa.4.0.copyload, 0
  br i1 %_317.not.i.i.i.i.i, label %bb6.i.i.i.i.i, label %bb3.i.i.i.i.i

bb6.i.i.i.i.i:                                    ; preds = %bb3.i.i.i.i.i, %_RNvNvNtNtCs9l4wcBNbII5_4core5slice3raw14from_raw_parts18precondition_check.exit.i
  %start1.sroa.0.0.lcssa.i.i.i.i.i = phi i64 [ 0, %_RNvNvNtNtCs9l4wcBNbII5_4core5slice3raw14from_raw_parts18precondition_check.exit.i ], [ %start1.sroa.0.018.i.i.i.i.i, %bb3.i.i.i.i.i ]
  %_1220.i.i.i.i.i = icmp samesign ult i64 %start1.sroa.0.0.lcssa.i.i.i.i.i, %_6.sroa.4.0.copyload
  br i1 %_1220.i.i.i.i.i, label %bb9.i.i.i.i.i, label %_RNCNvNvNtCscgZyRT41Cnx_20mime_type_validation3ffi1__20___parse_content_type0B7_.exit

bb3.i.i.i.i.i:                                    ; preds = %_RNvNvNtNtCs9l4wcBNbII5_4core5slice3raw14from_raw_parts18precondition_check.exit.i, %bb4.i.i.i.i.i
  %start1.sroa.0.018.i.i.i.i.i = phi i64 [ %_9.0.i.i.i.i.i, %bb4.i.i.i.i.i ], [ 0, %_RNvNvNtNtCs9l4wcBNbII5_4core5slice3raw14from_raw_parts18precondition_check.exit.i ]
  %0 = getelementptr inbounds nuw i8, ptr %_6.sroa.0.0.copyload, i64 %start1.sroa.0.018.i.i.i.i.i
  %_6.i.i.i.i.i = load i8, ptr %0, align 1, !alias.scope !167, !noalias !152, !noundef !57
  switch i8 %_6.i.i.i.i.i, label %bb6.i.i.i.i.i [
    i8 32, label %bb4.i.i.i.i.i
    i8 9, label %bb4.i.i.i.i.i
  ]

bb4.i.i.i.i.i:                                    ; preds = %bb3.i.i.i.i.i, %bb3.i.i.i.i.i
  %_9.0.i.i.i.i.i = add nuw nsw i64 %start1.sroa.0.018.i.i.i.i.i, 1
  %exitcond.not.i.i.i.i.i = icmp eq i64 %_9.0.i.i.i.i.i, %_6.sroa.4.0.copyload
  br i1 %exitcond.not.i.i.i.i.i, label %_RNCNvNvNtCscgZyRT41Cnx_20mime_type_validation3ffi1__20___parse_content_type0B7_.exit, label %bb3.i.i.i.i.i

bb16.i.i.i.i.i:                                   ; preds = %bb14.i.i.i.i.i, %bb9.i.i.i.i.i, %bb9.i.i.i.i.i, %bb9.i.i.i.i.i, %bb9.i.i.i.i.i
  %slash.sroa.0.0.lcssa.i.i.i.i.i = phi i1 [ %2, %bb14.i.i.i.i.i ], [ %slash.sroa.0.021.i.i.i.i.i, %bb9.i.i.i.i.i ], [ %slash.sroa.0.021.i.i.i.i.i, %bb9.i.i.i.i.i ], [ %slash.sroa.0.021.i.i.i.i.i, %bb9.i.i.i.i.i ], [ %slash.sroa.0.021.i.i.i.i.i, %bb9.i.i.i.i.i ]
  %end.sroa.0.0.lcssa.i.i.i.i.i = phi i64 [ %_6.sroa.4.0.copyload, %bb14.i.i.i.i.i ], [ %end.sroa.0.022.i.i.i.i.i, %bb9.i.i.i.i.i ], [ %end.sroa.0.022.i.i.i.i.i, %bb9.i.i.i.i.i ], [ %end.sroa.0.022.i.i.i.i.i, %bb9.i.i.i.i.i ], [ %end.sroa.0.022.i.i.i.i.i, %bb9.i.i.i.i.i ]
  br i1 %slash.sroa.0.0.lcssa.i.i.i.i.i, label %bb2.i.i.i.i, label %_RNCNvNvNtCscgZyRT41Cnx_20mime_type_validation3ffi1__20___parse_content_type0B7_.exit

bb9.i.i.i.i.i:                                    ; preds = %bb6.i.i.i.i.i, %bb14.i.i.i.i.i
  %end.sroa.0.022.i.i.i.i.i = phi i64 [ %_23.0.i.i.i.i.i, %bb14.i.i.i.i.i ], [ %start1.sroa.0.0.lcssa.i.i.i.i.i, %bb6.i.i.i.i.i ]
  %slash.sroa.0.021.i.i.i.i.i = phi i1 [ %2, %bb14.i.i.i.i.i ], [ false, %bb6.i.i.i.i.i ]
  %1 = getelementptr inbounds nuw i8, ptr %_6.sroa.0.0.copyload, i64 %end.sroa.0.022.i.i.i.i.i
  %_14.i.i.i.i.i = load i8, ptr %1, align 1, !alias.scope !167, !noalias !152, !noundef !57
  switch i8 %_14.i.i.i.i.i, label %bb14.i.i.i.i.i [
    i8 32, label %bb16.i.i.i.i.i
    i8 9, label %bb16.i.i.i.i.i
    i8 59, label %bb16.i.i.i.i.i
    i8 40, label %bb16.i.i.i.i.i
  ]

bb14.i.i.i.i.i:                                   ; preds = %bb9.i.i.i.i.i
  %_23.0.i.i.i.i.i = add nuw i64 %end.sroa.0.022.i.i.i.i.i, 1
  %_19.i.i.i.i.i = icmp eq i8 %_14.i.i.i.i.i, 47
  %2 = or i1 %slash.sroa.0.021.i.i.i.i.i, %_19.i.i.i.i.i
  %exitcond36.not.i.i.i.i.i = icmp eq i64 %_23.0.i.i.i.i.i, %_6.sroa.4.0.copyload
  br i1 %exitcond36.not.i.i.i.i.i, label %bb16.i.i.i.i.i, label %bb9.i.i.i.i.i

bb2.i.i.i.i:                                      ; preds = %bb16.i.i.i.i.i
  %3 = icmp eq i64 %_6.sroa.4.0.copyload, 3
  br i1 %3, label %bb53.i.i.i.i, label %bb5.i.i.i.i

bb53.i.i.i.i:                                     ; preds = %bb2.i.i.i.i
  %4 = load i24, ptr %_6.sroa.0.0.copyload, align 1, !alias.scope !170, !noalias !152
  %_9.i.i.i.i = icmp eq i24 %4, 2764586
  br i1 %_9.i.i.i.i, label %_RNCNvNvNtCscgZyRT41Cnx_20mime_type_validation3ffi1__20___parse_content_type0B7_.exit, label %bb5.i.i.i.i

bb5.i.i.i.i:                                      ; preds = %bb53.i.i.i.i, %bb2.i.i.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %iter.i.i.i.i), !noalias !171
  store ptr %_6.sroa.0.0.copyload, ptr %iter.i.i.i.i, align 8, !noalias !171
  %_10.sroa.2.0.iter.sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %iter.i.i.i.i, i64 8
  store i64 %_6.sroa.4.0.copyload, ptr %_10.sroa.2.0.iter.sroa_idx.i.i.i.i, align 8, !noalias !171
  %_10.sroa.3.0.iter.sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %iter.i.i.i.i, i64 16
  store i64 %end.sroa.0.0.lcssa.i.i.i.i.i, ptr %_10.sroa.3.0.iter.sroa_idx.i.i.i.i, align 8, !noalias !171
; call <mime_type_validation::mime_type_parser::Parameters as core::iter::traits::iterator::Iterator>::next
  call fastcc void @_RNvXs_NtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB4_10ParametersNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next(ptr noalias nofree noundef align 8 captures(none) dereferenceable(56) %_13.i.i.i.i, ptr noalias nofree noundef align 8 dereferenceable(24) %iter.i.i.i.i) #19, !noalias !173
  %5 = getelementptr inbounds nuw i8, ptr %_13.i.i.i.i, i64 16
  %6 = load i8, ptr %5, align 8, !range !174, !noalias !171, !noundef !57
  %.not65206.i.i.i.i = icmp eq i8 %6, 2
  br i1 %.not65206.i.i.i.i, label %bb23.i.i.i.i, label %bb9.lr.ph.i.i.i.i

bb9.lr.ph.i.i.i.i:                                ; preds = %bb5.i.i.i.i
  %name.sroa.5.0._13.sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_13.i.i.i.i, i64 8
  %7 = getelementptr inbounds nuw i8, ptr %_13.i.i.i.i, i64 24
  %value.sroa.6.0..sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_13.i.i.i.i, i64 48
  %value.sroa.7.0..sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_13.i.i.i.i, i64 49
  br label %bb9.i.i.i.i

bb9.i.i.i.i:                                      ; preds = %bb22.i.i.i.i, %bb9.lr.ph.i.i.i.i
  %8 = phi i8 [ %6, %bb9.lr.ph.i.i.i.i ], [ %37, %bb22.i.i.i.i ]
  %charset.sroa.2.0208.i.i.i.i = phi i8 [ 2, %bb9.lr.ph.i.i.i.i ], [ %charset.sroa.2.2.i.i.i.i, %bb22.i.i.i.i ]
  %boundary.sroa.2.0207.i.i.i.i = phi i8 [ 2, %bb9.lr.ph.i.i.i.i ], [ %boundary.sroa.2.2.i.i.i.i, %bb22.i.i.i.i ]
  %name.sroa.0.0.copyload.i.i.i.i = load i64, ptr %_13.i.i.i.i, align 8, !noalias !171
  %name.sroa.5.0.copyload.i.i.i.i = load i64, ptr %name.sroa.5.0._13.sroa_idx.i.i.i.i, align 8, !noalias !171
  %value.sroa.6.0.copyload.i.i.i.i = load i8, ptr %value.sroa.6.0..sroa_idx.i.i.i.i, align 8, !noalias !171
  %_4.i.i.i.i.i = trunc nuw i8 %8 to i1
  %spec.select.i.i.i.i.i = select i1 %_4.i.i.i.i.i, i64 0, i64 %_6.sroa.4.0.copyload
  %_13.i.i.i.i.i = icmp ult i64 %name.sroa.5.0.copyload.i.i.i.i, %name.sroa.0.0.copyload.i.i.i.i
  %_7.not.i.i.i.i.i = icmp ugt i64 %name.sroa.5.0.copyload.i.i.i.i, %spec.select.i.i.i.i.i
  %or.cond.i.i.i.i.i = select i1 %_13.i.i.i.i.i, i1 true, i1 %_7.not.i.i.i.i.i, !prof !70
  br i1 %or.cond.i.i.i.i.i, label %bb6.i77.i.i.i.i, label %_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit.i.i.i.i, !prof !70

bb6.i77.i.i.i.i:                                  ; preds = %bb9.i.i.i.i
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCs9l4wcBNbII5_4core5slice5index16slice_index_fail(i64 noundef %name.sroa.0.0.copyload.i.i.i.i, i64 noundef %name.sroa.5.0.copyload.i.i.i.i, i64 noundef %spec.select.i.i.i.i.i, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_ad438f04501d3850fe5717f2a4e651e9) #20, !noalias !175
  unreachable

_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit.i.i.i.i: ; preds = %bb9.i.i.i.i
  %spec.select4.i.i.i.i.i = select i1 %_4.i.i.i.i.i, ptr inttoptr (i64 1 to ptr), ptr %_6.sroa.0.0.copyload
  %_14.i76.i.i.i.i = sub nuw i64 %name.sroa.5.0.copyload.i.i.i.i, %name.sroa.0.0.copyload.i.i.i.i
  %_16.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %spec.select4.i.i.i.i.i, i64 %name.sroa.0.0.copyload.i.i.i.i
  %.not66.i.i.i.i = icmp eq i8 %charset.sroa.2.0208.i.i.i.i, 2
  %9 = icmp eq i64 %_14.i76.i.i.i.i, 7
  %or.cond72.i.i.i.i = select i1 %.not66.i.i.i.i, i1 %9, i1 false
  br i1 %or.cond72.i.i.i.i, label %bb60.i.i.i.i, label %bb14.i.i.i.i

bb23.i.i.i.i:                                     ; preds = %bb79.i.i.i.i, %bb20.i.i.i.i, %bb19.i.i.i.i, %bb22.i.i.i.i, %bb5.i.i.i.i
  %boundary.sroa.2.1.i.i.i.i = phi i8 [ 2, %bb5.i.i.i.i ], [ %boundary.sroa.2.2.i.i.i.i, %bb22.i.i.i.i ], [ %boundary.sroa.2.4.i.i.i.i, %bb20.i.i.i.i ], [ %boundary.sroa.2.0207.i.i.i.i, %bb19.i.i.i.i ], [ %boundary.sroa.2.0207.i.i.i.i, %bb79.i.i.i.i ]
  %charset.sroa.2.1.i.i.i.i = phi i8 [ 2, %bb5.i.i.i.i ], [ %charset.sroa.2.2.i.i.i.i, %bb22.i.i.i.i ], [ %charset.sroa.2.4.i.i.i.i, %bb20.i.i.i.i ], [ %value.sroa.6.0.copyload.i.i.i.i, %bb19.i.i.i.i ], [ %charset.sroa.2.0208.i.i.i.i, %bb79.i.i.i.i ]
  call void @llvm.lifetime.end.p0(ptr nonnull %iter.i.i.i.i), !noalias !171
  call void @llvm.lifetime.start.p0(ptr nonnull %result.i.i.i.i), !noalias !171
  %10 = getelementptr inbounds nuw i8, ptr %result.i.i.i.i, i64 96
  store i8 0, ptr %10, align 8, !noalias !171
  %11 = getelementptr inbounds nuw i8, ptr %result.i.i.i.i, i64 24
  %12 = getelementptr inbounds nuw i8, ptr %result.i.i.i.i, i64 97
  store i8 0, ptr %12, align 1, !noalias !171
  %13 = getelementptr inbounds nuw i8, ptr %result.i.i.i.i, i64 48
  %14 = getelementptr inbounds nuw i8, ptr %result.i.i.i.i, i64 98
  store i8 0, ptr %14, align 2, !noalias !171
  %15 = getelementptr inbounds nuw i8, ptr %result.i.i.i.i, i64 72
  %_78.sroa.6.0..sroa_idx57.i.i.i.i = getelementptr inbounds nuw i8, ptr %result.i.i.i.i, i64 80
  %_78.sroa.7.0..sroa_idx61.i.i.i.i = getelementptr inbounds nuw i8, ptr %result.i.i.i.i, i64 88
  store i64 0, ptr %result.i.i.i.i, align 8, !noalias !171
  %_79.sroa.4.0.result.sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %result.i.i.i.i, i64 8
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(17) %11, i8 0, i64 17, i1 false), !noalias !171
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(17) %13, i8 0, i64 17, i1 false), !noalias !171
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(17) %15, i8 0, i64 17, i1 false), !noalias !171
  store ptr inttoptr (i64 1 to ptr), ptr %_79.sroa.4.0.result.sroa_idx.i.i.i.i, align 8, !noalias !171
  %_79.sroa.5.0.result.sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %result.i.i.i.i, i64 16
  store i64 0, ptr %_79.sroa.5.0.result.sroa_idx.i.i.i.i, align 8, !noalias !171
  %.not70.i.i.i.i = icmp eq i8 %boundary.sroa.2.1.i.i.i.i, 2
  br i1 %.not70.i.i.i.i, label %bb31.i.i.i.i, label %bb26.i.i.i.i

bb14.i.i.i.i:                                     ; preds = %bb1.i.6.i.i.i.i, %bb1.i.5.i.i.i.i, %bb1.i.4.i.i.i.i, %bb1.i.3.i.i.i.i, %bb1.i.2.i.i.i.i, %bb1.i.1.i.i.i.i, %bb60.i.i.i.i, %_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit.i.i.i.i
  br i1 %want_boundary, label %bb15.i.i.i.i, label %bb79.i.i.i.i

bb60.i.i.i.i:                                     ; preds = %_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit.i.i.i.i
  %_14.i80.i.i.i.i = load i8, ptr %_16.i.i.i.i.i, align 1, !alias.scope !180, !noalias !173, !noundef !57
  %16 = add i8 %_14.i80.i.i.i.i, -65
  %17 = icmp ult i8 %16, 26
  %18 = select i1 %17, i8 32, i8 0
  %_18.sroa.0.0.i.i.i.i.i = or i8 %18, %_14.i80.i.i.i.i
  %_11.i.i.i.i.i = icmp eq i8 %_18.sroa.0.0.i.i.i.i.i, 99
  br i1 %_11.i.i.i.i.i, label %bb1.i.1.i.i.i.i, label %bb14.i.i.i.i

bb1.i.1.i.i.i.i:                                  ; preds = %bb60.i.i.i.i
  %rest_a.0.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %_16.i.i.i.i.i, i64 1
  %_14.i80.1.i.i.i.i = load i8, ptr %rest_a.0.i.i.i.i.i, align 1, !alias.scope !180, !noalias !173, !noundef !57
  %19 = add i8 %_14.i80.1.i.i.i.i, -65
  %20 = icmp ult i8 %19, 26
  %21 = select i1 %20, i8 32, i8 0
  %_18.sroa.0.0.i.1.i.i.i.i = or i8 %21, %_14.i80.1.i.i.i.i
  %_11.i.1.i.i.i.i = icmp eq i8 %_18.sroa.0.0.i.1.i.i.i.i, 104
  br i1 %_11.i.1.i.i.i.i, label %bb1.i.2.i.i.i.i, label %bb14.i.i.i.i

bb1.i.2.i.i.i.i:                                  ; preds = %bb1.i.1.i.i.i.i
  %rest_a.0.i.1.i.i.i.i = getelementptr inbounds nuw i8, ptr %_16.i.i.i.i.i, i64 2
  %_14.i80.2.i.i.i.i = load i8, ptr %rest_a.0.i.1.i.i.i.i, align 1, !alias.scope !180, !noalias !173, !noundef !57
  %22 = add i8 %_14.i80.2.i.i.i.i, -65
  %23 = icmp ult i8 %22, 26
  %24 = select i1 %23, i8 32, i8 0
  %_18.sroa.0.0.i.2.i.i.i.i = or i8 %24, %_14.i80.2.i.i.i.i
  %_11.i.2.i.i.i.i = icmp eq i8 %_18.sroa.0.0.i.2.i.i.i.i, 97
  br i1 %_11.i.2.i.i.i.i, label %bb1.i.3.i.i.i.i, label %bb14.i.i.i.i

bb1.i.3.i.i.i.i:                                  ; preds = %bb1.i.2.i.i.i.i
  %rest_a.0.i.2.i.i.i.i = getelementptr inbounds nuw i8, ptr %_16.i.i.i.i.i, i64 3
  %_14.i80.3.i.i.i.i = load i8, ptr %rest_a.0.i.2.i.i.i.i, align 1, !alias.scope !180, !noalias !173, !noundef !57
  %25 = add i8 %_14.i80.3.i.i.i.i, -65
  %26 = icmp ult i8 %25, 26
  %27 = select i1 %26, i8 32, i8 0
  %_18.sroa.0.0.i.3.i.i.i.i = or i8 %27, %_14.i80.3.i.i.i.i
  %_11.i.3.i.i.i.i = icmp eq i8 %_18.sroa.0.0.i.3.i.i.i.i, 114
  br i1 %_11.i.3.i.i.i.i, label %bb1.i.4.i.i.i.i, label %bb14.i.i.i.i

bb1.i.4.i.i.i.i:                                  ; preds = %bb1.i.3.i.i.i.i
  %rest_a.0.i.3.i.i.i.i = getelementptr inbounds nuw i8, ptr %_16.i.i.i.i.i, i64 4
  %_14.i80.4.i.i.i.i = load i8, ptr %rest_a.0.i.3.i.i.i.i, align 1, !alias.scope !180, !noalias !173, !noundef !57
  %28 = add i8 %_14.i80.4.i.i.i.i, -65
  %29 = icmp ult i8 %28, 26
  %30 = select i1 %29, i8 32, i8 0
  %_18.sroa.0.0.i.4.i.i.i.i = or i8 %30, %_14.i80.4.i.i.i.i
  %_11.i.4.i.i.i.i = icmp eq i8 %_18.sroa.0.0.i.4.i.i.i.i, 115
  br i1 %_11.i.4.i.i.i.i, label %bb1.i.5.i.i.i.i, label %bb14.i.i.i.i

bb1.i.5.i.i.i.i:                                  ; preds = %bb1.i.4.i.i.i.i
  %rest_a.0.i.4.i.i.i.i = getelementptr inbounds nuw i8, ptr %_16.i.i.i.i.i, i64 5
  %_14.i80.5.i.i.i.i = load i8, ptr %rest_a.0.i.4.i.i.i.i, align 1, !alias.scope !180, !noalias !173, !noundef !57
  %31 = add i8 %_14.i80.5.i.i.i.i, -65
  %32 = icmp ult i8 %31, 26
  %33 = select i1 %32, i8 32, i8 0
  %_18.sroa.0.0.i.5.i.i.i.i = or i8 %33, %_14.i80.5.i.i.i.i
  %_11.i.5.i.i.i.i = icmp eq i8 %_18.sroa.0.0.i.5.i.i.i.i, 101
  br i1 %_11.i.5.i.i.i.i, label %bb1.i.6.i.i.i.i, label %bb14.i.i.i.i

bb1.i.6.i.i.i.i:                                  ; preds = %bb1.i.5.i.i.i.i
  %rest_a.0.i.5.i.i.i.i = getelementptr inbounds nuw i8, ptr %_16.i.i.i.i.i, i64 6
  %_14.i80.6.i.i.i.i = load i8, ptr %rest_a.0.i.5.i.i.i.i, align 1, !alias.scope !180, !noalias !173, !noundef !57
  %34 = add i8 %_14.i80.6.i.i.i.i, -65
  %35 = icmp ult i8 %34, 26
  %36 = select i1 %35, i8 32, i8 0
  %_18.sroa.0.0.i.6.i.i.i.i = or i8 %36, %_14.i80.6.i.i.i.i
  %_11.i.6.i.i.i.i = icmp eq i8 %_18.sroa.0.0.i.6.i.i.i.i, 116
  br i1 %_11.i.6.i.i.i.i, label %bb12.i.i.i.i, label %bb14.i.i.i.i

bb12.i.i.i.i:                                     ; preds = %bb1.i.6.i.i.i.i
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %charset.sroa.0.i.i.i.i, ptr noundef nonnull align 8 dereferenceable(24) %7, i64 24, i1 false), !noalias !171
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(7) %charset.sroa.8.i.i.i.i, ptr noundef nonnull align 1 dereferenceable(7) %value.sroa.7.0..sroa_idx.i.i.i.i, i64 7, i1 false), !noalias !171
  %.not68.i.i.i.i = icmp eq i8 %value.sroa.6.0.copyload.i.i.i.i, 2
  br i1 %.not68.i.i.i.i, label %bb22.i.i.i.i, label %bb19.i.i.i.i

bb22.i.i.i.i:                                     ; preds = %bb80.i.i.i.i, %bb79.i.i.i.i, %bb20.i.i.i.i, %bb12.i.i.i.i
  %boundary.sroa.2.2.i.i.i.i = phi i8 [ 2, %bb20.i.i.i.i ], [ %boundary.sroa.2.0207.i.i.i.i, %bb12.i.i.i.i ], [ %boundary.sroa.2.5.i.i.i.i, %bb80.i.i.i.i ], [ %boundary.sroa.2.0207.i.i.i.i, %bb79.i.i.i.i ]
  %charset.sroa.2.2.i.i.i.i = phi i8 [ %charset.sroa.2.4.i.i.i.i, %bb20.i.i.i.i ], [ 2, %bb12.i.i.i.i ], [ 2, %bb80.i.i.i.i ], [ 2, %bb79.i.i.i.i ]
; call <mime_type_validation::mime_type_parser::Parameters as core::iter::traits::iterator::Iterator>::next
  call fastcc void @_RNvXs_NtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB4_10ParametersNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next(ptr noalias nofree noundef align 8 captures(none) dereferenceable(56) %_13.i.i.i.i, ptr noalias nofree noundef align 8 dereferenceable(24) %iter.i.i.i.i) #19, !noalias !173
  %37 = load i8, ptr %5, align 8, !range !174, !noalias !171, !noundef !57
  %.not65.i.i.i.i = icmp eq i8 %37, 2
  br i1 %.not65.i.i.i.i, label %bb23.i.i.i.i, label %bb9.i.i.i.i

bb19.i.i.i.i:                                     ; preds = %bb12.i.i.i.i
  br i1 %want_boundary, label %bb20.i.i.i.i, label %bb23.i.i.i.i

bb20.i.i.i.i:                                     ; preds = %bb80.i.i.i.i, %bb19.i.i.i.i
  %boundary.sroa.2.4.i.i.i.i = phi i8 [ %boundary.sroa.2.0207.i.i.i.i, %bb19.i.i.i.i ], [ %boundary.sroa.2.5.i.i.i.i, %bb80.i.i.i.i ]
  %charset.sroa.2.4.i.i.i.i = phi i8 [ %value.sroa.6.0.copyload.i.i.i.i, %bb19.i.i.i.i ], [ %charset.sroa.2.0208.i.i.i.i, %bb80.i.i.i.i ]
  %.not69.i.i.i.i = icmp eq i8 %boundary.sroa.2.4.i.i.i.i, 2
  br i1 %.not69.i.i.i.i, label %bb22.i.i.i.i, label %bb23.i.i.i.i

bb79.i.i.i.i:                                     ; preds = %bb14.i.i.i.i
  br i1 %.not66.i.i.i.i, label %bb22.i.i.i.i, label %bb23.i.i.i.i

bb15.i.i.i.i:                                     ; preds = %bb14.i.i.i.i
  %.not67.i.i.i.i = icmp eq i8 %boundary.sroa.2.0207.i.i.i.i, 2
  %38 = icmp eq i64 %_14.i76.i.i.i.i, 8
  %or.cond73.i.i.i.i = select i1 %.not67.i.i.i.i, i1 %38, i1 false
  br i1 %or.cond73.i.i.i.i, label %bb66.i.i.i.i, label %bb80.i.i.i.i

bb80.i.i.i.i:                                     ; preds = %bb17.i.i.i.i, %bb1.i82.7.i.i.i.i, %bb1.i82.6.i.i.i.i, %bb1.i82.5.i.i.i.i, %bb1.i82.4.i.i.i.i, %bb1.i82.3.i.i.i.i, %bb1.i82.2.i.i.i.i, %bb1.i82.1.i.i.i.i, %bb66.i.i.i.i, %bb15.i.i.i.i
  %boundary.sroa.2.5.i.i.i.i = phi i8 [ %value.sroa.6.0.copyload.i.i.i.i, %bb17.i.i.i.i ], [ %boundary.sroa.2.0207.i.i.i.i, %bb15.i.i.i.i ], [ 2, %bb1.i82.7.i.i.i.i ], [ 2, %bb1.i82.6.i.i.i.i ], [ 2, %bb1.i82.5.i.i.i.i ], [ 2, %bb1.i82.4.i.i.i.i ], [ 2, %bb1.i82.3.i.i.i.i ], [ 2, %bb1.i82.2.i.i.i.i ], [ 2, %bb1.i82.1.i.i.i.i ], [ 2, %bb66.i.i.i.i ]
  br i1 %.not66.i.i.i.i, label %bb22.i.i.i.i, label %bb20.i.i.i.i

bb66.i.i.i.i:                                     ; preds = %bb15.i.i.i.i
  %_14.i95.i.i.i.i = load i8, ptr %_16.i.i.i.i.i, align 1, !alias.scope !183, !noalias !173, !noundef !57
  %39 = add i8 %_14.i95.i.i.i.i, -65
  %40 = icmp ult i8 %39, 26
  %41 = select i1 %40, i8 32, i8 0
  %_18.sroa.0.0.i96.i.i.i.i = or i8 %41, %_14.i95.i.i.i.i
  %_11.i99.i.i.i.i = icmp eq i8 %_18.sroa.0.0.i96.i.i.i.i, 98
  br i1 %_11.i99.i.i.i.i, label %bb1.i82.1.i.i.i.i, label %bb80.i.i.i.i

bb1.i82.1.i.i.i.i:                                ; preds = %bb66.i.i.i.i
  %rest_a.0.i91.i.i.i.i = getelementptr inbounds nuw i8, ptr %_16.i.i.i.i.i, i64 1
  %_14.i95.1.i.i.i.i = load i8, ptr %rest_a.0.i91.i.i.i.i, align 1, !alias.scope !183, !noalias !173, !noundef !57
  %42 = add i8 %_14.i95.1.i.i.i.i, -65
  %43 = icmp ult i8 %42, 26
  %44 = select i1 %43, i8 32, i8 0
  %_18.sroa.0.0.i96.1.i.i.i.i = or i8 %44, %_14.i95.1.i.i.i.i
  %_11.i99.1.i.i.i.i = icmp eq i8 %_18.sroa.0.0.i96.1.i.i.i.i, 111
  br i1 %_11.i99.1.i.i.i.i, label %bb1.i82.2.i.i.i.i, label %bb80.i.i.i.i

bb1.i82.2.i.i.i.i:                                ; preds = %bb1.i82.1.i.i.i.i
  %rest_a.0.i91.1.i.i.i.i = getelementptr inbounds nuw i8, ptr %_16.i.i.i.i.i, i64 2
  %_14.i95.2.i.i.i.i = load i8, ptr %rest_a.0.i91.1.i.i.i.i, align 1, !alias.scope !183, !noalias !173, !noundef !57
  %45 = add i8 %_14.i95.2.i.i.i.i, -65
  %46 = icmp ult i8 %45, 26
  %47 = select i1 %46, i8 32, i8 0
  %_18.sroa.0.0.i96.2.i.i.i.i = or i8 %47, %_14.i95.2.i.i.i.i
  %_11.i99.2.i.i.i.i = icmp eq i8 %_18.sroa.0.0.i96.2.i.i.i.i, 117
  br i1 %_11.i99.2.i.i.i.i, label %bb1.i82.3.i.i.i.i, label %bb80.i.i.i.i

bb1.i82.3.i.i.i.i:                                ; preds = %bb1.i82.2.i.i.i.i
  %rest_a.0.i91.2.i.i.i.i = getelementptr inbounds nuw i8, ptr %_16.i.i.i.i.i, i64 3
  %_14.i95.3.i.i.i.i = load i8, ptr %rest_a.0.i91.2.i.i.i.i, align 1, !alias.scope !183, !noalias !173, !noundef !57
  %48 = add i8 %_14.i95.3.i.i.i.i, -65
  %49 = icmp ult i8 %48, 26
  %50 = select i1 %49, i8 32, i8 0
  %_18.sroa.0.0.i96.3.i.i.i.i = or i8 %50, %_14.i95.3.i.i.i.i
  %_11.i99.3.i.i.i.i = icmp eq i8 %_18.sroa.0.0.i96.3.i.i.i.i, 110
  br i1 %_11.i99.3.i.i.i.i, label %bb1.i82.4.i.i.i.i, label %bb80.i.i.i.i

bb1.i82.4.i.i.i.i:                                ; preds = %bb1.i82.3.i.i.i.i
  %rest_a.0.i91.3.i.i.i.i = getelementptr inbounds nuw i8, ptr %_16.i.i.i.i.i, i64 4
  %_14.i95.4.i.i.i.i = load i8, ptr %rest_a.0.i91.3.i.i.i.i, align 1, !alias.scope !183, !noalias !173, !noundef !57
  %51 = add i8 %_14.i95.4.i.i.i.i, -65
  %52 = icmp ult i8 %51, 26
  %53 = select i1 %52, i8 32, i8 0
  %_18.sroa.0.0.i96.4.i.i.i.i = or i8 %53, %_14.i95.4.i.i.i.i
  %_11.i99.4.i.i.i.i = icmp eq i8 %_18.sroa.0.0.i96.4.i.i.i.i, 100
  br i1 %_11.i99.4.i.i.i.i, label %bb1.i82.5.i.i.i.i, label %bb80.i.i.i.i

bb1.i82.5.i.i.i.i:                                ; preds = %bb1.i82.4.i.i.i.i
  %rest_a.0.i91.4.i.i.i.i = getelementptr inbounds nuw i8, ptr %_16.i.i.i.i.i, i64 5
  %_14.i95.5.i.i.i.i = load i8, ptr %rest_a.0.i91.4.i.i.i.i, align 1, !alias.scope !183, !noalias !173, !noundef !57
  %54 = add i8 %_14.i95.5.i.i.i.i, -65
  %55 = icmp ult i8 %54, 26
  %56 = select i1 %55, i8 32, i8 0
  %_18.sroa.0.0.i96.5.i.i.i.i = or i8 %56, %_14.i95.5.i.i.i.i
  %_11.i99.5.i.i.i.i = icmp eq i8 %_18.sroa.0.0.i96.5.i.i.i.i, 97
  br i1 %_11.i99.5.i.i.i.i, label %bb1.i82.6.i.i.i.i, label %bb80.i.i.i.i

bb1.i82.6.i.i.i.i:                                ; preds = %bb1.i82.5.i.i.i.i
  %rest_a.0.i91.5.i.i.i.i = getelementptr inbounds nuw i8, ptr %_16.i.i.i.i.i, i64 6
  %_14.i95.6.i.i.i.i = load i8, ptr %rest_a.0.i91.5.i.i.i.i, align 1, !alias.scope !183, !noalias !173, !noundef !57
  %57 = add i8 %_14.i95.6.i.i.i.i, -65
  %58 = icmp ult i8 %57, 26
  %59 = select i1 %58, i8 32, i8 0
  %_18.sroa.0.0.i96.6.i.i.i.i = or i8 %59, %_14.i95.6.i.i.i.i
  %_11.i99.6.i.i.i.i = icmp eq i8 %_18.sroa.0.0.i96.6.i.i.i.i, 114
  br i1 %_11.i99.6.i.i.i.i, label %bb1.i82.7.i.i.i.i, label %bb80.i.i.i.i

bb1.i82.7.i.i.i.i:                                ; preds = %bb1.i82.6.i.i.i.i
  %rest_a.0.i91.6.i.i.i.i = getelementptr inbounds nuw i8, ptr %_16.i.i.i.i.i, i64 7
  %_14.i95.7.i.i.i.i = load i8, ptr %rest_a.0.i91.6.i.i.i.i, align 1, !alias.scope !183, !noalias !173, !noundef !57
  %60 = add i8 %_14.i95.7.i.i.i.i, -65
  %61 = icmp ult i8 %60, 26
  %62 = select i1 %61, i8 32, i8 0
  %_18.sroa.0.0.i96.7.i.i.i.i = or i8 %62, %_14.i95.7.i.i.i.i
  %_11.i99.7.i.i.i.i = icmp eq i8 %_18.sroa.0.0.i96.7.i.i.i.i, 121
  br i1 %_11.i99.7.i.i.i.i, label %bb17.i.i.i.i, label %bb80.i.i.i.i

bb17.i.i.i.i:                                     ; preds = %bb1.i82.7.i.i.i.i
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %boundary.sroa.0.i.i.i.i, ptr noundef nonnull align 8 dereferenceable(24) %7, i64 24, i1 false), !noalias !171
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(7) %boundary.sroa.7.i.i.i.i, ptr noundef nonnull align 1 dereferenceable(7) %value.sroa.7.0..sroa_idx.i.i.i.i, i64 7, i1 false), !noalias !171
  br label %bb80.i.i.i.i

bb26.i.i.i.i:                                     ; preds = %bb23.i.i.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %value1.i.i.i.i), !noalias !171
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %value1.i.i.i.i, ptr noundef nonnull align 8 dereferenceable(24) %boundary.sroa.0.i.i.i.i, i64 24, i1 false), !noalias !171
  %boundary.sroa.2.0.value1.sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %value1.i.i.i.i, i64 24
  store i8 %boundary.sroa.2.1.i.i.i.i, ptr %boundary.sroa.2.0.value1.sroa_idx.i.i.i.i, align 8, !noalias !171
  %boundary.sroa.7.0.value1.sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %value1.i.i.i.i, i64 25
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(7) %boundary.sroa.7.0.value1.sroa_idx.i.i.i.i, ptr noundef nonnull align 1 dereferenceable(7) %boundary.sroa.7.i.i.i.i, i64 7, i1 false), !noalias !171
  store i8 1, ptr %14, align 2, !noalias !171
  call void @llvm.lifetime.start.p0(ptr nonnull %_33.i.i.i.i), !noalias !171
; call mime_type_validation::mime_type_parser::output_value
  call fastcc void @_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser12output_value(ptr noalias nofree noundef align 8 captures(address) dereferenceable(24) %_33.i.i.i.i, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %_6.sroa.0.0.copyload, i64 noundef range(i64 0, -9223372036854775808) %_6.sroa.4.0.copyload, ptr noalias nofree noundef readonly align 8 captures(none) dereferenceable(32) %value1.i.i.i.i, ptr noalias nofree noundef align 8 dereferenceable(24) %result.i.i.i.i, i1 noundef zeroext true, i1 noundef zeroext false) #19, !noalias !173
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %15, ptr noundef nonnull align 8 dereferenceable(24) %_33.i.i.i.i, i64 24, i1 false), !noalias !171
  call void @llvm.lifetime.end.p0(ptr nonnull %_33.i.i.i.i), !noalias !171
  call void @llvm.lifetime.end.p0(ptr nonnull %value1.i.i.i.i), !noalias !171
  %.pre.i.i.i.i = load i8, ptr %14, align 2, !range !73, !noalias !171
  %63 = trunc nuw i8 %.pre.i.i.i.i to i1
  %or.cond.i.i.i.i = select i1 %boundary_is_mime, i1 %63, i1 false
  br i1 %or.cond.i.i.i.i, label %bb28.i.i.i.i, label %bb31.i.i.i.i

bb31.i.i.i.i:                                     ; preds = %bb26.i.i.i.i, %bb23.i.i.i.i
  %_13.i105.i.i.i.i = icmp ult i64 %end.sroa.0.0.lcssa.i.i.i.i.i, %start1.sroa.0.0.lcssa.i.i.i.i.i
  %_7.not.i106.i.i.i.i = icmp ugt i64 %end.sroa.0.0.lcssa.i.i.i.i.i, %_6.sroa.4.0.copyload
  %or.cond.i107.i.i.i.i = or i1 %_13.i105.i.i.i.i, %_7.not.i106.i.i.i.i
  br i1 %or.cond.i107.i.i.i.i, label %bb6.i112.i.i.i.i, label %_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit113.i.i.i.i, !prof !70

bb6.i112.i.i.i.i:                                 ; preds = %bb31.i.i.i.i
; call core::slice::index::slice_index_fail
  call void @_RNvNtNtCs9l4wcBNbII5_4core5slice5index16slice_index_fail(i64 noundef %start1.sroa.0.0.lcssa.i.i.i.i.i, i64 noundef %end.sroa.0.0.lcssa.i.i.i.i.i, i64 noundef range(i64 0, -9223372036854775808) %_6.sroa.4.0.copyload, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_ad438f04501d3850fe5717f2a4e651e9) #20, !noalias !186
  unreachable

_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit113.i.i.i.i: ; preds = %bb31.i.i.i.i
  %_14.i110.i.i.i.i = sub nuw nsw i64 %end.sroa.0.0.lcssa.i.i.i.i.i, %start1.sroa.0.0.lcssa.i.i.i.i.i
  %_16.i111.i.i.i.i = getelementptr inbounds nuw i8, ptr %_6.sroa.0.0.copyload, i64 %start1.sroa.0.0.lcssa.i.i.i.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %__return.i.i.i.i.i.i), !noalias !171
  call void @"net$mime_type_internal$cxxbridge1$205$ContentTypeState$current_mime"(ptr noundef nonnull %state, ptr noundef nonnull %__return.i.i.i.i.i.i) #19, !noalias !173
  %_5.sroa.2.0.__return.sroa_idx.i.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %__return.i.i.i.i.i.i, i64 8
  %_5.sroa.2.0.copyload.i.i.i.i.i.i = load i64, ptr %_5.sroa.2.0.__return.sroa_idx.i.i.i.i.i.i, align 8, !noalias !171
  %_7.not.i.i.i.i.i.i.i = icmp slt i64 %_5.sroa.2.0.copyload.i.i.i.i.i.i, 0
  br i1 %_7.not.i.i.i.i.i.i.i, label %bb5.i.i.i.i.i.i.i, label %_RNCNvCscgZyRT41Cnx_20mime_type_validation18parse_content_type0B3_.exit.i.i.i.i, !prof !69

bb5.i.i.i.i.i.i.i:                                ; preds = %_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit113.i.i.i.i
; call core::panicking::panic_nounwind_fmt
  call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_a28e8c8fd5088943a8b5d44af697ff83, ptr noundef nonnull inttoptr (i64 559 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_7d52e238cba565908982a5cea838db34) #20, !noalias !173
  unreachable

_RNCNvCscgZyRT41Cnx_20mime_type_validation18parse_content_type0B3_.exit.i.i.i.i: ; preds = %_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit113.i.i.i.i
  %_5.sroa.0.0.copyload.i.i.i.i.i.i = load ptr, ptr %__return.i.i.i.i.i.i, align 8, !noalias !171, !nonnull !57, !noundef !57
  call void @llvm.lifetime.end.p0(ptr nonnull %__return.i.i.i.i.i.i), !noalias !171
  %_88.not.i.i.i.i = icmp eq i64 %_14.i110.i.i.i.i, %_5.sroa.2.0.copyload.i.i.i.i.i.i
  br i1 %_88.not.i.i.i.i, label %bb75.i.i.i.i, label %bb39.i.i.i.i

bb28.i.i.i.i:                                     ; preds = %bb26.i.i.i.i
  %_13.i118.i.i.i.i = icmp ult i64 %end.sroa.0.0.lcssa.i.i.i.i.i, %start1.sroa.0.0.lcssa.i.i.i.i.i
  %_7.not.i119.i.i.i.i = icmp ugt i64 %end.sroa.0.0.lcssa.i.i.i.i.i, %_6.sroa.4.0.copyload
  %or.cond.i120.i.i.i.i = or i1 %_13.i118.i.i.i.i, %_7.not.i119.i.i.i.i
  br i1 %or.cond.i120.i.i.i.i, label %bb6.i125.i.i.i.i, label %_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit126.i.i.i.i, !prof !70

bb6.i125.i.i.i.i:                                 ; preds = %bb28.i.i.i.i
; call core::slice::index::slice_index_fail
  call void @_RNvNtNtCs9l4wcBNbII5_4core5slice5index16slice_index_fail(i64 noundef %start1.sroa.0.0.lcssa.i.i.i.i.i, i64 noundef %end.sroa.0.0.lcssa.i.i.i.i.i, i64 noundef range(i64 0, -9223372036854775808) %_6.sroa.4.0.copyload, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_ad438f04501d3850fe5717f2a4e651e9) #20, !noalias !191
  unreachable

_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit126.i.i.i.i: ; preds = %bb28.i.i.i.i
  %_14.i123.i.i.i.i = sub nuw nsw i64 %end.sroa.0.0.lcssa.i.i.i.i.i, %start1.sroa.0.0.lcssa.i.i.i.i.i
  %_16.i124.i.i.i.i = getelementptr inbounds nuw i8, ptr %_6.sroa.0.0.copyload, i64 %start1.sroa.0.0.lcssa.i.i.i.i.i
  %_40.sroa.0.0.copyload.i.i.i.i = load i64, ptr %15, align 8, !noalias !171
  %_40.sroa.4.0.copyload.i.i.i.i = load i64, ptr %_78.sroa.6.0..sroa_idx57.i.i.i.i, align 8, !noalias !171
  %_40.sroa.5.0.copyload.i.i.i.i = load i8, ptr %_78.sroa.7.0..sroa_idx61.i.i.i.i, align 8, !noalias !171
  %_82.i.i.i.i = load i64, ptr %_79.sroa.5.0.result.sroa_idx.i.i.i.i, align 8, !noalias !171, !noundef !57
  %_4.i127.i.i.i.i = trunc nuw i8 %_40.sroa.5.0.copyload.i.i.i.i to i1
  %spec.select.i128.i.i.i.i = select i1 %_4.i127.i.i.i.i, i64 %_82.i.i.i.i, i64 %_6.sroa.4.0.copyload
  %_13.i131.i.i.i.i = icmp ult i64 %_40.sroa.4.0.copyload.i.i.i.i, %_40.sroa.0.0.copyload.i.i.i.i
  %_7.not.i132.i.i.i.i = icmp ugt i64 %_40.sroa.4.0.copyload.i.i.i.i, %spec.select.i128.i.i.i.i
  %or.cond.i133.i.i.i.i = select i1 %_13.i131.i.i.i.i, i1 true, i1 %_7.not.i132.i.i.i.i, !prof !70
  br i1 %or.cond.i133.i.i.i.i, label %bb6.i138.i.i.i.i, label %_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit139.i.i.i.i, !prof !70

bb6.i138.i.i.i.i:                                 ; preds = %_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit126.i.i.i.i
; call core::slice::index::slice_index_fail
  call void @_RNvNtNtCs9l4wcBNbII5_4core5slice5index16slice_index_fail(i64 noundef %_40.sroa.0.0.copyload.i.i.i.i, i64 noundef %_40.sroa.4.0.copyload.i.i.i.i, i64 noundef %spec.select.i128.i.i.i.i, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_ad438f04501d3850fe5717f2a4e651e9) #20, !noalias !196
  unreachable

_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit139.i.i.i.i: ; preds = %_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit126.i.i.i.i
  %_83.i.i.i.i = load ptr, ptr %_79.sroa.4.0.result.sroa_idx.i.i.i.i, align 8, !noalias !171, !nonnull !57, !noundef !57
  %spec.select4.i135.i.i.i.i = select i1 %_4.i127.i.i.i.i, ptr %_83.i.i.i.i, ptr %_6.sroa.0.0.copyload
  %_14.i136.i.i.i.i = sub nuw i64 %_40.sroa.4.0.copyload.i.i.i.i, %_40.sroa.0.0.copyload.i.i.i.i
  %_16.i137.i.i.i.i = getelementptr inbounds nuw i8, ptr %spec.select4.i135.i.i.i.i, i64 %_40.sroa.0.0.copyload.i.i.i.i
  %_84.not.i.i.i.i = icmp eq i64 %_14.i123.i.i.i.i, %_14.i136.i.i.i.i
  br i1 %_84.not.i.i.i.i, label %bb69.i.i.i.i, label %bb39.i.i.i.i

bb75.i.i.i.i:                                     ; preds = %_RNCNvCscgZyRT41Cnx_20mime_type_validation18parse_content_type0B3_.exit.i.i.i.i
  %_91.i.i.i.i = icmp samesign ugt i64 %_14.i110.i.i.i.i, 15
  br i1 %_91.i.i.i.i, label %bb76.i.i.i.i, label %bb78.i.i.i.i

bb78.i.i.i.i:                                     ; preds = %bb75.i.i.i.i
  call void @llvm.experimental.noalias.scope.decl(metadata !201)
  call void @llvm.experimental.noalias.scope.decl(metadata !204)
  %_6.not.i145.i.i.i.i30 = icmp eq i64 %_14.i110.i.i.i.i, 0
  br i1 %_6.not.i145.i.i.i.i30, label %bb41.i.i.i.i, label %bb3.i148.i.i.i.i

bb1.i140.i.i.i.i:                                 ; preds = %bb3.i148.i.i.i.i
  %rest_a.0.i149.i.i.i.i = getelementptr inbounds nuw i8, ptr %self.sroa.0.0.i144.i.i.i.i33, i64 1
  %rest_b.0.i151.i.i.i.i = getelementptr inbounds nuw i8, ptr %other.sroa.0.0.i142.i.i.i.i32, i64 1
  %rest_b.1.i152.i.i.i.i = add nsw i64 %other.sroa.5.0.i141.i.i.i.i31, -1
  %_6.not.i145.i.i.i.i = icmp eq i64 %rest_b.1.i152.i.i.i.i, 0
  br i1 %_6.not.i145.i.i.i.i, label %bb41.i.i.i.i, label %bb3.i148.i.i.i.i

bb3.i148.i.i.i.i:                                 ; preds = %bb78.i.i.i.i, %bb1.i140.i.i.i.i
  %self.sroa.0.0.i144.i.i.i.i33 = phi ptr [ %rest_a.0.i149.i.i.i.i, %bb1.i140.i.i.i.i ], [ %_16.i111.i.i.i.i, %bb78.i.i.i.i ]
  %other.sroa.0.0.i142.i.i.i.i32 = phi ptr [ %rest_b.0.i151.i.i.i.i, %bb1.i140.i.i.i.i ], [ %_5.sroa.0.0.copyload.i.i.i.i.i.i, %bb78.i.i.i.i ]
  %other.sroa.5.0.i141.i.i.i.i31 = phi i64 [ %rest_b.1.i152.i.i.i.i, %bb1.i140.i.i.i.i ], [ %_14.i110.i.i.i.i, %bb78.i.i.i.i ]
  %_14.i153.i.i.i.i = load i8, ptr %self.sroa.0.0.i144.i.i.i.i33, align 1, !alias.scope !206, !noalias !152, !noundef !57
  %64 = add i8 %_14.i153.i.i.i.i, -65
  %65 = icmp ult i8 %64, 26
  %66 = select i1 %65, i8 32, i8 0
  %_18.sroa.0.0.i154.i.i.i.i = or i8 %66, %_14.i153.i.i.i.i
  %_19.i155.i.i.i.i = load i8, ptr %other.sroa.0.0.i142.i.i.i.i32, align 1, !alias.scope !204, !noalias !173, !noundef !57
  %67 = add i8 %_19.i155.i.i.i.i, -65
  %68 = icmp ult i8 %67, 26
  %69 = select i1 %68, i8 32, i8 0
  %_23.sroa.0.0.i156.i.i.i.i = or i8 %69, %_19.i155.i.i.i.i
  %_11.i157.i.i.i.i = icmp eq i8 %_18.sroa.0.0.i154.i.i.i.i, %_23.sroa.0.0.i156.i.i.i.i
  br i1 %_11.i157.i.i.i.i, label %bb1.i140.i.i.i.i, label %bb39.i.i.i.i

bb76.i.i.i.i:                                     ; preds = %bb75.i.i.i.i
; call <[u8]>::eq_ignore_ascii_case_chunks::<16>
  %70 = call fastcc noundef zeroext i1 @_RINvMNtNtCs9l4wcBNbII5_4core5slice5asciiSh27eq_ignore_ascii_case_chunksKj10_ECscgZyRT41Cnx_20mime_type_validation(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %_16.i111.i.i.i.i, i64 noundef %_14.i110.i.i.i.i, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %_5.sroa.0.0.copyload.i.i.i.i.i.i, i64 noundef %_14.i110.i.i.i.i) #19, !noalias !173
  br i1 %70, label %bb41.i.i.i.i, label %bb39.i.i.i.i

bb69.i.i.i.i:                                     ; preds = %_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit139.i.i.i.i
  %_87.i.i.i.i = icmp ugt i64 %_14.i123.i.i.i.i, 15
  br i1 %_87.i.i.i.i, label %bb70.i.i.i.i, label %bb72.i.i.i.i

bb72.i.i.i.i:                                     ; preds = %bb69.i.i.i.i
  call void @llvm.experimental.noalias.scope.decl(metadata !207)
  call void @llvm.experimental.noalias.scope.decl(metadata !210)
  %_6.not.i164.i.i.i.i26 = icmp eq i64 %_14.i123.i.i.i.i, 0
  br i1 %_6.not.i164.i.i.i.i26, label %bb41.i.i.i.i, label %bb3.i167.i.i.i.i

bb1.i159.i.i.i.i:                                 ; preds = %bb3.i167.i.i.i.i
  %rest_a.0.i168.i.i.i.i = getelementptr inbounds nuw i8, ptr %self.sroa.0.0.i163.i.i.i.i29, i64 1
  %rest_b.0.i170.i.i.i.i = getelementptr inbounds nuw i8, ptr %other.sroa.0.0.i161.i.i.i.i28, i64 1
  %rest_b.1.i171.i.i.i.i = add nsw i64 %other.sroa.5.0.i160.i.i.i.i27, -1
  %_6.not.i164.i.i.i.i = icmp eq i64 %rest_b.1.i171.i.i.i.i, 0
  br i1 %_6.not.i164.i.i.i.i, label %bb41.i.i.i.i, label %bb3.i167.i.i.i.i

bb3.i167.i.i.i.i:                                 ; preds = %bb72.i.i.i.i, %bb1.i159.i.i.i.i
  %self.sroa.0.0.i163.i.i.i.i29 = phi ptr [ %rest_a.0.i168.i.i.i.i, %bb1.i159.i.i.i.i ], [ %_16.i124.i.i.i.i, %bb72.i.i.i.i ]
  %other.sroa.0.0.i161.i.i.i.i28 = phi ptr [ %rest_b.0.i170.i.i.i.i, %bb1.i159.i.i.i.i ], [ %_16.i137.i.i.i.i, %bb72.i.i.i.i ]
  %other.sroa.5.0.i160.i.i.i.i27 = phi i64 [ %rest_b.1.i171.i.i.i.i, %bb1.i159.i.i.i.i ], [ %_14.i123.i.i.i.i, %bb72.i.i.i.i ]
  %_14.i172.i.i.i.i = load i8, ptr %self.sroa.0.0.i163.i.i.i.i29, align 1, !alias.scope !212, !noalias !152, !noundef !57
  %71 = add i8 %_14.i172.i.i.i.i, -65
  %72 = icmp ult i8 %71, 26
  %73 = select i1 %72, i8 32, i8 0
  %_18.sroa.0.0.i173.i.i.i.i = or i8 %73, %_14.i172.i.i.i.i
  %_19.i174.i.i.i.i = load i8, ptr %other.sroa.0.0.i161.i.i.i.i28, align 1, !alias.scope !210, !noalias !173, !noundef !57
  %74 = add i8 %_19.i174.i.i.i.i, -65
  %75 = icmp ult i8 %74, 26
  %76 = select i1 %75, i8 32, i8 0
  %_23.sroa.0.0.i175.i.i.i.i = or i8 %76, %_19.i174.i.i.i.i
  %_11.i176.i.i.i.i = icmp eq i8 %_18.sroa.0.0.i173.i.i.i.i, %_23.sroa.0.0.i175.i.i.i.i
  br i1 %_11.i176.i.i.i.i, label %bb1.i159.i.i.i.i, label %bb39.i.i.i.i

bb70.i.i.i.i:                                     ; preds = %bb69.i.i.i.i
; call <[u8]>::eq_ignore_ascii_case_chunks::<16>
  %77 = call fastcc noundef zeroext i1 @_RINvMNtNtCs9l4wcBNbII5_4core5slice5asciiSh27eq_ignore_ascii_case_chunksKj10_ECscgZyRT41Cnx_20mime_type_validation(ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %_16.i124.i.i.i.i, i64 noundef %_14.i123.i.i.i.i, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %_16.i137.i.i.i.i, i64 noundef %_14.i123.i.i.i.i) #19, !noalias !173
  br i1 %77, label %bb41.i.i.i.i, label %bb39.i.i.i.i

bb39.i.i.i.i:                                     ; preds = %bb3.i167.i.i.i.i, %bb3.i148.i.i.i.i, %bb70.i.i.i.i, %bb76.i.i.i.i, %_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit139.i.i.i.i, %_RNCNvCscgZyRT41Cnx_20mime_type_validation18parse_content_type0B3_.exit.i.i.i.i
  %_0.i.i178.i.i.i.i = call noundef zeroext i1 @"net$mime_type_internal$cxxbridge1$205$ContentTypeState$had_charset"(ptr noundef nonnull %state) #19, !noalias !173
  %had.sroa.0.1.i.i.i.i = zext i1 %_0.i.i178.i.i.i.i to i8
  store i8 1, ptr %10, align 8, !noalias !171
  call void @llvm.lifetime.start.p0(ptr nonnull %_49.i.i.i.i), !noalias !171
  call void @llvm.lifetime.start.p0(ptr nonnull %_50.i.i.i.i), !noalias !171
  store i64 %start1.sroa.0.0.lcssa.i.i.i.i.i, ptr %_50.i.i.i.i, align 8, !noalias !171
  %mime.sroa.7.0._50.sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_50.i.i.i.i, i64 8
  store i64 %end.sroa.0.0.lcssa.i.i.i.i.i, ptr %mime.sroa.7.0._50.sroa_idx.i.i.i.i, align 8, !noalias !171
  %mime.sroa.8.0._50.sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %_50.i.i.i.i, i64 16
  store i64 0, ptr %mime.sroa.8.0._50.sroa_idx.i.i.i.i, align 8, !noalias !171
  %78 = getelementptr inbounds nuw i8, ptr %_50.i.i.i.i, i64 24
  store i8 0, ptr %78, align 8, !noalias !171
; call mime_type_validation::mime_type_parser::output_value
  call fastcc void @_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser12output_value(ptr noalias nofree noundef align 8 captures(address) dereferenceable(24) %_49.i.i.i.i, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %_6.sroa.0.0.copyload, i64 noundef range(i64 0, -9223372036854775808) %_6.sroa.4.0.copyload, ptr noalias nofree noundef readonly align 8 captures(none) dereferenceable(32) %_50.i.i.i.i, ptr noalias nofree noundef align 8 dereferenceable(24) %result.i.i.i.i, i1 noundef zeroext false, i1 noundef zeroext true) #19, !noalias !173
  call void @llvm.lifetime.end.p0(ptr nonnull %_50.i.i.i.i), !noalias !171
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %11, ptr noundef nonnull align 8 dereferenceable(24) %_49.i.i.i.i, i64 24, i1 false), !noalias !171
  call void @llvm.lifetime.end.p0(ptr nonnull %_49.i.i.i.i), !noalias !171
  br label %bb41.i.i.i.i

bb41.i.i.i.i:                                     ; preds = %bb1.i159.i.i.i.i, %bb1.i140.i.i.i.i, %bb72.i.i.i.i, %bb78.i.i.i.i, %bb39.i.i.i.i, %bb70.i.i.i.i, %bb76.i.i.i.i
  %had.sroa.0.2.i.i.i.i = phi i8 [ %had.sroa.0.1.i.i.i.i, %bb39.i.i.i.i ], [ 0, %bb76.i.i.i.i ], [ 0, %bb70.i.i.i.i ], [ 0, %bb78.i.i.i.i ], [ 0, %bb72.i.i.i.i ], [ 0, %bb1.i140.i.i.i.i ], [ 0, %bb1.i159.i.i.i.i ]
  %.not71.i.i.i.i = icmp eq i8 %charset.sroa.2.1.i.i.i.i, 2
  br i1 %.not71.i.i.i.i, label %bb45.i.i.i.i, label %bb42.i.i.i.i

bb42.i.i.i.i:                                     ; preds = %bb41.i.i.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %value2.i.i.i.i), !noalias !171
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %value2.i.i.i.i, ptr noundef nonnull align 8 dereferenceable(24) %charset.sroa.0.i.i.i.i, i64 24, i1 false), !noalias !171
  %charset.sroa.2.0.value2.sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %value2.i.i.i.i, i64 24
  store i8 %charset.sroa.2.1.i.i.i.i, ptr %charset.sroa.2.0.value2.sroa_idx.i.i.i.i, align 8, !noalias !171
  %charset.sroa.8.0.value2.sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %value2.i.i.i.i, i64 25
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(7) %charset.sroa.8.0.value2.sroa_idx.i.i.i.i, ptr noundef nonnull align 1 dereferenceable(7) %charset.sroa.8.i.i.i.i, i64 7, i1 false), !noalias !171
  store i8 1, ptr %12, align 1, !noalias !171
  call void @llvm.lifetime.start.p0(ptr nonnull %_54.i.i.i.i), !noalias !171
; call mime_type_validation::mime_type_parser::output_value
  call fastcc void @_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser12output_value(ptr noalias nofree noundef align 8 captures(address) dereferenceable(24) %_54.i.i.i.i, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %_6.sroa.0.0.copyload, i64 noundef range(i64 0, -9223372036854775808) %_6.sroa.4.0.copyload, ptr noalias nofree noundef readonly align 8 captures(none) dereferenceable(32) %value2.i.i.i.i, ptr noalias nofree noundef align 8 dereferenceable(24) %result.i.i.i.i, i1 noundef zeroext true, i1 noundef zeroext true) #19, !noalias !173
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %13, ptr noundef nonnull align 8 dereferenceable(24) %_54.i.i.i.i, i64 24, i1 false), !noalias !171
  call void @llvm.lifetime.end.p0(ptr nonnull %_54.i.i.i.i), !noalias !171
  call void @llvm.lifetime.end.p0(ptr nonnull %value2.i.i.i.i), !noalias !171
  %plan.sroa.28.0.copyload.pre.i.i.i = load i8, ptr %12, align 1, !noalias !213
  br label %bb45.i.i.i.i

bb45.i.i.i.i:                                     ; preds = %bb42.i.i.i.i, %bb41.i.i.i.i
  %plan.sroa.28.0.copyload.i.i.i = phi i8 [ %plan.sroa.28.0.copyload.pre.i.i.i, %bb42.i.i.i.i ], [ %had.sroa.0.2.i.i.i.i, %bb41.i.i.i.i ]
  %plan.sroa.0.0.copyload.i.i.i = load i64, ptr %result.i.i.i.i, align 8, !noalias !213
  %plan.sroa.6.0.copyload.i.i.i = load ptr, ptr %_79.sroa.4.0.result.sroa_idx.i.i.i.i, align 8, !noalias !213
  %plan.sroa.8.0.copyload.i.i.i = load i64, ptr %_79.sroa.5.0.result.sroa_idx.i.i.i.i, align 8, !noalias !213
  %79 = load <2 x i64>, ptr %11, align 8, !noalias !213
  %plan.sroa.14.0.result.i.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %result.i.i.i.i, i64 40
  %plan.sroa.14.0.copyload.i.i.i = load i8, ptr %plan.sroa.14.0.result.i.sroa_idx.i.i.i, align 8, !noalias !213
  %80 = load <2 x i64>, ptr %13, align 8, !noalias !213
  %plan.sroa.19.0.result.i.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %result.i.i.i.i, i64 64
  %plan.sroa.19.0.copyload.i.i.i = load i8, ptr %plan.sroa.19.0.result.i.sroa_idx.i.i.i, align 8, !noalias !213
  %81 = load <2 x i64>, ptr %15, align 8, !noalias !213
  %plan.sroa.24.0.copyload.i.i.i = load i8, ptr %_78.sroa.7.0..sroa_idx61.i.i.i.i, align 8, !noalias !213
  %plan.sroa.256.0.copyload.i.i.i = load i8, ptr %10, align 8, !noalias !213
  %plan.sroa.31.0.copyload.i.i.i = load i8, ptr %14, align 2, !noalias !213
  call void @llvm.lifetime.end.p0(ptr nonnull %result.i.i.i.i), !noalias !171
  br label %_RNCNvNvNtCscgZyRT41Cnx_20mime_type_validation3ffi1__20___parse_content_type0B7_.exit

_RNCNvNvNtCscgZyRT41Cnx_20mime_type_validation3ffi1__20___parse_content_type0B7_.exit: ; preds = %bb4.i.i.i.i.i, %bb6.i.i.i.i.i, %bb16.i.i.i.i.i, %bb53.i.i.i.i, %bb45.i.i.i.i
  %plan.sroa.14.0.i.i.i = phi i8 [ 0, %bb6.i.i.i.i.i ], [ %plan.sroa.14.0.copyload.i.i.i, %bb45.i.i.i.i ], [ 0, %bb16.i.i.i.i.i ], [ 0, %bb53.i.i.i.i ], [ 0, %bb4.i.i.i.i.i ]
  %plan.sroa.19.0.i.i.i = phi i8 [ 0, %bb6.i.i.i.i.i ], [ %plan.sroa.19.0.copyload.i.i.i, %bb45.i.i.i.i ], [ 0, %bb16.i.i.i.i.i ], [ 0, %bb53.i.i.i.i ], [ 0, %bb4.i.i.i.i.i ]
  %plan.sroa.24.0.i.i.i = phi i8 [ 0, %bb6.i.i.i.i.i ], [ %plan.sroa.24.0.copyload.i.i.i, %bb45.i.i.i.i ], [ 0, %bb16.i.i.i.i.i ], [ 0, %bb53.i.i.i.i ], [ 0, %bb4.i.i.i.i.i ]
  %plan.sroa.31.0.i.i.i = phi i8 [ 0, %bb6.i.i.i.i.i ], [ %plan.sroa.31.0.copyload.i.i.i, %bb45.i.i.i.i ], [ 0, %bb16.i.i.i.i.i ], [ 0, %bb53.i.i.i.i ], [ 0, %bb4.i.i.i.i.i ]
  %plan.sroa.28.0.i.i.i = phi i8 [ 0, %bb6.i.i.i.i.i ], [ %plan.sroa.28.0.copyload.i.i.i, %bb45.i.i.i.i ], [ 0, %bb16.i.i.i.i.i ], [ 0, %bb53.i.i.i.i ], [ 0, %bb4.i.i.i.i.i ]
  %plan.sroa.256.0.i.i.i = phi i8 [ 0, %bb6.i.i.i.i.i ], [ %plan.sroa.256.0.copyload.i.i.i, %bb45.i.i.i.i ], [ 0, %bb16.i.i.i.i.i ], [ 0, %bb53.i.i.i.i ], [ 0, %bb4.i.i.i.i.i ]
  %plan.sroa.8.0.i.i.i = phi i64 [ 0, %bb6.i.i.i.i.i ], [ %plan.sroa.8.0.copyload.i.i.i, %bb45.i.i.i.i ], [ 0, %bb16.i.i.i.i.i ], [ 0, %bb53.i.i.i.i ], [ 0, %bb4.i.i.i.i.i ]
  %plan.sroa.6.0.i.i.i = phi ptr [ inttoptr (i64 1 to ptr), %bb6.i.i.i.i.i ], [ %plan.sroa.6.0.copyload.i.i.i, %bb45.i.i.i.i ], [ inttoptr (i64 1 to ptr), %bb16.i.i.i.i.i ], [ inttoptr (i64 1 to ptr), %bb53.i.i.i.i ], [ inttoptr (i64 1 to ptr), %bb4.i.i.i.i.i ]
  %plan.sroa.0.0.i.i.i = phi i64 [ 0, %bb6.i.i.i.i.i ], [ %plan.sroa.0.0.copyload.i.i.i, %bb45.i.i.i.i ], [ 0, %bb16.i.i.i.i.i ], [ 0, %bb53.i.i.i.i ], [ 0, %bb4.i.i.i.i.i ]
  %82 = phi <2 x i64> [ zeroinitializer, %bb6.i.i.i.i.i ], [ %79, %bb45.i.i.i.i ], [ zeroinitializer, %bb16.i.i.i.i.i ], [ zeroinitializer, %bb53.i.i.i.i ], [ zeroinitializer, %bb4.i.i.i.i.i ]
  %83 = phi <2 x i64> [ zeroinitializer, %bb6.i.i.i.i.i ], [ %80, %bb45.i.i.i.i ], [ zeroinitializer, %bb16.i.i.i.i.i ], [ zeroinitializer, %bb53.i.i.i.i ], [ zeroinitializer, %bb4.i.i.i.i.i ]
  %84 = phi <2 x i64> [ zeroinitializer, %bb6.i.i.i.i.i ], [ %81, %bb45.i.i.i.i ], [ zeroinitializer, %bb16.i.i.i.i.i ], [ zeroinitializer, %bb53.i.i.i.i ], [ zeroinitializer, %bb4.i.i.i.i.i ]
  call void @llvm.lifetime.end.p0(ptr nonnull %boundary.sroa.0.i.i.i.i)
  call void @llvm.lifetime.end.p0(ptr nonnull %boundary.sroa.7.i.i.i.i)
  call void @llvm.lifetime.end.p0(ptr nonnull %charset.sroa.0.i.i.i.i)
  call void @llvm.lifetime.end.p0(ptr nonnull %charset.sroa.8.i.i.i.i)
  call void @llvm.lifetime.end.p0(ptr nonnull %_13.i.i.i.i), !noalias !164
  store i8 %plan.sroa.256.0.i.i.i, ptr %__return, align 8, !noalias !152
  %_3.sroa.41.0._2.sroa_idx.i = getelementptr inbounds nuw i8, ptr %__return, i64 8
  store <2 x i64> %82, ptr %_3.sroa.41.0._2.sroa_idx.i, align 8, !noalias !152
  %_3.sroa.6.0._2.sroa_idx.i = getelementptr inbounds nuw i8, ptr %__return, i64 24
  store i8 %plan.sroa.14.0.i.i.i, ptr %_3.sroa.6.0._2.sroa_idx.i, align 8, !noalias !152
  %_3.sroa.72.0._2.sroa_idx.i = getelementptr inbounds nuw i8, ptr %__return, i64 32
  store i8 %plan.sroa.28.0.i.i.i, ptr %_3.sroa.72.0._2.sroa_idx.i, align 8, !noalias !152
  %_3.sroa.83.0._2.sroa_idx.i = getelementptr inbounds nuw i8, ptr %__return, i64 40
  store <2 x i64> %83, ptr %_3.sroa.83.0._2.sroa_idx.i, align 8, !noalias !152
  %_3.sroa.10.0._2.sroa_idx.i = getelementptr inbounds nuw i8, ptr %__return, i64 56
  store i8 %plan.sroa.19.0.i.i.i, ptr %_3.sroa.10.0._2.sroa_idx.i, align 8, !noalias !152
  %_3.sroa.114.0._2.sroa_idx.i = getelementptr inbounds nuw i8, ptr %__return, i64 64
  store i8 %plan.sroa.31.0.i.i.i, ptr %_3.sroa.114.0._2.sroa_idx.i, align 8, !noalias !152
  %_3.sroa.125.0._2.sroa_idx.i = getelementptr inbounds nuw i8, ptr %__return, i64 72
  store <2 x i64> %84, ptr %_3.sroa.125.0._2.sroa_idx.i, align 8, !noalias !152
  %_3.sroa.14.0._2.sroa_idx.i = getelementptr inbounds nuw i8, ptr %__return, i64 88
  store i8 %plan.sroa.24.0.i.i.i, ptr %_3.sroa.14.0._2.sroa_idx.i, align 8, !noalias !152
  %_3.sroa.156.0._2.sroa_idx.i = getelementptr inbounds nuw i8, ptr %__return, i64 96
  store i64 %plan.sroa.0.0.i.i.i, ptr %_3.sroa.156.0._2.sroa_idx.i, align 8, !noalias !152
  %_3.sroa.16.0._2.sroa_idx.i = getelementptr inbounds nuw i8, ptr %__return, i64 104
  store ptr %plan.sroa.6.0.i.i.i, ptr %_3.sroa.16.0._2.sroa_idx.i, align 8, !noalias !152
  %_3.sroa.17.0._2.sroa_idx.i = getelementptr inbounds nuw i8, ptr %__return, i64 112
  store i64 %plan.sroa.8.0.i.i.i, ptr %_3.sroa.17.0._2.sroa_idx.i, align 8, !noalias !152
  ret void
}

; Function Attrs: nounwind uwtable
define void @"net$mime_type_internal$cxxbridge1$205$parse_mime"(ptr noalias nofree noundef readonly align 8 captures(none) dead_on_return dereferenceable(16) %input, i1 noundef zeroext %want_parameters, ptr nofree noundef writeonly captures(none) %__return) unnamed_addr #3 personality ptr @__CxxFrameHandler3 !guid !214 {
start:
  %value1.i.i.i = alloca [24 x i8], align 16
  %_13.i.i.i = alloca [56 x i8], align 16
  %iter.i.i.i = alloca [24 x i8], align 8
  %result.i.i.i = alloca [48 x i8], align 8
  %parameters.i.i = alloca [24 x i8], align 8
  %_4.sroa.7 = alloca [31 x i8], align 1
  call void @llvm.lifetime.start.p0(ptr nonnull %_4.sroa.7)
  %_9.0 = load ptr, ptr %input, align 8, !nonnull !57, !noundef !57
  %0 = getelementptr inbounds nuw i8, ptr %input, i64 8
  %_9.1 = load i64, ptr %0, align 8, !noundef !57
  %_7.not.i = icmp slt i64 %_9.1, 0
  br i1 %_7.not.i, label %bb5.i, label %_RNvNvNtNtCs9l4wcBNbII5_4core5slice3raw14from_raw_parts18precondition_check.exit, !prof !69

bb5.i:                                            ; preds = %start
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_a28e8c8fd5088943a8b5d44af697ff83, ptr noundef nonnull inttoptr (i64 559 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_7d52e238cba565908982a5cea838db34) #20
  unreachable

_RNvNvNtNtCs9l4wcBNbII5_4core5slice3raw14from_raw_parts18precondition_check.exit: ; preds = %start
  tail call void @llvm.experimental.noalias.scope.decl(metadata !215)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !218)
  call void @llvm.lifetime.start.p0(ptr nonnull %parameters.i.i), !noalias !221
  store i64 0, ptr %parameters.i.i, align 8, !noalias !223
  %1 = getelementptr inbounds nuw i8, ptr %parameters.i.i, i64 8
  store ptr inttoptr (i64 8 to ptr), ptr %1, align 8, !noalias !223
  %2 = getelementptr inbounds nuw i8, ptr %parameters.i.i, i64 16
  store i64 0, ptr %2, align 8, !noalias !223
  tail call void @llvm.experimental.noalias.scope.decl(metadata !225)
  call void @llvm.lifetime.start.p0(ptr nonnull %_13.i.i.i), !noalias !223
  %_317.not.i.i.i.i = icmp eq i64 %_9.1, 0
  br i1 %_317.not.i.i.i.i, label %bb6.i.i.i.i, label %bb3.i.i.i.i

bb6.i.i.i.i:                                      ; preds = %bb3.i.i.i.i, %_RNvNvNtNtCs9l4wcBNbII5_4core5slice3raw14from_raw_parts18precondition_check.exit
  %start1.sroa.0.0.lcssa.i.i.i.i = phi i64 [ 0, %_RNvNvNtNtCs9l4wcBNbII5_4core5slice3raw14from_raw_parts18precondition_check.exit ], [ %start1.sroa.0.018.i.i.i.i, %bb3.i.i.i.i ]
  %_1220.i.i.i.i = icmp samesign ult i64 %start1.sroa.0.0.lcssa.i.i.i.i, %_9.1
  br i1 %_1220.i.i.i.i, label %bb9.i.i.i.i, label %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.thread.i.i

bb3.i.i.i.i:                                      ; preds = %_RNvNvNtNtCs9l4wcBNbII5_4core5slice3raw14from_raw_parts18precondition_check.exit, %bb4.i.i.i.i
  %start1.sroa.0.018.i.i.i.i = phi i64 [ %_9.0.i.i.i.i, %bb4.i.i.i.i ], [ 0, %_RNvNvNtNtCs9l4wcBNbII5_4core5slice3raw14from_raw_parts18precondition_check.exit ]
  %3 = getelementptr inbounds nuw i8, ptr %_9.0, i64 %start1.sroa.0.018.i.i.i.i
  %_6.i.i.i.i = load i8, ptr %3, align 1, !alias.scope !228, !noundef !57
  switch i8 %_6.i.i.i.i, label %bb6.i.i.i.i [
    i8 32, label %bb4.i.i.i.i
    i8 9, label %bb4.i.i.i.i
  ]

bb4.i.i.i.i:                                      ; preds = %bb3.i.i.i.i, %bb3.i.i.i.i
  %_9.0.i.i.i.i = add nuw nsw i64 %start1.sroa.0.018.i.i.i.i, 1
  %exitcond.not.i.i.i.i = icmp eq i64 %_9.0.i.i.i.i, %_9.1
  br i1 %exitcond.not.i.i.i.i, label %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.thread.i.i, label %bb3.i.i.i.i

bb16.i.i.i.i:                                     ; preds = %bb14.i.i.i.i, %bb9.i.i.i.i, %bb9.i.i.i.i, %bb9.i.i.i.i, %bb9.i.i.i.i
  %slash.sroa.0.0.lcssa.i.i.i.i = phi i1 [ %5, %bb14.i.i.i.i ], [ %slash.sroa.0.021.i.i.i.i, %bb9.i.i.i.i ], [ %slash.sroa.0.021.i.i.i.i, %bb9.i.i.i.i ], [ %slash.sroa.0.021.i.i.i.i, %bb9.i.i.i.i ], [ %slash.sroa.0.021.i.i.i.i, %bb9.i.i.i.i ]
  %end.sroa.0.0.lcssa.i.i.i.i = phi i64 [ %_9.1, %bb14.i.i.i.i ], [ %end.sroa.0.022.i.i.i.i, %bb9.i.i.i.i ], [ %end.sroa.0.022.i.i.i.i, %bb9.i.i.i.i ], [ %end.sroa.0.022.i.i.i.i, %bb9.i.i.i.i ], [ %end.sroa.0.022.i.i.i.i, %bb9.i.i.i.i ]
  br i1 %slash.sroa.0.0.lcssa.i.i.i.i, label %bb13.i.i.i, label %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.thread.i.i

bb9.i.i.i.i:                                      ; preds = %bb6.i.i.i.i, %bb14.i.i.i.i
  %end.sroa.0.022.i.i.i.i = phi i64 [ %_23.0.i.i.i.i, %bb14.i.i.i.i ], [ %start1.sroa.0.0.lcssa.i.i.i.i, %bb6.i.i.i.i ]
  %slash.sroa.0.021.i.i.i.i = phi i1 [ %5, %bb14.i.i.i.i ], [ false, %bb6.i.i.i.i ]
  %4 = getelementptr inbounds nuw i8, ptr %_9.0, i64 %end.sroa.0.022.i.i.i.i
  %_14.i.i.i.i = load i8, ptr %4, align 1, !alias.scope !228, !noundef !57
  switch i8 %_14.i.i.i.i, label %bb14.i.i.i.i [
    i8 32, label %bb16.i.i.i.i
    i8 9, label %bb16.i.i.i.i
    i8 59, label %bb16.i.i.i.i
    i8 40, label %bb16.i.i.i.i
  ]

bb14.i.i.i.i:                                     ; preds = %bb9.i.i.i.i
  %_23.0.i.i.i.i = add nuw i64 %end.sroa.0.022.i.i.i.i, 1
  %_19.i.i.i.i = icmp eq i8 %_14.i.i.i.i, 47
  %5 = or i1 %slash.sroa.0.021.i.i.i.i, %_19.i.i.i.i
  %exitcond36.not.i.i.i.i = icmp eq i64 %_23.0.i.i.i.i, %_9.1
  br i1 %exitcond36.not.i.i.i.i, label %bb16.i.i.i.i, label %bb9.i.i.i.i

bb13.i.i.i:                                       ; preds = %bb16.i.i.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %result.i.i.i), !noalias !231
  %6 = getelementptr inbounds nuw i8, ptr %result.i.i.i, i64 24
  store i64 %start1.sroa.0.0.lcssa.i.i.i.i, ptr %6, align 8, !noalias !231
  %mime.sroa.2.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %result.i.i.i, i64 32
  store i64 %end.sroa.0.0.lcssa.i.i.i.i, ptr %mime.sroa.2.0..sroa_idx.i.i.i, align 8, !noalias !231
  %mime.sroa.3.0..sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %result.i.i.i, i64 40
  store i64 0, ptr %mime.sroa.3.0..sroa_idx.i.i.i, align 8, !noalias !231
  store i64 0, ptr %result.i.i.i, align 8, !noalias !231
  %_9.sroa.4.0.result.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %result.i.i.i, i64 8
  store ptr inttoptr (i64 1 to ptr), ptr %_9.sroa.4.0.result.sroa_idx.i.i.i, align 8, !noalias !231
  %_9.sroa.5.0.result.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %result.i.i.i, i64 16
  store i64 0, ptr %_9.sroa.5.0.result.sroa_idx.i.i.i, align 8, !noalias !231
  br i1 %want_parameters, label %bb3.i.i.i, label %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.thread30.i.i

_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.thread30.i.i: ; preds = %bb13.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %result.i.i.i), !noalias !231
  call void @llvm.lifetime.end.p0(ptr nonnull %_13.i.i.i), !noalias !223
  br label %_RNvNvNvNtCscgZyRT41Cnx_20mime_type_validation3ffi1__12___parse_mime12___parse_mime.exit

bb3.i.i.i:                                        ; preds = %bb13.i.i.i
  call void @llvm.lifetime.start.p0(ptr nonnull %iter.i.i.i), !noalias !231
  store ptr %_9.0, ptr %iter.i.i.i, align 8, !noalias !231
  %_10.sroa.2.0.iter.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %iter.i.i.i, i64 8
  store i64 %_9.1, ptr %_10.sroa.2.0.iter.sroa_idx.i.i.i, align 8, !noalias !231
  %_10.sroa.3.0.iter.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %iter.i.i.i, i64 16
  store i64 %end.sroa.0.0.lcssa.i.i.i.i, ptr %_10.sroa.3.0.iter.sroa_idx.i.i.i, align 8, !noalias !231
; call <mime_type_validation::mime_type_parser::Parameters as core::iter::traits::iterator::Iterator>::next
  call fastcc void @_RNvXs_NtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB4_10ParametersNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next(ptr noalias nofree noundef align 8 captures(none) dereferenceable(56) %_13.i.i.i, ptr noalias nofree noundef align 8 dereferenceable(24) %iter.i.i.i) #19, !noalias !234
  %7 = getelementptr inbounds nuw i8, ptr %_13.i.i.i, i64 16
  %8 = load i8, ptr %7, align 16, !range !174, !noalias !231, !noundef !57
  %.not514.i.i.i = icmp eq i8 %8, 2
  br i1 %.not514.i.i.i, label %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.thread44.i.i, label %bb6.lr.ph.i.i.i

_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.thread44.i.i: ; preds = %bb3.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %iter.i.i.i), !noalias !231
  call void @llvm.lifetime.end.p0(ptr nonnull %result.i.i.i), !noalias !231
  call void @llvm.lifetime.end.p0(ptr nonnull %_13.i.i.i), !noalias !223
  br label %_RNvNvNvNtCscgZyRT41Cnx_20mime_type_validation3ffi1__12___parse_mime12___parse_mime.exit

bb6.lr.ph.i.i.i:                                  ; preds = %bb3.i.i.i
  %9 = getelementptr inbounds nuw i8, ptr %_13.i.i.i, i64 24
  %_22.sroa.9.24.value1.sroa_idx.i.i.i = getelementptr inbounds nuw i8, ptr %value1.i.i.i, i64 16
  br label %bb6.i.i.i

bb6.i.i.i:                                        ; preds = %_RNCNvCscgZyRT41Cnx_20mime_type_validation10parse_mime0B3_.exit.i.i.i, %bb6.lr.ph.i.i.i
  %_14.i.i.i16.i.i = phi ptr [ inttoptr (i64 8 to ptr), %bb6.lr.ph.i.i.i ], [ %_14.i.i.i.i.i, %_RNCNvCscgZyRT41Cnx_20mime_type_validation10parse_mime0B3_.exit.i.i.i ]
  %len.i.i.i.i.i = phi i64 [ 0, %bb6.lr.ph.i.i.i ], [ %13, %_RNCNvCscgZyRT41Cnx_20mime_type_validation10parse_mime0B3_.exit.i.i.i ]
  %10 = phi i8 [ %8, %bb6.lr.ph.i.i.i ], [ %14, %_RNCNvCscgZyRT41Cnx_20mime_type_validation10parse_mime0B3_.exit.i.i.i ]
  %11 = load <2 x i64>, ptr %_13.i.i.i, align 16, !noalias !231
  call void @llvm.lifetime.start.p0(ptr nonnull %value1.i.i.i), !noalias !231
; call mime_type_validation::mime_type_parser::output_value
  call fastcc void @_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser12output_value(ptr noalias nofree noundef align 8 captures(address) dereferenceable(24) %value1.i.i.i, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) %_9.0, i64 noundef range(i64 0, -9223372036854775808) %_9.1, ptr noalias nofree noundef readonly align 8 captures(none) dereferenceable(32) %9, ptr noalias nofree noundef align 8 dereferenceable(24) %result.i.i.i, i1 noundef zeroext false, i1 noundef zeroext false) #19, !noalias !234
  %12 = load <2 x i64>, ptr %value1.i.i.i, align 16, !noalias !231
  %_22.sroa.9.24.copyload.i.i.i = load i8, ptr %_22.sroa.9.24.value1.sroa_idx.i.i.i, align 16, !noalias !231
  %self1.i.i.i.i.i = load i64, ptr %parameters.i.i, align 8, !range !56, !noalias !223, !noundef !57
  %_4.i.i.i.i.i = icmp eq i64 %len.i.i.i.i.i, %self1.i.i.i.i.i
  br i1 %_4.i.i.i.i.i, label %bb1.i.i.i.i.i, label %_RNCNvCscgZyRT41Cnx_20mime_type_validation10parse_mime0B3_.exit.i.i.i

bb1.i.i.i.i.i:                                    ; preds = %bb6.i.i.i
; call <alloc::raw_vec::RawVec<mime_type_validation::ffi::Parameter>>::grow_one
  call fastcc void @_RNvMs7_NtCs8tsiLsQ9XHg_5alloc7raw_vecINtB5_6RawVecNtNtCscgZyRT41Cnx_20mime_type_validation3ffi9ParameterE8grow_oneBQ_(ptr noalias nofree noundef nonnull align 8 dereferenceable(24) %parameters.i.i) #19, !noalias !235
  %_14.i.i.i.pre.i.i = load ptr, ptr %1, align 8, !noalias !223
  br label %_RNCNvCscgZyRT41Cnx_20mime_type_validation10parse_mime0B3_.exit.i.i.i

_RNCNvCscgZyRT41Cnx_20mime_type_validation10parse_mime0B3_.exit.i.i.i: ; preds = %bb1.i.i.i.i.i, %bb6.i.i.i
  %_14.i.i.i.i.i = phi ptr [ %_14.i.i.i.pre.i.i, %bb1.i.i.i.i.i ], [ %_14.i.i.i16.i.i, %bb6.i.i.i ]
  %end.i.i.i.i.i = getelementptr inbounds nuw [48 x i8], ptr %_14.i.i.i.i.i, i64 %len.i.i.i.i.i
  store <2 x i64> %11, ptr %end.i.i.i.i.i, align 8, !noalias !236
  %_4.sroa.5.0.end.i.sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %end.i.i.i.i.i, i64 16
  store i8 %10, ptr %_4.sroa.5.0.end.i.sroa_idx.i.i.i.i, align 8, !noalias !236
  %_4.sroa.61.0.end.i.sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %end.i.i.i.i.i, i64 24
  store <2 x i64> %12, ptr %_4.sroa.61.0.end.i.sroa_idx.i.i.i.i, align 8, !noalias !236
  %_4.sroa.8.0.end.i.sroa_idx.i.i.i.i = getelementptr inbounds nuw i8, ptr %end.i.i.i.i.i, i64 40
  store i8 %_22.sroa.9.24.copyload.i.i.i, ptr %_4.sroa.8.0.end.i.sroa_idx.i.i.i.i, align 8, !noalias !236
  %13 = add i64 %len.i.i.i.i.i, 1
  store i64 %13, ptr %2, align 8, !noalias !223
  call void @llvm.lifetime.end.p0(ptr nonnull %value1.i.i.i), !noalias !231
; call <mime_type_validation::mime_type_parser::Parameters as core::iter::traits::iterator::Iterator>::next
  call fastcc void @_RNvXs_NtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB4_10ParametersNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator4next(ptr noalias nofree noundef align 8 captures(none) dereferenceable(56) %_13.i.i.i, ptr noalias nofree noundef align 8 dereferenceable(24) %iter.i.i.i) #19, !noalias !234
  %14 = load i8, ptr %7, align 16, !range !174, !noalias !231, !noundef !57
  %.not5.i.i.i = icmp eq i8 %14, 2
  br i1 %.not5.i.i.i, label %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.i.i, label %bb6.i.i.i

_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.thread.i.i: ; preds = %bb4.i.i.i.i, %bb16.i.i.i.i, %bb6.i.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %_13.i.i.i), !noalias !223
  br label %_RNvNvNvNtCscgZyRT41Cnx_20mime_type_validation3ffi1__12___parse_mime12___parse_mime.exit

_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.i.i: ; preds = %_RNCNvCscgZyRT41Cnx_20mime_type_validation10parse_mime0B3_.exit.i.i.i
  %parsed.sroa.0.0.copyload.pr.pre.i.i = load i64, ptr %result.i.i.i, align 8, !noalias !242
  %parsed.sroa.5.0.copyload.pre.pre.i.i = load ptr, ptr %_9.sroa.4.0.result.sroa_idx.i.i.i, align 8, !noalias !242
  %parsed.sroa.6.0.copyload.pre.pre.i.i = load i64, ptr %_9.sroa.5.0.result.sroa_idx.i.i.i, align 8, !noalias !242
  %parsed.sroa.7.0.copyload.pre.pre.i.i = load i64, ptr %6, align 8, !noalias !242
  %parsed.sroa.8.0.copyload.pre.pre.i.i = load i64, ptr %mime.sroa.2.0..sroa_idx.i.i.i, align 8, !noalias !242
  %parsed.sroa.9.0.copyload.pre.pre.i.i = load i8, ptr %mime.sroa.3.0..sroa_idx.i.i.i, align 8, !noalias !242
  call void @llvm.lifetime.end.p0(ptr nonnull %iter.i.i.i), !noalias !231
  call void @llvm.lifetime.end.p0(ptr nonnull %result.i.i.i), !noalias !231
  call void @llvm.lifetime.end.p0(ptr nonnull %_13.i.i.i), !noalias !223
  %.not.i.i = icmp eq i64 %parsed.sroa.0.0.copyload.pr.pre.i.i, -1
  br i1 %.not.i.i, label %_RNvNvNvNtCscgZyRT41Cnx_20mime_type_validation3ffi1__12___parse_mime12___parse_mime.exit, label %bb5.i.i

bb5.i.i:                                          ; preds = %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.i.i
  br label %_RNvNvNvNtCscgZyRT41Cnx_20mime_type_validation3ffi1__12___parse_mime12___parse_mime.exit

_RNvNvNvNtCscgZyRT41Cnx_20mime_type_validation3ffi1__12___parse_mime12___parse_mime.exit: ; preds = %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.thread30.i.i, %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.thread44.i.i, %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.thread.i.i, %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.i.i, %bb5.i.i
  %15 = phi i8 [ 0, %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.thread.i.i ], [ 0, %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.i.i ], [ 1, %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.thread44.i.i ], [ 1, %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.thread30.i.i ], [ 1, %bb5.i.i ]
  %parsed1.sroa.4.0.i.i = phi i64 [ 0, %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.thread.i.i ], [ 0, %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.i.i ], [ 0, %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.thread44.i.i ], [ 0, %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.thread30.i.i ], [ %parsed.sroa.6.0.copyload.pre.pre.i.i, %bb5.i.i ]
  %parsed1.sroa.3.0.i.i = phi ptr [ inttoptr (i64 1 to ptr), %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.thread.i.i ], [ inttoptr (i64 1 to ptr), %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.i.i ], [ inttoptr (i64 1 to ptr), %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.thread44.i.i ], [ inttoptr (i64 1 to ptr), %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.thread30.i.i ], [ %parsed.sroa.5.0.copyload.pre.pre.i.i, %bb5.i.i ]
  %parsed1.sroa.0.0.i.i = phi i64 [ 0, %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.thread.i.i ], [ 0, %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.i.i ], [ 0, %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.thread44.i.i ], [ 0, %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.thread30.i.i ], [ %parsed.sroa.0.0.copyload.pr.pre.i.i, %bb5.i.i ]
  %parsed2.sroa.0.0.i.i = phi i64 [ 0, %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.thread.i.i ], [ 0, %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.i.i ], [ %start1.sroa.0.0.lcssa.i.i.i.i, %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.thread44.i.i ], [ %start1.sroa.0.0.lcssa.i.i.i.i, %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.thread30.i.i ], [ %parsed.sroa.7.0.copyload.pre.pre.i.i, %bb5.i.i ]
  %parsed3.sroa.0.0.i.i = phi i64 [ 0, %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.thread.i.i ], [ 0, %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.i.i ], [ %end.sroa.0.0.lcssa.i.i.i.i, %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.thread44.i.i ], [ %end.sroa.0.0.lcssa.i.i.i.i, %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.thread30.i.i ], [ %parsed.sroa.8.0.copyload.pre.pre.i.i, %bb5.i.i ]
  %parsed4.sroa.0.0.i.i = phi i8 [ 0, %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.thread.i.i ], [ 0, %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.i.i ], [ 0, %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.thread44.i.i ], [ 0, %_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_.exit.thread30.i.i ], [ %parsed.sroa.9.0.copyload.pre.pre.i.i, %bb5.i.i ]
  %_4.sroa.7.32..sroa_idx = getelementptr inbounds nuw i8, ptr %_4.sroa.7, i64 7
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(24) %_4.sroa.7.32..sroa_idx, ptr noundef nonnull align 8 dereferenceable(24) %parameters.i.i, i64 24, i1 false), !noalias !243
  call void @llvm.lifetime.end.p0(ptr nonnull %parameters.i.i), !noalias !221
  store i8 %15, ptr %__return, align 8
  %_4.sroa.41.0.__return.sroa_idx = getelementptr inbounds nuw i8, ptr %__return, i64 8
  store i64 %parsed2.sroa.0.0.i.i, ptr %_4.sroa.41.0.__return.sroa_idx, align 8
  %_4.sroa.5.0.__return.sroa_idx = getelementptr inbounds nuw i8, ptr %__return, i64 16
  store i64 %parsed3.sroa.0.0.i.i, ptr %_4.sroa.5.0.__return.sroa_idx, align 8
  %_4.sroa.6.0.__return.sroa_idx = getelementptr inbounds nuw i8, ptr %__return, i64 24
  store i8 %parsed4.sroa.0.0.i.i, ptr %_4.sroa.6.0.__return.sroa_idx, align 8
  %_4.sroa.7.0.__return.sroa_idx = getelementptr inbounds nuw i8, ptr %__return, i64 25
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(31) %_4.sroa.7.0.__return.sroa_idx, ptr noundef nonnull align 1 dereferenceable(31) %_4.sroa.7, i64 31, i1 false)
  %_4.sroa.8.0.__return.sroa_idx = getelementptr inbounds nuw i8, ptr %__return, i64 56
  store i64 %parsed1.sroa.0.0.i.i, ptr %_4.sroa.8.0.__return.sroa_idx, align 8
  %_4.sroa.9.0.__return.sroa_idx = getelementptr inbounds nuw i8, ptr %__return, i64 64
  store ptr %parsed1.sroa.3.0.i.i, ptr %_4.sroa.9.0.__return.sroa_idx, align 8
  %_4.sroa.10.0.__return.sroa_idx = getelementptr inbounds nuw i8, ptr %__return, i64 72
  store i64 %parsed1.sroa.4.0.i.i, ptr %_4.sroa.10.0.__return.sroa_idx, align 8
  call void @llvm.lifetime.end.p0(ptr nonnull %_4.sroa.7)
  ret void
}

; Function Attrs: nounwind uwtable
define void @"net$mime_type_internal$cxxbridge1$205$parse_without_parameters"(ptr noalias nofree noundef readonly align 8 captures(none) dead_on_return dereferenceable(16) %input, ptr nofree noundef writeonly captures(none) %__return) unnamed_addr #3 personality ptr @__CxxFrameHandler3 !guid !244 {
start:
  %parsed.sroa.5.i.i = alloca i8, align 8
  %parsed.sroa.17.i.i = alloca i8, align 8
  %_8.0 = load ptr, ptr %input, align 8, !nonnull !57, !noundef !57
  %0 = getelementptr inbounds nuw i8, ptr %input, i64 8
  %_8.1 = load i64, ptr %0, align 8, !noundef !57
  %_7.not.i = icmp slt i64 %_8.1, 0
  br i1 %_7.not.i, label %bb5.i, label %_RNvNvNtNtCs9l4wcBNbII5_4core5slice3raw14from_raw_parts18precondition_check.exit, !prof !69

bb5.i:                                            ; preds = %start
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_a28e8c8fd5088943a8b5d44af697ff83, ptr noundef nonnull inttoptr (i64 559 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_7d52e238cba565908982a5cea838db34) #20
  unreachable

_RNvNvNtNtCs9l4wcBNbII5_4core5slice3raw14from_raw_parts18precondition_check.exit: ; preds = %start
  tail call void @llvm.experimental.noalias.scope.decl(metadata !245)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !248)
  call void @llvm.lifetime.start.p0(ptr nonnull %parsed.sroa.5.i.i)
  call void @llvm.lifetime.start.p0(ptr nonnull %parsed.sroa.17.i.i)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !251)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !254)
  %_41.i.i.i = getelementptr inbounds nuw i8, ptr %_8.0, i64 %_8.1
  %_296.i.i.i.i = icmp samesign eq i64 %_8.1, 0
  br i1 %_296.i.i.i.i, label %_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser18without_parameters.exit.i.i, label %bb23.i.i.i.i

bb23.i.i.i.i:                                     ; preds = %_RNvNvNtNtCs9l4wcBNbII5_4core5slice3raw14from_raw_parts18precondition_check.exit, %bb7.i.i.i.i
  %indvars.iv.i.i.i = phi i64 [ %indvars.iv.next.i.i.i, %bb7.i.i.i.i ], [ 1, %_RNvNvNtNtCs9l4wcBNbII5_4core5slice3raw14from_raw_parts18precondition_check.exit ]
  %i.sroa.0.08.i.i.i.i = phi i64 [ %1, %bb7.i.i.i.i ], [ 0, %_RNvNvNtNtCs9l4wcBNbII5_4core5slice3raw14from_raw_parts18precondition_check.exit ]
  %_3957.i.i.i.i = phi ptr [ %_39.i.i.i.i, %bb7.i.i.i.i ], [ %_8.0, %_RNvNvNtNtCs9l4wcBNbII5_4core5slice3raw14from_raw_parts18precondition_check.exit ]
  %ptr.val.i.i.i.i = load i8, ptr %_3957.i.i.i.i, align 1, !alias.scope !256, !noalias !257, !noundef !57
  %_0.i.i.i.i.i = icmp eq i8 %ptr.val.i.i.i.i, 47
  br i1 %_0.i.i.i.i.i, label %bb6.i.i.i.i, label %bb7.i.i.i.i

bb7.i.i.i.i:                                      ; preds = %bb23.i.i.i.i
  %_39.i.i.i.i = getelementptr inbounds nuw i8, ptr %_3957.i.i.i.i, i64 1
  %1 = add nuw nsw i64 %i.sroa.0.08.i.i.i.i, 1
  %_29.i.i.i.i = icmp eq ptr %_39.i.i.i.i, %_41.i.i.i
  %indvars.iv.next.i.i.i = add nuw i64 %indvars.iv.i.i.i, 1
  br i1 %_29.i.i.i.i, label %_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser18without_parameters.exit.i.i, label %bb23.i.i.i.i

bb6.i.i.i.i:                                      ; preds = %bb23.i.i.i.i
  %cond.i.i.i.i = icmp samesign ult i64 %i.sroa.0.08.i.i.i.i, %_8.1
  br i1 %cond.i.i.i.i, label %bb25.i.i.i, label %bb1.i.i.i.i.i, !prof !71

bb1.i.i.i.i.i:                                    ; preds = %bb6.i.i.i.i
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_64e308ef4babfeb8b6220184de794a17, ptr noundef nonnull inttoptr (i64 443 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_1d1b1e35bb489427b2bdc9752de92226) #20, !noalias !260
  unreachable

bb25.i.i.i:                                       ; preds = %bb6.i.i.i.i
  %_11.0.i.i.i = add nuw nsw i64 %i.sroa.0.08.i.i.i.i, 1
  %_1253.not.i.i.i = icmp eq i64 %i.sroa.0.08.i.i.i.i, 0
  br i1 %_1253.not.i.i.i, label %bb9.i.i.i, label %bb5.i.i.i

bb5.i.i.i:                                        ; preds = %bb25.i.i.i, %bb7.i.i.i
  %top.sroa.0.054.i.i.i = phi i64 [ %_18.0.i.i.i, %bb7.i.i.i ], [ 0, %bb25.i.i.i ]
  %2 = getelementptr inbounds nuw i8, ptr %_8.0, i64 %top.sroa.0.054.i.i.i
  %_15.i.i.i = load i8, ptr %2, align 1, !alias.scope !256, !noundef !57
  switch i8 %_15.i.i.i, label %bb9.i.i.i [
    i8 32, label %bb7.i.i.i
    i8 9, label %bb7.i.i.i
    i8 10, label %bb7.i.i.i
    i8 11, label %bb7.i.i.i
    i8 12, label %bb7.i.i.i
    i8 13, label %bb7.i.i.i
  ]

bb9.i.i.i:                                        ; preds = %bb7.i.i.i, %bb5.i.i.i, %bb25.i.i.i
  %top.sroa.0.0.lcssa.i.i.i = phi i64 [ 0, %bb25.i.i.i ], [ %i.sroa.0.08.i.i.i.i, %bb7.i.i.i ], [ %top.sroa.0.054.i.i.i, %bb5.i.i.i ]
  %_1956.i.i.i = icmp samesign ugt i64 %_8.1, %_11.0.i.i.i
  br i1 %_1956.i.i.i, label %bb11.i.i.i, label %_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit.i.i.i

bb7.i.i.i:                                        ; preds = %bb5.i.i.i, %bb5.i.i.i, %bb5.i.i.i, %bb5.i.i.i, %bb5.i.i.i, %bb5.i.i.i
  %_18.0.i.i.i = add nuw nsw i64 %top.sroa.0.054.i.i.i, 1
  %exitcond.not.i.i.i = icmp eq i64 %_18.0.i.i.i, %i.sroa.0.08.i.i.i.i
  br i1 %exitcond.not.i.i.i, label %bb9.i.i.i, label %bb5.i.i.i

bb11.i.i.i:                                       ; preds = %bb9.i.i.i, %bb14.i.i.i
  %sub.sroa.4.057.i.i.i = phi i64 [ %_25.0.i.i.i, %bb14.i.i.i ], [ %_8.1, %bb9.i.i.i ]
  %_25.0.i.i.i = add nsw i64 %sub.sroa.4.057.i.i.i, -1
  %_26.i.i.i = icmp ult i64 %_25.0.i.i.i, %_8.1
  br i1 %_26.i.i.i, label %bb13.i.i.i, label %panic4.i.i.i

_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit.i.i.i: ; preds = %bb14.i.i.i, %bb13.i.i.i, %bb9.i.i.i
  %sub.sroa.4.0.lcssa.i.i.i = phi i64 [ %_8.1, %bb9.i.i.i ], [ %indvars.iv.i.i.i, %bb14.i.i.i ], [ %sub.sroa.4.057.i.i.i, %bb13.i.i.i ]
  tail call void @llvm.experimental.noalias.scope.decl(metadata !263)
  %3 = icmp eq i64 %i.sroa.0.08.i.i.i.i, %top.sroa.0.0.lcssa.i.i.i
  br i1 %3, label %_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser18without_parameters.exit.i.i, label %bb2.i.i.i.i

bb2.i.i.i.i:                                      ; preds = %_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit.i.i.i
  %_8.i.i.i.i = getelementptr inbounds nuw i8, ptr %_8.0, i64 %i.sroa.0.08.i.i.i.i
  %_16.i.i.i.i = getelementptr inbounds nuw i8, ptr %_8.0, i64 %top.sroa.0.0.lcssa.i.i.i
  br label %bb13.i.i.i.i.i

bb1.i.i15.i.i.i:                                  ; preds = %_RNCNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5token0B5_.exit.i.i.i.i.i
  %_12.i.i.i.i.i = icmp eq ptr %_22.i.i.i.i.i, %_8.i.i.i.i
  br i1 %_12.i.i.i.i.i, label %bb19.i.i.i, label %bb13.i.i.i.i.i

bb13.i.i.i.i.i:                                   ; preds = %bb2.i.i.i.i, %bb1.i.i15.i.i.i
  %_223.i.i.i.i.i28 = phi ptr [ %_16.i.i.i.i, %bb2.i.i.i.i ], [ %_22.i.i.i.i.i, %bb1.i.i15.i.i.i ]
  %_22.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %_223.i.i.i.i.i28, i64 1
  %ptr.val.i.i.i.i.i = load i8, ptr %_223.i.i.i.i.i28, align 1, !alias.scope !266, !noalias !267, !noundef !57
  %4 = add i8 %ptr.val.i.i.i.i.i, -33
  %or.cond.i.i.i.i.i.i = icmp ult i8 %4, 94
  br i1 %or.cond.i.i.i.i.i.i, label %bb2.i.i.i.i.i.i, label %_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser18without_parameters.exit.i.i

bb2.i.i.i.i.i.i:                                  ; preds = %bb13.i.i.i.i.i
; call core::slice::memchr::memchr_aligned
  %5 = tail call { i64, i64 } @_RNvNtNtCs9l4wcBNbII5_4core5slice6memchr14memchr_aligned(i8 noundef %ptr.val.i.i.i.i.i, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_d82b0e089738a8d65da181c674b5c170, i64 noundef 17) #19, !noalias !270
  %6 = extractvalue { i64, i64 } %5, 0
  %7 = trunc nuw i64 %6 to i1
  %8 = extractvalue { i64, i64 } %5, 1
  %cond.i.i.i.i.i.i.i.i = icmp ugt i64 %8, 16
  %or.cond.not.i.i.i.i.i.i.i = select i1 %7, i1 %cond.i.i.i.i.i.i.i.i, i1 false, !prof !271
  br i1 %or.cond.not.i.i.i.i.i.i.i, label %bb1.i.i.i.i.i.i.i.i.i, label %_RNCNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5token0B5_.exit.i.i.i.i.i, !prof !271

bb1.i.i.i.i.i.i.i.i.i:                            ; preds = %bb2.i.i.i.i.i.i
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_64e308ef4babfeb8b6220184de794a17, ptr noundef nonnull inttoptr (i64 443 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_9447f9e979cd1531f5a09d1c25b3ec18) #20, !noalias !270
  unreachable

_RNCNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5token0B5_.exit.i.i.i.i.i: ; preds = %bb2.i.i.i.i.i.i
  br i1 %7, label %_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser18without_parameters.exit.i.i, label %bb1.i.i15.i.i.i

bb13.i.i.i:                                       ; preds = %bb11.i.i.i
  %9 = getelementptr inbounds nuw i8, ptr %_8.0, i64 %_25.0.i.i.i
  %_22.i.i.i = load i8, ptr %9, align 1, !alias.scope !256, !noundef !57
  switch i8 %_22.i.i.i, label %_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit.i.i.i [
    i8 32, label %bb14.i.i.i
    i8 9, label %bb14.i.i.i
    i8 10, label %bb14.i.i.i
    i8 11, label %bb14.i.i.i
    i8 12, label %bb14.i.i.i
    i8 13, label %bb14.i.i.i
  ]

panic4.i.i.i:                                     ; preds = %bb11.i.i.i
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_bounds_check(i64 noundef %_25.0.i.i.i, i64 noundef range(i64 0, -9223372036854775808) %_8.1, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_bf5509759b66626e8f66aa42686e3529) #20, !noalias !272
  unreachable

bb14.i.i.i:                                       ; preds = %bb13.i.i.i, %bb13.i.i.i, %bb13.i.i.i, %bb13.i.i.i, %bb13.i.i.i, %bb13.i.i.i
  %_19.i.i.i = icmp ugt i64 %_25.0.i.i.i, %_11.0.i.i.i
  br i1 %_19.i.i.i, label %bb11.i.i.i, label %_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit.i.i.i

bb19.i.i.i:                                       ; preds = %bb1.i.i15.i.i.i
  %_13.i21.i.i.i = icmp ule i64 %sub.sroa.4.0.lcssa.i.i.i, %i.sroa.0.08.i.i.i.i
  %_7.not.i22.i.i.i = icmp ugt i64 %sub.sroa.4.0.lcssa.i.i.i, %_8.1
  %or.cond.i23.i.i.i = or i1 %_13.i21.i.i.i, %_7.not.i22.i.i.i
  br i1 %or.cond.i23.i.i.i, label %bb6.i27.i.i.i, label %_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit28.i.i.i, !prof !70

bb6.i27.i.i.i:                                    ; preds = %bb19.i.i.i
; call core::slice::index::slice_index_fail
  tail call void @_RNvNtNtCs9l4wcBNbII5_4core5slice5index16slice_index_fail(i64 noundef %_11.0.i.i.i, i64 noundef %sub.sroa.4.0.lcssa.i.i.i, i64 noundef range(i64 0, -9223372036854775808) %_8.1, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_ad438f04501d3850fe5717f2a4e651e9) #20, !noalias !273
  unreachable

_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit28.i.i.i: ; preds = %bb19.i.i.i
  tail call void @llvm.experimental.noalias.scope.decl(metadata !278)
  %10 = icmp eq i64 %sub.sroa.4.0.lcssa.i.i.i, %_11.0.i.i.i
  br i1 %10, label %_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser18without_parameters.exit.i.i, label %bb2.i29.i.i.i

bb2.i29.i.i.i:                                    ; preds = %_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit28.i.i.i
  %_8.i30.i.i.i = getelementptr inbounds nuw i8, ptr %_8.0, i64 %sub.sroa.4.0.lcssa.i.i.i
  %_16.i26.i.i.i = getelementptr inbounds nuw i8, ptr %_8.0, i64 %_11.0.i.i.i
  br label %bb13.i.i34.i.i.i

bb1.i.i31.i.i.i:                                  ; preds = %_RNCNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5token0B5_.exit.i.i42.i.i.i
  %_12.i.i33.i.i.i = icmp eq ptr %_22.i.i35.i.i.i, %_8.i30.i.i.i
  br i1 %_12.i.i33.i.i.i, label %bb31.i.i.i, label %bb13.i.i34.i.i.i

bb13.i.i34.i.i.i:                                 ; preds = %bb2.i29.i.i.i, %bb1.i.i31.i.i.i
  %_223.i.i32.i.i.i30 = phi ptr [ %_16.i26.i.i.i, %bb2.i29.i.i.i ], [ %_22.i.i35.i.i.i, %bb1.i.i31.i.i.i ]
  %_22.i.i35.i.i.i = getelementptr inbounds nuw i8, ptr %_223.i.i32.i.i.i30, i64 1
  %ptr.val.i.i36.i.i.i = load i8, ptr %_223.i.i32.i.i.i30, align 1, !alias.scope !281, !noalias !282, !noundef !57
  %11 = add i8 %ptr.val.i.i36.i.i.i, -33
  %or.cond.i.i.i37.i.i.i = icmp ult i8 %11, 94
  br i1 %or.cond.i.i.i37.i.i.i, label %bb2.i.i.i39.i.i.i, label %_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser18without_parameters.exit.i.i

bb2.i.i.i39.i.i.i:                                ; preds = %bb13.i.i34.i.i.i
; call core::slice::memchr::memchr_aligned
  %12 = tail call { i64, i64 } @_RNvNtNtCs9l4wcBNbII5_4core5slice6memchr14memchr_aligned(i8 noundef %ptr.val.i.i36.i.i.i, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance) @alloc_d82b0e089738a8d65da181c674b5c170, i64 noundef 17) #19, !noalias !285
  %13 = extractvalue { i64, i64 } %12, 0
  %14 = trunc nuw i64 %13 to i1
  %15 = extractvalue { i64, i64 } %12, 1
  %cond.i.i.i.i.i40.i.i.i = icmp ugt i64 %15, 16
  %or.cond.not.i.i.i.i41.i.i.i = select i1 %14, i1 %cond.i.i.i.i.i40.i.i.i, i1 false, !prof !271
  br i1 %or.cond.not.i.i.i.i41.i.i.i, label %bb1.i.i.i.i.i.i43.i.i.i, label %_RNCNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5token0B5_.exit.i.i42.i.i.i, !prof !271

bb1.i.i.i.i.i.i43.i.i.i:                          ; preds = %bb2.i.i.i39.i.i.i
; call core::panicking::panic_nounwind_fmt
  tail call void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull @alloc_64e308ef4babfeb8b6220184de794a17, ptr noundef nonnull inttoptr (i64 443 to ptr), i1 noundef zeroext false, ptr noalias nofree noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_9447f9e979cd1531f5a09d1c25b3ec18) #20, !noalias !285
  unreachable

_RNCNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5token0B5_.exit.i.i42.i.i.i: ; preds = %bb2.i.i.i39.i.i.i
  br i1 %14, label %_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser18without_parameters.exit.i.i, label %bb1.i.i31.i.i.i

bb31.i.i.i:                                       ; preds = %bb1.i.i31.i.i.i
  store i8 0, ptr %parsed.sroa.5.i.i, align 8, !alias.scope !251, !noalias !286
  br label %_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser18without_parameters.exit.i.i

_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser18without_parameters.exit.i.i: ; preds = %bb7.i.i.i.i, %_RNCNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5token0B5_.exit.i.i.i.i.i, %bb13.i.i.i.i.i, %_RNCNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5token0B5_.exit.i.i42.i.i.i, %bb13.i.i34.i.i.i, %bb31.i.i.i, %_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit28.i.i.i, %_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit.i.i.i, %_RNvNvNtNtCs9l4wcBNbII5_4core5slice3raw14from_raw_parts18precondition_check.exit
  %parsed.sroa.16.0.i.i = phi i64 [ undef, %_RNvNvNtNtCs9l4wcBNbII5_4core5slice3raw14from_raw_parts18precondition_check.exit ], [ undef, %_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit.i.i.i ], [ undef, %_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit28.i.i.i ], [ %sub.sroa.4.0.lcssa.i.i.i, %bb31.i.i.i ], [ undef, %_RNCNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5token0B5_.exit.i.i42.i.i.i ], [ undef, %_RNCNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5token0B5_.exit.i.i.i.i.i ], [ undef, %bb13.i.i34.i.i.i ], [ undef, %bb13.i.i.i.i.i ], [ undef, %bb7.i.i.i.i ]
  %parsed.sroa.1513.0.i.i = phi i64 [ undef, %_RNvNvNtNtCs9l4wcBNbII5_4core5slice3raw14from_raw_parts18precondition_check.exit ], [ undef, %_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit.i.i.i ], [ undef, %_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit28.i.i.i ], [ %_11.0.i.i.i, %bb31.i.i.i ], [ undef, %_RNCNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5token0B5_.exit.i.i42.i.i.i ], [ undef, %_RNCNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5token0B5_.exit.i.i.i.i.i ], [ undef, %bb13.i.i34.i.i.i ], [ undef, %bb13.i.i.i.i.i ], [ undef, %bb7.i.i.i.i ]
  %parsed.sroa.4.0.i.i = phi i64 [ undef, %_RNvNvNtNtCs9l4wcBNbII5_4core5slice3raw14from_raw_parts18precondition_check.exit ], [ undef, %_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit.i.i.i ], [ undef, %_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit28.i.i.i ], [ %i.sroa.0.08.i.i.i.i, %bb31.i.i.i ], [ undef, %_RNCNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5token0B5_.exit.i.i42.i.i.i ], [ undef, %_RNCNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5token0B5_.exit.i.i.i.i.i ], [ undef, %bb13.i.i34.i.i.i ], [ undef, %bb13.i.i.i.i.i ], [ undef, %bb7.i.i.i.i ]
  %parsed.sroa.0.0.i.i = phi i64 [ undef, %_RNvNvNtNtCs9l4wcBNbII5_4core5slice3raw14from_raw_parts18precondition_check.exit ], [ undef, %_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit.i.i.i ], [ undef, %_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit28.i.i.i ], [ %top.sroa.0.0.lcssa.i.i.i, %bb31.i.i.i ], [ undef, %_RNCNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5token0B5_.exit.i.i42.i.i.i ], [ undef, %_RNCNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5token0B5_.exit.i.i.i.i.i ], [ undef, %bb13.i.i34.i.i.i ], [ undef, %bb13.i.i.i.i.i ], [ undef, %bb7.i.i.i.i ]
  %.sink72.i.sroa.phi.i.i = phi ptr [ %parsed.sroa.5.i.i, %_RNvNvNtNtCs9l4wcBNbII5_4core5slice3raw14from_raw_parts18precondition_check.exit ], [ %parsed.sroa.5.i.i, %_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit.i.i.i ], [ %parsed.sroa.5.i.i, %_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit28.i.i.i ], [ %parsed.sroa.17.i.i, %bb31.i.i.i ], [ %parsed.sroa.5.i.i, %_RNCNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5token0B5_.exit.i.i42.i.i.i ], [ %parsed.sroa.5.i.i, %_RNCNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5token0B5_.exit.i.i.i.i.i ], [ %parsed.sroa.5.i.i, %bb13.i.i34.i.i.i ], [ %parsed.sroa.5.i.i, %bb13.i.i.i.i.i ], [ %parsed.sroa.5.i.i, %bb7.i.i.i.i ]
  %.sink.i.i.i = phi i8 [ 2, %_RNvNvNtNtCs9l4wcBNbII5_4core5slice3raw14from_raw_parts18precondition_check.exit ], [ 2, %_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit.i.i.i ], [ 2, %_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes.exit28.i.i.i ], [ 0, %bb31.i.i.i ], [ 2, %_RNCNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5token0B5_.exit.i.i42.i.i.i ], [ 2, %_RNCNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5token0B5_.exit.i.i.i.i.i ], [ 2, %bb13.i.i34.i.i.i ], [ 2, %bb13.i.i.i.i.i ], [ 2, %bb7.i.i.i.i ]
  store i8 %.sink.i.i.i, ptr %.sink72.i.sroa.phi.i.i, align 8, !alias.scope !251, !noalias !286
  %parsed.sroa.5.i.i.0.parsed.sroa.5.i.i.0.parsed.sroa.5.i.i.0.parsed.sroa.5.i.0.parsed.sroa.5.i.0.parsed.sroa.5.0.parsed.sroa.5.0.parsed.sroa.5.16..i.i = load i8, ptr %parsed.sroa.5.i.i, align 8, !range !174, !noalias !286, !noundef !57
  %16 = icmp ne i8 %parsed.sroa.5.i.i.0.parsed.sroa.5.i.i.0.parsed.sroa.5.i.i.0.parsed.sroa.5.i.0.parsed.sroa.5.i.0.parsed.sroa.5.0.parsed.sroa.5.0.parsed.sroa.5.16..i.i, 2
  br i1 %16, label %bb5.i.i, label %_RNvNvNvNtCscgZyRT41Cnx_20mime_type_validation3ffi1__26___parse_without_parameters26___parse_without_parameters.exit

bb5.i.i:                                          ; preds = %_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser18without_parameters.exit.i.i
  %parsed.sroa.17.i.i.0.parsed.sroa.17.i.i.0.parsed.sroa.17.i.i.0.parsed.sroa.17.i.0.parsed.sroa.17.i.0.parsed.sroa.17.0.parsed.sroa.17.0.parsed.sroa.17.0.copyload.i.i = load i8, ptr %parsed.sroa.17.i.i, align 8, !noalias !286
  br label %_RNvNvNvNtCscgZyRT41Cnx_20mime_type_validation3ffi1__26___parse_without_parameters26___parse_without_parameters.exit

_RNvNvNvNtCscgZyRT41Cnx_20mime_type_validation3ffi1__26___parse_without_parameters26___parse_without_parameters.exit: ; preds = %_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser18without_parameters.exit.i.i, %bb5.i.i
  %_4.sroa.0.0.i.i = phi i64 [ %parsed.sroa.0.0.i.i, %bb5.i.i ], [ 0, %_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser18without_parameters.exit.i.i ]
  %_4.sroa.5.0.i.i = phi i64 [ %parsed.sroa.4.0.i.i, %bb5.i.i ], [ 0, %_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser18without_parameters.exit.i.i ]
  %_4.sroa.10.0.i.i = phi i64 [ %parsed.sroa.1513.0.i.i, %bb5.i.i ], [ 0, %_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser18without_parameters.exit.i.i ]
  %_4.sroa.13.0.i.i = phi i64 [ %parsed.sroa.16.0.i.i, %bb5.i.i ], [ 0, %_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser18without_parameters.exit.i.i ]
  %_4.sroa.15.0.i.i = phi i8 [ %parsed.sroa.17.i.i.0.parsed.sroa.17.i.i.0.parsed.sroa.17.i.i.0.parsed.sroa.17.i.0.parsed.sroa.17.i.0.parsed.sroa.17.0.parsed.sroa.17.0.parsed.sroa.17.0.copyload.i.i, %bb5.i.i ], [ 0, %_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser18without_parameters.exit.i.i ]
  %_4.sroa.7.0.i.i = phi i8 [ %parsed.sroa.5.i.i.0.parsed.sroa.5.i.i.0.parsed.sroa.5.i.i.0.parsed.sroa.5.i.0.parsed.sroa.5.i.0.parsed.sroa.5.0.parsed.sroa.5.0.parsed.sroa.5.16..i.i, %bb5.i.i ], [ 0, %_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser18without_parameters.exit.i.i ]
  %17 = zext i1 %16 to i8
  call void @llvm.lifetime.end.p0(ptr nonnull %parsed.sroa.5.i.i)
  call void @llvm.lifetime.end.p0(ptr nonnull %parsed.sroa.17.i.i)
  store i8 %17, ptr %__return, align 8
  %_3.sroa.41.0.__return.sroa_idx = getelementptr inbounds nuw i8, ptr %__return, i64 8
  store i64 %_4.sroa.0.0.i.i, ptr %_3.sroa.41.0.__return.sroa_idx, align 8
  %_3.sroa.5.0.__return.sroa_idx = getelementptr inbounds nuw i8, ptr %__return, i64 16
  store i64 %_4.sroa.5.0.i.i, ptr %_3.sroa.5.0.__return.sroa_idx, align 8
  %_3.sroa.6.0.__return.sroa_idx = getelementptr inbounds nuw i8, ptr %__return, i64 24
  store i8 %_4.sroa.7.0.i.i, ptr %_3.sroa.6.0.__return.sroa_idx, align 8
  %_3.sroa.72.0.__return.sroa_idx = getelementptr inbounds nuw i8, ptr %__return, i64 32
  store i64 %_4.sroa.10.0.i.i, ptr %_3.sroa.72.0.__return.sroa_idx, align 8
  %_3.sroa.8.0.__return.sroa_idx = getelementptr inbounds nuw i8, ptr %__return, i64 40
  store i64 %_4.sroa.13.0.i.i, ptr %_3.sroa.8.0.__return.sroa_idx, align 8
  %_3.sroa.9.0.__return.sroa_idx = getelementptr inbounds nuw i8, ptr %__return, i64 48
  store i8 %_4.sroa.15.0.i.i, ptr %_3.sroa.9.0.__return.sroa_idx, align 8
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #5

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #6

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #6

; core::panicking::panic_bounds_check
; Function Attrs: cold minsize noinline noreturn nounwind optsize uwtable
declare void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_bounds_check(i64 noundef, i64 noundef, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #7

declare i32 @__CxxFrameHandler3(...) unnamed_addr #8

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #6

; alloc::raw_vec::handle_error
; Function Attrs: cold minsize noreturn nounwind optsize uwtable
declare void @_RNvNtCs8tsiLsQ9XHg_5alloc7raw_vec12handle_error(i64 noundef range(i64 0, -9223372036854775807), i64) unnamed_addr #9

; core::panicking::panic_misaligned_pointer_dereference
; Function Attrs: cold minsize noinline noreturn nounwind optsize uwtable
declare void @_RNvNtCs9l4wcBNbII5_4core9panicking36panic_misaligned_pointer_dereference(i64 noundef, i64 noundef, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #7

; core::panicking::panic_null_reference_constructed
; Function Attrs: cold minsize noinline noreturn nounwind optsize uwtable
declare void @_RNvNtCs9l4wcBNbII5_4core9panicking32panic_null_reference_constructed(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #7

; core::slice::index::slice_index_fail
; Function Attrs: cold noinline noreturn nounwind uwtable
declare void @_RNvNtNtCs9l4wcBNbII5_4core5slice5index16slice_index_fail(i64 noundef, i64 noundef, i64 noundef, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #10

; core::panicking::panic_const::panic_const_sub_overflow
; Function Attrs: cold noinline noreturn nounwind uwtable
declare void @_RNvNtNtCs9l4wcBNbII5_4core9panicking11panic_const24panic_const_sub_overflow(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #10

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.ctpop.i64(i64) #11

; __rustc::__rust_dealloc
; Function Attrs: nounwind allockind("free") uwtable
declare void @_RNvCs6d6XRwTwhVh_7___rustc14___rust_dealloc(ptr allocptr noundef nonnull captures(address), i64 noundef, i64 noundef range(i64 1, -9223372036854775807)) unnamed_addr #12

; __rustc::__rust_realloc
; Function Attrs: nounwind allockind("realloc,aligned") allocsize(3) uwtable
declare noalias noundef ptr @_RNvCs6d6XRwTwhVh_7___rustc14___rust_realloc(ptr allocptr noundef nonnull, i64 noundef, i64 allocalign noundef range(i64 1, -9223372036854775807), i64 noundef) unnamed_addr #13

; __rustc::__rust_no_alloc_shim_is_unstable_v2
; Function Attrs: nounwind uwtable
declare void @_RNvCs6d6XRwTwhVh_7___rustc35___rust_no_alloc_shim_is_unstable_v2() unnamed_addr #3

; __rustc::__rust_alloc
; Function Attrs: nounwind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable
declare noalias noundef ptr @_RNvCs6d6XRwTwhVh_7___rustc12___rust_alloc(i64 noundef, i64 allocalign noundef range(i64 1, -9223372036854775807)) unnamed_addr #14

; Function Attrs: nounwind uwtable
declare noundef zeroext i1 @"net$mime_type_internal$cxxbridge1$205$ContentTypeState$had_charset"(ptr noundef nonnull) unnamed_addr #3

; Function Attrs: nounwind uwtable
declare void @"net$mime_type_internal$cxxbridge1$205$ContentTypeState$current_mime"(ptr noundef nonnull, ptr noundef) unnamed_addr #3

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.umul.with.overflow.i64(i64, i64) #11

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umax.i64(i64, i64) #11

; <alloc::raw_vec::RawVec<u8>>::grow_one
; Function Attrs: noinline nounwind uwtable
declare void @_RNvMs7_NtCs8tsiLsQ9XHg_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_(ptr noalias nofree noundef align 8 dereferenceable(16)) unnamed_addr #15

; core::panicking::panic_const::panic_const_add_overflow
; Function Attrs: cold noinline noreturn nounwind uwtable
declare void @_RNvNtNtCs9l4wcBNbII5_4core9panicking11panic_const24panic_const_add_overflow(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #10

; core::slice::memchr::memchr_aligned
; Function Attrs: nounwind uwtable
declare { i64, i64 } @_RNvNtNtCs9l4wcBNbII5_4core5slice6memchr14memchr_aligned(i8 noundef, ptr noalias nofree noundef nonnull readonly captures(address, read_provenance), i64 noundef range(i64 0, -9223372036854775808)) unnamed_addr #3

; core::panicking::panic_nounwind_fmt
; Function Attrs: cold noinline noreturn nounwind uwtable
declare void @_RNvNtCs9l4wcBNbII5_4core9panicking18panic_nounwind_fmt(ptr noundef nonnull, ptr noundef nonnull, i1 noundef zeroext, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #10

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #16

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umin.i64(i64, i64) #17

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #18

attributes #0 = { inlinehint nofree norecurse nosync nounwind memory(argmem: read, inaccessiblemem: readwrite) uwtable "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #1 = { cold nounwind uwtable "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #2 = { cold noinline nounwind uwtable "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #3 = { nounwind uwtable "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #4 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #5 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #6 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #7 = { cold minsize noinline noreturn nounwind optsize uwtable "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #8 = { "target-cpu"="x86-64" }
attributes #9 = { cold minsize noreturn nounwind optsize uwtable "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #10 = { cold noinline noreturn nounwind uwtable "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #11 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #12 = { nounwind allockind("free") uwtable "alloc-family"="__rust_alloc" "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #13 = { nounwind allockind("realloc,aligned") allocsize(3) uwtable "alloc-family"="__rust_alloc" "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #14 = { nounwind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "alloc-variant-zeroed"="_RNvCs6d6XRwTwhVh_7___rustc19___rust_alloc_zeroed" "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #15 = { noinline nounwind uwtable "target-cpu"="x86-64" "target-features"="+cx16,+sse,+sse2,+sse3,+sahf" }
attributes #16 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #17 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #18 = { nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #19 = { nounwind }
attributes #20 = { noreturn nounwind }

!llvm.module.flags = !{!37, !38, !39}
!llvm.ident = !{!40}

!0 = !{i64 3530390871427515767}
!1 = !{i64 -7114343403616539804}
!2 = !{i64 -5794870665082610242}
!3 = !{i64 7543254171543336612}
!4 = !{i64 1461264442829402299}
!5 = !{i64 7029680400832759081}
!6 = !{i64 8293237367085074838}
!7 = !{i64 -1619175072425132061}
!8 = !{i64 5167629539795848699}
!9 = !{i64 5813243827676139139}
!10 = !{i64 -5312161812965835071}
!11 = !{i64 6266770935432900572}
!12 = !{i64 5646803170137744995}
!13 = !{i64 7001226874632793845}
!14 = !{i64 -5106756882981973337}
!15 = !{i64 9180993032510108411}
!16 = !{i64 -6421956624691436268}
!17 = !{i64 -7609558288467938703}
!18 = !{i64 -712528493413786218}
!19 = !{i64 6520532020151661634}
!20 = !{i64 -1855315905063862775}
!21 = !{i64 2297448610173994463}
!22 = !{i64 -3155691036575023594}
!23 = !{i64 4657001773916787824}
!24 = !{i64 765203688225990871}
!25 = !{i64 -5280097306610975525}
!26 = !{i64 -6637965161465338256}
!27 = !{i64 6107006886286147316}
!28 = !{i64 517647001949183879}
!29 = !{i64 1229757382003052180}
!30 = !{i64 -5972465356466408344}
!31 = !{i64 -2462098988435182568}
!32 = !{i64 -2524269071646392552}
!33 = !{i64 8980270192097318257}
!34 = !{i64 -4557706627241160842}
!35 = !{i64 -4780399726021539432}
!36 = !{i64 -208461651433807409}
!37 = !{i32 8, !"PIC Level", i32 2}
!38 = !{i32 7, !"uwtable", i32 2}
!39 = !{i32 2, !"cfguard", i32 2}
!40 = !{!"rustc version 1.101.0-nightly (41b321963 2026-10-29) (96a18bf5ffa2b24f9cf3d1c731a9eb121c1acad9-4-llvmorg-24-init-17044-gc3223914 chromium)"}
!41 = !{i64 5985001469152934243}
!42 = !{!43}
!43 = distinct !{!43, !44, !"_RINvNvMNtNtCs9l4wcBNbII5_4core5slice5asciiSh27eq_ignore_ascii_case_chunks21eq_ignore_ascii_innerKj10_ECscgZyRT41Cnx_20mime_type_validation: %lhs"}
!44 = distinct !{!44, i1 true, !"_RINvNvMNtNtCs9l4wcBNbII5_4core5slice5asciiSh27eq_ignore_ascii_case_chunks21eq_ignore_ascii_innerKj10_ECscgZyRT41Cnx_20mime_type_validation"}
!45 = !{!46}
!46 = distinct !{!46, !44, !"_RINvNvMNtNtCs9l4wcBNbII5_4core5slice5asciiSh27eq_ignore_ascii_case_chunks21eq_ignore_ascii_innerKj10_ECscgZyRT41Cnx_20mime_type_validation: %rhs"}
!47 = !{!48}
!48 = distinct !{!48, !49, !"_RINvNvMNtNtCs9l4wcBNbII5_4core5slice5asciiSh27eq_ignore_ascii_case_chunks21eq_ignore_ascii_innerKj10_ECscgZyRT41Cnx_20mime_type_validation: %lhs"}
!49 = distinct !{!49, i1 true, !"_RINvNvMNtNtCs9l4wcBNbII5_4core5slice5asciiSh27eq_ignore_ascii_case_chunks21eq_ignore_ascii_innerKj10_ECscgZyRT41Cnx_20mime_type_validation"}
!50 = !{!51}
!51 = distinct !{!51, !49, !"_RINvNvMNtNtCs9l4wcBNbII5_4core5slice5asciiSh27eq_ignore_ascii_case_chunks21eq_ignore_ascii_innerKj10_ECscgZyRT41Cnx_20mime_type_validation: %rhs"}
!52 = !{i64 -338958305458676176}
!53 = !{!54}
!54 = distinct !{!54, !55, !"_RNvMs8_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14grow_amortizedCscgZyRT41Cnx_20mime_type_validation: %self"}
!55 = distinct !{!55, i1 true, !"_RNvMs8_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14grow_amortizedCscgZyRT41Cnx_20mime_type_validation"}
!56 = !{i64 0, i64 -9223372036854775808}
!57 = !{}
!58 = !{i64 0, i64 2}
!59 = !{i64 0, i64 -9223372036854775807}
!60 = !{i64 -1350930885022910430}
!61 = !{!62}
!62 = distinct !{!62, !63, !"_RNvMs8_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14grow_amortizedCscgZyRT41Cnx_20mime_type_validation: %self"}
!63 = distinct !{!63, i1 true, !"_RNvMs8_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14grow_amortizedCscgZyRT41Cnx_20mime_type_validation"}
!64 = !{i64 1019915062215995680}
!65 = !{!"branch_weights", i32 2002, i32 2000}
!66 = !{!67}
!67 = distinct !{!67, !68, !"_RNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCscgZyRT41Cnx_20mime_type_validation: %_0"}
!68 = distinct !{!68, i1 true, !"_RNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCscgZyRT41Cnx_20mime_type_validation"}
!69 = !{!"branch_weights", !"expected", i32 1, i32 2000}
!70 = !{!"branch_weights", i32 4001, i32 4000000}
!71 = !{!"branch_weights", !"expected", i32 2000, i32 1}
!72 = !{i64 1925275859185746903}
!73 = !{i8 0, i8 2}
!74 = !{!75}
!75 = distinct !{!75, !76, !"_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser4trim: %span"}
!76 = distinct !{!76, i1 true, !"_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser4trim"}
!77 = !{!78}
!78 = distinct !{!78, !76, !"_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser4trim: %source.0"}
!79 = !{!80, !75, !78}
!80 = distinct !{!80, !76, !"_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser4trim: %_0"}
!81 = !{!82}
!82 = distinct !{!82, !83, !"_RINvXs2J_NtNtCs9l4wcBNbII5_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNvMs4_NtBb_3numh18is_ascii_uppercaseECscgZyRT41Cnx_20mime_type_validation: %self"}
!83 = distinct !{!83, i1 true, !"_RINvXs2J_NtNtCs9l4wcBNbII5_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNvMs4_NtBb_3numh18is_ascii_uppercaseECscgZyRT41Cnx_20mime_type_validation"}
!84 = !{!85}
!85 = distinct !{!85, !86, !"_RINvMsk_NtCs8tsiLsQ9XHg_5alloc3vecINtB6_3VechE14extend_trustedINtNtNtNtCs9l4wcBNbII5_4core4iter8adapters3map3MapINtNtNtB17_5slice4iter4IterhENvMs4_NtB17_3numh18to_ascii_lowercaseEECscgZyRT41Cnx_20mime_type_validation: %self"}
!86 = distinct !{!86, i1 true, !"_RINvMsk_NtCs8tsiLsQ9XHg_5alloc3vecINtB6_3VechE14extend_trustedINtNtNtNtCs9l4wcBNbII5_4core4iter8adapters3map3MapINtNtNtB17_5slice4iter4IterhENvMs4_NtB17_3numh18to_ascii_lowercaseEECscgZyRT41Cnx_20mime_type_validation"}
!87 = !{!88, !85}
!88 = distinct !{!88, !89, !"_RNvMs_NtCs8tsiLsQ9XHg_5alloc3vecINtB4_3VechE7reserveCscgZyRT41Cnx_20mime_type_validation: %self"}
!89 = distinct !{!89, i1 true, !"_RNvMs_NtCs8tsiLsQ9XHg_5alloc3vecINtB4_3VechE7reserveCscgZyRT41Cnx_20mime_type_validation"}
!90 = !{!91, !93, !95, !85}
!91 = distinct !{!91, !92, !"_RINvXs2J_NtNtCs9l4wcBNbII5_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator4folduNCINvNtNtBY_8adapters3map8map_foldRhhuNvMs4_NtBb_3numh18to_ascii_lowercaseNCINvNvBS_8for_each4callhNCINvMsk_NtCs8tsiLsQ9XHg_5alloc3vecINtB3n_3VechE14extend_trustedINtB1I_3MapBF_B2f_EE0E0E0ECscgZyRT41Cnx_20mime_type_validation: %f"}
!92 = distinct !{!92, i1 true, !"_RINvXs2J_NtNtCs9l4wcBNbII5_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator4folduNCINvNtNtBY_8adapters3map8map_foldRhhuNvMs4_NtBb_3numh18to_ascii_lowercaseNCINvNvBS_8for_each4callhNCINvMsk_NtCs8tsiLsQ9XHg_5alloc3vecINtB3n_3VechE14extend_trustedINtB1I_3MapBF_B2f_EE0E0E0ECscgZyRT41Cnx_20mime_type_validation"}
!93 = distinct !{!93, !94, !"_RINvXs0_NtNtNtCs9l4wcBNbII5_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_5slice4iter4IterhENvMs4_NtBc_3numh18to_ascii_lowercaseENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB20_8for_each4callhNCINvMsk_NtCs8tsiLsQ9XHg_5alloc3vecINtB3d_3VechE14extend_trustedBN_E0E0ECscgZyRT41Cnx_20mime_type_validation: %g"}
!94 = distinct !{!94, i1 true, !"_RINvXs0_NtNtNtCs9l4wcBNbII5_4core4iter8adapters3mapINtB6_3MapINtNtNtBc_5slice4iter4IterhENvMs4_NtBc_3numh18to_ascii_lowercaseENtNtNtBa_6traits8iterator8Iterator4folduNCINvNvB20_8for_each4callhNCINvMsk_NtCs8tsiLsQ9XHg_5alloc3vecINtB3d_3VechE14extend_trustedBN_E0E0ECscgZyRT41Cnx_20mime_type_validation"}
!95 = distinct !{!95, !96, !"_RINvYINtNtNtNtCs9l4wcBNbII5_4core4iter8adapters3map3MapINtNtNtBc_5slice4iter4IterhENvMs4_NtBc_3numh18to_ascii_lowercaseENtNtNtBa_6traits8iterator8Iterator8for_eachNCINvMsk_NtCs8tsiLsQ9XHg_5alloc3vecINtB2K_3VechE14extend_trustedB3_E0ECscgZyRT41Cnx_20mime_type_validation: %f"}
!96 = distinct !{!96, i1 true, !"_RINvYINtNtNtNtCs9l4wcBNbII5_4core4iter8adapters3map3MapINtNtNtBc_5slice4iter4IterhENvMs4_NtBc_3numh18to_ascii_lowercaseENtNtNtBa_6traits8iterator8Iterator8for_eachNCINvMsk_NtCs8tsiLsQ9XHg_5alloc3vecINtB2K_3VechE14extend_trustedB3_E0ECscgZyRT41Cnx_20mime_type_validation"}
!97 = !{!98, !100, !102, !91, !93, !95, !85}
!98 = distinct !{!98, !99, !"_RNCINvMsk_NtCs8tsiLsQ9XHg_5alloc3vecINtB8_3VechE14extend_trustedINtNtNtNtCs9l4wcBNbII5_4core4iter8adapters3map3MapINtNtNtB19_5slice4iter4IterhENvMs4_NtB19_3numh18to_ascii_lowercaseEE0CscgZyRT41Cnx_20mime_type_validation: %_1"}
!99 = distinct !{!99, i1 true, !"_RNCINvMsk_NtCs8tsiLsQ9XHg_5alloc3vecINtB8_3VechE14extend_trustedINtNtNtNtCs9l4wcBNbII5_4core4iter8adapters3map3MapINtNtNtB19_5slice4iter4IterhENvMs4_NtB19_3numh18to_ascii_lowercaseEE0CscgZyRT41Cnx_20mime_type_validation"}
!100 = distinct !{!100, !101, !"_RNCINvNvNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator8for_each4callhNCINvMsk_NtCs8tsiLsQ9XHg_5alloc3vecINtB1p_3VechE14extend_trustedINtNtNtBc_8adapters3map3MapINtNtNtBe_5slice4iter4IterhENvMs4_NtBe_3numh18to_ascii_lowercaseEE0E0CscgZyRT41Cnx_20mime_type_validation: %_1"}
!101 = distinct !{!101, i1 true, !"_RNCINvNvNtNtNtNtCs9l4wcBNbII5_4core4iter6traits8iterator8Iterator8for_each4callhNCINvMsk_NtCs8tsiLsQ9XHg_5alloc3vecINtB1p_3VechE14extend_trustedINtNtNtBc_8adapters3map3MapINtNtNtBe_5slice4iter4IterhENvMs4_NtBe_3numh18to_ascii_lowercaseEE0E0CscgZyRT41Cnx_20mime_type_validation"}
!102 = distinct !{!102, !103, !"_RNCINvNtNtNtCs9l4wcBNbII5_4core4iter8adapters3map8map_foldRhhuNvMs4_NtBa_3numh18to_ascii_lowercaseNCINvNvNtNtNtB8_6traits8iterator8Iterator8for_each4callhNCINvMsk_NtCs8tsiLsQ9XHg_5alloc3vecINtB2B_3VechE14extend_trustedINtB4_3MapINtNtNtBa_5slice4iter4IterhEBY_EE0E0E0CscgZyRT41Cnx_20mime_type_validation: %_1"}
!103 = distinct !{!103, i1 true, !"_RNCINvNtNtNtCs9l4wcBNbII5_4core4iter8adapters3map8map_foldRhhuNvMs4_NtBa_3numh18to_ascii_lowercaseNCINvNvNtNtNtB8_6traits8iterator8Iterator8for_each4callhNCINvMsk_NtCs8tsiLsQ9XHg_5alloc3vecINtB2B_3VechE14extend_trustedINtB4_3MapINtNtNtBa_5slice4iter4IterhEBY_EE0E0E0CscgZyRT41Cnx_20mime_type_validation"}
!104 = distinct !{!104, !105, !106}
!105 = !{!"llvm.loop.isvectorized", i32 1}
!106 = !{!"llvm.loop.unroll.runtime.disable"}
!107 = !{!"branch_weights", i32 8, i32 24}
!108 = distinct !{!108, !105, !106}
!109 = distinct !{!109, !106, !105}
!110 = !{!91, !93, !95}
!111 = !{!112}
!112 = distinct !{!112, !113, !"_RNvMs_NtCs8tsiLsQ9XHg_5alloc3vecINtB4_3VechE7reserveCscgZyRT41Cnx_20mime_type_validation: %self"}
!113 = distinct !{!113, i1 true, !"_RNvMs_NtCs8tsiLsQ9XHg_5alloc3vecINtB4_3VechE7reserveCscgZyRT41Cnx_20mime_type_validation"}
!114 = !{!115}
!115 = distinct !{!115, !116, !"_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser4trim: %source.0"}
!116 = distinct !{!116, i1 true, !"_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser4trim"}
!117 = !{!118, !119, !115}
!118 = distinct !{!118, !116, !"_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser4trim: %_0"}
!119 = distinct !{!119, !116, !"_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser4trim: %span"}
!120 = !{!121}
!121 = distinct !{!121, !122, !"_RNvMsG_NtCs8tsiLsQ9XHg_5alloc3vecINtB5_3VechE8push_mutCscgZyRT41Cnx_20mime_type_validation: %self"}
!122 = distinct !{!122, i1 true, !"_RNvMsG_NtCs8tsiLsQ9XHg_5alloc3vecINtB5_3VechE8push_mutCscgZyRT41Cnx_20mime_type_validation"}
!123 = !{i64 2684418962696793624}
!124 = !{!"branch_weights", i32 1, i32 127}
!125 = !{!126}
!126 = distinct !{!126, !127, !"_RINvXs2J_NtNtCs9l4wcBNbII5_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator8positionNCNvXs_NtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB1N_10ParametersBS_4next0EB1P_: %self"}
!127 = distinct !{!127, i1 true, !"_RINvXs2J_NtNtCs9l4wcBNbII5_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator8positionNCNvXs_NtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB1N_10ParametersBS_4next0EB1P_"}
!128 = !{!"branch_weights", i32 127, i32 255873}
!129 = !{i64 6963602497899363490}
!130 = !{i64 4895386535200541426}
!131 = !{i64 -3582816822438246300}
!132 = !{!133}
!133 = distinct !{!133, !134, !"_RNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCscgZyRT41Cnx_20mime_type_validation: %_0"}
!134 = distinct !{!134, i1 true, !"_RNvMs5_NtCs8tsiLsQ9XHg_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCscgZyRT41Cnx_20mime_type_validation"}
!135 = !{i64 -4967518883682608486}
!136 = !{i64 2308284660240342615}
!137 = !{i64 -8524226240281405057}
!138 = !{!139}
!139 = distinct !{!139, !140, !"_RNvMNtCsdVJFY9KZ4lg_3cxx8rust_vecINtB2_7RustVecNtNtCscgZyRT41Cnx_20mime_type_validation3ffi9ParameterE13reserve_totalBN_: %self"}
!140 = distinct !{!140, i1 true, !"_RNvMNtCsdVJFY9KZ4lg_3cxx8rust_vecINtB2_7RustVecNtNtCscgZyRT41Cnx_20mime_type_validation3ffi9ParameterE13reserve_totalBN_"}
!141 = !{i64 -4278457674289016587}
!142 = !{!143}
!143 = distinct !{!143, !144, !"_RNvMNtCsdVJFY9KZ4lg_3cxx8rust_vecINtB2_7RustVecNtNtCscgZyRT41Cnx_20mime_type_validation3ffi9ParameterE7set_lenBN_: %self"}
!144 = distinct !{!144, i1 true, !"_RNvMNtCsdVJFY9KZ4lg_3cxx8rust_vecINtB2_7RustVecNtNtCscgZyRT41Cnx_20mime_type_validation3ffi9ParameterE7set_lenBN_"}
!145 = !{i64 1432126408251008051}
!146 = !{!147, !149}
!147 = distinct !{!147, !148, !"_RNvMs_NtCs8tsiLsQ9XHg_5alloc3vecINtB4_3VecNtNtCscgZyRT41Cnx_20mime_type_validation3ffi9ParameterE8truncateBI_: %self"}
!148 = distinct !{!148, i1 true, !"_RNvMs_NtCs8tsiLsQ9XHg_5alloc3vecINtB4_3VecNtNtCscgZyRT41Cnx_20mime_type_validation3ffi9ParameterE8truncateBI_"}
!149 = distinct !{!149, !150, !"_RNvMNtCsdVJFY9KZ4lg_3cxx8rust_vecINtB2_7RustVecNtNtCscgZyRT41Cnx_20mime_type_validation3ffi9ParameterE8truncateBN_: %self"}
!150 = distinct !{!150, i1 true, !"_RNvMNtCsdVJFY9KZ4lg_3cxx8rust_vecINtB2_7RustVecNtNtCscgZyRT41Cnx_20mime_type_validation3ffi9ParameterE8truncateBN_"}
!151 = !{i64 -3132737430499788689}
!152 = !{!153}
!153 = distinct !{!153, !154, !"_RNCNvNvNtCscgZyRT41Cnx_20mime_type_validation3ffi1__20___parse_content_type0B7_: %_1"}
!154 = distinct !{!154, i1 true, !"_RNCNvNvNtCscgZyRT41Cnx_20mime_type_validation3ffi1__20___parse_content_type0B7_"}
!155 = !{!156}
!156 = distinct !{!156, !157, !"_RNvNvNvNtCscgZyRT41Cnx_20mime_type_validation3ffi1__20___parse_content_type20___parse_content_type: %input.0"}
!157 = distinct !{!157, i1 true, !"_RNvNvNvNtCscgZyRT41Cnx_20mime_type_validation3ffi1__20___parse_content_type20___parse_content_type"}
!158 = !{!159}
!159 = distinct !{!159, !160, !"_RNvCscgZyRT41Cnx_20mime_type_validation18parse_content_type: %input.0"}
!160 = distinct !{!160, i1 true, !"_RNvCscgZyRT41Cnx_20mime_type_validation18parse_content_type"}
!161 = !{!162}
!162 = distinct !{!162, !163, !"_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser12content_typeNCNvB4_18parse_content_type0NCB1c_s_0EB4_: %input.0"}
!163 = distinct !{!163, i1 true, !"_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser12content_typeNCNvB4_18parse_content_type0NCB1c_s_0EB4_"}
!164 = !{!165, !159, !166, !156, !153}
!165 = distinct !{!165, !160, !"_RNvCscgZyRT41Cnx_20mime_type_validation18parse_content_type: %_0"}
!166 = distinct !{!166, !157, !"_RNvNvNvNtCscgZyRT41Cnx_20mime_type_validation3ffi1__20___parse_content_type20___parse_content_type: %_0"}
!167 = !{!168, !162, !159, !156}
!168 = distinct !{!168, !169, !"_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser10mime_range: %input.0"}
!169 = distinct !{!169, i1 true, !"_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser10mime_range"}
!170 = !{!162, !159, !156}
!171 = !{!172, !162, !165, !159, !166, !156, !153}
!172 = distinct !{!172, !163, !"_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser12content_typeNCNvB4_18parse_content_type0NCB1c_s_0EB4_: %_0"}
!173 = !{!172, !165, !166, !153}
!174 = !{i8 0, i8 3}
!175 = !{!176, !178, !179, !172, !165, !166, !153}
!176 = distinct !{!176, !177, !"_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes: %self"}
!177 = distinct !{!177, i1 true, !"_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes"}
!178 = distinct !{!178, !177, !"_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes: %input.0"}
!179 = distinct !{!179, !177, !"_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes: argument 2"}
!180 = !{!181}
!181 = distinct !{!181, !182, !"_RNvMNtNtCs9l4wcBNbII5_4core5slice5asciiSh27eq_ignore_ascii_case_simple: argument 0"}
!182 = distinct !{!182, i1 true, !"_RNvMNtNtCs9l4wcBNbII5_4core5slice5asciiSh27eq_ignore_ascii_case_simple"}
!183 = !{!184}
!184 = distinct !{!184, !185, !"_RNvMNtNtCs9l4wcBNbII5_4core5slice5asciiSh27eq_ignore_ascii_case_simple: argument 0"}
!185 = distinct !{!185, i1 true, !"_RNvMNtNtCs9l4wcBNbII5_4core5slice5asciiSh27eq_ignore_ascii_case_simple"}
!186 = !{!187, !189, !190, !172, !165, !166, !153}
!187 = distinct !{!187, !188, !"_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes: %self"}
!188 = distinct !{!188, i1 true, !"_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes"}
!189 = distinct !{!189, !188, !"_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes: %input.0"}
!190 = distinct !{!190, !188, !"_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes: argument 2"}
!191 = !{!192, !194, !195, !172, !165, !166, !153}
!192 = distinct !{!192, !193, !"_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes: %self"}
!193 = distinct !{!193, i1 true, !"_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes"}
!194 = distinct !{!194, !193, !"_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes: %input.0"}
!195 = distinct !{!195, !193, !"_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes: argument 2"}
!196 = !{!197, !199, !200, !172, !165, !166, !153}
!197 = distinct !{!197, !198, !"_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes: %self"}
!198 = distinct !{!198, i1 true, !"_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes"}
!199 = distinct !{!199, !198, !"_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes: %input.0"}
!200 = distinct !{!200, !198, !"_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes: argument 2"}
!201 = !{!202}
!202 = distinct !{!202, !203, !"_RNvMNtNtCs9l4wcBNbII5_4core5slice5asciiSh27eq_ignore_ascii_case_simple: argument 0"}
!203 = distinct !{!203, i1 true, !"_RNvMNtNtCs9l4wcBNbII5_4core5slice5asciiSh27eq_ignore_ascii_case_simple"}
!204 = !{!205}
!205 = distinct !{!205, !203, !"_RNvMNtNtCs9l4wcBNbII5_4core5slice5asciiSh27eq_ignore_ascii_case_simple: argument 1"}
!206 = !{!202, !162, !159, !156}
!207 = !{!208}
!208 = distinct !{!208, !209, !"_RNvMNtNtCs9l4wcBNbII5_4core5slice5asciiSh27eq_ignore_ascii_case_simple: argument 0"}
!209 = distinct !{!209, i1 true, !"_RNvMNtNtCs9l4wcBNbII5_4core5slice5asciiSh27eq_ignore_ascii_case_simple"}
!210 = !{!211}
!211 = distinct !{!211, !209, !"_RNvMNtNtCs9l4wcBNbII5_4core5slice5asciiSh27eq_ignore_ascii_case_simple: argument 1"}
!212 = !{!208, !162, !159, !156}
!213 = !{!162, !165, !159, !166, !156, !153}
!214 = !{i64 -1329649357944306930}
!215 = !{!216}
!216 = distinct !{!216, !217, !"_RNvNvNvNtCscgZyRT41Cnx_20mime_type_validation3ffi1__12___parse_mime12___parse_mime: %input.0"}
!217 = distinct !{!217, i1 true, !"_RNvNvNvNtCscgZyRT41Cnx_20mime_type_validation3ffi1__12___parse_mime12___parse_mime"}
!218 = !{!219}
!219 = distinct !{!219, !220, !"_RNvCscgZyRT41Cnx_20mime_type_validation10parse_mime: %input.0"}
!220 = distinct !{!220, i1 true, !"_RNvCscgZyRT41Cnx_20mime_type_validation10parse_mime"}
!221 = !{!222, !216}
!222 = distinct !{!222, !217, !"_RNvNvNvNtCscgZyRT41Cnx_20mime_type_validation3ffi1__12___parse_mime12___parse_mime: %_0"}
!223 = !{!224, !219, !222, !216}
!224 = distinct !{!224, !220, !"_RNvCscgZyRT41Cnx_20mime_type_validation10parse_mime: %_0"}
!225 = !{!226}
!226 = distinct !{!226, !227, !"_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_: %input.0"}
!227 = distinct !{!227, i1 true, !"_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_"}
!228 = !{!229, !226, !219, !216}
!229 = distinct !{!229, !230, !"_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser10mime_range: %input.0"}
!230 = distinct !{!230, i1 true, !"_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser10mime_range"}
!231 = !{!232, !226, !233, !224, !219, !222, !216}
!232 = distinct !{!232, !227, !"_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_: %_0"}
!233 = distinct !{!233, !227, !"_RINvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5parseNCNvB4_10parse_mime0EB4_: argument 2"}
!234 = !{!232, !233, !224, !222}
!235 = !{!224, !222}
!236 = !{!237, !239, !241, !232, !233, !224, !222}
!237 = distinct !{!237, !238, !"_RNvMsG_NtCs8tsiLsQ9XHg_5alloc3vecINtB5_3VecNtNtCscgZyRT41Cnx_20mime_type_validation3ffi9ParameterE8push_mutBJ_: %self"}
!238 = distinct !{!238, i1 true, !"_RNvMsG_NtCs8tsiLsQ9XHg_5alloc3vecINtB5_3VecNtNtCscgZyRT41Cnx_20mime_type_validation3ffi9ParameterE8push_mutBJ_"}
!239 = distinct !{!239, !240, !"_RNCNvCscgZyRT41Cnx_20mime_type_validation10parse_mime0B3_: %name"}
!240 = distinct !{!240, i1 true, !"_RNCNvCscgZyRT41Cnx_20mime_type_validation10parse_mime0B3_"}
!241 = distinct !{!241, !240, !"_RNCNvCscgZyRT41Cnx_20mime_type_validation10parse_mime0B3_: %value"}
!242 = !{!226, !233, !224, !219, !222, !216}
!243 = !{!219, !216}
!244 = !{i64 940984334813237130}
!245 = !{!246}
!246 = distinct !{!246, !247, !"_RNvNvNvNtCscgZyRT41Cnx_20mime_type_validation3ffi1__26___parse_without_parameters26___parse_without_parameters: %input.0"}
!247 = distinct !{!247, i1 true, !"_RNvNvNvNtCscgZyRT41Cnx_20mime_type_validation3ffi1__26___parse_without_parameters26___parse_without_parameters"}
!248 = !{!249}
!249 = distinct !{!249, !250, !"_RNvCscgZyRT41Cnx_20mime_type_validation24parse_without_parameters: %input.0"}
!250 = distinct !{!250, i1 true, !"_RNvCscgZyRT41Cnx_20mime_type_validation24parse_without_parameters"}
!251 = !{!252}
!252 = distinct !{!252, !253, !"_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser18without_parameters: %_0"}
!253 = distinct !{!253, i1 true, !"_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser18without_parameters"}
!254 = !{!255}
!255 = distinct !{!255, !253, !"_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser18without_parameters: %input.0"}
!256 = !{!255, !249, !246}
!257 = !{!258}
!258 = distinct !{!258, !259, !"_RINvXs2J_NtNtCs9l4wcBNbII5_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator8positionNCNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser18without_parameters0EB1M_: %self"}
!259 = distinct !{!259, i1 true, !"_RINvXs2J_NtNtCs9l4wcBNbII5_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator8positionNCNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser18without_parameters0EB1M_"}
!260 = !{!258, !252, !255, !261, !249, !262, !246}
!261 = distinct !{!261, !250, !"_RNvCscgZyRT41Cnx_20mime_type_validation24parse_without_parameters: %_0"}
!262 = distinct !{!262, !247, !"_RNvNvNvNtCscgZyRT41Cnx_20mime_type_validation3ffi1__26___parse_without_parameters26___parse_without_parameters: %_0"}
!263 = !{!264}
!264 = distinct !{!264, !265, !"_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5token: %input.0"}
!265 = distinct !{!265, i1 true, !"_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5token"}
!266 = !{!264, !255, !249, !246}
!267 = !{!268}
!268 = distinct !{!268, !269, !"_RINvXs2J_NtNtCs9l4wcBNbII5_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator3allNCNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5token0EB1H_: %self"}
!269 = distinct !{!269, i1 true, !"_RINvXs2J_NtNtCs9l4wcBNbII5_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator3allNCNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5token0EB1H_"}
!270 = !{!268, !264, !252, !255, !261, !249, !262, !246}
!271 = !{!"branch_weights", i32 1, i32 4001}
!272 = !{!252, !255, !261, !249, !262, !246}
!273 = !{!274, !276, !277, !252, !255, !261, !249, !262, !246}
!274 = distinct !{!274, !275, !"_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes: %self"}
!275 = distinct !{!275, i1 true, !"_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes"}
!276 = distinct !{!276, !275, !"_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes: %input.0"}
!277 = distinct !{!277, !275, !"_RNvMNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parserNtB2_4Span5bytes: argument 2"}
!278 = !{!279}
!279 = distinct !{!279, !280, !"_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5token: %input.0"}
!280 = distinct !{!280, i1 true, !"_RNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5token"}
!281 = !{!279, !255, !249, !246}
!282 = !{!283}
!283 = distinct !{!283, !284, !"_RINvXs2J_NtNtCs9l4wcBNbII5_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator3allNCNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5token0EB1H_: %self"}
!284 = distinct !{!284, i1 true, !"_RINvXs2J_NtNtCs9l4wcBNbII5_4core5slice4iterINtB7_4IterhENtNtNtNtBb_4iter6traits8iterator8Iterator3allNCNvNtCscgZyRT41Cnx_20mime_type_validation16mime_type_parser5token0EB1H_"}
!285 = !{!283, !279, !252, !255, !261, !249, !262, !246}
!286 = !{!261, !249, !262, !246}
