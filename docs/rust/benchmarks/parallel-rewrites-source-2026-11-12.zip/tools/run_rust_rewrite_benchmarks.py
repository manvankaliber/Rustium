#!/usr/bin/env python3
"""Measure a configured GN rewrite benchmark and preserve its provenance."""

import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import time

ROOT = Path(__file__).resolve().parents[1]
MODULES = {
    "http-range": {
        "patterns": [("net/http", "http_range*"), ("net/http", "http_util.cc"),
                     ("net/http", "http_util.h"), ("net/http", "http_byte_range.*"),
                     ("net/base", "parse_number*")],
        "targets": ["http_range_perftests", "http_range_test_reference",
                    "parse_number_test_reference", "http_range_parser", "parse_number_core"],
    },
    "protocol-numbers": {
        "patterns": [("net/base", "parse_number*")],
        "targets": ["parse_number_candidate_perftests", "parse_number_test_reference",
                    "parse_number_parser", "parse_number_core"],
    },
    "hsts": {
        "patterns": [("net/http", "hsts*"), ("net/http", "http_security_headers*"),
                     ("net/base", "parse_number*")],
        "targets": ["hsts_perftests", "hsts_test_reference", "parse_number_test_reference",
                    "hsts_parser", "parse_number_core"],
    },
    "mime-sniffer": {
        "patterns": [("net/base", "mime_sniffer*")],
        "targets": ["mime_sniffer_rust_perftests", "mime_sniffer_reference", "mime_sniffer_parser"],
    },
    "gzip-header": {
        "patterns": [("net/filter", "gzip_header*")],
        "targets": ["gzip_header_perftests", "gzip_header_test_reference", "gzip_header_parser"],
    },
}


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def method_tokens(source, signature):
    """Compare C++ function tokens while ignoring formatting and comments."""
    source = source[source.index(signature):]
    tokens = re.findall(r'//[^\n]*|/\*[\s\S]*?\*/|"(?:\\.|[^"\\])*"|'
                        r"'(?:\\.|[^'\\])*'|\w+|[^\s\w]", source)
    result, depth, opened = [], 0, False
    for token in tokens:
        if token.startswith(('//', '/*')):
            continue
        result.append(token)
        if token == '{':
            opened, depth = True, depth + 1
        elif token == '}':
            depth -= 1
            if opened and depth == 0:
                return result
    raise ValueError('Unterminated benchmark method: ' + signature)


def check_range_adapter(root, allow_candidate=False):
    actual = (root / 'net/http/http_util.cc').read_text()
    adapter = (root / 'net/http/http_range_benchmark_adapter.cc').read_text()
    signatures = ['bool HttpUtil::ParseRangeHeader(',
                  'std::optional<HttpByteRange> HttpUtil::ParseFetchSingleRange(',
                  'bool HttpUtil::ParseContentRangeHeaderFor206(']
    checked = []
    for signature in signatures:
        if allow_candidate and 'ParseContentRangeHeaderFor206' in signature:
            continue
        if method_tokens(actual, signature) != method_tokens(adapter, signature):
            raise ValueError('Benchmark adapter differs from production: ' + signature)
        checked.append(signature)
    return checked


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--module", choices=MODULES, required=True)
    parser.add_argument("--executable", type=Path, required=True)
    parser.add_argument("--build-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--run", required=True)
    parser.add_argument("--cpu", type=int, default=4)
    parser.add_argument("--allow-candidate", action="store_true",
                        help="Explicitly measure a test-only experiment that is not integrated")
    args = parser.parse_args()
    if args.module == "protocol-numbers" and not args.allow_candidate:
        parser.error("Public numeric entry points remain C++; use --allow-candidate for the test-only experiment")
    if not re.fullmatch(r"[a-z][a-z0-9-]*", args.run):
        parser.error("Run must be a lowercase slug")
    if not 0 <= args.cpu < min(64, os.cpu_count() or 1):
        parser.error("CPU index is outside the supported affinity mask")
    executable = args.executable.resolve(strict=True)
    build = args.build_root.resolve(strict=True)
    if not executable.is_relative_to(build / "out"):
        parser.error("Use the configured GN executable beneath the build root's out directory")
    module = MODULES[args.module]
    adapter_methods = (check_range_adapter(ROOT, args.allow_candidate)
                       if args.module == 'http-range' else None)
    if executable.stem != module["targets"][0]:
        parser.error("Executable name must match the module's configured benchmark target")
    clean_command = [str(build / "third_party/ninja/ninja.exe"), "-C",
                     str(executable.parent), "-n", module["targets"][0]]
    clean_result = subprocess.run(clean_command, capture_output=True, text=True)
    if clean_result.returncode or "no work to do" not in clean_result.stdout:
        raise RuntimeError("Configured benchmark needs rebuilding:\n" +
                           clean_result.stdout + clean_result.stderr)
    files = [ROOT / "net/BUILD.gn", ROOT / "net/base/BUILD.gn"]
    for directory, pattern in module["patterns"]:
        files.extend(path for path in (ROOT / directory).glob(pattern) if path.is_file())
    files = sorted(set(files))
    hashes = {path.relative_to(ROOT).as_posix(): digest(path) for path in files}
    for relative, expected in hashes.items():
        if not (build / relative).is_file() or digest(build / relative) != expected:
            raise RuntimeError("Editing/configured source mismatch: " + relative)
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    (output / f"{args.run}-source-hashes.json").write_text(json.dumps(hashes, indent=2) + "\n")
    binary_hash = digest(executable)
    env = os.environ.copy()
    env["PATH"] = str(executable.parent) + os.pathsep + env.get("PATH", "")
    started = time.monotonic()
    with (output / f"{args.run}-benchmark.jsonl").open("wb") as stream:
        process = subprocess.Popen([str(executable)], cwd=executable.parent, env=env,
                                   stdout=stream, stderr=subprocess.PIPE)
        try:
            if os.name == "nt":
                if not ctypes.windll.kernel32.SetProcessAffinityMask(
                        ctypes.c_void_p(int(process._handle)), ctypes.c_size_t(1 << args.cpu)):
                    raise RuntimeError("CPU affinity could not be set")
            else:
                os.sched_setaffinity(process.pid, {args.cpu})
            _, errors = process.communicate()
        except BaseException:
            process.kill()
            process.wait()
            raise
    record = {"exit_code": process.returncode, "elapsed_seconds": time.monotonic() - started,
              "command": [str(executable)], "executable_sha256": binary_hash,
              "module": args.module, "cpu": args.cpu, "affinity_mask": 1 << args.cpu,
              "production_status": "deferred" if args.module == "protocol-numbers" else "candidate pending validation",
              "environment": {"platform": platform.platform(), "processor": platform.processor(),
                              "logical_cpus": os.cpu_count()},
              "uncontrolled": ["power/thermal state", "other system processes"],
              "stderr": errors.decode(errors="replace"), "configured_flags": {}}
    record["build_clean_check"] = {"command": clean_command, "output": clean_result.stdout.strip()}
    if adapter_methods:
        record['adapter_identity_check'] = {'method_signatures': adapter_methods,
                                            'comparison': 'C++ tokens, comments and whitespace ignored'}
        if args.allow_candidate:
            record['candidate_methods'] = ['ParseContentRangeHeaderFor206']
            record['production_status'] = 'Range-list and Fetch APIs integrated; Content-Range candidate only'
    for target in module["targets"]:
        ninja = executable.parent / "obj/net" / (target + ".ninja")
        if ninja.is_file():
            record["configured_flags"][target] = dict(re.findall(
                r"^(defines|cflags|cflags_cc|rustflags) = (.*)$", ninja.read_text(), re.M))
    for name, relative in [("rust", "third_party/rust-toolchain/bin/rustc.exe"),
                           ("clang", "third_party/llvm-build/Release+Asserts/bin/clang-cl.exe")]:
        compiler = build / relative
        if compiler.is_file():
            record[name + "_version"] = subprocess.check_output(
                [str(compiler), "--version"], text=True).strip()
    if binary_hash != digest(executable) or any(digest(ROOT / path) != sha or
                                               digest(build / path) != sha
                                               for path, sha in hashes.items()):
        raise RuntimeError("Source or measured executable changed during the benchmark")
    record['raw_report_sha256'] = digest(output / f'{args.run}-benchmark.jsonl')
    record['source_hashes_file_sha256'] = digest(output / f'{args.run}-source-hashes.json')
    (output / f"{args.run}-execution.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps({key: record[key] for key in ["module", "exit_code", "elapsed_seconds",
                                                   "cpu", "executable_sha256"]}, indent=2))
    raise SystemExit(process.returncode)


if __name__ == "__main__":
    main()
