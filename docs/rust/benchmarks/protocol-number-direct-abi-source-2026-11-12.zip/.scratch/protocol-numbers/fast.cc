#include "net/base/parse_number.h"
#include "base/check.h"
#include <type_traits>

namespace net {
static_assert(sizeof(ParseIntError) == 4);
static_assert(alignof(ParseIntError) == 4);
static_assert(static_cast<int32_t>(ParseIntError::FAILED_OVERFLOW) == 0);
static_assert(static_cast<int32_t>(ParseIntError::FAILED_UNDERFLOW) == 1);
static_assert(static_cast<int32_t>(ParseIntError::FAILED_PARSE) == 2);
extern "C" bool rustium_parse_number_i32(const uint8_t*, size_t, int32_t, int32_t*, ParseIntError*);
extern "C" bool rustium_parse_number_i64(const uint8_t*, size_t, int32_t, int64_t*, ParseIntError*);
extern "C" bool rustium_parse_number_u32(const uint8_t*, size_t, int32_t, uint32_t*, ParseIntError*);
extern "C" bool rustium_parse_number_u64(const uint8_t*, size_t, int32_t, uint64_t*, ParseIntError*);
bool ParseInt32(std::string_view input, ParseIntFormat format, int32_t* output, ParseIntError* error) {
  return rustium_parse_number_i32(reinterpret_cast<const uint8_t*>(input.data()),input.size(),static_cast<int32_t>(format),output,error);
}
bool ParseInt64(std::string_view input, ParseIntFormat format, int64_t* output, ParseIntError* error) {
  return rustium_parse_number_i64(reinterpret_cast<const uint8_t*>(input.data()),input.size(),static_cast<int32_t>(format),output,error);
}
bool ParseUint32(std::string_view input, ParseIntFormat format, uint32_t* output, ParseIntError* error) {
  CHECK(format==ParseIntFormat::NON_NEGATIVE||format==ParseIntFormat::STRICT_NON_NEGATIVE);
  return rustium_parse_number_u32(reinterpret_cast<const uint8_t*>(input.data()),input.size(),static_cast<int32_t>(format),output,error);
}
bool ParseUint64(std::string_view input, ParseIntFormat format, uint64_t* output, ParseIntError* error) {
  CHECK(format==ParseIntFormat::NON_NEGATIVE||format==ParseIntFormat::STRICT_NON_NEGATIVE);
  return rustium_parse_number_u64(reinterpret_cast<const uint8_t*>(input.data()),input.size(),static_cast<int32_t>(format),output,error);
}
}
