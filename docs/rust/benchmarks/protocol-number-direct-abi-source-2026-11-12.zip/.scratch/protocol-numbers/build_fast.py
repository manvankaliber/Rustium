from pathlib import Path
import os, subprocess, shutil, re, sys

root=Path('D:/Rustium');full=Path('D:/RustiumBuild/src');out=full/'out/Default';work=root/'.scratch/protocol-numbers'
env=os.environ.copy()
for item in (out/'environment.x64').read_bytes().decode().split('\0'):
    k,s,v=item.partition('=')
    if s:env[k]=v
mode=sys.argv[1] if len(sys.argv)>1 else 'rust'
if mode in ('rust','coverage'):
    tool=full/'third_party/rust-toolchain/bin'
    env.update({'RUSTC':str(tool/'rustc.exe'),'RUSTDOC':str(tool/'rustdoc.exe'),'CARGO_TARGET_DIR':str(work/('fast-coverage-target' if mode=='coverage' else 'fast-target')),'RUSTFLAGS':'-Cdebug-assertions=yes -Ccontrol-flow-guard=yes -Cpanic=abort'+(' -Cinstrument-coverage' if mode=='coverage' else ''),'CXX':str(full/'third_party/llvm-build/Release+Asserts/bin/clang-cl.exe'),'CXXFLAGS':'/std:c++20 /ID:/Rustium','CARGO_TARGET_X86_64_PC_WINDOWS_MSVC_LINKER':str(full/'third_party/llvm-build/Release+Asserts/bin/lld-link.exe')})
    subprocess.run(['C:/Users/jackv/.cargo/bin/cargo.exe','build','--release','--manifest-path',str(work/'fast/Cargo.toml')],cwd=work,env=env,check=True)
    print('Built direct ABI candidate Rust library.');sys.exit()
    bridge=out/'win_clang_x64_for_rust_host_build_tools/cxxbridge.exe'
    source=root/'net/base/parse_number_ffi.rs'
    target=work/'include/net/base/parse_number_ffi.rs.h';target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(subprocess.check_output([str(bridge),str(source),'--header']))
    (work/'bridge.cc').write_bytes(subprocess.check_output([str(bridge),str(source)]))
    print('Built Chromium Rust static library and generated matching bridge.')
    sys.exit()

variables=dict(re.findall(r'^(\w+) = (.*)$',(out/'obj/net/net.ninja').read_text(),re.M))
template=(out/'toolchain.ninja').read_text().split('rule cxx\n',1)[1].splitlines()[0].strip().removeprefix('command = ')
def compile(source,name,bridge=False):
    values=dict(variables)
    if mode=='unit' and name in ('unit','unit_main','unit_old'):
        values=dict(re.findall(r'^(\w+) = (.*)$',(out/'obj/net/gzip_header_unittests.ninja').read_text(),re.M))
    values.update({'in':str(source),'source_name_part':name})
    command=re.sub(r'\$\{(\w+)\}',lambda m:values.get(m[1],''),template).replace('$:',':')
    command=command.replace('-I../.. ','-I'+str(work/'include')+' -I'+str(root)+' -I../.. ')
    command=re.sub(r'/Fo\S+',lambda _: '/Fo'+str(work/(name+'.obj')),command)
    command=re.sub(r'/Fd"[^"]+"',lambda _: '/Fd"'+str(work/(name+'.pdb'))+'"',command)
    if bridge:command+=' /FIthird_party/rust/cxx/v1/cxx.h'
    if mode=='unit':command+=' /DNET_IMPLEMENTATION'
    if mode=='fuzz':command+=' -fsanitize-coverage=inline-8bit-counters,pc-table,trace-cmp -fno-sanitize-link-runtime'
    compiler,args=command.split(' ',1);rsp=work/(name+'.rsp');rsp.write_text(args)
    result=subprocess.run([str((out/compiler).resolve()),'@'+str(rsp)],cwd=out,env=env,capture_output=True,text=True)
    (work/(name+'-compile.log')).write_text(result.stdout+result.stderr)
    if result.returncode:
        print('\n'.join(l for l in (result.stdout+result.stderr).splitlines() if 'including file:' not in l));result.check_returncode()

compile(work/'fast.cc','reader')
compile(root/'net/base/parse_number_test_support.cc','legacy')

source=root/'net/base'/('parse_number_perftest.cc' if mode=='bench' else 'parse_number_parser_unittest.cc' if mode=='unit' else 'parse_number_fuzzer.cc')
compile(source,mode)
if mode=='unit':
    compile(root/'net/base/parse_number_unittest.cc','unit_old')
    main=work/'unit_main.cc';main.write_text('#include "testing/gtest/include/gtest/gtest.h"\nextern "C" int __llvm_profile_write_file();\nint main(int argc,char** argv){::testing::InitGoogleTest(&argc,argv);int result=RUN_ALL_TESTS();__llvm_profile_write_file();return result;}\n')
    compile(main,'unit_main')
line=next(l for l in (out/'obj/net/net.ninja').read_text().splitlines() if l.startswith('build ./net.dll '))
dependencies=[]
for p in line.split(': solink ',1)[1].split(' | ',1)[0].split():
    if p.endswith(('.lib','.rlib')) and '/net/' not in p and not p.startswith('obj/net/'):
        dependencies.append(str((out/p).resolve()))
# Only the base/zlib support libraries are needed by these focused programs;
# keep the comparison independent of the production net.dll's exported parser.
dependencies=[str(out/'base.dll.lib'),str(out/'libc++.dll.lib'),*[str(out/('base_allocator_partition_allocator_src_partition_alloc_allocator_'+name+'.dll.lib')) for name in ('base','core','shim')],str(out/'base_allocator_partition_allocator_src_partition_alloc_raw_ptr.dll.lib')]
libraries=['advapi32.lib','userenv.lib','ws2_32.lib','bcrypt.lib','ntdll.lib','dbghelp.lib','synchronization.lib','shlwapi.lib','shell32.lib']
command=[str(full/'third_party/llvm-build/Release+Asserts/bin/lld-link.exe'),'/OUT:'+str(work/(mode+'.exe')),'/SUBSYSTEM:CONSOLE','/INCREMENTAL:NO',*[str(work/(n+'.obj')) for n in ('reader','legacy',mode)],str(work/('fast-coverage-target' if mode=='unit' else 'fast-target')/'release/protocol_number_validation.lib'),*dependencies,*libraries]
if mode=='unit':
    command += [str(work/'unit_main.obj'),str(work/'unit_old.obj'),*map(str,(out/'obj/third_party/googletest/gtest').glob('*.obj')),str(out/'third_party_abseil-cpp_absl.dll.lib'),str(out/'third_party_boringssl.dll.lib'),str(out/'obj/third_party/re2/re2.lib')]
    command += list(map(str,(full/'third_party/rust-toolchain/lib/rustlib/x86_64-pc-windows-msvc/lib').glob('libprofiler_builtins-*.rlib')))
for directory in ['C:/Program Files (x86)/Microsoft Visual Studio/2022/BuildTools/VC/Tools/MSVC/14.44.35207/lib/x64','C:/Program Files (x86)/Windows Kits/10/Lib/10.0.26100.0/um/x64','C:/Program Files (x86)/Windows Kits/10/Lib/10.0.26100.0/ucrt/x64']:
    command.append('/LIBPATH:'+directory)
if mode=='fuzz':
    command.append('/NODEFAULTLIB:clang_rt.ubsan_standalone-x86_64.lib')
    runtime=full/'third_party/llvm-build/Release+Asserts/lib/clang/24/lib/windows'
    command.extend([str(runtime/'clang_rt.ubsan_standalone-x86_64.lib'),str(runtime/'clang_rt.ubsan_standalone_cxx-x86_64.lib')])
    command.extend(map(str,(root/'.scratch/data-pack/fuzzer-engine').glob('*.obj')))
result=subprocess.run(command,cwd=out,env=env,capture_output=True,text=True)
(work/(mode+'-link.log')).write_text(result.stdout+result.stderr);print(result.stdout,result.stderr);result.check_returncode()
print('Built',mode)
